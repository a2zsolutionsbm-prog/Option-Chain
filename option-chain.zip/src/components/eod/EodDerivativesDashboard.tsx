import React, { useState, useMemo, useEffect, useCallback } from 'react';
import {
  AlertCircle,
  ArrowRight,
  BarChart2,
  Calendar,
  CheckCircle2,
  Clock,
  Download,
  FileSpreadsheet,
  LayoutDashboard,
  PieChart as PieChartIcon,
  RefreshCw,
  Table2,
  Trash2,
  TrendingDown,
  TrendingUp,
  Upload,
} from 'lucide-react';
import {
  BanStockRow,
  BhavcopyRecord,
  buildComparisonFromTwoDays,
  EodActivityRow,
  fetchNseParticipantOiByDate,
  FiiStatsRow,
  formatIsoDateDisplay,
  NseParticipantOiMatrixRow,
  parseSingleDayCsvToRows,
  SingleDayParticipantRow,
} from './eodComparisonEngine';

export type {
  EodActivityRow,
  NseParticipantOiMatrixRow,
  BhavcopyRecord,
  FiiStatsRow,
  BanStockRow,
};

export type EodSubTab = 'DASHBOARD' | 'NSE_OI_DATA';

interface EodDerivativesDashboardProps {
  activeSubTab?: EodSubTab;
  onSubTabChange?: (tab: EodSubTab) => void;
}

function describeArc(
  x: number,
  y: number,
  radius: number,
  startAngle: number,
  endAngle: number
): string {
  const rad = (deg: number) => ((deg - 90) * Math.PI) / 180.0;
  const start = {
    x: x + radius * Math.cos(rad(endAngle)),
    y: y + radius * Math.sin(rad(endAngle)),
  };
  const end = {
    x: x + radius * Math.cos(rad(startAngle)),
    y: y + radius * Math.sin(rad(startAngle)),
  };
  const largeArcFlag = endAngle - startAngle <= 180 ? '0' : '1';
  return ['M', start.x, start.y, 'A', radius, radius, 0, largeArcFlag, 0, end.x, end.y].join(' ');
}

interface IstClockState {
  istTimeStr: string;
  istDateKey: string;
  istDisplayDate: string;
  isPast8PmIst: boolean;
  countdownTo8PmStr: string;
}

function getIstClockState(now: Date = new Date()): IstClockState {
  const utcMs = now.getTime() + now.getTimezoneOffset() * 60000;
  const istDate = new Date(utcMs + 330 * 60000);

  const year = istDate.getFullYear();
  const monthIdx = istDate.getMonth();
  const day = istDate.getDate();
  const hours = istDate.getHours();
  const minutes = istDate.getMinutes();
  const seconds = istDate.getSeconds();

  const istDateKey = `${year}-${String(monthIdx + 1).padStart(2, '0')}-${String(day).padStart(
    2,
    '0'
  )}`;
  const istDisplayDate = formatIsoDateDisplay(istDateKey);

  const ampm = hours >= 12 ? 'PM' : 'AM';
  const hour12 = hours % 12 === 0 ? 12 : hours % 12;
  const istTimeStr = `${String(hour12).padStart(2, '0')}:${String(minutes).padStart(
    2,
    '0'
  )}:${String(seconds).padStart(2, '0')} ${ampm} IST`;

  const isPast8PmIst = hours >= 20;

  const targetIst = new Date(istDate.getTime());
  targetIst.setHours(20, 0, 0, 0);
  if (istDate.getTime() >= targetIst.getTime()) {
    targetIst.setDate(targetIst.getDate() + 1);
  }

  const diffSec = Math.max(0, Math.floor((targetIst.getTime() - istDate.getTime()) / 1000));
  const remH = Math.floor(diffSec / 3600);
  const remM = Math.floor((diffSec % 3600) / 60);
  const remS = diffSec % 60;
  const countdownTo8PmStr = `${String(remH).padStart(2, '0')}h ${String(remM).padStart(
    2,
    '0'
  )}m ${String(remS).padStart(2, '0')}s`;

  return {
    istTimeStr,
    istDateKey,
    istDisplayDate,
    isPast8PmIst,
    countdownTo8PmStr,
  };
}

const DEFAULT_PARTICIPANT_CLIENT_TYPES: Array<{
  key: SingleDayParticipantRow['clientType'];
  displayLabel: string;
}> = [
  { key: 'Client (Retail)', displayLabel: 'Client' },
  { key: 'DII', displayLabel: 'DII' },
  { key: 'FII', displayLabel: 'FII' },
  { key: 'Pro', displayLabel: 'Pro' },
];

const EMPTY_SUMMARY_TEMPLATE: Array<{
  participant: EodActivityRow['participant'];
  segment: EodActivityRow['segment'];
}> = [
  { participant: 'RETAIL TRADERS', segment: 'CALLS' },
  { participant: 'RETAIL TRADERS', segment: 'PUTS' },
  { participant: 'RETAIL TRADERS', segment: 'FUTURES' },
  { participant: 'DII TRADERS', segment: 'CALLS' },
  { participant: 'DII TRADERS', segment: 'PUTS' },
  { participant: 'DII TRADERS', segment: 'FUTURES' },
  { participant: 'FII TRADERS', segment: 'CALLS' },
  { participant: 'FII TRADERS', segment: 'PUTS' },
  { participant: 'FII TRADERS', segment: 'FUTURES' },
  { participant: 'PRO TRADERS', segment: 'CALLS' },
  { participant: 'PRO TRADERS', segment: 'PUTS' },
  { participant: 'PRO TRADERS', segment: 'FUTURES' },
];

export const EodDerivativesDashboard: React.FC<EodDerivativesDashboardProps> = ({
  activeSubTab: controlledSubTab,
  onSubTabChange,
}) => {
  const [internalSubTab, setInternalSubTab] = useState<EodSubTab>('DASHBOARD');
  const currentTab: EodSubTab = controlledSubTab ?? internalSubTab;

  const handleSelectSubTab = (tab: EodSubTab) => {
    setInternalSubTab(tab);
    onSubTabChange?.(tab);
  };

  const [istClock, setIstClock] = useState<IstClockState>(() => getIstClockState());

  // User-selected Yesterday Date (T-1) and Today Date (T)
  const [yesterdayDate, setYesterdayDate] = useState<string>('');
  const [todayDate, setTodayDate] = useState<string>('');

  // Two-Part Data State: Starts empty until user clicks "Get Data" or uploads CSVs
  const [yesterdayRows, setYesterdayRows] = useState<SingleDayParticipantRow[] | null>(null);
  const [todayRows, setTodayRows] = useState<SingleDayParticipantRow[] | null>(null);
  const [yesterdaySourceLabel, setYesterdaySourceLabel] = useState<string>('');
  const [todaySourceLabel, setTodaySourceLabel] = useState<string>('');

  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [statusMessage, setStatusMessage] = useState<string | null>(null);
  const [participantFilter, setParticipantFilter] = useState<string>('ALL');
  const [barChartMode, setBarChartMode] = useState<'DOD_CHANGE' | 'PREV_VS_CURR'>('DOD_CHANGE');
  const [autoRefresh8Pm, setAutoRefresh8Pm] = useState<boolean>(true);
  const [lastAutoSyncKey, setLastAutoSyncKey] = useState<string>('');

  // Clear any legacy localStorage pre-populated EOD data on mount
  useEffect(() => {
    try {
      localStorage.removeItem('ds_nse_eod_summary_rows_v2');
    } catch {
      // ignore
    }
  }, []);

  // Core handler: Fetch Yesterday Data and Today Data when user clicks "Get Data"
  const handleGetData = useCallback(
    async (customYesterday?: string, customToday?: string) => {
      const yDate = (customYesterday ?? yesterdayDate).trim();
      const tDate = (customToday ?? todayDate).trim();

      setErrorMessage(null);
      setStatusMessage(null);

      if (!yDate || !tDate) {
        setYesterdayRows(null);
        setTodayRows(null);
        setErrorMessage(
          'Error: Please select both Yesterday Date and Today Date before clicking Get Data.'
        );
        return;
      }

      if (yDate === tDate) {
        setYesterdayRows(null);
        setTodayRows(null);
        setErrorMessage(
          'Error: Yesterday Date and Today Date cannot be the same date. Please select two distinct dates.'
        );
        return;
      }

      if (yDate > tDate) {
        setYesterdayRows(null);
        setTodayRows(null);
        setErrorMessage('Error: Yesterday Date must be earlier than Today Date.');
        return;
      }

      setIsLoading(true);
      const currentIst = getIstClockState();

      const [yesterdayResult, todayResult] = await Promise.all([
        fetchNseParticipantOiByDate(yDate, currentIst.istDateKey, currentIst.isPast8PmIst),
        fetchNseParticipantOiByDate(tDate, currentIst.istDateKey, currentIst.isPast8PmIst),
      ]);

      setIsLoading(false);

      // If either Yesterday Data or Today Data is not available, show error and do not render stale data
      if (!yesterdayResult.ok || !todayResult.ok) {
        const errors: string[] = [];
        if (!todayResult.ok && todayResult.error) {
          errors.push(`Today Date (${formatIsoDateDisplay(tDate)}): ${todayResult.error}`);
        }
        if (!yesterdayResult.ok && yesterdayResult.error) {
          errors.push(`Yesterday Date (${formatIsoDateDisplay(yDate)}): ${yesterdayResult.error}`);
        }
        setYesterdayRows(null);
        setTodayRows(null);
        setErrorMessage(errors.join(' | '));
        return;
      }

      if (yesterdayResult.rows && todayResult.rows) {
        setYesterdayRows(yesterdayResult.rows);
        setTodayRows(todayResult.rows);
        setYesterdaySourceLabel(formatIsoDateDisplay(yDate));
        setTodaySourceLabel(formatIsoDateDisplay(tDate));
        setStatusMessage(
          `Loaded Today Data (${formatIsoDateDisplay(tDate)}) and Yesterday Data (${formatIsoDateDisplay(
            yDate
          )}) — Dashboard Charts, View Table, and Part 1 & Part 2 NSE Participant OI tables updated.`
        );
      }
    },
    [yesterdayDate, todayDate]
  );

  // Live IST Clock & Automatic 8:00 PM IST Post-Market Trigger (only when dates are selected)
  useEffect(() => {
    const tick = () => {
      const currentIst = getIstClockState();
      setIstClock(currentIst);

      if (
        autoRefresh8Pm &&
        currentIst.isPast8PmIst &&
        lastAutoSyncKey !== currentIst.istDateKey &&
        yesterdayDate &&
        todayDate
      ) {
        setLastAutoSyncKey(currentIst.istDateKey);
        handleGetData(yesterdayDate, todayDate);
      }
    };

    tick();
    const timerId = window.setInterval(tick, 1000);
    return () => window.clearInterval(timerId);
  }, [autoRefresh8Pm, lastAutoSyncKey, yesterdayDate, todayDate, handleGetData]);

  // Manual CSV Upload for Yesterday Data or Today Data
  const handleManualFileUpload = (
    target: 'YESTERDAY' | 'TODAY',
    e: React.ChangeEvent<HTMLInputElement>
  ) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setErrorMessage(null);
    setStatusMessage(null);

    const reader = new FileReader();
    reader.onload = (ev) => {
      const text = String(ev.target?.result || '');
      const parsed = parseSingleDayCsvToRows(text);
      if (!parsed) {
        setErrorMessage(
          `Error: Could not parse valid NSE Participant OI data from "${file.name}". Please upload a valid NSE Participant Wise Open Interest CSV file.`
        );
        e.target.value = '';
        return;
      }

      if (target === 'YESTERDAY') {
        setYesterdayRows(parsed);
        const label = yesterdayDate
          ? `${formatIsoDateDisplay(yesterdayDate)} (${file.name})`
          : file.name;
        setYesterdaySourceLabel(label);
        setStatusMessage(
          `Uploaded Yesterday Data from "${file.name}". ${
            todayRows ? 'Comparison & Views updated.' : 'Now upload or fetch Today Data.'
          }`
        );
      } else {
        setTodayRows(parsed);
        const label = todayDate ? `${formatIsoDateDisplay(todayDate)} (${file.name})` : file.name;
        setTodaySourceLabel(label);
        setStatusMessage(
          `Uploaded Today Data from "${file.name}". ${
            yesterdayRows ? 'Comparison & Views updated.' : 'Now upload or fetch Yesterday Data.'
          }`
        );
      }
      e.target.value = '';
    };
    reader.readAsText(file);
  };

  // Clear all EOD data back to empty state
  const handleClearAllData = () => {
    setYesterdayDate('');
    setTodayDate('');
    setYesterdayRows(null);
    setTodayRows(null);
    setYesterdaySourceLabel('');
    setTodaySourceLabel('');
    setErrorMessage(null);
    setStatusMessage(null);
  };

  // Derived Comparison Data (only computed when BOTH Today Data and Yesterday Data exist)
  const bothPartsAvailable = Boolean(
    yesterdayRows && yesterdayRows.length > 0 && todayRows && todayRows.length > 0
  );

  const { summaryRows, participantMatrix } = useMemo(() => {
    if (!yesterdayRows || !todayRows || yesterdayRows.length === 0 || todayRows.length === 0) {
      return {
        summaryRows: [] as EodActivityRow[],
        participantMatrix: [] as NseParticipantOiMatrixRow[],
      };
    }
    const result = buildComparisonFromTwoDays(yesterdayRows, todayRows);
    return {
      summaryRows: result?.summaryRows ?? [],
      participantMatrix: result?.matrixRows ?? [],
    };
  }, [yesterdayRows, todayRows]);

  const bullishSignals = useMemo(
    () => (summaryRows || []).filter((r) => r.view === 'BULLISH').length,
    [summaryRows]
  );
  const bearishSignals = useMemo(
    () => (summaryRows || []).filter((r) => r.view === 'BEARISH').length,
    [summaryRows]
  );
  const prevBullishSignals = useMemo(
    () => (summaryRows || []).filter((r) => r.prevDayView === 'BULLISH').length,
    [summaryRows]
  );
  const prevBearishSignals = useMemo(
    () => (summaryRows || []).filter((r) => r.prevDayView === 'BEARISH').length,
    [summaryRows]
  );

  const totalBullishVolume = useMemo(
    () =>
      (summaryRows || [])
        .filter((r) => r.view === 'BULLISH')
        .reduce((acc, r) => acc + Math.abs(r.directionalImpact), 0),
    [summaryRows]
  );
  const totalBearishVolume = useMemo(
    () =>
      (summaryRows || [])
        .filter((r) => r.view === 'BEARISH')
        .reduce((acc, r) => acc + Math.abs(r.directionalImpact), 0),
    [summaryRows]
  );

  const filteredSummaryRows = useMemo(() => {
    const list = summaryRows || [];
    if (participantFilter === 'ALL') return list;
    return list.filter((r) => r.participant === participantFilter);
  }, [summaryRows, participantFilter]);

  const filteredEmptyTemplateRows = useMemo(() => {
    if (participantFilter === 'ALL') return EMPTY_SUMMARY_TEMPLATE;
    return EMPTY_SUMMARY_TEMPLATE.filter((r) => r.participant === participantFilter);
  }, [participantFilter]);

  const maxAbsChange = useMemo(() => {
    if (!summaryRows || summaryRows.length === 0) return 1;
    return Math.max(...summaryRows.map((r) => Math.abs(r.netChanges)), 1);
  }, [summaryRows]);

  const participantShareData = useMemo(() => {
    const colors = ['#2563EB', '#F59E0B', '#16A34A', '#0891B2'];
    if (!participantMatrix || participantMatrix.length === 0) {
      return DEFAULT_PARTICIPANT_CLIENT_TYPES.map((item, i) => ({
        label: item.key,
        pct: 0,
        color: colors[i % colors.length],
        startAngle: i * 90,
        endAngle: (i + 1) * 90 - 0.01,
      }));
    }
    const totalCurr = Math.max(
      1,
      participantMatrix.reduce((acc, r) => acc + r.totalLong + r.totalShort, 0)
    );
    let angleCursor = 0;
    return participantMatrix.map((r, i) => {
      const grossCurr = r.totalLong + r.totalShort;
      const pct = (grossCurr / totalCurr) * 100;
      const sweep = (pct / 100) * 359.99;
      const startAngle = angleCursor;
      const endAngle = angleCursor + sweep;
      angleCursor = endAngle;
      return {
        label: r.clientType,
        pct,
        color: colors[i % colors.length],
        startAngle,
        endAngle,
      };
    });
  }, [participantMatrix]);

  const handleExportComparisonCsv = () => {
    if (!bothPartsAvailable) return;
    const lines = [
      'FII, DII, PRO & RETAIL TRADER OPEN INTEREST DATA (TODAY vs YESTERDAY COMPARISON)',
      `Yesterday Date:,${yesterdaySourceLabel},Today Date:,${todaySourceLabel}`,
      'PARTICIPANT,SEGMENT,YESTERDAY NET OI,TODAY NET OI,NET ACTIVITY,NET CHANGES (TODAY - YESTERDAY),VIEW,DIRECTIONAL IMPACT',
    ];
    summaryRows.forEach((r) => {
      lines.push(
        `${r.participant},${r.segment},${r.prevDayNetOi},${r.currDayNetOi},${r.netActivity},${r.netChanges},${r.view},${r.directionalImpact}`
      );
    });
    const blob = new Blob([lines.join('\n')], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `EOD_Today_vs_Yesterday_Comparison.csv`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  // Helper to render a single day's NSE Participant OI Table (Part 1: Today Data & Part 2: Yesterday Data)
  // Heading columns AND Client Type rows (Client, DII, FII, Pro, TOTAL) are ALWAYS visible even before data is loaded!
  const renderSingleDayTable = (
    partTitle: string,
    dateLabel: string,
    badgeText: string,
    headerBgClass: string,
    accentTextClass: string,
    rows: SingleDayParticipantRow[] | null
  ) => {
    const hasData = Boolean(rows && rows.length > 0);
    const totals = hasData
      ? rows!.reduce(
          (acc, r) => ({
            futIdxLong: acc.futIdxLong + r.futIdxLong,
            futIdxShort: acc.futIdxShort + r.futIdxShort,
            futStkLong: acc.futStkLong + r.futStkLong,
            futStkShort: acc.futStkShort + r.futStkShort,
            optIdxCallLong: acc.optIdxCallLong + r.optIdxCallLong,
            optIdxPutLong: acc.optIdxPutLong + r.optIdxPutLong,
            optIdxCallShort: acc.optIdxCallShort + r.optIdxCallShort,
            optIdxPutShort: acc.optIdxPutShort + r.optIdxPutShort,
            optStkCallLong: acc.optStkCallLong + r.optStkCallLong,
            optStkPutLong: acc.optStkPutLong + r.optStkPutLong,
            optStkCallShort: acc.optStkCallShort + r.optStkCallShort,
            optStkPutShort: acc.optStkPutShort + r.optStkPutShort,
            totalLong: acc.totalLong + r.totalLong,
            totalShort: acc.totalShort + r.totalShort,
          }),
          {
            futIdxLong: 0,
            futIdxShort: 0,
            futStkLong: 0,
            futStkShort: 0,
            optIdxCallLong: 0,
            optIdxPutLong: 0,
            optIdxCallShort: 0,
            optIdxPutShort: 0,
            optStkCallLong: 0,
            optStkPutLong: 0,
            optStkCallShort: 0,
            optStkPutShort: 0,
            totalLong: 0,
            totalShort: 0,
          }
        )
      : null;

    const fmt = (n: number | undefined) => (n !== undefined ? n.toLocaleString('en-IN') : '—');

    const getRowTheme = (clientKey: SingleDayParticipantRow['clientType']) => {
      switch (clientKey) {
        case 'Client (Retail)':
          return {
            stickyBg: 'bg-[#F4F8FD]',
            leftAccent: 'border-l-4 border-l-[#2563EB]',
            labelText: 'text-[#0F172A] font-bold',
            cellBg: 'bg-[#F8FAFC]',
            cellText: 'text-[#1E293B] font-semibold',
          };
        case 'DII':
          return {
            stickyBg: 'bg-[#E6FBF0]',
            leftAccent: 'border-l-4 border-l-[#10B981]',
            labelText: 'text-[#065F46] font-bold',
            cellBg: 'bg-[#ECFDF5]',
            cellText: 'text-[#0F172A] font-bold',
          };
        case 'FII':
          return {
            stickyBg: 'bg-[#E5F0FF]',
            leftAccent: 'border-l-4 border-l-[#2563EB]',
            labelText: 'text-[#0F172A] font-bold',
            cellBg: 'bg-[#EFF6FF]',
            cellText: 'text-[#1E293B] font-bold',
          };
        case 'Pro':
          return {
            stickyBg: 'bg-[#FFF3D6]',
            leftAccent: 'border-l-4 border-l-[#F97316]',
            labelText: 'text-[#0F172A] font-bold',
            cellBg: 'bg-[#FEF3C7]/80',
            cellText: 'text-[#1E293B] font-semibold',
          };
      }
    };

    return (
      <div className="bg-[#FFFFFF] border border-[#BFDBFE] rounded-[12px] shadow-[0_1px_3px_rgba(0,0,0,0.06)] overflow-hidden">
        {/* Centered Table Title & Date Banner */}
        <div
          className={`px-4 py-2.5 border-b border-[#BFDBFE] flex flex-col items-center justify-center text-center relative ${headerBgClass}`}
        >
          <div className="flex items-center justify-center gap-2 flex-wrap">
            <span className={`text-xs sm:text-sm font-bold uppercase tracking-wide ${accentTextClass}`}>
              {partTitle}
            </span>
            <span className="px-2.5 py-0.5 rounded text-[10.5px] font-bold bg-[#FFFFFF] border border-[#BFDBFE] text-[#1E40AF] shadow-2xs">
              {badgeText}
            </span>
          </div>
          <div className="text-[11px] text-[#334155] font-medium mt-0.5 text-center">
            Participant wise Open Interest (no. of contracts) in Equity Derivatives as on{' '}
            <strong className="text-[#0F172A]">
              {dateLabel || 'Select Date & Click Get Data'}
            </strong>
          </div>
        </div>

        {/* Always-Visible 15-Column Official NSE Table (Styled per Reference Image) */}
        <div className="overflow-x-auto">
          <table className="w-full border-collapse text-[11.5px] font-mono-num">
            <thead className="sticky top-0 z-20">
              <tr className="bg-[#DCEBFE] border-b border-[#BFDBFE] text-[#1E40AF] text-[11px]">
                <th className="sticky left-0 z-20 bg-[#DCEBFE] py-2.5 px-3 text-left font-bold border-r border-[#BFDBFE] min-w-[86px]">
                  Client Type
                </th>
                <th className="py-2 px-1.5 text-center font-bold border-r border-[#BFDBFE] leading-tight">
                  Future Index Long
                </th>
                <th className="py-2 px-1.5 text-center font-bold border-r border-[#BFDBFE] leading-tight">
                  Future Index Short
                </th>
                <th className="py-2 px-1.5 text-center font-bold border-r border-[#BFDBFE] leading-tight">
                  Future Stock Long
                </th>
                <th className="py-2 px-1.5 text-center font-bold border-r border-[#BFDBFE] leading-tight">
                  Future Stock Short
                </th>
                <th className="py-2 px-1.5 text-center font-bold border-r border-[#BFDBFE] leading-tight">
                  Option Index Call Long
                </th>
                <th className="py-2 px-1.5 text-center font-bold border-r border-[#BFDBFE] leading-tight">
                  Option Index Put Long
                </th>
                <th className="py-2 px-1.5 text-center font-bold border-r border-[#BFDBFE] leading-tight">
                  Option Index Call Short
                </th>
                <th className="py-2 px-1.5 text-center font-bold border-r border-[#BFDBFE] leading-tight">
                  Option Index Put Short
                </th>
                <th className="py-2 px-1.5 text-center font-bold border-r border-[#BFDBFE] leading-tight">
                  Option Stock Call Long
                </th>
                <th className="py-2 px-1.5 text-center font-bold border-r border-[#BFDBFE] leading-tight">
                  Option Stock Put Long
                </th>
                <th className="py-2 px-1.5 text-center font-bold border-r border-[#BFDBFE] leading-tight">
                  Option Stock Call Short
                </th>
                <th className="py-2 px-1.5 text-center font-bold border-r border-[#BFDBFE] leading-tight">
                  Option Stock Put Short
                </th>
                <th className="py-2 px-1.5 text-center font-bold text-[#1E40AF] border-r border-[#BFDBFE] leading-tight bg-[#DCEBFE]">
                  Total Long Contracts
                </th>
                <th className="py-2 px-1.5 text-center font-bold text-[#1E40AF] leading-tight bg-[#DCEBFE]">
                  Total Short Contracts
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#CBD5E1]">
              {DEFAULT_PARTICIPANT_CLIENT_TYPES.map(({ key, displayLabel }) => {
                const rowData = hasData ? rows!.find((r) => r.clientType === key) : undefined;
                const rowTheme = getRowTheme(key);
                return (
                  <tr key={key} className="transition-colors">
                    <td
                      className={`sticky left-0 z-10 py-2.5 px-3 font-sans text-xs border-r border-[#CBD5E1] whitespace-nowrap ${rowTheme.stickyBg} ${rowTheme.leftAccent} ${rowTheme.labelText}`}
                    >
                      {displayLabel}
                    </td>
                    <td
                      className={`py-2.5 px-2 text-center border-r border-[#CBD5E1]/80 ${rowTheme.cellBg} ${rowTheme.cellText}`}
                    >
                      {fmt(rowData?.futIdxLong)}
                    </td>
                    <td
                      className={`py-2.5 px-2 text-center border-r border-[#CBD5E1]/80 ${rowTheme.cellBg} ${rowTheme.cellText}`}
                    >
                      {fmt(rowData?.futIdxShort)}
                    </td>
                    <td
                      className={`py-2.5 px-2 text-center border-r border-[#CBD5E1]/80 ${rowTheme.cellBg} ${rowTheme.cellText}`}
                    >
                      {fmt(rowData?.futStkLong)}
                    </td>
                    <td
                      className={`py-2.5 px-2 text-center border-r border-[#CBD5E1]/80 ${rowTheme.cellBg} ${rowTheme.cellText}`}
                    >
                      {fmt(rowData?.futStkShort)}
                    </td>
                    <td
                      className={`py-2.5 px-2 text-center border-r border-[#CBD5E1]/80 ${rowTheme.cellBg} ${rowTheme.cellText}`}
                    >
                      {fmt(rowData?.optIdxCallLong)}
                    </td>
                    <td
                      className={`py-2.5 px-2 text-center border-r border-[#CBD5E1]/80 ${rowTheme.cellBg} ${rowTheme.cellText}`}
                    >
                      {fmt(rowData?.optIdxPutLong)}
                    </td>
                    <td
                      className={`py-2.5 px-2 text-center border-r border-[#CBD5E1]/80 ${rowTheme.cellBg} ${rowTheme.cellText}`}
                    >
                      {fmt(rowData?.optIdxCallShort)}
                    </td>
                    <td
                      className={`py-2.5 px-2 text-center border-r border-[#CBD5E1]/80 ${rowTheme.cellBg} ${rowTheme.cellText}`}
                    >
                      {fmt(rowData?.optIdxPutShort)}
                    </td>
                    <td
                      className={`py-2.5 px-2 text-center border-r border-[#CBD5E1]/80 ${rowTheme.cellBg} ${rowTheme.cellText}`}
                    >
                      {fmt(rowData?.optStkCallLong)}
                    </td>
                    <td
                      className={`py-2.5 px-2 text-center border-r border-[#CBD5E1]/80 ${rowTheme.cellBg} ${rowTheme.cellText}`}
                    >
                      {fmt(rowData?.optStkPutLong)}
                    </td>
                    <td
                      className={`py-2.5 px-2 text-center border-r border-[#CBD5E1]/80 ${rowTheme.cellBg} ${rowTheme.cellText}`}
                    >
                      {fmt(rowData?.optStkCallShort)}
                    </td>
                    <td
                      className={`py-2.5 px-2 text-center border-r border-[#CBD5E1]/80 ${rowTheme.cellBg} ${rowTheme.cellText}`}
                    >
                      {fmt(rowData?.optStkPutShort)}
                    </td>
                    <td className="py-2.5 px-2 text-center font-bold text-[#15803D] bg-[#DCFCE7] border-r border-[#BBF7D0]">
                      {fmt(rowData?.totalLong)}
                    </td>
                    <td className="py-2.5 px-2 text-center font-bold text-[#E11D48] bg-[#FEE2E2]">
                      {fmt(rowData?.totalShort)}
                    </td>
                  </tr>
                );
              })}
            </tbody>
            <tfoot>
              <tr className="bg-[#0A2351] border-t-2 border-[#1E3A8A] font-bold text-white">
                <td className="sticky left-0 z-10 bg-[#0A2351] py-2.5 px-3 font-sans font-bold text-white border-r border-[#1E3A8A]">
                  TOTAL
                </td>
                <td className="py-2.5 px-2 text-center text-white border-r border-[#1E3A8A]">
                  {fmt(totals?.futIdxLong)}
                </td>
                <td className="py-2.5 px-2 text-center text-white border-r border-[#1E3A8A]">
                  {fmt(totals?.futIdxShort)}
                </td>
                <td className="py-2.5 px-2 text-center text-white border-r border-[#1E3A8A]">
                  {fmt(totals?.futStkLong)}
                </td>
                <td className="py-2.5 px-2 text-center text-white border-r border-[#1E3A8A]">
                  {fmt(totals?.futStkShort)}
                </td>
                <td className="py-2.5 px-2 text-center text-white border-r border-[#1E3A8A]">
                  {fmt(totals?.optIdxCallLong)}
                </td>
                <td className="py-2.5 px-2 text-center text-white border-r border-[#1E3A8A]">
                  {fmt(totals?.optIdxPutLong)}
                </td>
                <td className="py-2.5 px-2 text-center text-white border-r border-[#1E3A8A]">
                  {fmt(totals?.optIdxCallShort)}
                </td>
                <td className="py-2.5 px-2 text-center text-white border-r border-[#1E3A8A]">
                  {fmt(totals?.optIdxPutShort)}
                </td>
                <td className="py-2.5 px-2 text-center text-white border-r border-[#1E3A8A]">
                  {fmt(totals?.optStkCallLong)}
                </td>
                <td className="py-2.5 px-2 text-center text-white border-r border-[#1E3A8A]">
                  {fmt(totals?.optStkPutLong)}
                </td>
                <td className="py-2.5 px-2 text-center text-white border-r border-[#1E3A8A]">
                  {fmt(totals?.optStkCallShort)}
                </td>
                <td className="py-2.5 px-2 text-center text-white border-r border-[#1E3A8A]">
                  {fmt(totals?.optStkPutShort)}
                </td>
                <td className="py-2.5 px-2 text-center font-bold text-white bg-[#0A2351] border-r border-[#1E3A8A]">
                  {fmt(totals?.totalLong)}
                </td>
                <td className="py-2.5 px-2 text-center font-bold text-white bg-[#0A2351]">
                  {fmt(totals?.totalShort)}
                </td>
              </tr>
            </tfoot>
          </table>
        </div>
      </div>
    );
  };

  return (
    <div className="flex-1 overflow-y-auto bg-[#F8FAFC] p-3 xl:p-4 space-y-3.5 text-xs select-none">
      {/* =================================================================
          CLEAN TOP NAVIGATION TAB BAR: ONLY TWO TABS
          1. Dashboard
          2. NSE Participant Open Interest Data
         ================================================================= */}
      <div className="bg-[#FFFFFF] border border-[#E2E8F0] rounded-[12px] px-3.5 py-2.5 shadow-[0_1px_3px_rgba(0,0,0,0.05)] flex items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <button
            onClick={() => handleSelectSubTab('DASHBOARD')}
            className={`h-[36px] px-4 rounded-[8px] font-bold text-xs flex items-center gap-2 transition-colors cursor-pointer ${
              currentTab === 'DASHBOARD'
                ? 'bg-[#2563EB] text-white shadow-xs'
                : 'bg-[#F8FAFC] border border-[#E2E8F0] text-[#475569] hover:text-[#0F172A] hover:bg-[#F1F5F9]'
            }`}
          >
            <LayoutDashboard className="w-4 h-4" />
            <span>Dashboard</span>
          </button>

          <button
            onClick={() => handleSelectSubTab('NSE_OI_DATA')}
            className={`h-[36px] px-4 rounded-[8px] font-bold text-xs flex items-center gap-2 transition-colors cursor-pointer ${
              currentTab === 'NSE_OI_DATA'
                ? 'bg-[#2563EB] text-white shadow-xs'
                : 'bg-[#F8FAFC] border border-[#E2E8F0] text-[#475569] hover:text-[#0F172A] hover:bg-[#F1F5F9]'
            }`}
          >
            <Table2 className="w-4 h-4" />
            <span>NSE Participant Open Interest Data</span>
          </button>
        </div>
      </div>

      {/* =================================================================
          TAB 1: DASHBOARD (PIE CHART + BAR CHART + VIEW TODAY & YESTERDAY DATA)
         ================================================================= */}
      {currentTab === 'DASHBOARD' && (
        <div className="space-y-3.5">

          {/* VISUAL ANALYTICS ROW: SUMMARY & OVERALL SENTIMENT TABLE + PARTICIPANT OI BAR CHART */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-3.5 items-stretch">
            {/* LEFT COLUMN (6 Cols): SUMMARY / NET ACTIVITY / NET CHANGES / VIEWS + OVERALL SENTIMENT */}
            <div className="lg:col-span-6 rounded-[10px] overflow-hidden border border-[#1E3A5F] bg-[#0B1320] shadow-[0_2px_6px_rgba(0,0,0,0.12)] flex flex-col justify-between">
              <div className="overflow-x-auto flex-1 flex flex-col justify-between">
                <table className="w-full border-collapse text-xs">
                  <thead>
                    <tr className="bg-[#9CC3E5] text-[#1B365D] border-b-2 border-[#0B1320] text-[12px] font-bold uppercase tracking-wide">
                      <th className="py-2.5 px-3 text-center border-r border-[#2C5282] w-[28%]">
                        SUMMARY
                      </th>
                      <th className="py-2.5 px-3 text-center border-r border-[#2C5282] w-[30%]">
                        NET ACTIVITY
                      </th>
                      <th className="py-2.5 px-3 text-center border-r border-[#2C5282] w-[22%]">
                        NET CHANGES
                      </th>
                      <th className="py-2.5 px-3 text-center w-[20%]">
                        VIEWS
                      </th>
                    </tr>
                  </thead>
                  <tbody>
                    {(
                      [
                        'RETAIL TRADERS',
                        'DII TRADERS',
                        'FII TRADERS',
                        'PRO TRADERS',
                      ] as EodActivityRow['participant'][]
                    ).map((participantName, groupIdx) => {
                      const groupSegments: EodActivityRow['segment'][] = [
                        'CALLS',
                        'PUTS',
                        'FUTURES',
                      ];
                      return (
                        <React.Fragment key={participantName}>
                          {groupIdx > 0 && (
                            <tr className="bg-[#090F1B] h-[7px]">
                              <td colSpan={4} className="p-0 border-0" />
                            </tr>
                          )}
                          {groupSegments.map((seg, segIdx) => {
                            const rowData = bothPartsAvailable
                              ? summaryRows.find(
                                  (r) => r.participant === participantName && r.segment === seg
                                )
                              : undefined;
                            const isBullish = rowData?.view === 'BULLISH';
                            const isBearish = rowData?.view === 'BEARISH';

                            return (
                              <tr
                                key={`${participantName}_${seg}`}
                                className="border-b border-[#234975]"
                              >
                                {segIdx === 0 && (
                                  <td
                                    rowSpan={3}
                                    className="bg-[#113358] text-[#FFD700] font-bold text-center align-middle px-3 py-2 border-r border-[#234975] text-[12.5px] tracking-wide"
                                  >
                                    {participantName}
                                  </td>
                                )}
                                <td className="bg-[#113358] text-[#FFD700] font-bold text-center py-2 px-3 border-r border-[#234975] text-[12px] tracking-wide">
                                  {rowData ? rowData.netActivity : '—'}
                                </td>
                                <td className="bg-[#0F243C] text-[#FFD700] font-bold text-center py-2 px-3 border-r border-[#234975] font-mono-num text-[12.5px]">
                                  {rowData ? Math.abs(rowData.netChanges).toLocaleString('en-IN') : '—'}
                                </td>
                                <td
                                  className={`font-bold text-center py-2 px-3 text-[12px] tracking-wide ${
                                    isBullish
                                      ? 'bg-[#1E824C] text-white'
                                      : isBearish
                                      ? 'bg-[#C0392B] text-white'
                                      : 'bg-[#0F243C] text-[#94A3B8]'
                                  }`}
                                >
                                  {rowData ? rowData.view : '—'}
                                </td>
                              </tr>
                            );
                          })}
                        </React.Fragment>
                      );
                    })}
                  </tbody>
                </table>

                {/* OVERALL SENTIMENT FOOTER BLOCK */}
                <div className="mt-auto">
                  <div className="bg-[#070B12] py-2.5 px-4 text-center border-t-[6px] border-b border-[#0B1320]">
                    <span className="text-[#FFD700] font-bold text-[13px] tracking-wide">
                      ——— Overall Sentiment ———
                    </span>
                  </div>
                  <div className="bg-[#0E1B2E] py-3 px-4 grid grid-cols-4 items-center text-center">
                    <span className="text-[#2ECC71] font-serif font-bold text-sm sm:text-[15px]">
                      BULLISH Signals
                    </span>
                    <span className="text-[#2ECC71] font-bold text-sm sm:text-[15px] font-mono-num">
                      {bothPartsAvailable ? bullishSignals : '—'}
                    </span>
                    <span className="text-[#FF5252] font-serif font-bold text-sm sm:text-[15px]">
                      BEARISH Signals
                    </span>
                    <span className="text-[#FF5252] font-bold text-sm sm:text-[15px] font-mono-num">
                      {bothPartsAvailable ? bearishSignals : '—'}
                    </span>
                  </div>
                </div>
              </div>
            </div>

            {/* RIGHT COLUMN (6 Cols): FII DII FUTURE & OPTION NET OI CHANGE BAR CHART */}
            <div className="lg:col-span-6 rounded-[12px] border border-[#CBD5E1] bg-gradient-to-b from-[#FFFFFF] via-[#F8FAFC] to-[#E2E8F0] p-4 shadow-[0_2px_6px_rgba(0,0,0,0.06)] flex flex-col justify-between">
              <div className="flex items-center justify-between gap-2 pb-1">
                <div className="flex items-center gap-1.5 text-[11px] font-semibold text-[#475569]">
                  <BarChart2 className="w-4 h-4 text-[#16A34A]" />
                  <span>Participant OI Bar Chart (Calls • Puts • Futures)</span>
                </div>
                <div className="flex items-center gap-1 bg-white/90 border border-[#CBD5E1] p-0.5 rounded-[6px]">
                  <button
                    onClick={() => setBarChartMode('DOD_CHANGE')}
                    className={`px-2 py-0.5 rounded text-[10px] font-semibold cursor-pointer ${
                      barChartMode === 'DOD_CHANGE'
                        ? 'bg-[#2563EB] text-white'
                        : 'text-[#475569] hover:text-[#0F172A]'
                    }`}
                  >
                    Net OI Change (Today − Yesterday)
                  </button>
                  <button
                    onClick={() => setBarChartMode('PREV_VS_CURR')}
                    className={`px-2 py-0.5 rounded text-[10px] font-semibold cursor-pointer ${
                      barChartMode === 'PREV_VS_CURR'
                        ? 'bg-[#2563EB] text-white'
                        : 'text-[#475569] hover:text-[#0F172A]'
                    }`}
                  >
                    Yesterday vs Today
                  </button>
                </div>
              </div>

              <div className="w-full flex-1 flex items-center justify-center">
                {(() => {
                  const maxImpact = Math.max(
                    400000,
                    ...summaryRows.map((r) =>
                      Math.abs(
                        barChartMode === 'DOD_CHANGE' ? r.directionalImpact : r.currDayNetOi
                      )
                    )
                  );
                  const step = Math.max(100000, Math.ceil(maxImpact / 450000) * 100000);
                  const ticks = [
                    step * 4,
                    step * 3,
                    step * 2,
                    step * 1,
                    0,
                    -step * 1,
                    -step * 2,
                    -step * 3,
                    -step * 4,
                    -step * 5,
                  ];
                  const plotLeft = 86;
                  const plotRight = 752;
                  const plotWidth = plotRight - plotLeft;
                  const yZero = 190;
                  const pxPerStep = 30;

                  const participantsOrder: EodActivityRow['participant'][] = [
                    'RETAIL TRADERS',
                    'DII TRADERS',
                    'FII TRADERS',
                    'PRO TRADERS',
                  ];

                  return (
                    <svg viewBox="0 0 780 435" className="w-full h-auto max-h-[395px] select-none">
                      <text
                        x="400"
                        y="32"
                        textAnchor="middle"
                        fill="#333333"
                        fontSize="23"
                        fontWeight="700"
                      >
                        FII DII Future &amp; Option Net OI Change
                      </text>

                      {ticks.map((tickVal) => {
                        const yPos = yZero - (tickVal / step) * pxPerStep;
                        const isZero = tickVal === 0;
                        return (
                          <g key={tickVal}>
                            <line
                              x1={plotLeft}
                              y1={yPos}
                              x2={plotRight}
                              y2={yPos}
                              stroke={isZero ? '#1F2937' : '#D1D5DB'}
                              strokeWidth={isZero ? '2.2' : '0.9'}
                            />
                            <text
                              x={plotLeft - 12}
                              y={yPos + 4}
                              textAnchor="end"
                              fill="#4B5563"
                              fontSize="13"
                              fontWeight="500"
                            >
                              {tickVal}
                            </text>
                          </g>
                        );
                      })}

                      {summaryRows.map((row, idx) => {
                        const slotWidth = plotWidth / 12;
                        const centerX = plotLeft + (idx + 0.5) * slotWidth;
                        const barWidth = 23;
                        const val =
                          barChartMode === 'DOD_CHANGE' ? row.directionalImpact : row.currDayNetOi;
                        const prevVal = row.prevDayNetOi;

                        const barH = Math.max(2, (Math.abs(val) / step) * pxPerStep);
                        const barY = val >= 0 ? yZero - barH : yZero;
                        const barFill = val >= 0 ? '#12B850' : '#FF1A1A';

                        const prevBarH = Math.max(2, (Math.abs(prevVal) / step) * pxPerStep);
                        const prevBarY = prevVal >= 0 ? yZero - prevBarH : yZero;

                        const labelY = val >= 0 ? barY - 9 : barY + barH + 16;

                        return (
                          <g key={`${row.participant}_${row.segment}`}>
                            <title>
                              {`${row.participant} (${row.segment}): ${row.netActivity} | Net Change: ${val} | View: ${row.view}`}
                            </title>
                            {barChartMode === 'PREV_VS_CURR' ? (
                              <>
                                <rect
                                  x={centerX - 13}
                                  y={prevBarY}
                                  width="11"
                                  height={prevBarH}
                                  fill="#94A3B8"
                                  stroke="#334155"
                                  strokeWidth="1"
                                />
                                <rect
                                  x={centerX + 1}
                                  y={barY}
                                  width="12"
                                  height={barH}
                                  fill={barFill}
                                  stroke="#243046"
                                  strokeWidth="1.2"
                                />
                              </>
                            ) : (
                              <rect
                                x={centerX - barWidth / 2}
                                y={barY}
                                width={barWidth}
                                height={barH}
                                fill={barFill}
                                stroke="#243046"
                                strokeWidth="1.2"
                              />
                            )}

                            <text
                              x={centerX}
                              y={labelY}
                              textAnchor="middle"
                              fill="#262626"
                              fontSize="12.5"
                              fontWeight="500"
                            >
                              {val}
                            </text>
                          </g>
                        );
                      })}

                      {participantsOrder.map((partName, pIdx) => {
                        const slotWidth = plotWidth / 12;
                        const labelX = plotLeft + (pIdx * 3 + 0.65) * slotWidth;
                        const labelY = 358;
                        return (
                          <text
                            key={partName}
                            x={labelX}
                            y={labelY}
                            transform={`rotate(32, ${labelX}, ${labelY})`}
                            textAnchor="start"
                            fill="#374151"
                            fontSize="13"
                            fontWeight="600"
                            letterSpacing="0.3"
                          >
                            {partName}
                          </text>
                        );
                      })}
                    </svg>
                  );
                })()}
              </div>

              <div className="flex items-center justify-between flex-wrap gap-2 text-[10.5px] text-[#475569] bg-white/80 px-3 py-1.5 rounded-[8px] border border-[#CBD5E1]">
                <span>
                  Each participant group displays <strong>3 bars</strong> in order:{' '}
                  <strong>1. CALLS</strong> • <strong>2. PUTS</strong> • <strong>3. FUTURES</strong>
                </span>
                <span className="flex items-center gap-3 font-semibold">
                  <span className="inline-flex items-center gap-1 text-[#15803D]">
                    <span className="w-2.5 h-2.5 bg-[#12B850] border border-[#243046] inline-block" />
                    Bullish (+OI Impact)
                  </span>
                  <span className="inline-flex items-center gap-1 text-[#B91C1C]">
                    <span className="w-2.5 h-2.5 bg-[#FF1A1A] border border-[#243046] inline-block" />
                    Bearish (−OI Impact)
                  </span>
                </span>
              </div>
            </div>
          </div>

          {/* VIEW TODAY & YESTERDAY DATA SUMMARY TABLE */}
          <div className="bg-[#FFFFFF] border border-[#E2E8F0] rounded-[12px] shadow-[0_1px_3px_rgba(0,0,0,0.05)] overflow-hidden">
            <div className="px-4 py-3 border-b border-[#E2E8F0] bg-[#F8FAFC] flex flex-wrap items-center justify-between gap-2">
              <div>
                <div className="text-xs font-semibold text-[#2563EB] uppercase tracking-wider">
                  View Today &amp; Yesterday Data — Calculated OI Comparison (Today Data − Yesterday
                  Data)
                </div>
                <div className="text-sm font-semibold text-[#0F172A] mt-0.5">
                  Comparing Yesterday (
                  <span className="text-[#64748B]">
                    {yesterdaySourceLabel || formatIsoDateDisplay(yesterdayDate) || 'Not Loaded'}
                  </span>
                  ) vs Today (
                  <span className="text-[#2563EB]">
                    {todaySourceLabel || formatIsoDateDisplay(todayDate) || 'Not Loaded'}
                  </span>
                  )
                </div>
              </div>

              <div className="flex items-center flex-wrap gap-1.5">
                {['ALL', 'RETAIL TRADERS', 'DII TRADERS', 'FII TRADERS', 'PRO TRADERS'].map((p) => (
                  <button
                    key={p}
                    onClick={() => setParticipantFilter(p)}
                    className={`px-2.5 py-1 rounded-[6px] text-[10.5px] font-semibold transition-colors cursor-pointer ${
                      participantFilter === p
                        ? 'bg-[#2563EB] text-white'
                        : 'bg-[#FFFFFF] border border-[#E2E8F0] text-[#475569] hover:text-[#0F172A]'
                    }`}
                  >
                    {p === 'ALL' ? 'All Participants' : p.replace(' TRADERS', '')}
                  </button>
                ))}
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full border-collapse text-xs font-mono-num">
                <thead>
                  <tr className="bg-[#F1F5F9] border-b border-[#E2E8F0] text-[#475569] uppercase text-[10.5px]">
                    <th className="py-2.5 px-3.5 text-left font-semibold">PARTICIPANT / SEGMENT</th>
                    <th className="py-2.5 px-2.5 text-right font-semibold text-[#64748B]">
                      YESTERDAY NET OI (T-1)
                    </th>
                    <th className="py-2.5 px-2.5 text-right font-semibold text-[#2563EB]">
                      TODAY NET OI (T)
                    </th>
                    <th className="py-2.5 px-3 text-left font-semibold">CALCULATED NET ACTIVITY</th>
                    <th className="py-2.5 px-2.5 text-right font-semibold">
                      NET CHANGES |T − (T-1)|
                    </th>
                    <th className="py-2.5 px-2.5 text-center font-semibold">CALCULATED VIEW</th>
                    <th className="py-2.5 px-2.5 text-right font-semibold">RAW Δ (T − T-1)</th>
                    <th className="py-2.5 px-2.5 text-right font-semibold">DIRECTIONAL IMPACT</th>
                    <th className="py-2.5 px-3.5 text-left font-semibold min-w-[160px]">
                      OI CHANGE BAR
                    </th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#E2E8F0]">
                  {bothPartsAvailable
                    ? filteredSummaryRows.map((row, idx) => {
                        const isFirstOfGroup =
                          idx === 0 ||
                          filteredSummaryRows[idx - 1].participant !== row.participant;
                        const isBullish = row.view === 'BULLISH';
                        const barPct = Math.min(
                          100,
                          Math.max(4, Math.round((Math.abs(row.netChanges) / maxAbsChange) * 100))
                        );

                        return (
                          <tr
                            key={`${row.participant}_${row.segment}`}
                            className={`hover:bg-[#F8FAFC] ${
                              isFirstOfGroup && idx !== 0 ? 'border-t-2 border-[#CBD5E1]' : ''
                            }`}
                          >
                            <td className="py-2.5 px-3.5 font-sans font-semibold text-[#0F172A]">
                              {isFirstOfGroup ? (
                                <span className="text-xs font-bold text-[#1E40AF]">
                                  {row.participant} ({row.segment})
                                </span>
                              ) : (
                                <span className="text-[#475569] pl-3">↳ {row.segment}</span>
                              )}
                            </td>
                            <td className="py-2.5 px-2.5 text-right text-[#64748B]">
                              {row.prevDayNetOi >= 0 ? '+' : ''}
                              {row.prevDayNetOi.toLocaleString('en-IN')}
                            </td>
                            <td className="py-2.5 px-2.5 text-right font-semibold text-[#2563EB]">
                              {row.currDayNetOi >= 0 ? '+' : ''}
                              {row.currDayNetOi.toLocaleString('en-IN')}
                            </td>
                            <td className="py-2.5 px-3 font-sans font-semibold text-[#0F172A]">
                              {row.netActivity}
                            </td>
                            <td className="py-2.5 px-2.5 text-right font-semibold text-[#0F172A]">
                              {Math.abs(row.netChanges).toLocaleString('en-IN')}
                            </td>
                            <td className="py-2.5 px-2.5 text-center font-sans">
                              <span
                                className={`inline-flex items-center gap-1 font-bold text-[11px] ${
                                  isBullish ? 'text-[#166534]' : 'text-[#991B1B]'
                                }`}
                              >
                                {isBullish ? (
                                  <TrendingUp className="w-3.5 h-3.5 text-[#16A34A]" />
                                ) : (
                                  <TrendingDown className="w-3.5 h-3.5 text-[#DC2626]" />
                                )}
                                <span>{row.view}</span>
                              </span>
                            </td>
                            <td
                              className={`py-2.5 px-2.5 text-right font-semibold ${
                                row.netChanges >= 0 ? 'text-[#16A34A]' : 'text-[#DC2626]'
                              }`}
                            >
                              {row.netChanges >= 0 ? '+' : ''}
                              {row.netChanges.toLocaleString('en-IN')}
                            </td>
                            <td
                              className={`py-2.5 px-2.5 text-right font-semibold ${
                                row.directionalImpact >= 0 ? 'text-[#16A34A]' : 'text-[#DC2626]'
                              }`}
                            >
                              {row.directionalImpact >= 0 ? '+' : ''}
                              {row.directionalImpact.toLocaleString('en-IN')}
                            </td>
                            <td className="py-2.5 px-3.5">
                              <div className="w-full bg-[#F1F5F9] h-3 rounded-full overflow-hidden flex items-center p-0.5">
                                <div
                                  style={{
                                    width: `${barPct}%`,
                                    backgroundColor: isBullish ? '#16A34A' : '#DC2626',
                                  }}
                                  className="h-2 rounded-full transition-all"
                                />
                              </div>
                            </td>
                          </tr>
                        );
                      })
                    : filteredEmptyTemplateRows.map((row, idx) => {
                        const isFirstOfGroup =
                          idx === 0 ||
                          filteredEmptyTemplateRows[idx - 1].participant !== row.participant;
                        return (
                          <tr
                            key={`${row.participant}_${row.segment}`}
                            className={`hover:bg-[#F8FAFC] ${
                              isFirstOfGroup && idx !== 0 ? 'border-t-2 border-[#CBD5E1]' : ''
                            }`}
                          >
                            <td className="py-2.5 px-3.5 font-sans font-semibold text-[#0F172A]">
                              {isFirstOfGroup ? (
                                <span className="text-xs font-bold text-[#1E40AF]">
                                  {row.participant} ({row.segment})
                                </span>
                              ) : (
                                <span className="text-[#475569] pl-3">↳ {row.segment}</span>
                              )}
                            </td>
                            <td className="py-2.5 px-2.5 text-right text-[#94A3B8]">—</td>
                            <td className="py-2.5 px-2.5 text-right text-[#94A3B8]">—</td>
                            <td className="py-2.5 px-3 font-sans text-[#94A3B8]">—</td>
                            <td className="py-2.5 px-2.5 text-right text-[#94A3B8]">—</td>
                            <td className="py-2.5 px-2.5 text-center font-sans text-[#94A3B8]">
                              —
                            </td>
                            <td className="py-2.5 px-2.5 text-right text-[#94A3B8]">—</td>
                            <td className="py-2.5 px-2.5 text-right text-[#94A3B8]">—</td>
                            <td className="py-2.5 px-3.5">
                              <div className="w-full bg-[#F1F5F9] h-3 rounded-full overflow-hidden" />
                            </td>
                          </tr>
                        );
                      })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* =================================================================
          TAB 2: NSE PARTICIPANT OPEN INTEREST DATA
          (Contains all Auto-Refresh, Manual Upload, Yesterday/Today Date, Get Data, Clear buttons
           + Part 1: Today Data & Part 2: Yesterday Data with Heading Columns ALWAYS VISIBLE)
         ================================================================= */}
      {currentTab === 'NSE_OI_DATA' && (
        <div className="space-y-3.5">
          {/* EOD DATA SYNC & CONTROL PANEL (All controls cleanly inside NSE Participant Open Interest Data tab) */}
          <div className="bg-[#FFFFFF] border border-[#E2E8F0] rounded-[12px] p-3.5 shadow-[0_1px_3px_rgba(0,0,0,0.05)] space-y-3">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-[10px] bg-[#EFF6FF] border border-[#BFDBFE] flex items-center justify-center text-[#2563EB] shrink-0">
                  <FileSpreadsheet className="w-5 h-5" />
                </div>
                <div>
                  <div className="flex items-center gap-2 flex-wrap">
                    <h2 className="text-sm xl:text-base font-semibold text-[#0F172A]">
                      NSE Participant Open Interest Data — Fetch &amp; Upload Controls
                    </h2>
                    <span className="text-[11px] text-[#64748B]">
                      · Daily 8:00 PM IST EOD Sync
                    </span>
                  </div>
                  <p className="text-[11px] text-[#64748B] mt-0.5">
                    Select <strong className="text-[#0F172A]">Today Date</strong> and{' '}
                    <strong className="text-[#0F172A]">Yesterday Date</strong> and click{' '}
                    <strong className="text-[#2563EB]">Get Data</strong>, or use{' '}
                    <strong className="text-[#0F172A]">Manual Upload CSV</strong>
                  </p>
                </div>
              </div>

              {/* Today Date FIRST + Yesterday Date SECOND + Get Data + Clear Buttons */}
              <div className="flex items-center flex-wrap gap-2">
                {/* 1. Today Date Input (First) */}
                <div className="flex items-center gap-1.5 h-[36px] bg-[#EFF6FF]/60 border border-[#BFDBFE] rounded-[8px] px-2.5">
                  <Calendar className="w-3.5 h-3.5 text-[#2563EB]" />
                  <span className="text-[11px] text-[#1E40AF] font-semibold">Today Date:</span>
                  <input
                    type="date"
                    value={todayDate}
                    onChange={(e) => setTodayDate(e.target.value)}
                    className="bg-transparent text-[#0F172A] font-semibold text-xs focus:outline-none border-0! p-0! shadow-none! cursor-pointer"
                  />
                </div>

                <ArrowRight className="w-3.5 h-3.5 text-[#64748B] hidden sm:block" />

                {/* 2. Yesterday Date Input (Second) */}
                <div className="flex items-center gap-1.5 h-[36px] bg-[#F8FAFC] border border-[#CBD5E1] rounded-[8px] px-2.5">
                  <Calendar className="w-3.5 h-3.5 text-[#64748B]" />
                  <span className="text-[11px] text-[#475569] font-semibold">Yesterday Date:</span>
                  <input
                    type="date"
                    value={yesterdayDate}
                    onChange={(e) => setYesterdayDate(e.target.value)}
                    className="bg-transparent text-[#0F172A] font-semibold text-xs focus:outline-none border-0! p-0! shadow-none! cursor-pointer"
                  />
                </div>

                {/* Primary GET DATA Button */}
                <button
                  onClick={() => handleGetData()}
                  disabled={isLoading}
                  className="h-[36px] px-4 rounded-[8px] bg-[#2563EB] hover:bg-[#1D4ED8] text-white font-bold text-xs flex items-center gap-1.5 shadow-xs transition-colors cursor-pointer"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin' : ''}`} />
                  <span>Get Data</span>
                </button>

                {/* Clear Data Button (Always visible inside NSE Participant Open Interest Data tab) */}
                <button
                  onClick={handleClearAllData}
                  className="h-[36px] px-3 rounded-[8px] bg-[#FFFFFF] border border-[#CBD5E1] hover:bg-[#FEF2F2] hover:border-[#FECACA] text-[#475569] hover:text-[#DC2626] font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>Clear</span>
                </button>
              </div>
            </div>

            {/* Manual CSV Upload & 8:00 PM IST Auto-Refresh Strip */}
            <div className="pt-2.5 border-t border-[#E2E8F0] flex flex-wrap items-center justify-between gap-2 text-[11px]">
              <div className="flex items-center flex-wrap gap-2">
                {/* Manual Upload Today CSV (First) */}
                <label className="h-[32px] px-2.5 rounded-[6px] bg-[#EFF6FF] border border-[#BFDBFE] hover:bg-[#DBEAFE] text-[#1E40AF] font-semibold flex items-center gap-1.5 cursor-pointer transition-colors">
                  <Upload className="w-3.5 h-3.5 text-[#2563EB]" />
                  <span>Manual Upload Today CSV</span>
                  <input
                    type="file"
                    accept=".csv,.txt"
                    onChange={(e) => handleManualFileUpload('TODAY', e)}
                    className="hidden"
                  />
                </label>

                {/* Manual Upload Yesterday CSV (Second) */}
                <label className="h-[32px] px-2.5 rounded-[6px] bg-[#F8FAFC] border border-[#CBD5E1] hover:bg-[#F1F5F9] text-[#0F172A] font-semibold flex items-center gap-1.5 cursor-pointer transition-colors">
                  <Upload className="w-3.5 h-3.5 text-[#475569]" />
                  <span>Manual Upload Yesterday CSV</span>
                  <input
                    type="file"
                    accept=".csv,.txt"
                    onChange={(e) => handleManualFileUpload('YESTERDAY', e)}
                    className="hidden"
                  />
                </label>

                {bothPartsAvailable && (
                  <button
                    onClick={handleExportComparisonCsv}
                    className="h-[32px] px-2.5 rounded-[6px] bg-[#16A34A] hover:bg-[#15803D] text-white font-semibold flex items-center gap-1 cursor-pointer"
                  >
                    <Download className="w-3 h-3" />
                    <span>Export Comparison CSV</span>
                  </button>
                )}
              </div>

              <div className="flex items-center flex-wrap gap-2">
                <button
                  onClick={() => setAutoRefresh8Pm((prev) => !prev)}
                  className={`h-[30px] px-2.5 rounded-[6px] font-semibold flex items-center gap-1.5 border transition-colors cursor-pointer ${
                    autoRefresh8Pm
                      ? 'bg-[#DCFCE7] border-[#BBF7D0] text-[#166534]'
                      : 'bg-[#F1F5F9] border-[#CBD5E1] text-[#64748B]'
                  }`}
                >
                  <span
                    className={`w-2 h-2 rounded-full ${
                      autoRefresh8Pm ? 'bg-[#16A34A]' : 'bg-[#94A3B8]'
                    }`}
                  />
                  <span>Auto-Refresh @ 8:00 PM IST: {autoRefresh8Pm ? 'ON' : 'PAUSED'}</span>
                </button>

                <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-[6px] bg-[#F8FAFC] border border-[#E2E8F0] text-[#475569] font-mono-num">
                  <Clock className="w-3.5 h-3.5 text-[#2563EB]" />
                  <span>{istClock.istTimeStr}</span>
                  <span className="text-[#CBD5E1]">|</span>
                  <span className="text-[#1E40AF] font-semibold">
                    Next 8 PM: {istClock.countdownTo8PmStr}
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* ERROR BANNER WHEN DATA IS NOT AVAILABLE FOR SELECTED DATES */}
          {errorMessage && (
            <div className="bg-[#FEF2F2] border-2 border-[#EF4444] text-[#991B1B] p-4 rounded-[12px] shadow-xs flex items-start justify-between gap-3">
              <div className="flex items-start gap-3">
                <AlertCircle className="w-5 h-5 text-[#DC2626] shrink-0 mt-0.5" />
                <div>
                  <div className="font-bold text-sm text-[#991B1B]">EOD Data Not Available</div>
                  <div className="text-xs text-[#B91C1C] mt-1 font-medium">{errorMessage}</div>
                  <div className="mt-2.5 flex items-center flex-wrap gap-2">
                    <button
                      onClick={() => {
                        setYesterdayDate('2026-09-24');
                        setTodayDate('2026-09-25');
                        handleGetData('2026-09-24', '2026-09-25');
                      }}
                      className="px-3 py-1.5 rounded-[6px] bg-[#FFFFFF] border border-[#FCA5A5] hover:bg-[#FEE2E2] text-[#991B1B] font-semibold text-[11px] cursor-pointer"
                    >
                      Load Latest Available Trading Days (24 Sep 2026 &amp; 25 Sep 2026)
                    </button>
                  </div>
                </div>
              </div>
              <button
                onClick={() => setErrorMessage(null)}
                className="text-xs font-semibold text-[#991B1B] underline shrink-0"
              >
                Dismiss
              </button>
            </div>
          )}

          {/* SUCCESS NOTICE */}
          {statusMessage && !errorMessage && (
            <div className="bg-[#ECFDF5] border border-[#BBF7D0] text-[#166534] px-3.5 py-2.5 rounded-[10px] flex items-center justify-between text-xs font-medium">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-[#16A34A] shrink-0" />
                <span>{statusMessage}</span>
              </div>
              <button onClick={() => setStatusMessage(null)} className="text-xs underline">
                Dismiss
              </button>
            </div>
          )}

          {/* PART 1: TODAY DATA (Heading columns and Client Type rows ALWAYS visible) */}
          {renderSingleDayTable(
            'Part 1 — Today Data',
            todaySourceLabel || formatIsoDateDisplay(todayDate),
            'TODAY DATA',
            'bg-[#EFF6FF]/80',
            'text-[#1E40AF]',
            todayRows
          )}

          {/* PART 2: YESTERDAY DATA (Heading columns and Client Type rows ALWAYS visible) */}
          {renderSingleDayTable(
            'Part 2 — Yesterday Data',
            yesterdaySourceLabel || formatIsoDateDisplay(yesterdayDate),
            'YESTERDAY DATA',
            'bg-[#F8FAFC]',
            'text-[#0F172A]',
            yesterdayRows
          )}
        </div>
      )}
    </div>
  );
};
