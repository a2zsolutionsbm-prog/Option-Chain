import React, { useState } from 'react';
import { MarketHoliday, SystemBroadcast, UserAccount, UserRole } from '../../types';
import {
  AlertCircle,
  Bell,
  Calendar,
  CheckCircle2,
  Database,
  Radio,
  Server,
  Shield,
  Sliders,
  Users,
} from 'lucide-react';

interface AdminPanelProps {
  userRole: UserRole;
  broadcast: SystemBroadcast | null;
  onSetBroadcast: (b: SystemBroadcast | null) => void;
}

const INITIAL_USERS: UserAccount[] = [
  {
    id: 'u_1',
    name: 'Vikramaditya Roy',
    email: 'bmail75125@gmail.com',
    role: 'ADMIN',
    plan: 'Institutional Annual',
    status: 'ACTIVE',
    joinedDate: '2026-01-10',
    lastLogin: 'Just now',
    maxAlerts: 200,
  },
  {
    id: 'u_2',
    name: 'Priya Sharma',
    email: 'priya.investor@gmail.com',
    role: 'PREMIUM',
    plan: 'Pro Monthly',
    status: 'ACTIVE',
    joinedDate: '2026-03-14',
    lastLogin: '10 mins ago',
    maxAlerts: 50,
  },
  {
    id: 'u_3',
    name: 'Amit Patel',
    email: 'amit.quant@outlook.com',
    role: 'PREMIUM',
    plan: 'Pro Monthly',
    status: 'ACTIVE',
    joinedDate: '2026-05-22',
    lastLogin: '1 hour ago',
    maxAlerts: 50,
  },
  {
    id: 'u_4',
    name: 'Rahul Verma',
    email: 'rahul.trader@yahoo.com',
    role: 'RETAIL',
    plan: 'Retail Free',
    status: 'ACTIVE',
    joinedDate: '2026-08-01',
    lastLogin: '2 days ago',
    maxAlerts: 5,
  },
];

const NSE_HOLIDAYS_2026: MarketHoliday[] = [
  { date: '26 Jan 2026', day: 'Monday', occasion: 'Republic Day', status: 'CLOSED' },
  { date: '17 Feb 2026', day: 'Tuesday', occasion: 'Mahashivratri', status: 'CLOSED' },
  { date: '04 Mar 2026', day: 'Wednesday', occasion: 'Holi', status: 'CLOSED' },
  { date: '20 Mar 2026', day: 'Friday', occasion: 'Id-Ul-Fitr (Ramzan)', status: 'CLOSED' },
  { date: '03 Apr 2026', day: 'Friday', occasion: 'Good Friday', status: 'CLOSED' },
  { date: '14 Apr 2026', day: 'Tuesday', occasion: 'Dr. Baba Saheb Ambedkar Jayanti', status: 'CLOSED' },
  { date: '01 May 2026', day: 'Friday', occasion: 'Maharashtra Day', status: 'CLOSED' },
  { date: '15 Aug 2026', day: 'Saturday', occasion: 'Independence Day', status: 'CLOSED' },
  { date: '02 Oct 2026', day: 'Friday', occasion: 'Mahatma Gandhi Jayanti', status: 'CLOSED' },
  { date: '20 Oct 2026', day: 'Tuesday', occasion: 'Dussehra', status: 'CLOSED' },
  { date: '08 Nov 2026', day: 'Sunday', occasion: 'Diwali (Laxmi Pujan)', status: 'SPECIAL_TRADING' },
  { date: '25 Dec 2026', day: 'Friday', occasion: 'Christmas', status: 'CLOSED' },
];

export const AdminPanel: React.FC<AdminPanelProps> = ({
  userRole,
  broadcast,
  onSetBroadcast,
}) => {
  const [activeSection, setActiveSection] = useState<'USERS' | 'FEEDS' | 'HOLIDAYS' | 'BROADCAST'>('USERS');
  const [users, setUsers] = useState<UserAccount[]>(INITIAL_USERS);

  // Broadcast state
  const [broadcastTitle, setBroadcastTitle] = useState('NSE Market Expiry Notice');
  const [broadcastMessage, setBroadcastMessage] = useState(
    'Special trading volatility expected due to concurrent monthly index options expiry.'
  );
  const [broadcastLevel, setBroadcastLevel] = useState<'INFO' | 'WARNING' | 'CRITICAL'>('WARNING');

  // Provider state
  const [primaryFeed, setPrimaryFeed] = useState('NSE Realtime Direct Tick');
  const [feedStatus, setFeedStatus] = useState('Operational (12ms tick delay)');

  const handleToggleUserRole = (id: string) => {
    setUsers((prev) =>
      prev.map((u) => {
        if (u.id !== id) return u;
        const nextRole: UserRole =
          u.role === 'RETAIL' ? 'PREMIUM' : u.role === 'PREMIUM' ? 'ADMIN' : 'RETAIL';
        return { ...u, role: nextRole };
      })
    );
  };

  const handleToggleUserStatus = (id: string) => {
    setUsers((prev) =>
      prev.map((u) => {
        if (u.id !== id) return u;
        return {
          ...u,
          status: u.status === 'ACTIVE' ? 'SUSPENDED' : 'ACTIVE',
        };
      })
    );
  };

  const handlePublishBroadcast = (e: React.FormEvent) => {
    e.preventDefault();
    onSetBroadcast({
      id: `bc_${Date.now()}`,
      title: broadcastTitle,
      message: broadcastMessage,
      level: broadcastLevel,
      timestamp: new Date().toLocaleTimeString(),
      active: true,
    });
  };

  const handleClearBroadcast = () => {
    onSetBroadcast(null);
  };

  return (
    <div className="p-4 space-y-4 bg-[#0a0e17] overflow-y-auto text-slate-200 text-xs">
      {/* Sub Navigation */}
      <div className="flex items-center space-x-2 border-b border-slate-800 pb-2">
        <button
          onClick={() => setActiveSection('USERS')}
          className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-lg font-semibold transition-colors ${
            activeSection === 'USERS'
              ? 'bg-purple-600 text-white'
              : 'text-slate-400 hover:text-white bg-slate-900'
          }`}
        >
          <Users className="w-3.5 h-3.5" />
          <span>User Management</span>
        </button>

        <button
          onClick={() => setActiveSection('FEEDS')}
          className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-lg font-semibold transition-colors ${
            activeSection === 'FEEDS'
              ? 'bg-purple-600 text-white'
              : 'text-slate-400 hover:text-white bg-slate-900'
          }`}
        >
          <Server className="w-3.5 h-3.5" />
          <span>Data Providers & Feeds</span>
        </button>

        <button
          onClick={() => setActiveSection('HOLIDAYS')}
          className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-lg font-semibold transition-colors ${
            activeSection === 'HOLIDAYS'
              ? 'bg-purple-600 text-white'
              : 'text-slate-400 hover:text-white bg-slate-900'
          }`}
        >
          <Calendar className="w-3.5 h-3.5" />
          <span>Market Holidays 2026</span>
        </button>

        <button
          onClick={() => setActiveSection('BROADCAST')}
          className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-lg font-semibold transition-colors ${
            activeSection === 'BROADCAST'
              ? 'bg-purple-600 text-white'
              : 'text-slate-400 hover:text-white bg-slate-900'
          }`}
        >
          <Radio className="w-3.5 h-3.5" />
          <span>System Broadcasts</span>
        </button>
      </div>

      {/* Section 1: Users */}
      {activeSection === 'USERS' && (
        <div className="bg-[#0f1422] border border-slate-800 rounded-xl p-4 shadow-lg">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-4">
            <div>
              <h3 className="text-sm font-bold text-white flex items-center space-x-2">
                <Users className="w-4 h-4 text-purple-400" />
                <span>User Accounts & Permissions</span>
              </h3>
              <p className="text-[11px] text-slate-400">
                Manage roles, subscriptions, rate limiting, and access privileges
              </p>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left font-mono-num text-xs">
              <thead>
                <tr className="border-b border-slate-800 text-slate-400 uppercase text-[10px]">
                  <th className="py-2 px-3">User</th>
                  <th className="py-2 px-3">Role</th>
                  <th className="py-2 px-3">Plan</th>
                  <th className="py-2 px-3">Status</th>
                  <th className="py-2 px-3">Alerts Cap</th>
                  <th className="py-2 px-3">Last Active</th>
                  <th className="py-2 px-3 text-center">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {users.map((u) => (
                  <tr key={u.id} className="hover:bg-slate-900/40">
                    <td className="py-2.5 px-3">
                      <div className="font-bold text-white">{u.name}</div>
                      <div className="text-[10px] text-slate-400 font-sans">{u.email}</div>
                    </td>
                    <td className="py-2.5 px-3">
                      <span
                        className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          u.role === 'ADMIN'
                            ? 'bg-purple-950 text-purple-300 border border-purple-800'
                            : u.role === 'PREMIUM'
                            ? 'bg-amber-950 text-amber-300 border border-amber-800'
                            : 'bg-slate-800 text-slate-300'
                        }`}
                      >
                        {u.role}
                      </span>
                    </td>
                    <td className="py-2.5 px-3 text-slate-300">{u.plan}</td>
                    <td className="py-2.5 px-3">
                      <span
                        className={`px-1.5 py-0.5 rounded text-[10px] font-semibold ${
                          u.status === 'ACTIVE'
                            ? 'text-emerald-400 bg-emerald-950/60'
                            : 'text-rose-400 bg-rose-950/60'
                        }`}
                      >
                        {u.status}
                      </span>
                    </td>
                    <td className="py-2.5 px-3 text-slate-300">{u.maxAlerts}</td>
                    <td className="py-2.5 px-3 text-slate-400">{u.lastLogin}</td>
                    <td className="py-2.5 px-3 text-center space-x-2">
                      <button
                        onClick={() => handleToggleUserRole(u.id)}
                        className="bg-slate-800 hover:bg-slate-700 text-cyan-300 px-2 py-1 rounded text-[10px] font-semibold transition-colors"
                      >
                        Cycle Role
                      </button>
                      <button
                        onClick={() => handleToggleUserStatus(u.id)}
                        className={`px-2 py-1 rounded text-[10px] font-semibold transition-colors ${
                          u.status === 'ACTIVE'
                            ? 'bg-rose-950/60 text-rose-300 hover:bg-rose-900/60'
                            : 'bg-emerald-950/60 text-emerald-300 hover:bg-emerald-900/60'
                        }`}
                      >
                        {u.status === 'ACTIVE' ? 'Suspend' : 'Activate'}
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Section 2: Data Feeds */}
      {activeSection === 'FEEDS' && (
        <div className="bg-[#0f1422] border border-slate-800 rounded-xl p-5 shadow-lg max-w-2xl space-y-4">
          <h3 className="text-sm font-bold text-white flex items-center space-x-2">
            <Server className="w-4 h-4 text-purple-400" />
            <span>Market Data Feeds Configuration</span>
          </h3>

          <div className="space-y-3">
            <div className="bg-slate-900 p-3 rounded-lg border border-slate-800 flex items-center justify-between">
              <div>
                <div className="font-bold text-slate-200">NSE Live Stream (Tick-by-Tick)</div>
                <div className="text-[11px] text-emerald-400">Status: Active · Ultra Low Latency (14ms)</div>
              </div>
              <span className="bg-emerald-950 text-emerald-300 border border-emerald-800 px-2 py-0.5 rounded text-[10px] font-bold">
                PRIMARY
              </span>
            </div>

            <div className="bg-slate-900 p-3 rounded-lg border border-slate-800 flex items-center justify-between">
              <div>
                <div className="font-bold text-slate-200">BSE SENSEX Realtime Stream</div>
                <div className="text-[11px] text-emerald-400">Status: Active · 1000ms WebSocket Interval</div>
              </div>
              <span className="bg-cyan-950 text-cyan-300 border border-cyan-800 px-2 py-0.5 rounded text-[10px] font-bold">
                CONNECTED
              </span>
            </div>

            <div className="bg-slate-900 p-3 rounded-lg border border-slate-800 flex items-center justify-between">
              <div>
                <div className="font-bold text-slate-200">Historical OI & Volatility Database</div>
                <div className="text-[11px] text-slate-400">PostgreSQL / Supabase Storage Sync</div>
              </div>
              <span className="bg-purple-950 text-purple-300 border border-purple-800 px-2 py-0.5 rounded text-[10px] font-bold">
                SYNCHRONIZED
              </span>
            </div>
          </div>
        </div>
      )}

      {/* Section 3: Holidays */}
      {activeSection === 'HOLIDAYS' && (
        <div className="bg-[#0f1422] border border-slate-800 rounded-xl p-4 shadow-lg">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-3">
            <div>
              <h3 className="text-sm font-bold text-white flex items-center space-x-2">
                <Calendar className="w-4 h-4 text-purple-400" />
                <span>NSE & BSE Market Holidays (Calendar Year 2026)</span>
              </h3>
              <p className="text-[11px] text-slate-400">
                Official holiday schedule for Capital Market and Equity Derivative Segments
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2.5">
            {NSE_HOLIDAYS_2026.map((h) => (
              <div
                key={h.occasion}
                className="bg-slate-900/80 border border-slate-800 rounded-lg p-3 flex items-center justify-between"
              >
                <div>
                  <div className="font-bold text-white">{h.occasion}</div>
                  <div className="text-[10px] text-slate-400">
                    {h.date} ({h.day})
                  </div>
                </div>
                <span
                  className={`text-[9px] font-bold px-2 py-0.5 rounded ${
                    h.status === 'CLOSED'
                      ? 'bg-rose-950 text-rose-300 border border-rose-800'
                      : 'bg-amber-950 text-amber-300 border border-amber-800'
                  }`}
                >
                  {h.status === 'CLOSED' ? 'MARKET CLOSED' : 'MUHURAT TRADING'}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Section 4: System Broadcasts */}
      {activeSection === 'BROADCAST' && (
        <div className="bg-[#0f1422] border border-slate-800 rounded-xl p-5 shadow-lg max-w-2xl space-y-4">
          <div>
            <h3 className="text-sm font-bold text-white flex items-center space-x-2">
              <Radio className="w-4 h-4 text-purple-400" />
              <span>Broadcast System Notification</span>
            </h3>
            <p className="text-[11px] text-slate-400">
              Transmit high-priority ticker alerts and market notices to all logged-in trader terminals.
            </p>
          </div>

          <form onSubmit={handlePublishBroadcast} className="space-y-3">
            <div>
              <label className="text-[10px] text-slate-400 uppercase font-semibold block mb-1">
                Notice Title
              </label>
              <input
                type="text"
                value={broadcastTitle}
                onChange={(e) => setBroadcastTitle(e.target.value)}
                className="w-full bg-slate-900 border border-slate-800 rounded p-2 text-white font-bold text-xs focus:outline-none"
                required
              />
            </div>

            <div>
              <label className="text-[10px] text-slate-400 uppercase font-semibold block mb-1">
                Broadcast Body
              </label>
              <textarea
                rows={3}
                value={broadcastMessage}
                onChange={(e) => setBroadcastMessage(e.target.value)}
                className="w-full bg-slate-900 border border-slate-800 rounded p-2 text-white text-xs focus:outline-none"
                required
              />
            </div>

            <div>
              <label className="text-[10px] text-slate-400 uppercase font-semibold block mb-1">
                Severity Level
              </label>
              <div className="flex space-x-2">
                {(['INFO', 'WARNING', 'CRITICAL'] as const).map((lvl) => (
                  <button
                    key={lvl}
                    type="button"
                    onClick={() => setBroadcastLevel(lvl)}
                    className={`px-3 py-1.5 rounded text-xs font-bold transition-colors ${
                      broadcastLevel === lvl
                        ? lvl === 'CRITICAL'
                          ? 'bg-rose-600 text-white'
                          : lvl === 'WARNING'
                          ? 'bg-amber-600 text-slate-950 font-black'
                          : 'bg-cyan-600 text-white'
                        : 'bg-slate-900 text-slate-400 border border-slate-800'
                    }`}
                  >
                    {lvl}
                  </button>
                ))}
              </div>
            </div>

            <div className="flex space-x-2 pt-2">
              <button
                type="submit"
                className="bg-purple-600 hover:bg-purple-500 text-white font-bold py-2 px-4 rounded-lg text-xs transition-colors shadow-md"
              >
                Publish Broadcast to All Terminals
              </button>

              {broadcast && (
                <button
                  type="button"
                  onClick={handleClearBroadcast}
                  className="bg-slate-800 hover:bg-slate-700 text-slate-300 py-2 px-3 rounded-lg text-xs"
                >
                  Dismiss Active Broadcast
                </button>
              )}
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
