import React from 'react';
import { UserRole } from '../../types';
import { Check, Lock, Sparkles, X } from 'lucide-react';

interface RoleGateModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectRole: (role: UserRole) => void;
  featureName: string;
}

export const RoleGateModal: React.FC<RoleGateModalProps> = ({
  isOpen,
  onClose,
  onSelectRole,
  featureName,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-[#101726] border border-amber-500/40 rounded-2xl w-full max-w-lg p-6 shadow-2xl relative space-y-4 text-slate-200 text-xs">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-slate-400 hover:text-white p-1"
        >
          <X className="w-4 h-4" />
        </button>

        <div className="flex items-center space-x-3">
          <div className="w-12 h-12 rounded-xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-400">
            <Lock className="w-6 h-6" />
          </div>
          <div>
            <div className="text-base font-extrabold text-white">
              Unlock {featureName}
            </div>
            <div className="text-slate-400 text-xs">
              This advanced quantitative module requires Pro or Institutional privileges.
            </div>
          </div>
        </div>

        {/* Feature Highlights */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-3.5 space-y-2">
          <div className="text-[11px] font-bold text-slate-300 uppercase tracking-wider">
            Included in DigiService Option Chain Pro:
          </div>
          <div className="space-y-1.5 text-xs">
            <div className="flex items-center space-x-2 text-slate-300">
              <Check className="w-3.5 h-3.5 text-emerald-400 flex-shrink-0" />
              <span>1-second Ultra Low Latency Live Ticks & WebSocket Stream</span>
            </div>
            <div className="flex items-center space-x-2 text-slate-300">
              <Check className="w-3.5 h-3.5 text-emerald-400 flex-shrink-0" />
              <span>Realtime Black-Scholes Greeks (Delta, Theta, Gamma, Vega, Rho)</span>
            </div>
            <div className="flex items-center space-x-2 text-slate-300">
              <Check className="w-3.5 h-3.5 text-emerald-400 flex-shrink-0" />
              <span>Institutional Strategy & Unusual OI Momentum Scanner</span>
            </div>
            <div className="flex items-center space-x-2 text-slate-300">
              <Check className="w-3.5 h-3.5 text-emerald-400 flex-shrink-0" />
              <span>Unlimited Multi-Leg Custom Strategy Payoff Curves & POP Engine</span>
            </div>
            <div className="flex items-center space-x-2 text-slate-300">
              <Check className="w-3.5 h-3.5 text-emerald-400 flex-shrink-0" />
              <span>Telegram Webhook & Instant Browser Audio Alerts</span>
            </div>
          </div>
        </div>

        {/* Instant Evaluation Action */}
        <div className="pt-2 flex flex-col sm:flex-row gap-2">
          <button
            onClick={() => {
              onSelectRole('PREMIUM');
              onClose();
            }}
            className="flex-1 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black py-2.5 px-4 rounded-xl flex items-center justify-center space-x-1.5 transition-all shadow-lg shadow-amber-500/20 text-xs"
          >
            <Sparkles className="w-4 h-4" />
            <span>Switch to Premium (Instant Pro Mode)</span>
          </button>

          <button
            onClick={() => {
              onSelectRole('ADMIN');
              onClose();
            }}
            className="bg-purple-600 hover:bg-purple-500 text-white font-bold py-2.5 px-4 rounded-xl transition-all text-xs"
          >
            Switch to Admin Mode
          </button>
        </div>
      </div>
    </div>
  );
};
