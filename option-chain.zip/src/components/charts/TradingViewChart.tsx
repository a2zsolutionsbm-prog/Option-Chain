import React, { useState, useRef, useEffect } from 'react';
import { IndexMarketData } from '../../types';
import {
  Calendar,
  Maximize2,
  RefreshCw,
  Sliders,
  TrendingDown,
  TrendingUp,
} from 'lucide-react';

interface Candle {
  time: string;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
  ema9?: number;
  ema21?: number;
  vwap?: number;
  rsi?: number;
  macd?: number;
  macdSignal?: number;
  macdHist?: number;
  superTrend?: number;
  superTrendDir?: 'BULL' | 'BEAR';
}

interface TradingViewChartProps {
  currentIndex: IndexMarketData;
  maxPainStrike: number;
}

function generateHistoricalCandles(basePrice: number, strikeStep: number, numBars: number = 55): Candle[] {
  const generated: Candle[] = [];
  let current = basePrice - 120;
  const now = new Date();

  for (let i = numBars; i >= 0; i--) {
    const barTime = new Date(now.getTime() - i * 5 * 60 * 1000);
    const timeStr = barTime.toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' });

    const volatility = (strikeStep || 50) * 0.35;
    const change = (Math.random() - 0.48) * volatility;
    const open = Number(current.toFixed(2));
    const close = Number((current + change).toFixed(2));
    const high = Number((Math.max(open, close) + Math.random() * (volatility * 0.6)).toFixed(2));
    const low = Number((Math.min(open, close) - Math.random() * (volatility * 0.6)).toFixed(2));
    const volume = Math.floor(15000 + Math.random() * 45000);

    current = close;

    generated.push({
      time: timeStr,
      open,
      high,
      low,
      close,
      volume,
    });
  }

  // Force the last bar close to match the current spot price
  if (generated.length > 0) {
    const last = generated[generated.length - 1];
    last.close = basePrice;
    last.high = Math.max(last.high, basePrice);
    last.low = Math.min(last.low, basePrice);
  }

  // Calculate Technical Indicators: EMA 9, EMA 21, VWAP, RSI, MACD, SuperTrend
  let cumulativeVol = 0;
  let cumulativeVolPrice = 0;

  const k9 = 2 / (9 + 1);
  const k21 = 2 / (21 + 1);
  let ema9 = generated[0].close;
  let ema21 = generated[0].close;

  // RSI storage
  let avgGain = 0;
  let avgLoss = 0;

  // MACD EMAs
  let ema12 = generated[0].close;
  let ema26 = generated[0].close;
  const k12 = 2 / (12 + 1);
  const k26 = 2 / (26 + 1);
  const kSignal = 2 / (9 + 1);
  let signalLine = 0;

  for (let i = 0; i < generated.length; i++) {
    const bar = generated[i];
    const typicalPrice = (bar.high + bar.low + bar.close) / 3;

    // VWAP
    cumulativeVol += bar.volume;
    cumulativeVolPrice += typicalPrice * bar.volume;
    bar.vwap = Number((cumulativeVolPrice / (cumulativeVol || 1)).toFixed(2));

    // EMAs
    ema9 = bar.close * k9 + ema9 * (1 - k9);
    ema21 = bar.close * k21 + ema21 * (1 - k21);
    bar.ema9 = Number(ema9.toFixed(2));
    bar.ema21 = Number(ema21.toFixed(2));

    // RSI
    if (i > 0) {
      const diff = bar.close - generated[i - 1].close;
      const gain = diff > 0 ? diff : 0;
      const loss = diff < 0 ? Math.abs(diff) : 0;

      if (i < 14) {
        avgGain += gain / 14;
        avgLoss += loss / 14;
        bar.rsi = 50;
      } else {
        avgGain = (avgGain * 13 + gain) / 14;
        avgLoss = (avgLoss * 13 + loss) / 14;
        const rs = avgLoss === 0 ? 100 : avgGain / avgLoss;
        bar.rsi = Number((100 - 100 / (1 + rs)).toFixed(1));
      }
    } else {
      bar.rsi = 50;
    }

    // MACD
    ema12 = bar.close * k12 + ema12 * (1 - k12);
    ema26 = bar.close * k26 + ema26 * (1 - k26);
    const macdVal = ema12 - ema26;
    signalLine = macdVal * kSignal + signalLine * (1 - kSignal);
    bar.macd = Number(macdVal.toFixed(2));
    bar.macdSignal = Number(signalLine.toFixed(2));
    bar.macdHist = Number((macdVal - signalLine).toFixed(2));

    // SuperTrend (approximate ATR based)
    const isBull = bar.close > (bar.ema21 || bar.close);
    bar.superTrendDir = isBull ? 'BULL' : 'BEAR';
    bar.superTrend = Number((isBull ? bar.low * 0.997 : bar.high * 1.003).toFixed(2));
  }

  return generated;
}

export const TradingViewChart: React.FC<TradingViewChartProps> = ({
  currentIndex,
  maxPainStrike,
}) => {
  const [timeframe, setTimeframe] = useState<'1m' | '5m' | '15m' | '30m' | '1h' | '1D'>('5m');
  const [showEMA, setShowEMA] = useState(true);
  const [showVWAP, setShowVWAP] = useState(true);
  const [showSuperTrend, setShowSuperTrend] = useState(true);
  const [showRSI, setShowRSI] = useState(true);
  const [showMACD, setShowMACD] = useState(true);
  const [candles, setCandles] = useState<Candle[]>(() =>
    generateHistoricalCandles(currentIndex.spotPrice || 24864, currentIndex.strikeStep || 50, 55)
  );
  const [hoveredCandle, setHoveredCandle] = useState<Candle | null>(null);

  const containerRef = useRef<HTMLDivElement>(null);

  // Generate realistic historical intraday candlestick series on symbol/timeframe change
  useEffect(() => {
    const generated = generateHistoricalCandles(
      currentIndex.spotPrice || 24864,
      currentIndex.strikeStep || 50,
      55
    );
    setCandles(generated);
  }, [currentIndex.symbol, timeframe]);

  // Update last candle when spot price ticks
  useEffect(() => {
    if (!candles.length) return;
    setCandles((prev) => {
      if (!prev.length) return prev;
      const next = [...prev];
      const last = { ...next[next.length - 1] };
      last.close = currentIndex.spotPrice;
      last.high = Math.max(last.high, currentIndex.spotPrice);
      last.low = Math.min(last.low, currentIndex.spotPrice);
      next[next.length - 1] = last;
      return next;
    });
  }, [currentIndex.spotPrice]);

  // Chart coordinate calculations
  const chartHeight = 340;
  const rsiHeight = showRSI ? 85 : 0;
  const macdHeight = showMACD ? 85 : 0;
  const totalSvgHeight = chartHeight + rsiHeight + macdHeight + 30;

  let minPrice = (currentIndex.spotPrice || 24864) * 0.98;
  let maxPrice = (currentIndex.spotPrice || 24864) * 1.02;
  let maxVolume = 1;

  if (candles.length > 0) {
    minPrice = Number.MAX_VALUE;
    maxPrice = -Number.MAX_VALUE;
    candles.forEach((c) => {
      if (Number.isFinite(c.low) && c.low < minPrice) minPrice = c.low;
      if (Number.isFinite(c.high) && c.high > maxPrice) maxPrice = c.high;
      if (Number.isFinite(c.volume) && c.volume > maxVolume) maxVolume = c.volume;
    });
  }

  if (!Number.isFinite(minPrice) || !Number.isFinite(maxPrice) || minPrice >= maxPrice) {
    minPrice = (currentIndex.spotPrice || 24864) - 150;
    maxPrice = (currentIndex.spotPrice || 24864) + 150;
  }

  const pricePadding = Math.max(10, (maxPrice - minPrice) * 0.08);
  const yMin = minPrice - pricePadding;
  const yMax = maxPrice + pricePadding;
  const yRange = Math.max(1, yMax - yMin);

  const width = 850;
  const plotWidth = width - 75; // leave space for right price axis
  const barSpacing = plotWidth / (candles.length || 1);

  const getY = (val: number): number => {
    if (!Number.isFinite(val)) return chartHeight / 2;
    const res = chartHeight - ((val - yMin) / yRange) * (chartHeight - 30) - 20;
    return Number.isFinite(res) ? res : chartHeight / 2;
  };

  const activeCandle = hoveredCandle || (candles.length > 0 ? candles[candles.length - 1] : null);

  return (
    <div className="flex flex-col h-full bg-[#090d16] select-none text-xs">
      {/* Top Chart Toolbar */}
      <div className="flex flex-wrap items-center justify-between px-3 py-2 bg-[#0e1422] border-b border-slate-800 gap-2">
        <div className="flex items-center space-x-2">
          {/* Symbol */}
          <div className="flex items-center space-x-1.5 font-bold text-slate-100 text-sm">
            <span>{currentIndex.name}</span>
            <span className="text-cyan-400 font-mono-num font-extrabold">
              ₹{currentIndex.spotPrice.toFixed(2)}
            </span>
          </div>

          {/* Timeframe Buttons */}
          <div className="flex items-center bg-slate-900 border border-slate-800 rounded p-0.5 ml-2">
            {(['1m', '5m', '15m', '30m', '1h', '1D'] as const).map((tf) => (
              <button
                key={tf}
                onClick={() => setTimeframe(tf)}
                className={`px-2 py-0.5 rounded text-[11px] font-medium transition-colors ${
                  timeframe === tf
                    ? 'bg-cyan-600 text-white font-bold'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {tf}
              </button>
            ))}
          </div>
        </div>

        {/* Technical Indicator Toggles */}
        <div className="flex items-center flex-wrap gap-1.5 text-[11px]">
          <button
            onClick={() => setShowEMA(!showEMA)}
            className={`px-2 py-1 rounded border font-semibold transition-colors flex items-center space-x-1 ${
              showEMA
                ? 'bg-amber-950/60 border-amber-700 text-amber-300'
                : 'bg-slate-900 border-slate-800 text-slate-500'
            }`}
          >
            <span>EMA (9/21)</span>
          </button>

          <button
            onClick={() => setShowVWAP(!showVWAP)}
            className={`px-2 py-1 rounded border font-semibold transition-colors flex items-center space-x-1 ${
              showVWAP
                ? 'bg-cyan-950/60 border-cyan-700 text-cyan-300'
                : 'bg-slate-900 border-slate-800 text-slate-500'
            }`}
          >
            <span>VWAP</span>
          </button>

          <button
            onClick={() => setShowSuperTrend(!showSuperTrend)}
            className={`px-2 py-1 rounded border font-semibold transition-colors flex items-center space-x-1 ${
              showSuperTrend
                ? 'bg-emerald-950/60 border-emerald-700 text-emerald-300'
                : 'bg-slate-900 border-slate-800 text-slate-500'
            }`}
          >
            <span>SuperTrend</span>
          </button>

          <button
            onClick={() => setShowRSI(!showRSI)}
            className={`px-2 py-1 rounded border font-semibold transition-colors flex items-center space-x-1 ${
              showRSI
                ? 'bg-purple-950/60 border-purple-700 text-purple-300'
                : 'bg-slate-900 border-slate-800 text-slate-500'
            }`}
          >
            <span>RSI (14)</span>
          </button>

          <button
            onClick={() => setShowMACD(!showMACD)}
            className={`px-2 py-1 rounded border font-semibold transition-colors flex items-center space-x-1 ${
              showMACD
                ? 'bg-blue-950/60 border-blue-700 text-blue-300'
                : 'bg-slate-900 border-slate-800 text-slate-500'
            }`}
          >
            <span>MACD</span>
          </button>
        </div>
      </div>

      {/* OHLCV Crosshair Status Bar */}
      {activeCandle && (
        <div className="flex flex-wrap items-center px-4 py-1.5 bg-[#0b101c] border-b border-slate-800/80 text-[11px] font-mono-num text-slate-300 gap-x-4 gap-y-1">
          <div className="flex items-center space-x-1 text-slate-400">
            <span>TIME:</span>
            <span className="text-slate-200 font-semibold">{activeCandle.time}</span>
          </div>
          <div>
            O: <span className="text-slate-100">{activeCandle.open.toFixed(2)}</span>
          </div>
          <div>
            H: <span className="text-emerald-400">{activeCandle.high.toFixed(2)}</span>
          </div>
          <div>
            L: <span className="text-rose-400">{activeCandle.low.toFixed(2)}</span>
          </div>
          <div>
            C:{' '}
            <span className={activeCandle.close >= activeCandle.open ? 'text-emerald-400' : 'text-rose-400'}>
              {activeCandle.close.toFixed(2)}
            </span>
          </div>
          <div>
            VOL: <span className="text-cyan-400">{(activeCandle.volume / 1000).toFixed(1)}k</span>
          </div>
          {showEMA && activeCandle.ema9 && (
            <div className="text-amber-300">EMA9: {activeCandle.ema9.toFixed(1)}</div>
          )}
          {showEMA && activeCandle.ema21 && (
            <div className="text-blue-400">EMA21: {activeCandle.ema21.toFixed(1)}</div>
          )}
          {showVWAP && activeCandle.vwap && (
            <div className="text-cyan-400">VWAP: {activeCandle.vwap.toFixed(1)}</div>
          )}
          {showRSI && activeCandle.rsi && (
            <div className="text-purple-400">RSI(14): {activeCandle.rsi.toFixed(1)}</div>
          )}
        </div>
      )}

      {/* Chart Canvas / SVG Viewport */}
      <div ref={containerRef} className="flex-1 overflow-x-auto overflow-y-auto p-3 bg-[#F8FAFC]">
        <div className="bg-[#FFFFFF] border border-[#E2E8F0] rounded-[12px] p-2 shadow-[0_1px_3px_rgba(0,0,0,0.05)]">
          <svg
            viewBox={`0 0 ${width} ${totalSvgHeight}`}
            className="w-full h-auto min-w-[750px]"
            style={{ background: '#FFFFFF' }}
          >
            {/* Horizontal Price Grid Lines */}
            {[0.2, 0.4, 0.6, 0.8].map((pct, i) => {
              const priceVal = yMin + yRange * pct;
              const y = getY(priceVal);
              return (
                <g key={i}>
                  <line x1="0" y1={y} x2={plotWidth} y2={y} stroke="#E2E8F0" strokeDasharray="3 3" />
                  <text
                    x={plotWidth + 8}
                    y={y + 4}
                    fill="#64748B"
                    fontSize="10"
                    fontFamily="Inter, sans-serif"
                    fontWeight="500"
                  >
                    {priceVal.toFixed(0)}
                  </text>
                </g>
              );
            })}

            {/* Max Pain Strike Line */}
            {maxPainStrike >= yMin && maxPainStrike <= yMax && (
              <g>
                <line
                  x1="0"
                  y1={getY(maxPainStrike)}
                  x2={plotWidth}
                  y2={getY(maxPainStrike)}
                  stroke="#F59E0B"
                  strokeWidth="1.5"
                  strokeDasharray="4 4"
                />
                <rect
                  x={plotWidth + 4}
                  y={getY(maxPainStrike) - 9}
                  width="64"
                  height="18"
                  fill="#FEF3C7"
                  stroke="#F59E0B"
                  rx="4"
                />
                <text
                  x={plotWidth + 8}
                  y={getY(maxPainStrike) + 4}
                  fill="#92400E"
                  fontSize="10"
                  fontFamily="Inter, sans-serif"
                  fontWeight="700"
                >
                  MP {maxPainStrike}
                </text>
              </g>
            )}

            {/* Current Spot Price Marker Line */}
            <g>
              <line
                x1="0"
                y1={getY(currentIndex.spotPrice)}
                x2={plotWidth}
                y2={getY(currentIndex.spotPrice)}
                stroke="#2563EB"
                strokeWidth="1.2"
                strokeDasharray="2 2"
              />
              <rect
                x={plotWidth + 4}
                y={getY(currentIndex.spotPrice) - 9}
                width="68"
                height="18"
                fill="#2563EB"
                rx="4"
              />
              <text
                x={plotWidth + 8}
                y={getY(currentIndex.spotPrice) + 4}
                fill="#FFFFFF"
                fontSize="10"
                fontFamily="Inter, sans-serif"
                fontWeight="600"
              >
                ₹{currentIndex.spotPrice.toFixed(1)}
              </text>
            </g>

            {/* Candlestick Series & Volume Bars */}
            {candles.map((c, i) => {
              const x = i * barSpacing + barSpacing * 0.5;
              const isGreen = c.close >= c.open;
              const candleColor = isGreen ? '#16A34A' : '#DC2626';
              const bodyTop = getY(Math.max(c.open, c.close));
              const bodyBottom = getY(Math.min(c.open, c.close));
              const bodyHeight = Math.max(2, bodyBottom - bodyTop);
              const wickTop = getY(c.high);
              const wickBottom = getY(c.low);
              const candleWidth = Math.max(3, barSpacing * 0.7);

              // Volume bar in bottom 50px of main chart
              const volHeight = (c.volume / maxVolume) * 45;
              const volY = chartHeight - volHeight;

              return (
                <g
                  key={i}
                  onMouseEnter={() => setHoveredCandle(c)}
                  onMouseLeave={() => setHoveredCandle(null)}
                  className="cursor-crosshair"
                >
                  {/* Volume Bar */}
                  <rect
                    x={x - candleWidth * 0.5}
                    y={volY}
                    width={candleWidth}
                    height={volHeight}
                    fill={isGreen ? 'rgba(22, 163, 74, 0.18)' : 'rgba(220, 38, 38, 0.18)'}
                  />

                  {/* Candle Wick */}
                  <line x1={x} y1={wickTop} x2={x} y2={wickBottom} stroke={candleColor} strokeWidth="1.2" />

                  {/* Candle Body */}
                  <rect
                    x={x - candleWidth * 0.5}
                    y={bodyTop}
                    width={candleWidth}
                    height={bodyHeight}
                    fill={candleColor}
                    rx="1"
                  />
                </g>
              );
            })}

            {/* Indicator Lines: EMA 9 (Amber), EMA 21 (Blue), VWAP (Cyan) */}
            {showEMA && (
              <>
                {/* EMA 9 */}
                <path
                  d={candles.reduce(
                    (acc, c, i) =>
                      `${acc} ${i === 0 ? 'M' : 'L'} ${i * barSpacing + barSpacing * 0.5} ${getY(c.ema9 || c.close)}`,
                    ''
                  )}
                  fill="none"
                  stroke="#F59E0B"
                  strokeWidth="1.5"
                />
                {/* EMA 21 */}
                <path
                  d={candles.reduce(
                    (acc, c, i) =>
                      `${acc} ${i === 0 ? 'M' : 'L'} ${i * barSpacing + barSpacing * 0.5} ${getY(c.ema21 || c.close)}`,
                    ''
                  )}
                  fill="none"
                  stroke="#2563EB"
                  strokeWidth="1.5"
                />
              </>
            )}

            {showVWAP && (
              <path
                d={candles.reduce(
                  (acc, c, i) =>
                    `${acc} ${i === 0 ? 'M' : 'L'} ${i * barSpacing + barSpacing * 0.5} ${getY(c.vwap || c.close)}`,
                  ''
                )}
                fill="none"
                stroke="#0891B2"
                strokeWidth="1.5"
                strokeDasharray="4 2"
              />
            )}

            {showSuperTrend && (
              <path
                d={candles.reduce(
                  (acc, c, i) =>
                    `${acc} ${i === 0 ? 'M' : 'L'} ${i * barSpacing + barSpacing * 0.5} ${getY(c.superTrend || c.close)}`,
                  ''
                )}
                fill="none"
                stroke="#16A34A"
                strokeWidth="2"
              />
            )}

            {/* Separator Line */}
            <line x1="0" y1={chartHeight} x2={width} y2={chartHeight} stroke="#E2E8F0" />

            {/* SUB-PANEL 1: RSI (14) */}
            {showRSI && (
              <g transform={`translate(0, ${chartHeight})`}>
                {/* RSI background & levels */}
                <rect x="0" y="0" width={plotWidth} height={rsiHeight} fill="#F8FAFC" />
                <text x="10" y="18" fill="#475569" fontSize="10" fontWeight="600">
                  RSI (14)
                </text>
                {/* 70 Level (Overbought) */}
                <line x1="0" y1={rsiHeight * 0.3} x2={plotWidth} y2={rsiHeight * 0.3} stroke="#DC2626" strokeDasharray="3 3" opacity="0.5" />
                <text x={plotWidth + 8} y={rsiHeight * 0.3 + 4} fill="#DC2626" fontSize="9" fontWeight="600">70</text>
                {/* 30 Level (Oversold) */}
                <line x1="0" y1={rsiHeight * 0.7} x2={plotWidth} y2={rsiHeight * 0.7} stroke="#16A34A" strokeDasharray="3 3" opacity="0.5" />
                <text x={plotWidth + 8} y={rsiHeight * 0.7 + 4} fill="#16A34A" fontSize="9" fontWeight="600">30</text>

                {/* RSI curve */}
                <path
                  d={candles.reduce((acc, c, i) => {
                    const val = c.rsi || 50;
                    const y = rsiHeight - (val / 100) * rsiHeight;
                    return `${acc} ${i === 0 ? 'M' : 'L'} ${i * barSpacing + barSpacing * 0.5} ${y}`;
                  }, '')}
                  fill="none"
                  stroke="#2563EB"
                  strokeWidth="1.8"
                />
                <line x1="0" y1={rsiHeight} x2={width} y2={rsiHeight} stroke="#E2E8F0" />
              </g>
            )}

            {/* SUB-PANEL 2: MACD (12, 26, 9) */}
            {showMACD && (
              <g transform={`translate(0, ${chartHeight + rsiHeight})`}>
                <rect x="0" y="0" width={plotWidth} height={macdHeight} fill="#FFFFFF" />
                <text x="10" y="18" fill="#475569" fontSize="10" fontWeight="600">
                  MACD (12, 26, 9)
                </text>
                <line x1="0" y1={macdHeight * 0.5} x2={plotWidth} y2={macdHeight * 0.5} stroke="#E2E8F0" strokeDasharray="2 2" />

                {/* MACD Histograms & Lines */}
                {candles.map((c, i) => {
                  const x = i * barSpacing + barSpacing * 0.5;
                  const hist = c.macdHist || 0;
                  const histH = Math.min(30, Math.abs(hist) * 2.5);
                  const isPos = hist >= 0;
                  const histY = isPos ? macdHeight * 0.5 - histH : macdHeight * 0.5;
                  return (
                    <rect
                      key={i}
                      x={x - 2}
                      y={histY}
                      width={4}
                      height={histH}
                      fill={isPos ? '#16A34A' : '#DC2626'}
                      opacity="0.85"
                    />
                  );
                })}

                {/* MACD Line */}
                <path
                  d={candles.reduce((acc, c, i) => {
                    const y = macdHeight * 0.5 - (c.macd || 0) * 2.5;
                    return `${acc} ${i === 0 ? 'M' : 'L'} ${i * barSpacing + barSpacing * 0.5} ${y}`;
                  }, '')}
                  fill="none"
                  stroke="#2563EB"
                  strokeWidth="1.5"
                />
                {/* Signal Line */}
                <path
                  d={candles.reduce((acc, c, i) => {
                    const y = macdHeight * 0.5 - (c.macdSignal || 0) * 2.5;
                    return `${acc} ${i === 0 ? 'M' : 'L'} ${i * barSpacing + barSpacing * 0.5} ${y}`;
                  }, '')}
                  fill="none"
                  stroke="#F59E0B"
                  strokeWidth="1.5"
                />
              </g>
            )}

            {/* Bottom Time Axis Labels */}
            {candles.map((c, i) => {
              if (i % 6 !== 0) return null;
              const x = i * barSpacing + barSpacing * 0.5;
              return (
                <text
                  key={i}
                  x={x}
                  y={totalSvgHeight - 8}
                  fill="#64748B"
                  fontSize="9"
                  fontFamily="Inter, sans-serif"
                  fontWeight="500"
                  textAnchor="middle"
                >
                  {c.time}
                </text>
              );
            })}
          </svg>
        </div>
      </div>
    </div>
  );
};
