import React, { useState, useId } from 'react';
import {
  IndexMarketData,
  IndexSymbol,
  OptionType,
  ScannerSignal,
  StrategyLeg,
  StrikeRow,
  UserRole,
} from '../../types';
import { calculateStrategyMetrics, calculateMaxPain } from '../../utils/optionsAnalytics';
import { calculateGreeks } from '../../utils/blackScholes';
import { MOCK_SIGNALS } from '../scanner/StrategyScanner';
import { AnalyticsDashboard } from '../analytics/AnalyticsDashboard';
import {
  AlertCircle,
  AlertTriangle,
  ArrowRight,
  CheckCircle2,
  Copy,
  Download,
  Flame,
  Layers,
  Lock,
  Plus,
  Radar,
  RefreshCw,
  Share2,
  SlidersHorizontal,
  Sparkles,
  Target,
  Trash2,
  TrendingDown,
  TrendingUp,
  Zap,
} from 'lucide-react';

interface StrategyBuilderProps {
  currentIndex: IndexMarketData;
  strikes: StrikeRow[];
  legs: StrategyLeg[];
  onSetLegs: (legs: StrategyLeg[]) => void;
  userRole: UserRole;
  onUpgradeRole?: (role: UserRole) => void;
  onSelectStrikeForStrategy?: (symbol: IndexSymbol, strike: number, type: OptionType) => void;
  initialView?: 'builder' | 'maxpain' | 'scanner';
}

export const StrategyBuilder: React.FC<StrategyBuilderProps> = ({
  currentIndex,
  strikes,
  legs,
  onSetLegs,
  userRole,
  onUpgradeRole,
  onSelectStrikeForStrategy,
  initialView = 'builder',
}) => {
  const [activeSubView, setActiveSubView] = useState<'builder' | 'maxpain' | 'scanner'>(initialView);
  const [hoveredSpot, setHoveredSpot] = useState<number | null>(null);
  const [strategyName, setStrategyName] = useState<string>('Custom Strategy');
  const [copiedNotification, setCopiedNotification] = useState(false);
  const [scannerCategory, setScannerCategory] = useState<string>('ALL');
  const [scannerSentiment, setScannerSentiment] = useState<string>('ALL');
  const [addedSignalNotification, setAddedSignalNotification] = useState<string | null>(null);

  const { spotPrice, strikeStep, lotSize } = currentIndex;
  const atmStrike = Math.round(spotPrice / strikeStep) * strikeStep;
  const maxPain = calculateMaxPain(strikes, spotPrice);

  // Calculate Payoff and Metrics
  const { metrics, payoffPoints } = calculateStrategyMetrics(legs, spotPrice, 4);

  // Quick Strategy Template Presets
  const applyPreset = (presetName: string) => {
    const atmRow = strikes.find((r) => r.strike === atmStrike) || strikes[Math.floor(strikes.length / 2)];
    if (!atmRow) return;

    let newLegs: StrategyLeg[] = [];

    switch (presetName) {
      case 'Long Call': {
        setStrategyName('Long Call (Bullish Momentum)');
        newLegs = [
          {
            id: `leg_${Date.now()}_1`,
            type: 'CE',
            action: 'BUY',
            strike: atmStrike,
            lots: 1,
            lotSize,
            price: atmRow.call.ltp,
            iv: atmRow.call.iv,
            greeks: atmRow.call.greeks,
          },
        ];
        break;
      }
      case 'Long Put': {
        setStrategyName('Long Put (Bearish Downside)');
        newLegs = [
          {
            id: `leg_${Date.now()}_1`,
            type: 'PE',
            action: 'BUY',
            strike: atmStrike,
            lots: 1,
            lotSize,
            price: atmRow.put.ltp,
            iv: atmRow.put.iv,
            greeks: atmRow.put.greeks,
          },
        ];
        break;
      }
      case 'Bull Call Spread': {
        setStrategyName('Bull Call Spread (Controlled Upside)');
        const buyStrike = atmStrike;
        const sellStrike = atmStrike + strikeStep * 2;
        const buyRow = strikes.find((r) => r.strike === buyStrike) || atmRow;
        const sellRow = strikes.find((r) => r.strike === sellStrike) || atmRow;
        newLegs = [
          {
            id: `leg_${Date.now()}_1`,
            type: 'CE',
            action: 'BUY',
            strike: buyStrike,
            lots: 1,
            lotSize,
            price: buyRow.call.ltp,
            iv: buyRow.call.iv,
            greeks: buyRow.call.greeks,
          },
          {
            id: `leg_${Date.now()}_2`,
            type: 'CE',
            action: 'SELL',
            strike: sellStrike,
            lots: 1,
            lotSize,
            price: sellRow.call.ltp,
            iv: sellRow.call.iv,
            greeks: sellRow.call.greeks,
          },
        ];
        break;
      }
      case 'Bear Put Spread': {
        setStrategyName('Bear Put Spread (Controlled Downside)');
        const buyStrike = atmStrike;
        const sellStrike = atmStrike - strikeStep * 2;
        const buyRow = strikes.find((r) => r.strike === buyStrike) || atmRow;
        const sellRow = strikes.find((r) => r.strike === sellStrike) || atmRow;
        newLegs = [
          {
            id: `leg_${Date.now()}_1`,
            type: 'PE',
            action: 'BUY',
            strike: buyStrike,
            lots: 1,
            lotSize,
            price: buyRow.put.ltp,
            iv: buyRow.put.iv,
            greeks: buyRow.put.greeks,
          },
          {
            id: `leg_${Date.now()}_2`,
            type: 'PE',
            action: 'SELL',
            strike: sellStrike,
            lots: 1,
            lotSize,
            price: sellRow.put.ltp,
            iv: sellRow.put.iv,
            greeks: sellRow.put.greeks,
          },
        ];
        break;
      }
      case 'Iron Condor': {
        setStrategyName('Iron Condor (High-Probability Range)');
        const putBuyStrike = atmStrike - strikeStep * 4;
        const putSellStrike = atmStrike - strikeStep * 2;
        const callSellStrike = atmStrike + strikeStep * 2;
        const callBuyStrike = atmStrike + strikeStep * 4;

        const pbRow = strikes.find((r) => r.strike === putBuyStrike) || atmRow;
        const psRow = strikes.find((r) => r.strike === putSellStrike) || atmRow;
        const csRow = strikes.find((r) => r.strike === callSellStrike) || atmRow;
        const cbRow = strikes.find((r) => r.strike === callBuyStrike) || atmRow;

        newLegs = [
          {
            id: `leg_${Date.now()}_1`,
            type: 'PE',
            action: 'BUY',
            strike: putBuyStrike,
            lots: 1,
            lotSize,
            price: pbRow.put.ltp,
            iv: pbRow.put.iv,
            greeks: pbRow.put.greeks,
          },
          {
            id: `leg_${Date.now()}_2`,
            type: 'PE',
            action: 'SELL',
            strike: putSellStrike,
            lots: 1,
            lotSize,
            price: psRow.put.ltp,
            iv: psRow.put.iv,
            greeks: psRow.put.greeks,
          },
          {
            id: `leg_${Date.now()}_3`,
            type: 'CE',
            action: 'SELL',
            strike: callSellStrike,
            lots: 1,
            lotSize,
            price: csRow.call.ltp,
            iv: csRow.call.iv,
            greeks: csRow.call.greeks,
          },
          {
            id: `leg_${Date.now()}_4`,
            type: 'CE',
            action: 'BUY',
            strike: callBuyStrike,
            lots: 1,
            lotSize,
            price: cbRow.call.ltp,
            iv: cbRow.call.iv,
            greeks: cbRow.call.greeks,
          },
        ];
        break;
      }
      case 'Iron Butterfly': {
        setStrategyName('Iron Butterfly (Neutral Theta Harvest)');
        const putWing = atmStrike - strikeStep * 3;
        const callWing = atmStrike + strikeStep * 3;

        const pwRow = strikes.find((r) => r.strike === putWing) || atmRow;
        const cwRow = strikes.find((r) => r.strike === callWing) || atmRow;

        newLegs = [
          {
            id: `leg_${Date.now()}_1`,
            type: 'PE',
            action: 'BUY',
            strike: putWing,
            lots: 1,
            lotSize,
            price: pwRow.put.ltp,
            iv: pwRow.put.iv,
            greeks: pwRow.put.greeks,
          },
          {
            id: `leg_${Date.now()}_2`,
            type: 'PE',
            action: 'SELL',
            strike: atmStrike,
            lots: 1,
            lotSize,
            price: atmRow.put.ltp,
            iv: atmRow.put.iv,
            greeks: atmRow.put.greeks,
          },
          {
            id: `leg_${Date.now()}_3`,
            type: 'CE',
            action: 'SELL',
            strike: atmStrike,
            lots: 1,
            lotSize,
            price: atmRow.call.ltp,
            iv: atmRow.call.iv,
            greeks: atmRow.call.greeks,
          },
          {
            id: `leg_${Date.now()}_4`,
            type: 'CE',
            action: 'BUY',
            strike: callWing,
            lots: 1,
            lotSize,
            price: cwRow.call.ltp,
            iv: cwRow.call.iv,
            greeks: cwRow.call.greeks,
          },
        ];
        break;
      }
      case 'Straddle': {
        setStrategyName('Short Straddle (Delta Neutral High IV)');
        newLegs = [
          {
            id: `leg_${Date.now()}_1`,
            type: 'CE',
            action: 'SELL',
            strike: atmStrike,
            lots: 1,
            lotSize,
            price: atmRow.call.ltp,
            iv: atmRow.call.iv,
            greeks: atmRow.call.greeks,
          },
          {
            id: `leg_${Date.now()}_2`,
            type: 'PE',
            action: 'SELL',
            strike: atmStrike,
            lots: 1,
            lotSize,
            price: atmRow.put.ltp,
            iv: atmRow.put.iv,
            greeks: atmRow.put.greeks,
          },
        ];
        break;
      }
      case 'Strangle': {
        setStrategyName('Short Strangle (OTM Theta Harvesting)');
        const peStrike = atmStrike - strikeStep * 2;
        const ceStrike = atmStrike + strikeStep * 2;
        const peRow = strikes.find((r) => r.strike === peStrike) || atmRow;
        const ceRow = strikes.find((r) => r.strike === ceStrike) || atmRow;
        newLegs = [
          {
            id: `leg_${Date.now()}_1`,
            type: 'PE',
            action: 'SELL',
            strike: peStrike,
            lots: 1,
            lotSize,
            price: peRow.put.ltp,
            iv: peRow.put.iv,
            greeks: peRow.put.greeks,
          },
          {
            id: `leg_${Date.now()}_2`,
            type: 'CE',
            action: 'SELL',
            strike: ceStrike,
            lots: 1,
            lotSize,
            price: ceRow.call.ltp,
            iv: ceRow.call.iv,
            greeks: ceRow.call.greeks,
          },
        ];
        break;
      }
    }

    onSetLegs(newLegs);
  };

  // Add custom leg
  const handleAddCustomLeg = () => {
    const atmRow = strikes.find((r) => r.strike === atmStrike) || strikes[0];
    if (!atmRow) return;

    const newLeg: StrategyLeg = {
      id: `leg_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      type: 'CE',
      action: 'BUY',
      strike: atmStrike,
      lots: 1,
      lotSize,
      price: atmRow.call.ltp,
      iv: atmRow.call.iv,
      greeks: atmRow.call.greeks,
    };

    onSetLegs([...legs, newLeg]);
  };

  // Update Leg
  const handleUpdateLeg = (id: string, updates: Partial<StrategyLeg>) => {
    onSetLegs(
      legs.map((leg) => {
        if (leg.id !== id) return leg;
        const merged = { ...leg, ...updates };

        // If strike or type changed, update price & greeks from row
        if (updates.strike !== undefined || updates.type !== undefined) {
          const row = strikes.find((r) => r.strike === merged.strike);
          if (row) {
            const data = merged.type === 'CE' ? row.call : row.put;
            merged.price = data.ltp;
            merged.iv = data.iv;
            merged.greeks = data.greeks;
          }
        }
        return merged;
      })
    );
  };

  // Remove Leg
  const handleRemoveLeg = (id: string) => {
    onSetLegs(legs.filter((l) => l.id !== id));
  };

  // Add Scanner Signal into Active Strategy Leg
  const handleAddSignalToStrategy = (sig: ScannerSignal) => {
    const row = strikes.find((r) => r.strike === sig.strike);
    const data = row ? (sig.type === 'CE' ? row.call : row.put) : null;
    const ltp = data ? data.ltp : 125.5;
    const iv = data ? data.iv : 13.8;
    const greeks = data
      ? data.greeks
      : {
          delta: sig.type === 'CE' ? 0.48 : -0.48,
          gamma: 0.002,
          theta: -14.2,
          vega: 16.5,
          rho: 1.5,
          iv: 13.8,
        };

    const action = sig.sentiment === 'BEARISH' && sig.category === 'UNUSUAL_OI' ? 'SELL' : 'BUY';
    const newLeg: StrategyLeg = {
      id: `leg_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      type: sig.type,
      action,
      strike: sig.strike,
      lots: 1,
      lotSize,
      price: ltp,
      iv,
      greeks,
    };

    onSetLegs([...legs, newLeg]);
    setStrategyName(`${sig.symbol} ${sig.strike} ${sig.type} (${sig.category.replace('_', ' ')})`);
    setAddedSignalNotification(
      `Added ${sig.symbol} ${sig.strike} ${sig.type} (${action} @ ₹${ltp}) into Payoff Model!`
    );
    setTimeout(() => setAddedSignalNotification(null), 3500);
  };

  // Replace current strategy with this Scanner Signal
  const handleLoadSignalAsSetup = (sig: ScannerSignal) => {
    const row = strikes.find((r) => r.strike === sig.strike);
    const data = row ? (sig.type === 'CE' ? row.call : row.put) : null;
    const ltp = data ? data.ltp : 125.5;
    const iv = data ? data.iv : 13.8;
    const greeks = data
      ? data.greeks
      : {
          delta: sig.type === 'CE' ? 0.48 : -0.48,
          gamma: 0.002,
          theta: -14.2,
          vega: 16.5,
          rho: 1.5,
          iv: 13.8,
        };

    const action = sig.sentiment === 'BEARISH' && sig.category === 'UNUSUAL_OI' ? 'SELL' : 'BUY';
    const newLeg: StrategyLeg = {
      id: `leg_${Date.now()}`,
      type: sig.type,
      action,
      strike: sig.strike,
      lots: 1,
      lotSize,
      price: ltp,
      iv,
      greeks,
    };

    onSetLegs([newLeg]);
    setStrategyName(`${sig.title}`);
    setAddedSignalNotification(`Loaded "${sig.title}" into Strategy Payoff Builder!`);
    setActiveSubView('builder');
    setTimeout(() => setAddedSignalNotification(null), 3500);
  };

  // Copy strategy summary to clipboard
  const handleCopySummary = () => {
    const summary = `${strategyName} (${currentIndex.symbol})\n` +
      legs.map((l) => `${l.action} ${l.lots}x ${l.strike} ${l.type} @ ₹${l.price}`).join('\n') +
      `\nNet Credit/Debit: ₹${metrics.netCreditDebit.toFixed(0)} | POP: ${metrics.probabilityOfProfit}%`;
    navigator.clipboard.writeText(summary);
    setCopiedNotification(true);
    setTimeout(() => setCopiedNotification(false), 2500);
  };

  // SVG dimensions for Payoff diagram
  const svgWidth = 800;
  const svgHeight = 280;
  const paddingX = 40;
  const paddingY = 30;

  let minP = -1000;
  let maxP = 1000;
  let minSpot = spotPrice * 0.9;
  let maxSpot = spotPrice * 1.1;

  if (payoffPoints.length > 0) {
    minSpot = payoffPoints[0].spotPrice;
    maxSpot = payoffPoints[payoffPoints.length - 1].spotPrice;
    payoffPoints.forEach((p) => {
      if (p.expiryPayoff < minP) minP = p.expiryPayoff;
      if (p.expiryPayoff > maxP) maxP = p.expiryPayoff;
      if (p.t0Payoff < minP) minP = p.t0Payoff;
      if (p.t0Payoff > maxP) maxP = p.t0Payoff;
    });
  }

  // Symmetrical margin for clean zero line
  const absBound = Math.max(Math.abs(minP), Math.abs(maxP)) * 1.15 || 5000;
  const yZero = svgHeight * 0.5;

  const getSvgX = (spot: number): number => {
    if (!Number.isFinite(spot)) return paddingX;
    const diff = maxSpot - minSpot;
    const ratio = diff > 0 ? (spot - minSpot) / diff : 0.5;
    const res = paddingX + ratio * (svgWidth - paddingX * 2);
    return Number.isFinite(res) ? res : paddingX;
  };

  const getSvgY = (pnl: number): number => {
    if (!Number.isFinite(pnl)) return yZero;
    const bound = absBound > 0 ? absBound : 5000;
    const ratio = pnl / bound;
    const res = yZero - ratio * (svgHeight * 0.5 - paddingY);
    return Number.isFinite(res) ? res : yZero;
  };

  // Payoff path
  const expiryPath = payoffPoints.length > 0
    ? payoffPoints.reduce((acc, p, i) => {
        return `${acc} ${i === 0 ? 'M' : 'L'} ${getSvgX(p.spotPrice)} ${getSvgY(p.expiryPayoff)}`;
      }, '')
    : '';

  const t0Path = payoffPoints.length > 0
    ? payoffPoints.reduce((acc, p, i) => {
        return `${acc} ${i === 0 ? 'M' : 'L'} ${getSvgX(p.spotPrice)} ${getSvgY(p.t0Payoff)}`;
      }, '')
    : '';

  // Find hovered payoff safely with initial value
  const hoveredPoint =
    hoveredSpot !== null && payoffPoints.length > 0
      ? payoffPoints.reduce(
          (prev, curr) =>
            Math.abs(curr.spotPrice - hoveredSpot) < Math.abs(prev.spotPrice - hoveredSpot)
              ? curr
              : prev,
          payoffPoints[0]
        )
      : null;

  const isLocked = userRole === 'RETAIL';

  const filteredSignals = MOCK_SIGNALS.filter((sig) => {
    if (scannerCategory !== 'ALL' && sig.category !== scannerCategory) return false;
    if (scannerSentiment !== 'ALL' && sig.sentiment !== scannerSentiment) return false;
    return true;
  });

  return (
    <div className="p-4 space-y-4 bg-[#0a0e17] overflow-y-auto text-slate-200 text-xs">
      {/* Top Unified Hub Header & View Switcher */}
      <div className="flex flex-wrap items-center justify-between bg-[#0f1422] border border-slate-800 rounded-xl p-3 shadow-lg gap-3">
        <div className="flex items-center space-x-3">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center text-slate-950 font-black shadow-md shadow-cyan-500/20">
            <Sparkles className="w-4 h-4 text-white" />
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <h2 className="text-sm font-bold text-white tracking-tight">
                Strategy & Scanner Hub
              </h2>
              <span className="bg-cyan-500/15 text-cyan-400 border border-cyan-500/30 text-[9.5px] font-bold px-1.5 py-0.2 rounded uppercase">
                Unified Engine
              </span>
              <span className="text-[10px] text-slate-400 font-mono-num bg-slate-900 border border-slate-800 px-1.5 py-0.2 rounded">
                {legs.length} Active {legs.length === 1 ? 'Leg' : 'Legs'}
              </span>
            </div>
            <div className="text-[10.5px] text-slate-400">
              Interactive multi-leg payoff curves, live Greeks, and institutional unusual OI detection
            </div>
          </div>
        </div>

        {/* View Switcher: Builder | Max Pain | Scanner */}
        <div className="flex items-center space-x-1 bg-slate-900/90 border border-slate-800 p-1 rounded-lg">
          <button
            onClick={() => setActiveSubView('builder')}
            className={`px-3 py-1.5 rounded text-xs font-semibold flex items-center space-x-1.5 transition-all ${
              activeSubView === 'builder'
                ? 'bg-cyan-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
            }`}
          >
            <Zap className="w-3.5 h-3.5" />
            <span>Payoff & Builder</span>
          </button>
          <button
            onClick={() => setActiveSubView('maxpain')}
            className={`px-3 py-1.5 rounded text-xs font-semibold flex items-center space-x-1.5 transition-all ${
              activeSubView === 'maxpain'
                ? 'bg-purple-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
            }`}
          >
            <Target className="w-3.5 h-3.5 text-purple-300" />
            <span>Max Pain & Expiry</span>
            <span className="ml-1 text-[10px] px-1.5 py-0.2 rounded font-mono font-bold bg-purple-950 text-purple-300 border border-purple-800">
              {maxPain.maxPainStrike}
            </span>
          </button>
          <button
            onClick={() => setActiveSubView('scanner')}
            className={`px-3 py-1.5 rounded text-xs font-semibold flex items-center space-x-1.5 transition-all ${
              activeSubView === 'scanner'
                ? 'bg-cyan-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
            }`}
          >
            <Radar className="w-3.5 h-3.5 text-cyan-300" />
            <span>OI & Scanner</span>
            <span className="ml-1 text-[10px] px-1.5 py-0.2 rounded-full bg-slate-800 text-cyan-400 border border-slate-700 font-mono">
              {filteredSignals.length}
            </span>
          </button>
        </div>
      </div>

      {/* Added Signal Toast */}
      {addedSignalNotification && (
        <div className="bg-emerald-950/90 border border-emerald-700 text-emerald-300 px-3.5 py-2 rounded-lg text-xs flex items-center justify-between shadow-lg">
          <div className="flex items-center space-x-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            <span className="font-semibold">{addedSignalNotification}</span>
          </div>
          <div className="flex items-center space-x-2">
            {activeSubView === 'scanner' && (
              <button
                onClick={() => {
                  setActiveSubView('builder');
                  setAddedSignalNotification(null);
                }}
                className="bg-emerald-800 hover:bg-emerald-700 text-white font-semibold px-2.5 py-1 rounded text-[11px] transition-colors flex items-center space-x-1"
              >
                <span>View in Payoff Builder</span>
                <ArrowRight className="w-3 h-3" />
              </button>
            )}
            <button
              onClick={() => setAddedSignalNotification(null)}
              className="text-emerald-400 hover:text-white text-[11px] underline"
            >
              Dismiss
            </button>
          </div>
        </div>
      )}

      {/* Strategy Preset Selector Bar (Shown in builder view) */}
      {activeSubView === 'builder' && (
        <>
          <div className="bg-[#0f1422] border border-slate-800 rounded-xl p-3 shadow-lg">
            <div className="flex flex-wrap items-center justify-between gap-2 mb-2.5">
              <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider flex items-center space-x-1.5">
                <Zap className="w-3.5 h-3.5 text-cyan-400" />
                <span>Pre-Built Strategy Templates:</span>
              </span>

          <div className="flex items-center space-x-2">
            <button
              onClick={handleCopySummary}
              className="flex items-center space-x-1 px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 text-[11px] transition-colors"
            >
              {copiedNotification ? (
                <>
                  <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                  <span className="text-emerald-400">Copied!</span>
                </>
              ) : (
                <>
                  <Copy className="w-3 h-3 text-slate-400" />
                  <span>Copy Strategy</span>
                </>
              )}
            </button>

            <button
              onClick={handleAddCustomLeg}
              className="bg-cyan-600 hover:bg-cyan-500 text-white px-3 py-1 rounded text-[11px] font-bold flex items-center space-x-1 transition-colors"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add Custom Leg</span>
            </button>
          </div>
        </div>

        <div className="flex flex-wrap gap-1.5">
          {[
            'Long Call',
            'Long Put',
            'Bull Call Spread',
            'Bear Put Spread',
            'Iron Condor',
            'Iron Butterfly',
            'Straddle',
            'Strangle',
          ].map((preset) => (
            <button
              key={preset}
              onClick={() => applyPreset(preset)}
              className="bg-slate-900 hover:bg-slate-800 border border-slate-800 hover:border-slate-700 text-slate-300 hover:text-white px-2.5 py-1 rounded text-[11px] font-medium transition-all"
            >
              {preset}
            </button>
          ))}
        </div>
      </div>

      {/* Main Grid: Strategy Legs Table (Left) & Payoff Curve (Right) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Legs Table (5 cols on lg) */}
        <div className="lg:col-span-6 bg-[#0f1422] border border-slate-800 rounded-xl p-4 shadow-lg flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div>
                <h3 className="text-sm font-bold text-white flex items-center space-x-1.5">
                  <span>{strategyName}</span>
                </h3>
                <div className="text-[11px] text-slate-400">
                  {legs.length} Active Leg{legs.length === 1 ? '' : 's'} | Symbol: {currentIndex.symbol}
                </div>
              </div>
              {legs.length > 0 && (
                <button
                  onClick={() => onSetLegs([])}
                  className="text-rose-400 hover:text-rose-300 text-[11px] flex items-center space-x-1"
                >
                  <Trash2 className="w-3 h-3" />
                  <span>Clear All</span>
                </button>
              )}
            </div>

            {/* Legs List */}
            <div className="mt-3 space-y-2 max-h-[320px] overflow-y-auto">
              {legs.length === 0 ? (
                <div className="text-center py-10 text-slate-500">
                  <div className="text-sm font-semibold mb-1">No Strategy Legs Added</div>
                  <div className="text-[11px]">
                    Click any strike on the Option Chain or select a template above to simulate.
                  </div>
                </div>
              ) : (
                legs.map((leg, index) => (
                  <div
                    key={leg.id}
                    className="bg-slate-900/90 border border-slate-800 rounded-lg p-2.5 flex items-center justify-between gap-2 text-xs"
                  >
                    <div className="flex items-center space-x-2">
                      <span className="font-mono-num text-slate-500 font-bold text-[10px]">
                        #{index + 1}
                      </span>

                      {/* Buy / Sell Toggle */}
                      <button
                        onClick={() =>
                          handleUpdateLeg(leg.id, {
                            action: leg.action === 'BUY' ? 'SELL' : 'BUY',
                          })
                        }
                        className={`px-2 py-0.5 rounded text-[10px] font-black uppercase transition-colors ${
                          leg.action === 'BUY'
                            ? 'bg-emerald-600 text-white'
                            : 'bg-rose-600 text-white'
                        }`}
                      >
                        {leg.action}
                      </button>

                      {/* CE / PE Toggle */}
                      <button
                        onClick={() =>
                          handleUpdateLeg(leg.id, {
                            type: leg.type === 'CE' ? 'PE' : 'CE',
                          })
                        }
                        className="bg-slate-800 text-cyan-300 px-2 py-0.5 rounded text-[10px] font-bold border border-slate-700 uppercase"
                      >
                        {leg.type}
                      </button>

                      {/* Strike dropdown */}
                      <select
                        value={leg.strike}
                        onChange={(e) =>
                          handleUpdateLeg(leg.id, { strike: Number(e.target.value) })
                        }
                        className="bg-slate-800 text-white border border-slate-700 rounded px-2 py-0.5 text-xs font-mono-num focus:outline-none"
                      >
                        {strikes.map((r) => (
                          <option key={r.strike} value={r.strike}>
                            {r.strike} {r.isAtm ? '(ATM)' : ''}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div className="flex items-center space-x-2">
                      {/* Lots input */}
                      <div className="flex items-center space-x-1">
                        <span className="text-[10px] text-slate-500">Lots:</span>
                        <input
                          type="number"
                          min="1"
                          max="50"
                          value={leg.lots}
                          onChange={(e) =>
                            handleUpdateLeg(leg.id, { lots: Math.max(1, Number(e.target.value)) })
                          }
                          className="w-12 bg-slate-800 text-center text-white border border-slate-700 rounded py-0.5 text-xs font-mono-num"
                        />
                      </div>

                      {/* Price input */}
                      <div className="flex items-center space-x-1">
                        <span className="text-[10px] text-slate-500">Price:</span>
                        <input
                          type="number"
                          step="0.05"
                          value={leg.price}
                          onChange={(e) =>
                            handleUpdateLeg(leg.id, { price: Number(e.target.value) })
                          }
                          className="w-16 bg-slate-800 text-center text-white border border-slate-700 rounded py-0.5 text-xs font-mono-num"
                        />
                      </div>

                      {/* Remove Button */}
                      <button
                        onClick={() => handleRemoveLeg(leg.id)}
                        className="text-slate-500 hover:text-rose-400 p-1 transition-colors"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>

          {/* Strategy Summary Bar */}
          <div className="mt-4 pt-3 border-t border-slate-800 grid grid-cols-2 sm:grid-cols-4 gap-2 text-center">
            <div className="bg-slate-900/60 p-2 rounded border border-slate-800">
              <div className="text-[10px] text-slate-400">Net Premium</div>
              <div
                className={`font-mono-num font-bold text-xs mt-0.5 ${
                  metrics.netCreditDebit >= 0 ? 'text-emerald-400' : 'text-rose-400'
                }`}
              >
                {metrics.netCreditDebit >= 0 ? '+' : ''}₹{metrics.netCreditDebit.toLocaleString('en-IN', { maximumFractionDigits: 0 })}
                <span className="text-[9px] block text-slate-500 font-normal">
                  {metrics.netCreditDebit >= 0 ? 'CREDIT RECEIVED' : 'DEBIT PAID'}
                </span>
              </div>
            </div>

            <div className="bg-slate-900/60 p-2 rounded border border-slate-800">
              <div className="text-[10px] text-slate-400">Max Profit</div>
              <div className="font-mono-num font-bold text-xs text-emerald-400 mt-0.5">
                {typeof metrics.maxProfit === 'number'
                  ? `₹${metrics.maxProfit.toLocaleString('en-IN')}`
                  : 'UNLIMITED'}
              </div>
            </div>

            <div className="bg-slate-900/60 p-2 rounded border border-slate-800">
              <div className="text-[10px] text-slate-400">Max Loss</div>
              <div className="font-mono-num font-bold text-xs text-rose-400 mt-0.5">
                {typeof metrics.maxLoss === 'number'
                  ? `₹${metrics.maxLoss.toLocaleString('en-IN')}`
                  : 'UNLIMITED'}
              </div>
            </div>

            <div className="bg-slate-900/60 p-2 rounded border border-slate-800">
              <div className="text-[10px] text-slate-400">Probability of Profit</div>
              <div className="font-mono-num font-bold text-xs text-cyan-400 mt-0.5">
                {metrics.probabilityOfProfit}%
              </div>
            </div>
          </div>
        </div>

        {/* Payoff Graph Viewport (6 cols on lg) */}
        <div className="lg:col-span-6 bg-[#0f1422] border border-slate-800 rounded-xl p-4 shadow-lg flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <div>
                <h3 className="text-sm font-bold text-white flex items-center space-x-2">
                  <span>Interactive Payoff Curve</span>
                </h3>
                <div className="text-[11px] text-slate-400">
                  Green Line = Expiry Settlement | Cyan Dashed = T+0 Current Day
                </div>
              </div>

              {hoveredPoint && (
                <div className="text-right text-[11px] bg-slate-900 px-2 py-1 rounded border border-slate-800">
                  <span className="text-slate-400">At {hoveredPoint.spotPrice}: </span>
                  <span
                    className={`font-mono-num font-bold ${
                      hoveredPoint.expiryPayoff >= 0 ? 'text-emerald-400' : 'text-rose-400'
                    }`}
                  >
                    {hoveredPoint.expiryPayoff >= 0 ? '+' : ''}₹{hoveredPoint.expiryPayoff.toFixed(0)}
                  </span>
                </div>
              )}
            </div>

            {/* SVG Graph Container */}
            <div className="mt-2 w-full h-[230px] bg-[#FFFFFF] rounded-[12px] border border-[#E2E8F0] relative overflow-hidden">
              <svg
                viewBox={`0 0 ${svgWidth} ${svgHeight}`}
                className="w-full h-full cursor-crosshair"
                onMouseMove={(e) => {
                  const rect = e.currentTarget.getBoundingClientRect();
                  const x = ((e.clientX - rect.left) / rect.width) * svgWidth;
                  const ratio = (x - paddingX) / (svgWidth - paddingX * 2);
                  const spot = minSpot + ratio * (maxSpot - minSpot);
                  setHoveredSpot(Math.round(spot));
                }}
                onMouseLeave={() => setHoveredSpot(null)}
              >
                {/* Horizontal Zero P&L Line */}
                <line
                  x1="0"
                  y1={yZero}
                  x2={svgWidth}
                  y2={yZero}
                  stroke="#CBD5E1"
                  strokeWidth="1.5"
                  strokeDasharray="4 4"
                />

                {/* Vertical Spot Price Line */}
                <line
                  x1={getSvgX(spotPrice)}
                  y1="0"
                  x2={getSvgX(spotPrice)}
                  y2={svgHeight}
                  stroke="#2563EB"
                  strokeWidth="1.2"
                  strokeDasharray="3 3"
                />
                <text
                  x={getSvgX(spotPrice)}
                  y="16"
                  fill="#2563EB"
                  fontSize="10"
                  fontFamily="Inter, sans-serif"
                  textAnchor="middle"
                  fontWeight="600"
                >
                  Spot {spotPrice.toFixed(0)}
                </text>

                {/* Breakeven lines */}
                {metrics.breakevens.map((be) => (
                  <g key={be}>
                    <line
                      x1={getSvgX(be)}
                      y1="0"
                      x2={getSvgX(be)}
                      y2={svgHeight}
                      stroke="#F59E0B"
                      strokeWidth="1.2"
                      strokeDasharray="2 2"
                    />
                    <text
                      x={getSvgX(be)}
                      y={svgHeight - 12}
                      fill="#B45309"
                      fontSize="9"
                      fontFamily="Inter, sans-serif"
                      fontWeight="600"
                      textAnchor="middle"
                    >
                      BE {be}
                    </text>
                  </g>
                ))}

                {/* T+0 Line (Current theoretical Black-Scholes payoff) */}
                <path d={t0Path} fill="none" stroke="#2563EB" strokeWidth="1.5" strokeDasharray="3 3" opacity="0.85" />

                {/* Expiry Payoff Path */}
                <path d={expiryPath} fill="none" stroke="#16A34A" strokeWidth="2.5" />

                {/* Hover cursor */}
                {hoveredSpot && hoveredPoint && (
                  <g>
                    <line
                      x1={getSvgX(hoveredSpot)}
                      y1="0"
                      x2={getSvgX(hoveredSpot)}
                      y2={svgHeight}
                      stroke="#64748B"
                      strokeWidth="1"
                      opacity="0.5"
                    />
                    <circle
                      cx={getSvgX(hoveredSpot)}
                      cy={getSvgY(hoveredPoint.expiryPayoff)}
                      r="4.5"
                      fill={hoveredPoint.expiryPayoff >= 0 ? '#16A34A' : '#DC2626'}
                      stroke="#FFFFFF"
                      strokeWidth="1.5"
                    />
                  </g>
                )}
              </svg>
            </div>
          </div>

          {/* Strategy Greeks & Margins */}
          <div className="mt-3 pt-2 border-t border-slate-800 grid grid-cols-5 gap-2 text-center text-[10px]">
            <div className="bg-slate-900/60 p-1.5 rounded">
              <span className="text-slate-400 block">Delta (Δ)</span>
              <span className="font-mono-num font-bold text-slate-200">{metrics.netDelta.toFixed(1)}</span>
            </div>
            <div className="bg-slate-900/60 p-1.5 rounded">
              <span className="text-slate-400 block">Theta (θ)</span>
              <span className={`font-mono-num font-bold ${metrics.netTheta >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                {metrics.netTheta.toFixed(1)}
              </span>
            </div>
            <div className="bg-slate-900/60 p-1.5 rounded">
              <span className="text-slate-400 block">Gamma (γ)</span>
              <span className="font-mono-num font-bold text-slate-200">{metrics.netGamma.toFixed(3)}</span>
            </div>
            <div className="bg-slate-900/60 p-1.5 rounded">
              <span className="text-slate-400 block">Vega (ν)</span>
              <span className="font-mono-num font-bold text-slate-200">{metrics.netVega.toFixed(1)}</span>
            </div>
            <div className="bg-slate-900/60 p-1.5 rounded">
              <span className="text-slate-400 block">Est. Margin</span>
              <span className="font-mono-num font-bold text-cyan-400">
                ₹{(metrics.estimatedMargin / 100000).toFixed(1)}L
              </span>
            </div>
          </div>
        </div>
      </div>
    </>
  )}

      {/* Max Pain & Expiry Section (Shown in maxpain view) */}
      {activeSubView === 'maxpain' && (
        <div className="space-y-4">
          <div className="bg-[#0f1422] border border-purple-900/60 rounded-xl p-3.5 flex flex-wrap items-center justify-between gap-3 shadow-lg">
            <div className="flex items-center space-x-2.5">
              <div className="p-2 rounded-lg bg-purple-950 border border-purple-700 text-purple-400">
                <Target className="w-4 h-4" />
              </div>
              <div>
                <div className="flex items-center space-x-2">
                  <span className="text-xs font-bold text-white">Max Pain Strike:</span>
                  <span className="text-purple-400 font-mono font-black text-sm">{maxPain.maxPainStrike}</span>
                  <span
                    className={`text-[11px] font-mono font-semibold px-2 py-0.5 rounded ${
                      maxPain.distanceFromSpot >= 0
                        ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                        : 'bg-rose-950 text-rose-300 border border-rose-800'
                    }`}
                  >
                    {maxPain.distanceFromSpot >= 0 ? '+' : ''}
                    {maxPain.distanceFromSpot.toFixed(1)} pts ({maxPain.distancePercent}%)
                  </span>
                </div>
                <p className="text-[11px] text-slate-400 mt-0.5">
                  Point of maximum financial loss for option buyers where option writers have least payout liability at expiry.
                </p>
              </div>
            </div>

            <div className="flex items-center space-x-2">
              <button
                onClick={() => {
                  applyPreset('LONG_STRADDLE');
                  setActiveSubView('builder');
                }}
                className="px-3 py-1.5 bg-purple-600 hover:bg-purple-500 text-white rounded-lg text-xs font-semibold flex items-center space-x-1.5 shadow-md transition-all"
              >
                <Zap className="w-3.5 h-3.5" />
                <span>Simulate Payoff at Max Pain ({maxPain.maxPainStrike})</span>
              </button>
            </div>
          </div>

          <AnalyticsDashboard currentIndex={currentIndex} strikes={strikes} focusSection="MAX_PAIN" />
        </div>
      )}

      {/* Institutional Strategy & Unusual OI Scanner (Shown in scanner view) */}
      {activeSubView === 'scanner' && (
        <div className="bg-[#0f1422] border border-slate-800 rounded-xl p-4 shadow-lg space-y-3.5">
          {/* Header */}
          <div className="flex flex-wrap items-center justify-between pb-3 border-b border-slate-800 gap-2">
            <div>
              <div className="flex items-center space-x-2">
                <Radar className="w-4 h-4 text-cyan-400 animate-pulse" />
                <h3 className="text-sm font-bold text-white">
                  Institutional Strategy & Unusual OI Scanner
                </h3>
                <span className="bg-amber-500/15 text-amber-400 border border-amber-500/30 text-[10px] font-bold px-2 py-0.5 rounded">
                  PRO RADAR
                </span>
                <span className="text-[10px] text-slate-400 bg-slate-900 border border-slate-800 px-2 py-0.5 rounded font-mono">
                  {filteredSignals.length} Signals Detected
                </span>
              </div>
              <p className="text-[11px] text-slate-400 mt-0.5">
                Automated detection of institutional block writing, heavy put defense, and gamma squeeze setups. Click "+ Add to Payoff" to simulate with live payoff curve.
              </p>
            </div>

            {/* Filters */}
            <div className="flex items-center space-x-2">
              <select
                value={scannerCategory}
                onChange={(e) => setScannerCategory(e.target.value)}
                className="bg-slate-900 border border-slate-700/80 rounded px-2.5 py-1 text-slate-200 text-xs focus:outline-none cursor-pointer"
              >
                <option value="ALL">All Categories</option>
                <option value="UNUSUAL_OI">Unusual OI Surge</option>
                <option value="PUT_WRITING">Put Writing Base</option>
                <option value="SHORT_COVERING">Short Covering</option>
                <option value="IV_SPIKE">IV Spike</option>
                <option value="BREAKOUT">Gamma Breakout</option>
              </select>

              <select
                value={scannerSentiment}
                onChange={(e) => setScannerSentiment(e.target.value)}
                className="bg-slate-900 border border-slate-700/80 rounded px-2.5 py-1 text-slate-200 text-xs focus:outline-none cursor-pointer"
              >
                <option value="ALL">All Sentiments</option>
                <option value="BULLISH">Bullish Signals</option>
                <option value="BEARISH">Bearish Signals</option>
                <option value="NEUTRAL">Neutral / Volatility</option>
              </select>
            </div>
          </div>

          {/* Role Gate Banner if Retail User */}
          {isLocked && onUpgradeRole && (
            <div className="bg-gradient-to-r from-amber-950/40 via-purple-950/40 to-slate-900 border border-amber-500/40 rounded-xl p-3.5 flex flex-wrap items-center justify-between gap-3 shadow-xl">
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 rounded-full bg-amber-500/20 flex items-center justify-center text-amber-400 flex-shrink-0">
                  <Lock className="w-4 h-4" />
                </div>
                <div>
                  <div className="font-bold text-white text-xs">
                    Institutional Scanner Preview Mode
                  </div>
                  <div className="text-[10.5px] text-slate-400">
                    Retail Free mode shows preview signals. Instant 1-click upgrade to test full Pro algorithm setups.
                  </div>
                </div>
              </div>

              <button
                onClick={() => onUpgradeRole('PREMIUM')}
                className="bg-amber-500 hover:bg-amber-400 text-slate-950 font-black px-3 py-1.5 rounded-lg text-xs flex items-center space-x-1.5 shadow-md shadow-amber-500/20 transition-all"
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span>Unlock Pro Scanner</span>
              </button>
            </div>
          )}

          {/* Signals List */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {filteredSignals.map((signal) => {
              const isBull = signal.sentiment === 'BULLISH';
              const isBear = signal.sentiment === 'BEARISH';
              const isAlreadyInLegs = legs.some(
                (l) => l.strike === signal.strike && l.type === signal.type
              );

              return (
                <div
                  key={signal.id}
                  className={`bg-[#0a0e17] border rounded-xl p-3.5 transition-all shadow-md flex flex-col justify-between space-y-2.5 ${
                    isAlreadyInLegs
                      ? 'border-cyan-500/60 bg-cyan-950/10'
                      : 'border-slate-800 hover:border-slate-700'
                  }`}
                >
                  <div className="space-y-1.5">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <span className="font-black text-white text-xs">{signal.symbol}</span>
                        <span className="font-mono-num font-bold text-cyan-400 text-xs">
                          {signal.strike}
                        </span>
                        <span
                          className={`px-1.5 py-0.2 rounded text-[10px] font-black ${
                            signal.type === 'CE'
                              ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                              : 'bg-rose-950 text-rose-400 border border-rose-800'
                          }`}
                        >
                          {signal.type}
                        </span>
                        <span
                          className={`px-1.5 py-0.2 rounded text-[9.5px] font-bold flex items-center space-x-1 ${
                            isBull
                              ? 'bg-emerald-950/80 text-emerald-300 border border-emerald-700'
                              : isBear
                              ? 'bg-rose-950/80 text-rose-300 border border-rose-700'
                              : 'bg-amber-950/80 text-amber-300 border border-amber-700'
                          }`}
                        >
                          {isBull && <TrendingUp className="w-2.5 h-2.5" />}
                          {isBear && <TrendingDown className="w-2.5 h-2.5" />}
                          <span>{signal.sentiment}</span>
                        </span>
                      </div>

                      <span className="text-[10px] text-slate-500 font-mono-num">
                        {signal.timestamp}
                      </span>
                    </div>

                    <div className="font-bold text-slate-100 text-xs">{signal.title}</div>
                    <div className="text-[11px] text-slate-400 leading-relaxed">
                      {signal.description}
                    </div>
                  </div>

                  {/* Stats & Instant Merge Action */}
                  <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between">
                    <div className="flex items-center space-x-3 font-mono-num text-[11px]">
                      <div>
                        <span className="text-slate-500 text-[10px] mr-1">OI Move:</span>
                        <span
                          className={`font-bold ${
                            signal.oiChangePercent >= 0 ? 'text-emerald-400' : 'text-rose-400'
                          }`}
                        >
                          {signal.oiChangePercent >= 0 ? '+' : ''}
                          {signal.oiChangePercent}%
                        </span>
                      </div>
                      <div>
                        <span className="text-slate-500 text-[10px] mr-1">Vol:</span>
                        <span className="text-slate-300 font-semibold">+{signal.volumePercent}%</span>
                      </div>
                    </div>

                    <div className="flex items-center space-x-2">
                      <button
                        onClick={() => handleLoadSignalAsSetup(signal)}
                        className="px-2 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 text-[10.5px] font-semibold transition-colors"
                        title="Replace builder legs with this signal setup"
                      >
                        Load Setup
                      </button>

                      <button
                        onClick={() => handleAddSignalToStrategy(signal)}
                        className={`px-2.5 py-1 rounded text-[11px] font-bold flex items-center space-x-1 transition-all ${
                          isAlreadyInLegs
                            ? 'bg-cyan-900/60 border border-cyan-500 text-cyan-200'
                            : 'bg-cyan-600 hover:bg-cyan-500 text-white shadow-sm'
                        }`}
                        title="Add this strike into the active Strategy Payoff model"
                      >
                        <Plus className="w-3 h-3" />
                        <span>{isAlreadyInLegs ? 'Add Another Lot' : '+ Add to Payoff'}</span>
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};
