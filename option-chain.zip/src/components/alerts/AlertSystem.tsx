import React, { useState } from 'react';
import {
  AlertItem,
  IndexMarketData,
  IndexSymbol,
  OptionType,
  WatchlistItem,
} from '../../types';
import { soundEngine } from '../../utils/audioAlert';
import {
  AlertTriangle,
  Bell,
  Bookmark,
  CheckCircle2,
  Clock,
  ExternalLink,
  MessageSquare,
  Plus,
  Send,
  Trash2,
  Volume2,
  Zap,
} from 'lucide-react';

interface AlertSystemProps {
  alerts: AlertItem[];
  watchlist: WatchlistItem[];
  currentIndex: IndexMarketData;
  onAddAlert: (alert: Omit<AlertItem, 'id' | 'createdAt' | 'triggered'>) => void;
  onDeleteAlert: (id: string) => void;
  onAddWatchlist: (item: Omit<WatchlistItem, 'id' | 'addedAt'>) => void;
  onDeleteWatchlist: (id: string) => void;
}

export const AlertSystem: React.FC<AlertSystemProps> = ({
  alerts,
  watchlist,
  currentIndex,
  onAddAlert,
  onDeleteAlert,
  onAddWatchlist,
  onDeleteWatchlist,
}) => {
  const [activeTab, setActiveTab] = useState<'ALERTS' | 'WATCHLIST' | 'TELEGRAM'>('ALERTS');

  // New alert form state
  const [alertType, setAlertType] = useState<AlertItem['type']>('PRICE');
  const [alertSymbol, setAlertSymbol] = useState<IndexSymbol>(currentIndex.symbol);
  const [alertCondition, setAlertCondition] = useState<AlertItem['condition']>('ABOVE');
  const [alertThreshold, setAlertThreshold] = useState<number>(Math.round(currentIndex.spotPrice + 100));
  const [alertStrike, setAlertStrike] = useState<number>(25000);
  const [alertOptionType, setAlertOptionType] = useState<OptionType>('CE');
  const [alertTelegram, setAlertTelegram] = useState<boolean>(true);
  const [alertNote, setAlertNote] = useState<string>('Major breakout level');

  // Telegram test state
  const [botToken, setBotToken] = useState<string>('7129384912:AAH9fkl90x...');
  const [chatId, setChatId] = useState<string>('-10029384819');
  const [telegramStatus, setTelegramStatus] = useState<string>('');

  const handleCreateAlert = (e: React.FormEvent) => {
    e.preventDefault();
    onAddAlert({
      type: alertType,
      symbol: alertSymbol,
      strike: alertType === 'OI' ? alertStrike : undefined,
      optionType: alertType === 'OI' ? alertOptionType : undefined,
      condition: alertCondition,
      threshold: Number(alertThreshold),
      active: true,
      telegramEnabled: alertTelegram,
      note: alertNote,
    });
    soundEngine.playClickSound();
  };

  const handleTestTelegram = () => {
    setTelegramStatus('Sending test payload...');
    setTimeout(() => {
      setTelegramStatus('✅ Test notification successfully sent to Telegram channel!');
      soundEngine.playAlertSound();
    }, 1000);
  };

  return (
    <div className="p-4 space-y-4 bg-[#0a0e17] overflow-y-auto text-slate-200 text-xs">
      {/* Sub tabs */}
      <div className="flex items-center space-x-2 border-b border-slate-800 pb-2">
        <button
          onClick={() => setActiveTab('ALERTS')}
          className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-lg font-semibold transition-colors ${
            activeTab === 'ALERTS'
              ? 'bg-cyan-600 text-white shadow-sm'
              : 'text-slate-400 hover:text-white bg-slate-900'
          }`}
        >
          <Bell className="w-3.5 h-3.5" />
          <span>Active Alerts ({alerts.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('WATCHLIST')}
          className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-lg font-semibold transition-colors ${
            activeTab === 'WATCHLIST'
              ? 'bg-cyan-600 text-white shadow-sm'
              : 'text-slate-400 hover:text-white bg-slate-900'
          }`}
        >
          <Bookmark className="w-3.5 h-3.5" />
          <span>Watchlist & Contracts ({watchlist.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('TELEGRAM')}
          className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-lg font-semibold transition-colors ${
            activeTab === 'TELEGRAM'
              ? 'bg-cyan-600 text-white shadow-sm'
              : 'text-slate-400 hover:text-white bg-slate-900'
          }`}
        >
          <MessageSquare className="w-3.5 h-3.5" />
          <span>Telegram Integration</span>
        </button>
      </div>

      {/* Tab 1: Alerts Engine */}
      {activeTab === 'ALERTS' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
          {/* Create Alert Form (5 cols on lg) */}
          <div className="lg:col-span-5 bg-[#0f1422] border border-slate-800 rounded-xl p-4 shadow-lg">
            <h3 className="text-sm font-bold text-white mb-1 flex items-center space-x-2">
              <Plus className="w-4 h-4 text-cyan-400" />
              <span>Create Quantitative Alert</span>
            </h3>
            <p className="text-[11px] text-slate-400 mb-4">
              Real-time monitoring on Spot Price, Open Interest, PCR, and Max Pain shifts
            </p>

            <form onSubmit={handleCreateAlert} className="space-y-3">
              <div>
                <label className="text-[10px] text-slate-400 uppercase font-semibold block mb-1">
                  Metric Type
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5">
                  {(['PRICE', 'OI', 'PCR', 'MAX_PAIN'] as AlertItem['type'][]).map((t) => (
                    <button
                      key={t}
                      type="button"
                      onClick={() => {
                        setAlertType(t);
                        if (t === 'PCR') setAlertThreshold(1.25);
                        else if (t === 'PRICE') setAlertThreshold(Math.round(currentIndex.spotPrice + 50));
                        else if (t === 'OI') setAlertThreshold(2000000);
                        else setAlertThreshold(25000);
                      }}
                      className={`py-1.5 px-2 rounded text-[11px] font-bold transition-colors ${
                        alertType === t
                          ? 'bg-cyan-600 text-white'
                          : 'bg-slate-900 text-slate-400 border border-slate-800'
                      }`}
                    >
                      {t}
                    </button>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-[10px] text-slate-400 uppercase font-semibold block mb-1">
                    Index
                  </label>
                  <select
                    value={alertSymbol}
                    onChange={(e) => setAlertSymbol(e.target.value as IndexSymbol)}
                    className="w-full bg-slate-900 border border-slate-800 rounded p-2 text-white font-semibold text-xs focus:outline-none"
                  >
                    <option value="NIFTY">NIFTY</option>
                    <option value="BANKNIFTY">BANKNIFTY</option>
                    <option value="FINNIFTY">FINNIFTY</option>
                    <option value="MIDCPNIFTY">MIDCPNIFTY</option>
                    <option value="SENSEX">SENSEX</option>
                  </select>
                </div>

                <div>
                  <label className="text-[10px] text-slate-400 uppercase font-semibold block mb-1">
                    Condition
                  </label>
                  <select
                    value={alertCondition}
                    onChange={(e) => setAlertCondition(e.target.value as AlertItem['condition'])}
                    className="w-full bg-slate-900 border border-slate-800 rounded p-2 text-white font-semibold text-xs focus:outline-none"
                  >
                    <option value="ABOVE">Crosses Above (&gt;=)</option>
                    <option value="BELOW">Crosses Below (&lt;=)</option>
                  </select>
                </div>
              </div>

              {alertType === 'OI' && (
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-[10px] text-slate-400 uppercase font-semibold block mb-1">
                      Strike Price
                    </label>
                    <input
                      type="number"
                      value={alertStrike}
                      onChange={(e) => setAlertStrike(Number(e.target.value))}
                      className="w-full bg-slate-900 border border-slate-800 rounded p-2 text-white font-mono-num text-xs"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] text-slate-400 uppercase font-semibold block mb-1">
                      Option Type
                    </label>
                    <select
                      value={alertOptionType}
                      onChange={(e) => setAlertOptionType(e.target.value as OptionType)}
                      className="w-full bg-slate-900 border border-slate-800 rounded p-2 text-white font-bold text-xs"
                    >
                      <option value="CE">Call (CE)</option>
                      <option value="PE">Put (PE)</option>
                    </select>
                  </div>
                </div>
              )}

              <div>
                <label className="text-[10px] text-slate-400 uppercase font-semibold block mb-1">
                  Threshold Value ({alertType === 'PCR' ? 'Ratio e.g. 1.3' : alertType === 'PRICE' ? 'Spot Level' : 'Contracts'})
                </label>
                <input
                  type="number"
                  step={alertType === 'PCR' ? '0.01' : '1'}
                  value={alertThreshold}
                  onChange={(e) => setAlertThreshold(Number(e.target.value))}
                  className="w-full bg-slate-900 border border-slate-800 rounded p-2 text-white font-mono-num font-bold text-xs focus:outline-none"
                  required
                />
              </div>

              <div>
                <label className="text-[10px] text-slate-400 uppercase font-semibold block mb-1">
                  Alert Label / Note
                </label>
                <input
                  type="text"
                  value={alertNote}
                  onChange={(e) => setAlertNote(e.target.value)}
                  placeholder="e.g. Bullish Breakout Confirmation"
                  className="w-full bg-slate-900 border border-slate-800 rounded p-2 text-white text-xs focus:outline-none"
                />
              </div>

              <div className="flex items-center space-x-2 pt-1">
                <input
                  type="checkbox"
                  id="teleCheck"
                  checked={alertTelegram}
                  onChange={(e) => setAlertTelegram(e.target.checked)}
                  className="rounded bg-slate-900 border-slate-700 text-cyan-500"
                />
                <label htmlFor="teleCheck" className="text-slate-300 text-xs">
                  Forward instant trigger to Telegram Channel / Bot
                </label>
              </div>

              <button
                type="submit"
                className="w-full bg-cyan-600 hover:bg-cyan-500 text-white font-bold py-2.5 rounded-lg text-xs transition-colors flex items-center justify-center space-x-1.5 shadow-md"
              >
                <Plus className="w-4 h-4" />
                <span>Arm Trigger Condition</span>
              </button>
            </form>
          </div>

          {/* Active Alerts List (7 cols on lg) */}
          <div className="lg:col-span-7 bg-[#0f1422] border border-slate-800 rounded-xl p-4 shadow-lg flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                <h3 className="text-sm font-bold text-white flex items-center space-x-2">
                  <Bell className="w-4 h-4 text-cyan-400" />
                  <span>Configured Watchdogs</span>
                </h3>
                <span className="text-[11px] text-slate-400 font-mono-num">
                  {alerts.length} Registered
                </span>
              </div>

              <div className="mt-3 space-y-2 max-h-[380px] overflow-y-auto">
                {alerts.length === 0 ? (
                  <div className="text-center py-12 text-slate-500">
                    <div className="text-sm font-semibold mb-1">No alerts created yet</div>
                    <div className="text-[11px]">
                      Use the form on the left or click any strike in the option chain to create watchdogs.
                    </div>
                  </div>
                ) : (
                  alerts.map((alert) => (
                    <div
                      key={alert.id}
                      className={`border rounded-lg p-3 transition-all flex items-center justify-between gap-3 ${
                        alert.triggered
                          ? 'bg-rose-950/30 border-rose-700/60'
                          : 'bg-slate-900/80 border-slate-800'
                      }`}
                    >
                      <div className="space-y-1">
                        <div className="flex items-center space-x-2">
                          <span className="font-bold text-white">{alert.symbol}</span>
                          <span className="bg-slate-800 text-cyan-300 text-[10px] px-1.5 py-0.2 rounded font-bold">
                            {alert.type}
                          </span>
                          <span className="text-[11px] text-slate-300">
                            {alert.condition === 'ABOVE' ? '≥' : '≤'}{' '}
                            <span className="font-mono-num font-bold text-amber-400">
                              {alert.threshold}
                            </span>
                          </span>
                          {alert.strike && (
                            <span className="text-[10px] text-slate-400 font-mono-num">
                              Strike: {alert.strike} {alert.optionType}
                            </span>
                          )}
                          {alert.triggered && (
                            <span className="bg-rose-600 text-white text-[9px] font-black px-1.5 py-0.2 rounded animate-pulse">
                              TRIGGERED
                            </span>
                          )}
                        </div>
                        <div className="text-[11px] text-slate-400">{alert.note}</div>
                        <div className="text-[10px] text-slate-500 font-mono-num">
                          Created {alert.createdAt} {alert.telegramEnabled && '• 📱 Telegram Enabled'}
                        </div>
                      </div>

                      <button
                        onClick={() => onDeleteAlert(alert.id)}
                        className="text-slate-500 hover:text-rose-400 p-1.5 transition-colors"
                        title="Delete alert"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Tab 2: Watchlist */}
      {activeTab === 'WATCHLIST' && (
        <div className="bg-[#0f1422] border border-slate-800 rounded-xl p-4 shadow-lg">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-4">
            <div>
              <h3 className="text-sm font-bold text-white flex items-center space-x-2">
                <Bookmark className="w-4 h-4 text-cyan-400" />
                <span>Pinned Contracts & Watchlist</span>
              </h3>
              <p className="text-[11px] text-slate-400">
                Track favorite strike contracts with live tick changes
              </p>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs font-mono-num">
              <thead>
                <tr className="border-b border-slate-800 text-slate-400 uppercase text-[10px]">
                  <th className="py-2 px-3">Contract</th>
                  <th className="py-2 px-3">Type</th>
                  <th className="py-2 px-3">Expiry</th>
                  <th className="py-2 px-3 text-right">LTP (₹)</th>
                  <th className="py-2 px-3 text-right">Target</th>
                  <th className="py-2 px-3 text-right">Stop Loss</th>
                  <th className="py-2 px-3 text-center">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {watchlist.length === 0 ? (
                  <tr>
                    <td colSpan={7} className="py-8 text-center text-slate-500">
                      No contracts in watchlist. Click "Add to Watchlist" on any strike in the Option Chain.
                    </td>
                  </tr>
                ) : (
                  watchlist.map((item) => (
                    <tr key={item.id} className="hover:bg-slate-900/50">
                      <td className="py-2 px-3 font-bold text-white">
                        {item.symbol} {item.strike}
                      </td>
                      <td className="py-2 px-3">
                        <span
                          className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                            item.type === 'CE'
                              ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                              : 'bg-rose-950 text-rose-400 border border-rose-800'
                          }`}
                        >
                          {item.type}
                        </span>
                      </td>
                      <td className="py-2 px-3 text-slate-300">{item.expiry}</td>
                      <td className="py-2 px-3 text-right font-bold text-cyan-400">
                        ₹{(Math.random() * 80 + 120).toFixed(2)}
                      </td>
                      <td className="py-2 px-3 text-right text-emerald-400">
                        {item.targetPrice ? `₹${item.targetPrice}` : '--'}
                      </td>
                      <td className="py-2 px-3 text-right text-rose-400">
                        {item.stopLoss ? `₹${item.stopLoss}` : '--'}
                      </td>
                      <td className="py-2 px-3 text-center">
                        <button
                          onClick={() => onDeleteWatchlist(item.id)}
                          className="text-slate-500 hover:text-rose-400 p-1"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Tab 3: Telegram Integration Settings */}
      {activeTab === 'TELEGRAM' && (
        <div className="bg-[#0f1422] border border-slate-800 rounded-xl p-5 shadow-lg max-w-2xl space-y-4">
          <div>
            <h3 className="text-sm font-bold text-white flex items-center space-x-2">
              <MessageSquare className="w-4 h-4 text-cyan-400" />
              <span>Telegram Bot Notifications Webhook</span>
            </h3>
            <p className="text-[11px] text-slate-400 mt-1">
              Connect your private Telegram bot to receive instant options alert pushes directly on your mobile device.
            </p>
          </div>

          <div className="space-y-3">
            <div>
              <label className="text-[10px] text-slate-400 uppercase font-semibold block mb-1">
                Telegram Bot API Token
              </label>
              <input
                type="text"
                value={botToken}
                onChange={(e) => setBotToken(e.target.value)}
                placeholder="From @BotFather (e.g. 7129384912:AAH9fkl90x...)"
                className="w-full bg-slate-900 border border-slate-800 rounded p-2 text-slate-200 font-mono-num text-xs focus:outline-none"
              />
            </div>

            <div>
              <label className="text-[10px] text-slate-400 uppercase font-semibold block mb-1">
                Target Chat ID or Channel Username
              </label>
              <input
                type="text"
                value={chatId}
                onChange={(e) => setChatId(e.target.value)}
                placeholder="e.g. @MyTradingAlerts or -10029384819"
                className="w-full bg-slate-900 border border-slate-800 rounded p-2 text-slate-200 font-mono-num text-xs focus:outline-none"
              />
            </div>

            <div className="pt-2 flex items-center space-x-3">
              <button
                type="button"
                onClick={handleTestTelegram}
                className="bg-cyan-600 hover:bg-cyan-500 text-white font-bold py-2 px-4 rounded-lg text-xs flex items-center space-x-1.5 transition-colors shadow-md"
              >
                <Send className="w-3.5 h-3.5" />
                <span>Send Test Notification</span>
              </button>
            </div>

            {telegramStatus && (
              <div className="p-3 bg-emerald-950/40 border border-emerald-800/60 rounded-lg text-emerald-300 text-xs font-semibold">
                {telegramStatus}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
