import React, { useState, useMemo } from 'react';
import {
  IndexMarketData,
  IndexSymbol,
  OIBuildupType,
  OptionContractData,
  OptionType,
  StrikeRow,
  UserRole,
} from '../../types';
import { calculatePCR } from '../../utils/optionsAnalytics';
import {
  ArrowDownRight,
  ArrowUpRight,
  BookmarkPlus,
  Calendar,
  Crosshair,
  Layers,
  RefreshCw,
  Volume2,
  VolumeX,
  X,
} from 'lucide-react';

function renderBuildupBadge(buildup: OIBuildupType) {
  switch (buildup) {
    case 'LONG_BUILDUP':
      return (
        <span
          className="inline-flex items-center justify-center px-1.5 xl:px-2 py-0.5 rounded-[6px] text-[9.5px] xl:text-[10px] font-semibold bg-[#DCFCE7] text-[#166534] whitespace-nowrap"
          title="Long Build Up: Price ↑, OI ↑ (Bullish)"
        >
          Long Build Up
        </span>
      );
    case 'SHORT_BUILDUP':
      return (
        <span
          className="inline-flex items-center justify-center px-1.5 xl:px-2 py-0.5 rounded-[6px] text-[9.5px] xl:text-[10px] font-semibold bg-[#FEE2E2] text-[#991B1B] whitespace-nowrap"
          title="Short Build Up: Price ↓, OI ↑ (Bearish)"
        >
          Short Build Up
        </span>
      );
    case 'LONG_UNWINDING':
      return (
        <span
          className="inline-flex items-center justify-center px-1.5 xl:px-2 py-0.5 rounded-[6px] text-[9.5px] xl:text-[10px] font-semibold bg-[#FEF3C7] text-[#92400E] whitespace-nowrap"
          title="Long Unwinding: Price ↓, OI ↓ (Profit Booking)"
        >
          Long Unwinding
        </span>
      );
    case 'SHORT_COVERING':
      return (
        <span
          className="inline-flex items-center justify-center px-1.5 xl:px-2 py-0.5 rounded-[6px] text-[9.5px] xl:text-[10px] font-semibold bg-[#DBEAFE] text-[#1E40AF] whitespace-nowrap"
          title="Short Covering: Price ↑, OI ↓ (Short Squeeze)"
        >
          Short Covering
        </span>
      );
    default:
      return <span className="text-[#94A3B8] text-[10px]">—</span>;
  }
}

interface OptionChainTableProps {
  strikes: StrikeRow[];
  currentIndex: IndexMarketData;
  activeSymbol?: IndexSymbol;
  onSelectSymbol?: (sym: IndexSymbol) => void;
  activeExpiry: string;
  onSelectExpiry: (exp: string) => void;
  strikeRange: number;
  onSelectStrikeRange: (range: number) => void;
  searchQuery: string;
  onSearchQueryChange: (val: string) => void;
  userRole: UserRole;
  maxPainStrike: number;
  theme?: 'dark' | 'light';
  isAutoUpdating?: boolean;
  onToggleAutoUpdate?: () => void;
  soundEnabled?: boolean;
  onToggleSound?: () => void;
  onAddLegToStrategy: (
    type: OptionType,
    action: 'BUY' | 'SELL',
    strike: number,
    price: number,
    iv: number,
    greeks: OptionContractData['greeks']
  ) => void;
  onAddToWatchlist: (strike: number, type: OptionType) => void;
  onCreateAlert: (strike: number, type: OptionType, price: number) => void;
}

export const OptionChainTable: React.FC<OptionChainTableProps> = ({
  strikes,
  currentIndex,
  activeSymbol = 'NIFTY',
  onSelectSymbol,
  activeExpiry,
  onSelectExpiry,
  strikeRange,
  onSelectStrikeRange,
  searchQuery,
  userRole,
  maxPainStrike,
  theme = 'light',
  isAutoUpdating,
  onToggleAutoUpdate,
  soundEnabled,
  onToggleSound,
  onAddLegToStrategy,
  onAddToWatchlist,
  onCreateAlert,
}) => {
  const isDark = theme === 'dark';
  const showGreeks = true;
  const [selectedStrikeAction, setSelectedStrikeAction] = useState<{
    strike: number;
    type: OptionType;
    data: OptionContractData;
  } | null>(null);

  const { spotPrice, strikeStep } = currentIndex;
  const futurePrice = currentIndex.futurePrice || spotPrice + 54.3;
  const futureBasis = futurePrice - spotPrice;
  const atmStrike = Math.round(spotPrice / strikeStep) * strikeStep;

  // Filter strikes by range & search query
  let filtered = [...strikes];

  if (searchQuery.trim()) {
    const q = searchQuery.trim();
    filtered = filtered.filter((r) => r.strike.toString().includes(q));
  } else if (strikeRange > 0) {
    const atmIndex = filtered.findIndex((r) => r.strike === atmStrike);
    if (atmIndex !== -1) {
      const start = Math.max(0, atmIndex - strikeRange);
      const end = Math.min(filtered.length, atmIndex + strikeRange + 1);
      filtered = filtered.slice(start, end);
    }
  }

  // Max OI for relative percentage bar widths
  let maxOi = 1;
  strikes.forEach((r) => {
    if (r.call.oi > maxOi) maxOi = r.call.oi;
    if (r.put.oi > maxOi) maxOi = r.put.oi;
  });

  // Calculate Column Totals for the current visible table
  let sumCeOi = 0;
  let sumPeOi = 0;
  let sumCeChangeOi = 0;
  let sumPeChangeOi = 0;
  let sumCeVol = 0;
  let sumPeVol = 0;
  filtered.forEach((r) => {
    sumCeOi += r.call.oi;
    sumPeOi += r.put.oi;
    sumCeChangeOi += r.call.changeOi;
    sumPeChangeOi += r.put.changeOi;
    sumCeVol += r.call.volume;
    sumPeVol += r.put.volume;
  });

  // Calculate PCR (Put Call Ratio)
  const pcr = useMemo(() => calculatePCR(strikes), [strikes]);

  return (
    <div className="flex-1 min-h-0 flex flex-col overflow-hidden bg-[#F8FAFC] select-none text-xs">
      {/* =================================================================
          INSTITUTIONAL OPTION CHAIN CONTROL BAR (Single-Line Layout)
         ================================================================= */}
      <div className="flex items-center justify-between px-3 py-1.5 bg-[#FFFFFF] border-b border-[#E2E8F0] text-[#475569] gap-1.5 overflow-x-auto no-scrollbar whitespace-nowrap w-full shrink-0">
        {/* All Metrics & Controls in a Single Compact Line */}
        <div className="flex items-center gap-1.5 whitespace-nowrap">
          {onSelectSymbol && (
            <div className="flex items-center gap-1 h-[30px] bg-[#FFFFFF] border border-[#CBD5E1] rounded-[8px] px-2 shrink-0">
              <span className="text-[10.5px] text-[#64748B] font-medium">Index:</span>
              <select
                value={activeSymbol}
                onChange={(e) => onSelectSymbol(e.target.value as IndexSymbol)}
                className="bg-transparent text-[#2563EB] font-semibold focus:outline-none cursor-pointer text-[11px] border-0! p-0! shadow-none!"
              >
                {(['NIFTY', 'BANKNIFTY', 'FINNIFTY', 'MIDCPNIFTY', 'SENSEX'] as IndexSymbol[]).map(
                  (sym) => (
                    <option key={sym} value={sym} className="bg-[#FFFFFF] text-[#0F172A]">
                      {sym}
                    </option>
                  )
                )}
              </select>
            </div>
          )}

          <div className="flex items-center gap-1 h-[30px] bg-[#F8FAFC] border border-[#E2E8F0] px-2 rounded-[8px] shrink-0">
            <span className="font-medium text-[#64748B] text-[10.5px]">Spot:</span>
            <span className="font-mono-num font-semibold text-[#0F172A] text-[11.5px]">
              {spotPrice.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
            </span>
          </div>

          <div className="flex items-center gap-1 h-[30px] bg-[#F8FAFC] border border-[#E2E8F0] px-2 rounded-[8px] shrink-0">
            <span className="font-medium text-[#64748B] text-[10.5px]">Futures:</span>
            <span className="font-mono-num font-semibold text-[#2563EB] text-[11.5px]">
              {futurePrice.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
            </span>
            <span
              className={`text-[9.5px] font-mono-num font-semibold px-1 py-0.2 rounded ${
                futureBasis >= 0
                  ? 'bg-[#DCFCE7] text-[#166534]'
                  : 'bg-[#FEE2E2] text-[#991B1B]'
              }`}
              title="Futures Basis (Fut - Spot)"
            >
              {futureBasis >= 0 ? '+' : ''}
              {futureBasis.toFixed(1)}
            </span>
          </div>

          <div className="flex items-center gap-1 h-[30px] bg-[#FEF3C7] border border-[#FDE68A] px-2 rounded-[8px] shrink-0">
            <span className="text-[#92400E] font-medium text-[10.5px]">ATM:</span>
            <span className="font-mono-num font-bold text-[#92400E] text-[11.5px]">{atmStrike}</span>
          </div>

          <div
            style={{
              backgroundColor: '#16A34A',
              borderColor: '#15803D',
              color: '#FFFFFF',
            }}
            className="flex items-center gap-1 h-[30px] border px-2.5 rounded-[8px] shrink-0 shadow-xs"
          >
            <span style={{ color: '#FFFFFF' }} className="font-medium text-[10.5px]">
              Max Pain:
            </span>
            <span style={{ color: '#FFFFFF' }} className="font-mono-num font-bold text-[11.5px]">
              {maxPainStrike}
            </span>
          </div>

          <div
            className="flex items-center gap-1 h-[30px] bg-[#F8FAFC] border border-[#E2E8F0] px-2 rounded-[8px] shrink-0"
            title={`OI PCR: ${pcr.pcrOi} | Vol PCR: ${pcr.pcrVol} - ${pcr.summary}`}
          >
            <span className="text-[#64748B] font-medium text-[10.5px]">PCR:</span>
            <span
              className={`font-mono-num font-semibold text-[11.5px] ${
                pcr.pcrOi >= 1.05
                  ? 'text-[#16A34A]'
                  : pcr.pcrOi <= 0.85
                  ? 'text-[#DC2626]'
                  : 'text-[#B45309]'
              }`}
            >
              {pcr.pcrOi.toFixed(2)}
            </span>
            <span
              className={`text-[9px] px-1 py-0.2 rounded font-semibold uppercase ${
                pcr.sentiment.includes('BULLISH')
                  ? 'bg-[#DCFCE7] text-[#166534]'
                  : pcr.sentiment.includes('BEARISH')
                  ? 'bg-[#FEE2E2] text-[#991B1B]'
                  : 'bg-[#FEF3C7] text-[#92400E]'
              }`}
            >
              {pcr.sentiment.includes('BULLISH')
                ? 'Bullish'
                : pcr.sentiment.includes('BEARISH')
                ? 'Bearish'
                : 'Neutral'}
            </span>
          </div>

          <div className="flex items-center gap-1 h-[30px] bg-[#F8FAFC] border border-[#E2E8F0] px-2 rounded-[8px] shrink-0">
            <span className="text-[#64748B] font-medium text-[10.5px]">INDIA VIX:</span>
            <span className="font-semibold text-[#0F172A] font-mono-num text-[11.5px]">
              {(currentIndex.vix || 13.42).toFixed(2)}
            </span>
            <span className="text-[10px] text-[#16A34A] font-mono-num font-medium">(-0.25)</span>
          </div>
        </div>

        {/* Right Controls: Expiry, Strike Range, 1s Live & Speaker (Same Single Line) */}
        <div className="flex items-center gap-1.5 whitespace-nowrap shrink-0">
          {/* Expiry Selector */}
          {activeExpiry && onSelectExpiry && currentIndex.expiries && (
            <div className="flex items-center gap-1 h-[30px] bg-[#FFFFFF] border border-[#CBD5E1] rounded-[8px] px-2 shrink-0">
              <Calendar className="w-3 h-3 text-[#2563EB] shrink-0" />
              <span className="text-[10.5px] text-[#64748B] font-medium">Expiry:</span>
              <select
                value={activeExpiry}
                onChange={(e) => onSelectExpiry(e.target.value)}
                className="bg-transparent text-[#0F172A] font-semibold focus:outline-none cursor-pointer text-[11px] border-0! p-0! shadow-none!"
              >
                {currentIndex.expiries.map((exp) => (
                  <option key={exp} value={exp} className="bg-[#FFFFFF] text-[#0F172A]">
                    {exp}
                  </option>
                ))}
              </select>
            </div>
          )}

          {/* Strikes Range Selector */}
          {onSelectStrikeRange && (
            <div className="flex items-center gap-0.5 h-[30px] bg-[#F8FAFC] border border-[#E2E8F0] rounded-[8px] px-1.5 shrink-0">
              <Layers className="w-3 h-3 text-[#2563EB] mr-0.5 shrink-0" />
              <span className="text-[10.5px] text-[#64748B] font-medium mr-0.5">Strikes:</span>
              {[5, 10, 20, 0].map((range) => (
                <button
                  key={range}
                  onClick={() => onSelectStrikeRange(range)}
                  className={`px-1.5 py-0.5 text-[10px] rounded-[6px] font-semibold transition-colors ${
                    strikeRange === range
                      ? 'bg-[#2563EB] text-white'
                      : 'text-[#475569] hover:text-[#0F172A] hover:bg-[#E2E8F0]/50'
                  }`}
                >
                  {range === 0 ? 'All' : `±${range}`}
                </button>
              ))}
            </div>
          )}

          {/* Live Streaming Toggle */}
          {onToggleAutoUpdate && (
            <button
              onClick={onToggleAutoUpdate}
              className={`h-[30px] flex items-center gap-1 px-2.5 rounded-[8px] border text-[11px] font-semibold transition-colors shrink-0 ${
                isAutoUpdating
                  ? 'bg-[#DCFCE7] border-[#BBF7D0] text-[#166534]'
                  : 'bg-[#FFFFFF] border-[#E2E8F0] text-[#475569] hover:bg-[#F8FAFC]'
              }`}
              title={isAutoUpdating ? 'Pause 1s Live Streaming' : 'Resume Live Streaming'}
            >
              <RefreshCw className={`w-3 h-3 shrink-0 ${isAutoUpdating ? 'animate-spin' : ''}`} />
              <span>{isAutoUpdating ? '1s Live' : 'Paused'}</span>
            </button>
          )}

          {/* Sound Toggle */}
          {onToggleSound && (
            <button
              onClick={onToggleSound}
              className={`h-[30px] w-[30px] flex items-center justify-center rounded-[8px] border transition-colors shrink-0 ${
                soundEnabled
                  ? 'bg-[#EFF6FF] border-[#BFDBFE] text-[#2563EB]'
                  : 'bg-[#FFFFFF] border-[#E2E8F0] text-[#64748B] hover:bg-[#F8FAFC]'
              }`}
              title={soundEnabled ? 'Mute Audio Alerts' : 'Unmute Audio Alerts'}
            >
              {soundEnabled ? <Volume2 className="w-3.5 h-3.5" /> : <VolumeX className="w-3.5 h-3.5" />}
            </button>
          )}
        </div>
      </div>

      {/* =================================================================
          MAIN OPTION CHAIN TABLE (Excel-Style Frozen Header & Footer Panes)
          Call Side: #ECFDF5 | Put Side: #FEF2F2 | Strike: #EFF6FF (#BFDBFE)
          ATM Strike: #FEF3C7 (#92400E, 700) | OI+: #DCFCE7 | OI-: #FEE2E2
         ================================================================= */}
      <div className="flex-1 min-h-0 overflow-x-auto overflow-y-auto bg-[#FFFFFF] relative">
        <table className="w-full table-auto border-separate border-spacing-0 font-mono-num text-[10px] lg:text-[10.5px] xl:text-[11px] 2xl:text-xs">
          <thead className="sticky top-0 z-30">
            {/* FROZEN HEADER ROW 1: CALL OPTIONS (CE) | STRIKE | PUT OPTIONS (PE) */}
            <tr className="h-[32px]">
              <th
                colSpan={showGreeks ? 11 : 7}
                style={{
                  backgroundColor: isDark ? '#062E22' : '#ECFDF5',
                  color: isDark ? '#4ADE80' : '#166534',
                  borderColor: isDark ? '#1E293B' : '#CBD5E1',
                }}
                className="sticky top-0 z-30 h-[32px] py-1.5 px-2 text-center font-bold tracking-wider border-b border-r uppercase text-[10.5px] xl:text-xs"
              >
                CALL OPTIONS (CE)
              </th>
              <th
                colSpan={1}
                style={{
                  backgroundColor: isDark ? '#172554' : '#EFF6FF',
                  color: isDark ? '#60A5FA' : '#1E40AF',
                  borderColor: isDark ? '#1E3A8A' : '#BFDBFE',
                }}
                className="sticky top-0 z-30 h-[32px] py-1.5 px-2 text-center font-bold tracking-wider uppercase border-b border-r text-[10.5px] xl:text-xs"
              >
                STRIKE
              </th>
              <th
                colSpan={showGreeks ? 11 : 7}
                style={{
                  backgroundColor: isDark ? '#311016' : '#FEF2F2',
                  color: isDark ? '#F87171' : '#991B1B',
                  borderColor: isDark ? '#1E293B' : '#CBD5E1',
                }}
                className="sticky top-0 z-30 h-[32px] py-1.5 px-2 text-center font-bold tracking-wider uppercase border-b text-[10.5px] xl:text-xs"
              >
                PUT OPTIONS (PE)
              </th>
            </tr>

            {/* FROZEN HEADER ROW 2: COLUMN HEADINGS */}
            <tr
              style={{
                backgroundColor: isDark ? '#111827' : '#F1F5F9',
              }}
              className="h-[32px] text-[9.5px] xl:text-[10.5px] text-[#475569] uppercase whitespace-nowrap shadow-[0_2px_4px_rgba(0,0,0,0.08)]"
            >
              {/* Call Columns */}
              <th
                style={{
                  backgroundColor: isDark ? '#111827' : '#F1F5F9',
                  borderColor: isDark ? '#334155' : '#CBD5E1',
                }}
                className="sticky top-[32px] z-30 h-[32px] py-2 px-1 xl:px-1.5 text-center font-semibold border-b-2"
              >
                OI (Lots)
              </th>
              <th
                style={{
                  backgroundColor: isDark ? '#111827' : '#F1F5F9',
                  borderColor: isDark ? '#334155' : '#CBD5E1',
                }}
                className="sticky top-[32px] z-30 h-[32px] py-2 px-1 xl:px-1.5 text-center font-semibold border-b-2"
              >
                Chg OI
              </th>
              <th
                style={{
                  backgroundColor: isDark ? '#111827' : '#F1F5F9',
                  borderColor: isDark ? '#334155' : '#CBD5E1',
                }}
                className="sticky top-[32px] z-30 h-[32px] py-2 px-1 xl:px-1.5 text-center font-semibold border-b-2"
              >
                Volume
              </th>
              <th
                style={{
                  backgroundColor: isDark ? '#111827' : '#F1F5F9',
                  borderColor: isDark ? '#334155' : '#CBD5E1',
                }}
                className="sticky top-[32px] z-30 h-[32px] py-2 px-1 text-center font-semibold border-b-2"
              >
                IV%
              </th>
              {showGreeks && (
                <>
                  <th
                    style={{
                      backgroundColor: isDark ? '#111827' : '#F1F5F9',
                      borderColor: isDark ? '#334155' : '#CBD5E1',
                    }}
                    className="sticky top-[32px] z-30 h-[32px] py-2 px-1 text-center font-semibold text-[#16A34A] border-b-2"
                    title="Delta"
                  >
                    Δ Delta
                  </th>
                  <th
                    style={{
                      backgroundColor: isDark ? '#111827' : '#F1F5F9',
                      borderColor: isDark ? '#334155' : '#CBD5E1',
                    }}
                    className="sticky top-[32px] z-30 h-[32px] py-2 px-1 text-center font-semibold text-[#D97706] border-b-2"
                    title="Theta"
                  >
                    θ Theta
                  </th>
                  <th
                    style={{
                      backgroundColor: isDark ? '#111827' : '#F1F5F9',
                      borderColor: isDark ? '#334155' : '#CBD5E1',
                    }}
                    className="sticky top-[32px] z-30 h-[32px] py-2 px-1 text-center font-semibold text-[#0891B2] border-b-2"
                    title="Gamma"
                  >
                    γ Gamma
                  </th>
                  <th
                    style={{
                      backgroundColor: isDark ? '#111827' : '#F1F5F9',
                      borderColor: isDark ? '#334155' : '#CBD5E1',
                    }}
                    className="sticky top-[32px] z-30 h-[32px] py-2 px-1 text-center font-semibold text-[#64748B] border-b-2"
                    title="Vega"
                  >
                    ν Vega
                  </th>
                </>
              )}
              <th
                style={{
                  backgroundColor: isDark ? '#111827' : '#F1F5F9',
                  borderColor: isDark ? '#334155' : '#CBD5E1',
                }}
                className="sticky top-[32px] z-30 h-[32px] py-2 px-1 xl:px-1.5 text-center font-semibold text-[#0F172A] border-b-2"
              >
                Build Up
              </th>
              <th
                style={{
                  backgroundColor: isDark ? '#111827' : '#F1F5F9',
                  borderColor: isDark ? '#334155' : '#CBD5E1',
                }}
                className="sticky top-[32px] z-30 h-[32px] py-2 px-1 xl:px-1.5 text-center font-semibold text-[#0F172A] border-b-2"
              >
                Chg (₹)
              </th>
              <th
                style={{
                  backgroundColor: isDark ? '#111827' : '#F1F5F9',
                  borderColor: isDark ? '#334155' : '#CBD5E1',
                }}
                className="sticky top-[32px] z-30 h-[32px] py-2 px-1.5 xl:px-2 text-center font-semibold text-[#2563EB] border-r border-b-2"
              >
                LTP (₹)
              </th>

              {/* Strike Column Header */}
              <th
                style={{
                  backgroundColor: isDark ? '#172554' : '#EFF6FF',
                  color: isDark ? '#60A5FA' : '#1E40AF',
                  borderColor: isDark ? '#1E3A8A' : '#BFDBFE',
                }}
                className="sticky top-[32px] z-30 h-[32px] py-2 px-2 text-center font-bold border-r border-b-2 min-w-[76px] xl:min-w-[92px] text-[10px] xl:text-[11px] tracking-wider uppercase"
              >
                STRIKE
              </th>

              {/* Put Columns */}
              <th
                style={{
                  backgroundColor: isDark ? '#111827' : '#F1F5F9',
                  borderColor: isDark ? '#334155' : '#CBD5E1',
                }}
                className="sticky top-[32px] z-30 h-[32px] py-2 px-1.5 xl:px-2 text-center font-semibold text-[#2563EB] border-b-2"
              >
                LTP (₹)
              </th>
              <th
                style={{
                  backgroundColor: isDark ? '#111827' : '#F1F5F9',
                  borderColor: isDark ? '#334155' : '#CBD5E1',
                }}
                className="sticky top-[32px] z-30 h-[32px] py-2 px-1 xl:px-1.5 text-center font-semibold text-[#0F172A] border-b-2"
              >
                Chg (₹)
              </th>
              <th
                style={{
                  backgroundColor: isDark ? '#111827' : '#F1F5F9',
                  borderColor: isDark ? '#334155' : '#CBD5E1',
                }}
                className="sticky top-[32px] z-30 h-[32px] py-2 px-1 xl:px-1.5 text-center font-semibold text-[#0F172A] border-b-2"
              >
                Build Up
              </th>
              {showGreeks && (
                <>
                  <th
                    style={{
                      backgroundColor: isDark ? '#111827' : '#F1F5F9',
                      borderColor: isDark ? '#334155' : '#CBD5E1',
                    }}
                    className="sticky top-[32px] z-30 h-[32px] py-2 px-1 text-center font-semibold text-[#64748B] border-b-2"
                    title="Vega"
                  >
                    ν Vega
                  </th>
                  <th
                    style={{
                      backgroundColor: isDark ? '#111827' : '#F1F5F9',
                      borderColor: isDark ? '#334155' : '#CBD5E1',
                    }}
                    className="sticky top-[32px] z-30 h-[32px] py-2 px-1 text-center font-semibold text-[#0891B2] border-b-2"
                    title="Gamma"
                  >
                    γ Gamma
                  </th>
                  <th
                    style={{
                      backgroundColor: isDark ? '#111827' : '#F1F5F9',
                      borderColor: isDark ? '#334155' : '#CBD5E1',
                    }}
                    className="sticky top-[32px] z-30 h-[32px] py-2 px-1 text-center font-semibold text-[#D97706] border-b-2"
                    title="Theta"
                  >
                    θ Theta
                  </th>
                  <th
                    style={{
                      backgroundColor: isDark ? '#111827' : '#F1F5F9',
                      borderColor: isDark ? '#334155' : '#CBD5E1',
                    }}
                    className="sticky top-[32px] z-30 h-[32px] py-2 px-1 text-center font-semibold text-[#DC2626] border-b-2"
                    title="Delta"
                  >
                    Δ Delta
                  </th>
                </>
              )}
              <th
                style={{
                  backgroundColor: isDark ? '#111827' : '#F1F5F9',
                  borderColor: isDark ? '#334155' : '#CBD5E1',
                }}
                className="sticky top-[32px] z-30 h-[32px] py-2 px-1 text-center font-semibold border-b-2"
              >
                IV%
              </th>
              <th
                style={{
                  backgroundColor: isDark ? '#111827' : '#F1F5F9',
                  borderColor: isDark ? '#334155' : '#CBD5E1',
                }}
                className="sticky top-[32px] z-30 h-[32px] py-2 px-1 xl:px-1.5 text-center font-semibold border-b-2"
              >
                Volume
              </th>
              <th
                style={{
                  backgroundColor: isDark ? '#111827' : '#F1F5F9',
                  borderColor: isDark ? '#334155' : '#CBD5E1',
                }}
                className="sticky top-[32px] z-30 h-[32px] py-2 px-1 xl:px-1.5 text-center font-semibold border-b-2"
              >
                Chg OI
              </th>
              <th
                style={{
                  backgroundColor: isDark ? '#111827' : '#F1F5F9',
                  borderColor: isDark ? '#334155' : '#CBD5E1',
                }}
                className="sticky top-[32px] z-30 h-[32px] py-2 px-1 xl:px-1.5 text-center font-semibold border-b-2"
              >
                OI (Lots)
              </th>
            </tr>
          </thead>

          <tbody className="relative z-0 divide-y divide-[#E2E8F0]">
            {filtered.map((row, rowIndex) => {
              const { strike, call, put, isAtm, isItmCall, isItmPut } = row;
              const isMaxPain = strike === maxPainStrike;

              const ceOiPct = Math.min(100, Math.round((call.oi / maxOi) * 100));
              const peOiPct = Math.min(100, Math.round((put.oi / maxOi) * 100));

              const baseRowBg = isDark
                ? rowIndex % 2 === 0
                  ? '#0b101c'
                  : '#0e1525'
                : rowIndex % 2 === 0
                ? '#FFFFFF'
                : '#F8FAFC';

              // Solid opaque theme-aware Option Chain cell backgrounds:
              const callCellStyle: React.CSSProperties = isAtm
                ? { backgroundColor: isDark ? '#2B2108' : '#FEF3C7' }
                : isItmCall
                ? { backgroundColor: isDark ? '#07221B' : '#ECFDF5' }
                : { backgroundColor: baseRowBg };

              const putCellStyle: React.CSSProperties = isAtm
                ? { backgroundColor: isDark ? '#2B2108' : '#FEF3C7' }
                : isItmPut
                ? { backgroundColor: isDark ? '#241016' : '#FEF2F2' }
                : { backgroundColor: baseRowBg };

              const callPositive = call.change >= 0;
              const putPositive = put.change >= 0;

              return (
                <tr
                  key={strike}
                  className={`transition-colors hover:bg-[#F8FAFC] whitespace-nowrap ${
                    isAtm ? 'border-y-2 border-[#F59E0B] font-bold' : ''
                  }`}
                >
                  {/* CALL: OI with Positive / Negative bar */}
                  <td
                    style={callCellStyle}
                    className="py-1.5 xl:py-2 px-1 xl:px-1.5 text-center relative overflow-hidden text-[#0F172A] font-medium border-b border-[#E2E8F0]"
                  >
                    <div
                      style={{
                        width: `${ceOiPct}%`,
                        backgroundColor:
                          call.changeOi >= 0
                            ? isDark
                              ? 'rgba(22, 163, 74, 0.25)'
                              : '#DCFCE7'
                            : isDark
                            ? 'rgba(220, 38, 38, 0.25)'
                            : '#FEE2E2',
                      }}
                      className="absolute right-0 top-0 bottom-0 pointer-events-none"
                    />
                    <div className="relative z-[1] flex items-center justify-center">
                      <span>{(call.oi / currentIndex.lotSize).toLocaleString('en-IN')}</span>
                    </div>
                  </td>

                  {/* CALL: Change in OI */}
                  <td style={callCellStyle} className="py-1.5 xl:py-2 px-1 xl:px-1.5 text-center border-b border-[#E2E8F0]">
                    <span
                      className={`inline-block px-1 xl:px-1.5 py-0.5 rounded text-[9.5px] xl:text-[10.5px] font-semibold ${
                        call.changeOi >= 0
                          ? 'bg-[#DCFCE7] text-[#166534]'
                          : 'bg-[#FEE2E2] text-[#991B1B]'
                      }`}
                    >
                      {call.changeOi >= 0 ? '+' : ''}
                      {(call.changeOi / currentIndex.lotSize).toFixed(0)}
                    </span>
                  </td>

                  {/* CALL: Volume */}
                  <td style={callCellStyle} className="py-1.5 xl:py-2 px-1 xl:px-1.5 text-center text-[#475569] border-b border-[#E2E8F0]">
                    {(call.volume / 1000).toFixed(1)}k
                  </td>

                  {/* CALL: IV */}
                  <td style={callCellStyle} className="py-1.5 xl:py-2 px-1 text-center text-[#0F172A] font-medium border-b border-[#E2E8F0]">
                    {call.iv.toFixed(1)}%
                  </td>

                  {/* CALL Greeks */}
                  {showGreeks && (
                    <>
                      <td style={callCellStyle} className="py-1.5 xl:py-2 px-1 text-center text-[#16A34A] font-medium border-b border-[#E2E8F0]">
                        {call.greeks.delta.toFixed(2)}
                      </td>
                      <td style={callCellStyle} className="py-1.5 xl:py-2 px-1 text-center text-[#B45309] font-medium border-b border-[#E2E8F0]">
                        {call.greeks.theta.toFixed(1)}
                      </td>
                      <td style={callCellStyle} className="py-1.5 xl:py-2 px-1 text-center text-[#0891B2] font-medium border-b border-[#E2E8F0]">
                        {call.greeks.gamma.toFixed(2)}
                      </td>
                      <td style={callCellStyle} className="py-1.5 xl:py-2 px-1 text-center text-[#475569] font-medium border-b border-[#E2E8F0]">
                        {call.greeks.vega.toFixed(1)}
                      </td>
                    </>
                  )}

                  {/* CALL: Build Up */}
                  <td style={callCellStyle} className="py-1.5 xl:py-2 px-1 text-center border-b border-[#E2E8F0]">
                    {renderBuildupBadge(call.buildup)}
                  </td>

                  {/* CALL: Price Change */}
                  <td style={callCellStyle} className="py-1.5 xl:py-2 px-1 xl:px-1.5 text-center whitespace-nowrap border-b border-[#E2E8F0]">
                    <span
                      className={`font-semibold text-[10px] xl:text-[11px] ${
                        callPositive ? 'text-[#16A34A]' : 'text-[#DC2626]'
                      }`}
                    >
                      {call.change >= 0 ? '+' : ''}
                      {call.change.toFixed(2)} ({call.pChange >= 0 ? '+' : ''}
                      {call.pChange.toFixed(1)}%)
                    </span>
                  </td>

                  {/* CALL: LTP */}
                  <td
                    style={callCellStyle}
                    onClick={() =>
                      setSelectedStrikeAction({ strike, type: 'CE', data: call })
                    }
                    className="py-1.5 xl:py-2 px-1.5 xl:px-2 text-center font-semibold cursor-pointer border-r border-b border-[#E2E8F0] transition-colors"
                    title="Click to Trade / Analyze Call Strike"
                  >
                    <span
                      className={`inline-block px-1.5 py-0.5 rounded font-semibold text-[10.5px] xl:text-xs ${
                        call.lastTickDir === 'up'
                          ? 'bg-[#DCFCE7] text-[#166534]'
                          : call.lastTickDir === 'down'
                          ? 'bg-[#FEE2E2] text-[#991B1B]'
                          : 'text-[#2563EB] hover:underline'
                      }`}
                    >
                      {call.ltp.toFixed(2)}
                    </span>
                  </td>

                  {/* CENTER: STRIKE COLUMN (#EFF6FF / #BFDBFE or ATM #FEF3C7 / #92400E or MAX PAIN Green Rounded Box) */}
                  <td
                    style={
                      isAtm && !isMaxPain
                        ? {
                            backgroundColor: isDark ? '#3B2806' : '#FEF3C7',
                            color: isDark ? '#FBBF24' : '#92400E',
                            borderColor: '#F59E0B',
                            fontWeight: 700,
                          }
                        : {
                            backgroundColor: isDark ? '#111827' : '#EFF6FF',
                            color: isDark ? '#F8FAFC' : '#0F172A',
                            borderColor: isDark ? '#1e3a8a' : '#BFDBFE',
                          }
                    }
                    className="py-1 px-1.5 xl:px-2 text-center border-r border-b transition-colors"
                  >
                    {isMaxPain ? (
                      <div
                        style={{
                          backgroundColor: '#16A34A',
                          color: '#FFFFFF',
                        }}
                        className="flex flex-col items-center justify-center px-2.5 py-1 rounded-[8px] border border-[#15803D] shadow-xs min-w-[70px] xl:min-w-[82px] mx-auto"
                      >
                        <span
                          style={{ color: '#FFFFFF', fontWeight: 700 }}
                          className="text-[11px] xl:text-xs tracking-wide leading-tight"
                        >
                          {strike}
                        </span>
                        <span
                          style={{ color: '#FFFFFF' }}
                          className="text-[8px] xl:text-[8.5px] font-bold uppercase tracking-wider leading-none mt-0.5"
                        >
                          {isAtm ? 'ATM • MAX PAIN' : 'MAX PAIN'}
                        </span>
                      </div>
                    ) : (
                      <div className="flex flex-col items-center justify-center min-w-[72px] xl:min-w-[88px]">
                        <span
                          style={{
                            color: isAtm
                              ? isDark
                                ? '#FBBF24'
                                : '#92400E'
                              : isDark
                              ? '#F8FAFC'
                              : '#0F172A',
                            fontWeight: isAtm ? 700 : 600,
                          }}
                          className="text-[11px] xl:text-xs tracking-wide"
                        >
                          {strike}
                        </span>
                        {isAtm && (
                          <span
                            style={{ color: isDark ? '#FBBF24' : '#92400E' }}
                            className="text-[8.5px] xl:text-[9px] font-bold uppercase tracking-wider leading-none mt-0.5"
                          >
                            ATM
                          </span>
                        )}
                      </div>
                    )}
                  </td>

                  {/* PUT: LTP */}
                  <td
                    style={putCellStyle}
                    onClick={() =>
                      setSelectedStrikeAction({ strike, type: 'PE', data: put })
                    }
                    className="py-1.5 xl:py-2 px-1.5 xl:px-2 text-center font-semibold cursor-pointer border-b border-[#E2E8F0] transition-colors"
                    title="Click to Trade / Analyze Put Strike"
                  >
                    <span
                      className={`inline-block px-1.5 py-0.5 rounded font-semibold text-[10.5px] xl:text-xs ${
                        put.lastTickDir === 'up'
                          ? 'bg-[#DCFCE7] text-[#166534]'
                          : put.lastTickDir === 'down'
                          ? 'bg-[#FEE2E2] text-[#991B1B]'
                          : 'text-[#2563EB] hover:underline'
                      }`}
                    >
                      {put.ltp.toFixed(2)}
                    </span>
                  </td>

                  {/* PUT: Price Change */}
                  <td style={putCellStyle} className="py-1.5 xl:py-2 px-1 xl:px-1.5 text-center whitespace-nowrap border-b border-[#E2E8F0]">
                    <span
                      className={`font-semibold text-[10px] xl:text-[11px] ${
                        putPositive ? 'text-[#16A34A]' : 'text-[#DC2626]'
                      }`}
                    >
                      {put.change >= 0 ? '+' : ''}
                      {put.change.toFixed(2)} ({put.pChange >= 0 ? '+' : ''}
                      {put.pChange.toFixed(1)}%)
                    </span>
                  </td>

                  {/* PUT: Build Up */}
                  <td style={putCellStyle} className="py-1.5 xl:py-2 px-1 text-center border-b border-[#E2E8F0]">
                    {renderBuildupBadge(put.buildup)}
                  </td>

                  {/* PUT Greeks */}
                  {showGreeks && (
                    <>
                      <td style={putCellStyle} className="py-1.5 xl:py-2 px-1 text-center text-[#475569] font-medium border-b border-[#E2E8F0]">
                        {put.greeks.vega.toFixed(1)}
                      </td>
                      <td style={putCellStyle} className="py-1.5 xl:py-2 px-1 text-center text-[#0891B2] font-medium border-b border-[#E2E8F0]">
                        {put.greeks.gamma.toFixed(2)}
                      </td>
                      <td style={putCellStyle} className="py-1.5 xl:py-2 px-1 text-center text-[#B45309] font-medium border-b border-[#E2E8F0]">
                        {put.greeks.theta.toFixed(1)}
                      </td>
                      <td style={putCellStyle} className="py-1.5 xl:py-2 px-1 text-center text-[#DC2626] font-medium border-b border-[#E2E8F0]">
                        {put.greeks.delta.toFixed(2)}
                      </td>
                    </>
                  )}

                  {/* PUT: IV */}
                  <td style={putCellStyle} className="py-1.5 xl:py-2 px-1 text-center text-[#0F172A] font-medium border-b border-[#E2E8F0]">
                    {put.iv.toFixed(1)}%
                  </td>

                  {/* PUT: Volume */}
                  <td style={putCellStyle} className="py-1.5 xl:py-2 px-1 xl:px-1.5 text-center text-[#475569] border-b border-[#E2E8F0]">
                    {(put.volume / 1000).toFixed(1)}k
                  </td>

                  {/* PUT: Change in OI */}
                  <td style={putCellStyle} className="py-1.5 xl:py-2 px-1 xl:px-1.5 text-center border-b border-[#E2E8F0]">
                    <span
                      className={`inline-block px-1 xl:px-1.5 py-0.5 rounded text-[9.5px] xl:text-[10.5px] font-semibold ${
                        put.changeOi >= 0
                          ? 'bg-[#DCFCE7] text-[#166534]'
                          : 'bg-[#FEE2E2] text-[#991B1B]'
                      }`}
                    >
                      {put.changeOi >= 0 ? '+' : ''}
                      {(put.changeOi / currentIndex.lotSize).toFixed(0)}
                    </span>
                  </td>

                  {/* PUT: OI with Positive / Negative bar */}
                  <td
                    style={putCellStyle}
                    className="py-1.5 xl:py-2 px-1 xl:px-1.5 text-center relative overflow-hidden text-[#0F172A] font-medium border-b border-[#E2E8F0]"
                  >
                    <div
                      style={{
                        width: `${peOiPct}%`,
                        backgroundColor:
                          put.changeOi >= 0
                            ? isDark
                              ? 'rgba(22, 163, 74, 0.25)'
                              : '#DCFCE7'
                            : isDark
                            ? 'rgba(220, 38, 38, 0.25)'
                            : '#FEE2E2',
                      }}
                      className="absolute left-0 top-0 bottom-0 pointer-events-none"
                    />
                    <div className="relative z-[1] flex items-center justify-center">
                      <span>{(put.oi / currentIndex.lotSize).toLocaleString('en-IN')}</span>
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>

          {/* Table Footer Totals (Always Frozen & Visible at Bottom) */}
          <tfoot className="sticky bottom-0 z-30 font-semibold text-[10px] xl:text-xs whitespace-nowrap shadow-[0_-2px_6px_rgba(0,0,0,0.12)]">
            <tr className="h-[34px]">
              {[
                <span
                  key="ce-oi"
                  style={{ color: isDark ? '#F8FAFC' : '#0F172A' }}
                  className="font-bold"
                >
                  {(sumCeOi / currentIndex.lotSize).toLocaleString('en-IN')}
                </span>,
                <span
                  key="ce-chgoi"
                  className={`font-bold ${
                    sumCeChangeOi >= 0 ? 'text-[#16A34A]' : 'text-[#DC2626]'
                  }`}
                >
                  {sumCeChangeOi >= 0 ? '+' : ''}
                  {(sumCeChangeOi / currentIndex.lotSize).toLocaleString('en-IN', {
                    maximumFractionDigits: 0,
                  })}
                </span>,
                <span
                  key="ce-vol"
                  style={{ color: isDark ? '#CBD5E1' : '#334155' }}
                  className="font-bold"
                >
                  {(sumCeVol / 1000).toLocaleString('en-IN', { maximumFractionDigits: 0 })}k
                </span>,
                <span key="ce-iv" className="text-[#94A3B8]">—</span>,
                ...(showGreeks
                  ? [
                      <span key="ce-d" className="text-[#94A3B8]">—</span>,
                      <span key="ce-t" className="text-[#94A3B8]">—</span>,
                      <span key="ce-g" className="text-[#94A3B8]">—</span>,
                      <span key="ce-v" className="text-[#94A3B8]">—</span>,
                    ]
                  : []),
                <span key="ce-b" className="text-[#94A3B8]">—</span>,
                <span key="ce-c" className="text-[#94A3B8]">—</span>,
              ].map((cellContent, idx) => (
                <td
                  key={idx}
                  style={{
                    backgroundColor: isDark ? '#111827' : '#F1F5F9',
                    borderColor: isDark ? '#334155' : '#CBD5E1',
                  }}
                  className="sticky bottom-0 z-30 h-[34px] py-2 px-1 xl:px-1.5 text-center font-semibold border-t-2"
                >
                  {cellContent}
                </td>
              ))}
              <td
                style={{
                  backgroundColor: isDark ? '#111827' : '#F1F5F9',
                  borderColor: isDark ? '#334155' : '#CBD5E1',
                }}
                className="sticky bottom-0 z-30 h-[34px] py-2 px-1.5 text-center border-t-2 border-r text-[#16A34A] font-bold text-[10px] xl:text-[11px] uppercase"
              >
                TOTAL CE
              </td>
              <td
                style={{
                  backgroundColor: isDark ? '#172554' : '#EFF6FF',
                  color: isDark ? '#60A5FA' : '#1E40AF',
                  borderColor: isDark ? '#1E3A8A' : '#BFDBFE',
                }}
                className="sticky bottom-0 z-30 h-[34px] py-2 px-2 text-center font-bold border-t-2 border-r text-[10px] xl:text-[11px] uppercase"
              >
                TOTALS
              </td>
              <td
                style={{
                  backgroundColor: isDark ? '#111827' : '#F1F5F9',
                  borderColor: isDark ? '#334155' : '#CBD5E1',
                }}
                className="sticky bottom-0 z-30 h-[34px] py-2 px-1.5 text-center border-t-2 text-[#DC2626] font-bold text-[10px] xl:text-[11px] uppercase"
              >
                TOTAL PE
              </td>
              {[
                <span key="pe-c" className="text-[#94A3B8]">—</span>,
                <span key="pe-b" className="text-[#94A3B8]">—</span>,
                ...(showGreeks
                  ? [
                      <span key="pe-v" className="text-[#94A3B8]">—</span>,
                      <span key="pe-g" className="text-[#94A3B8]">—</span>,
                      <span key="pe-t" className="text-[#94A3B8]">—</span>,
                      <span key="pe-d" className="text-[#94A3B8]">—</span>,
                    ]
                  : []),
                <span key="pe-iv" className="text-[#94A3B8]">—</span>,
                <span
                  key="pe-vol"
                  style={{ color: isDark ? '#CBD5E1' : '#334155' }}
                  className="font-bold"
                >
                  {(sumPeVol / 1000).toLocaleString('en-IN', { maximumFractionDigits: 0 })}k
                </span>,
                <span
                  key="pe-chgoi"
                  className={`font-bold ${
                    sumPeChangeOi >= 0 ? 'text-[#16A34A]' : 'text-[#DC2626]'
                  }`}
                >
                  {sumPeChangeOi >= 0 ? '+' : ''}
                  {(sumPeChangeOi / currentIndex.lotSize).toLocaleString('en-IN', {
                    maximumFractionDigits: 0,
                  })}
                </span>,
                <span
                  key="pe-oi"
                  style={{ color: isDark ? '#F8FAFC' : '#0F172A' }}
                  className="font-bold"
                >
                  {(sumPeOi / currentIndex.lotSize).toLocaleString('en-IN')}
                </span>,
              ].map((cellContent, idx) => (
                <td
                  key={idx}
                  style={{
                    backgroundColor: isDark ? '#111827' : '#F1F5F9',
                    borderColor: isDark ? '#334155' : '#CBD5E1',
                  }}
                  className="sticky bottom-0 z-30 h-[34px] py-2 px-1 xl:px-1.5 text-center font-semibold border-t-2"
                >
                  {cellContent}
                </td>
              ))}
            </tr>
          </tfoot>
        </table>
      </div>

      {/* Institutional Strike Order / Action Modal */}
      {selectedStrikeAction && (
        <div className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-[2px] flex items-center justify-center p-4">
          <div className="bg-[#FFFFFF] border border-[#E2E8F0] rounded-[12px] w-full max-w-md p-5 shadow-xl space-y-4">
            <div className="flex items-center justify-between border-b border-[#E2E8F0] pb-3">
              <div>
                <div className="text-base font-semibold text-[#0F172A] flex items-center gap-2">
                  <span>{currentIndex.name}</span>
                  <span className="text-[#2563EB] font-mono-num">{selectedStrikeAction.strike}</span>
                  <span
                    className={`px-2 py-0.5 rounded text-xs font-semibold ${
                      selectedStrikeAction.type === 'CE'
                        ? 'bg-[#DCFCE7] text-[#166534]'
                        : 'bg-[#FEE2E2] text-[#991B1B]'
                    }`}
                  >
                    {selectedStrikeAction.type}
                  </span>
                </div>
                <div className="text-xs text-[#475569] mt-0.5">
                  LTP: ₹{selectedStrikeAction.data.ltp} • IV: {selectedStrikeAction.data.iv}% • Delta:{' '}
                  {selectedStrikeAction.data.greeks.delta}
                </div>
              </div>
              <button
                onClick={() => setSelectedStrikeAction(null)}
                className="text-[#64748B] hover:text-[#0F172A] p-1 rounded-[8px] hover:bg-[#F8FAFC]"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-2">
              <div className="text-xs font-semibold text-[#475569]">Execute Strategy Leg:</div>
              <div className="grid grid-cols-2 gap-2.5">
                <button
                  onClick={() => {
                    onAddLegToStrategy(
                      selectedStrikeAction.type,
                      'BUY',
                      selectedStrikeAction.strike,
                      selectedStrikeAction.data.ltp,
                      selectedStrikeAction.data.iv,
                      selectedStrikeAction.data.greeks
                    );
                    setSelectedStrikeAction(null);
                  }}
                  className="h-[38px] bg-[#16A34A] hover:bg-[#15803D] text-white px-3 rounded-[10px] font-semibold flex items-center justify-center gap-1.5 transition-colors"
                >
                  <ArrowUpRight className="w-4 h-4" />
                  <span>BUY ({selectedStrikeAction.type})</span>
                </button>

                <button
                  onClick={() => {
                    onAddLegToStrategy(
                      selectedStrikeAction.type,
                      'SELL',
                      selectedStrikeAction.strike,
                      selectedStrikeAction.data.ltp,
                      selectedStrikeAction.data.iv,
                      selectedStrikeAction.data.greeks
                    );
                    setSelectedStrikeAction(null);
                  }}
                  className="h-[38px] bg-[#DC2626] hover:bg-[#B91C1C] text-white px-3 rounded-[10px] font-semibold flex items-center justify-center gap-1.5 transition-colors"
                >
                  <ArrowDownRight className="w-4 h-4" />
                  <span>SELL ({selectedStrikeAction.type})</span>
                </button>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2.5 pt-3 border-t border-[#E2E8F0]">
              <button
                onClick={() => {
                  onAddToWatchlist(selectedStrikeAction.strike, selectedStrikeAction.type);
                  setSelectedStrikeAction(null);
                }}
                className="h-[38px] bg-[#FFFFFF] border border-[#E2E8F0] hover:bg-[#F8FAFC] text-[#0F172A] px-3 rounded-[10px] font-medium flex items-center justify-center gap-1.5 transition-colors text-xs"
              >
                <BookmarkPlus className="w-4 h-4 text-[#2563EB]" />
                <span>Add to Watchlist</span>
              </button>

              <button
                onClick={() => {
                  onCreateAlert(
                    selectedStrikeAction.strike,
                    selectedStrikeAction.type,
                    selectedStrikeAction.data.ltp
                  );
                  setSelectedStrikeAction(null);
                }}
                className="h-[38px] bg-[#FFFFFF] border border-[#E2E8F0] hover:bg-[#F8FAFC] text-[#0F172A] px-3 rounded-[10px] font-medium flex items-center justify-center gap-1.5 transition-colors text-xs"
              >
                <Crosshair className="w-4 h-4 text-[#F59E0B]" />
                <span>Set Price Alert</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
