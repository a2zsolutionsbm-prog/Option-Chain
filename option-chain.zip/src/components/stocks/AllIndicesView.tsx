/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * All Indices View (Displays all 23 NSE & BSE Indices from Excel dataset)
 */

import React, { useState, useEffect, useMemo } from 'react';
import {
  MarketIndexRecord,
  marketIndicesService,
} from '../../services/marketIndicesData';
import { GlobalIndicesView } from './GlobalIndicesView';
import {
  Activity,
  ArrowDownRight,
  ArrowUpRight,
  ChevronDown,
  Download,
  Filter,
  Globe,
  Layers,
  Search,
  Sparkles,
  TrendingDown,
  TrendingUp,
  X,
} from 'lucide-react';

export interface AllIndicesViewProps {
  initialScope?: 'GLOBAL' | 'INDIAN';
}

export const AllIndicesView: React.FC<AllIndicesViewProps> = ({
  initialScope = 'GLOBAL',
}) => {
  const [scope, setScope] = useState<'GLOBAL' | 'INDIAN'>(initialScope);
  const [indices, setIndices] = useState<MarketIndexRecord[]>(
    marketIndicesService.getIndices()
  );
  const [selectedFilter, setSelectedFilter] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [sortField, setSortField] = useState<keyof MarketIndexRecord>('ltp');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('desc');
  const [exportNotice, setExportNotice] = useState<string | null>(null);

  useEffect(() => {
    const unsub = marketIndicesService.subscribe((updated) => {
      setIndices([...updated]);
    });
    return () => unsub();
  }, []);

  const handleExportCSV = () => {
    const csvData = marketIndicesService.exportCSV();
    const blob = new Blob([csvData], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `All_Indices_NSE_BSE_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    setExportNotice('Indices exported to CSV successfully!');
    setTimeout(() => setExportNotice(null), 3000);
  };

  // Filtered indices
  const filteredIndices = useMemo(() => {
    return indices.filter((idx) => {
      // Exchange / Category filter
      if (selectedFilter === 'NSE' && idx.exchange !== 'NSE') return false;
      if (selectedFilter === 'BSE' && idx.exchange !== 'BSE') return false;
      if (selectedFilter === 'SECTORAL' && idx.category !== 'Sectoral') return false;
      if (selectedFilter === 'BROAD' && idx.category !== 'Broad Market') return false;
      if (selectedFilter === 'FACTOR' && idx.category !== 'Factor / Strategy') return false;
      if (selectedFilter === 'THEMATIC' && idx.category !== 'Thematic' && idx.category !== 'SME') return false;

      // Search query
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchName = idx.name.toLowerCase().includes(q);
        const matchCat = idx.category.toLowerCase().includes(q);
        const matchEx = idx.exchange.toLowerCase().includes(q);
        if (!matchName && !matchCat && !matchEx) return false;
      }

      return true;
    });
  }, [indices, selectedFilter, searchQuery]);

  // Sorted indices
  const sortedIndices = useMemo(() => {
    return [...filteredIndices].sort((a, b) => {
      const aVal = a[sortField];
      const bVal = b[sortField];
      if (typeof aVal === 'number' && typeof bVal === 'number') {
        return sortOrder === 'asc' ? aVal - bVal : bVal - aVal;
      }
      if (typeof aVal === 'string' && typeof bVal === 'string') {
        return sortOrder === 'asc'
          ? aVal.localeCompare(bVal)
          : bVal.localeCompare(aVal);
      }
      return 0;
    });
  }, [filteredIndices, sortField, sortOrder]);

  const handleSort = (field: keyof MarketIndexRecord) => {
    if (sortField === field) {
      setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortOrder('desc');
    }
  };

  // Stats calculation
  const totalCount = indices.length;
  const nseCount = indices.filter((i) => i.exchange === 'NSE').length;
  const bseCount = indices.filter((i) => i.exchange === 'BSE').length;
  const gainers = indices.filter((i) => i.pChange > 0).length;
  const losers = indices.filter((i) => i.pChange < 0).length;

  // Best multi-year compounders
  const best5Yr = [...indices].sort((a, b) => b.return5Yr - a.return5Yr)[0];
  const best1Yr = [...indices].sort((a, b) => b.return1Yr - a.return1Yr)[0];

  return (
    <div className="space-y-4">
      {/* Top Scope Switcher: All Global Indices vs 23 Indian Indices */}
      <div className="bg-[#0b101c] border border-slate-800 rounded-xl p-2.5 shadow-xl flex items-center justify-between flex-wrap gap-2">
        <div className="flex items-center space-x-2">
          <div className="p-1.5 rounded-lg bg-blue-950 border border-blue-800 text-blue-400">
            <Globe className="w-4 h-4" />
          </div>
          <div>
            <div className="text-xs font-black text-white uppercase tracking-wider flex items-center space-x-2">
              <span>MARKET INDICES INTELLIGENCE</span>
              <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-emerald-950 text-emerald-300 border border-emerald-800 font-mono font-bold">
                LIVE
              </span>
            </div>
            <div className="text-[10.5px] text-slate-400">
              Complete coverage of 31 Global Markets & 23 Domestic NSE/BSE Indices
            </div>
          </div>
        </div>

        <div className="flex items-center space-x-1.5 bg-slate-900/90 p-1 rounded-lg border border-slate-800 text-xs font-bold">
          <button
            onClick={() => setScope('GLOBAL')}
            className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-md transition-all ${
              scope === 'GLOBAL'
                ? 'bg-blue-600 text-white shadow-md ring-1 ring-blue-300'
                : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
            }`}
          >
            <span>🌐</span>
            <span>All Global Indices (31)</span>
            <span className="text-[10px] px-1 py-0.2 rounded bg-blue-900 text-blue-200">World</span>
          </button>

          <button
            onClick={() => setScope('INDIAN')}
            className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-md transition-all ${
              scope === 'INDIAN'
                ? 'bg-cyan-500 text-slate-950 shadow-md ring-1 ring-cyan-300'
                : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
            }`}
          >
            <span>🇮🇳</span>
            <span>Indian Indices (23 from Excel)</span>
            <span className="text-[10px] px-1 py-0.2 rounded bg-cyan-950 text-cyan-200">NSE & BSE</span>
          </button>
        </div>
      </div>

      {scope === 'GLOBAL' ? (
        <GlobalIndicesView />
      ) : (
        <>
          {/* Top Banner & KPI Cards */}
          <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-5 gap-3">
        <div className="bg-[#0b101c] border border-cyan-800/40 rounded-xl p-3 shadow-lg">
          <div className="text-[10.5px] uppercase font-bold text-slate-400">Total Tracked Indices</div>
          <div className="text-xl font-black text-white font-mono mt-0.5 flex items-baseline space-x-1.5">
            <span>{totalCount}</span>
            <span className="text-xs text-slate-400 font-normal">({nseCount} NSE | {bseCount} BSE)</span>
          </div>
          <div className="text-[10.5px] text-cyan-400 mt-1">Live Multi-Asset Coverage</div>
        </div>

        <div className="bg-[#0b101c] border border-emerald-800/40 rounded-xl p-3 shadow-lg">
          <div className="text-[10.5px] uppercase font-bold text-slate-400">Market Breadth (Indices)</div>
          <div className="text-xl font-black font-mono mt-0.5 flex items-center space-x-2">
            <span className="text-emerald-400">▲ {gainers}</span>
            <span className="text-slate-600">/</span>
            <span className="text-rose-400">▼ {losers}</span>
          </div>
          <div className="text-[10.5px] text-emerald-400/80 mt-1">Advancing vs Declining</div>
        </div>

        <div className="bg-[#0b101c] border border-purple-800/40 rounded-xl p-3 shadow-lg">
          <div className="text-[10.5px] uppercase font-bold text-slate-400">Top 1-Yr Return Leader</div>
          <div className="text-base font-black text-white truncate mt-0.5">
            {best1Yr?.name}
          </div>
          <div className="text-xs font-bold text-emerald-400 font-mono">
            +{best1Yr?.return1Yr.toFixed(2)}% (1 Year)
          </div>
        </div>

        <div className="bg-[#0b101c] border border-amber-800/40 rounded-xl p-3 shadow-lg col-span-2 sm:col-span-1">
          <div className="text-[10.5px] uppercase font-bold text-slate-400">Top 5-Yr Multibagger</div>
          <div className="text-base font-black text-white truncate mt-0.5">
            {best5Yr?.name}
          </div>
          <div className="text-xs font-bold text-amber-300 font-mono">
            +{best5Yr?.return5Yr.toLocaleString('en-IN')}% (5 Years)
          </div>
        </div>

        <div className="bg-[#0b101c] border border-slate-800 rounded-xl p-3 shadow-lg flex flex-col justify-between hidden lg:flex">
          <div className="text-[10.5px] uppercase font-bold text-slate-400">Excel Dataset</div>
          <button
            onClick={handleExportCSV}
            className="flex items-center justify-center space-x-1.5 w-full py-1.5 rounded-lg bg-cyan-950 border border-cyan-800 text-cyan-300 hover:bg-cyan-900 transition-colors text-xs font-bold shadow-md"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export 23 Indices</span>
          </button>
        </div>
      </div>

      {exportNotice && (
        <div className="bg-emerald-950/90 border border-emerald-500 text-emerald-200 px-4 py-2 rounded-lg text-xs font-medium flex items-center justify-between shadow-lg">
          <span>{exportNotice}</span>
          <span className="text-[10px] text-emerald-400">Download Complete</span>
        </div>
      )}

      {/* Filter Tabs & Search Bar */}
      <div className="bg-[#0b101c] border border-slate-800 rounded-xl p-3 shadow-xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs">
        {/* Filter Pills */}
        <div className="flex items-center flex-wrap gap-1.5">
          {[
            { id: 'ALL', label: `All Indices (${totalCount})` },
            { id: 'NSE', label: `NSE (${nseCount})` },
            { id: 'BSE', label: `BSE (${bseCount})` },
            { id: 'SECTORAL', label: 'Sectoral' },
            { id: 'BROAD', label: 'Broad Market' },
            { id: 'FACTOR', label: 'Factor / Strategy' },
            { id: 'THEMATIC', label: 'Thematic & SME' },
          ].map((f) => (
            <button
              key={f.id}
              onClick={() => setSelectedFilter(f.id)}
              className={`px-2.5 py-1 rounded font-bold transition-all ${
                selectedFilter === f.id
                  ? 'bg-cyan-500 text-slate-950 shadow-md ring-1 ring-cyan-300'
                  : 'bg-slate-900 border border-slate-800 text-slate-400 hover:text-white hover:bg-slate-800'
              }`}
            >
              {f.label}
            </button>
          ))}
        </div>

        {/* Search & Export on small screens */}
        <div className="flex items-center space-x-2 w-full sm:w-auto">
          <div className="relative w-full sm:w-56">
            <Search className="w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder="Search Index name..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-8 pr-3 py-1 bg-slate-900 border border-slate-800 rounded-lg text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500 transition-colors"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-2 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          <button
            onClick={handleExportCSV}
            className="lg:hidden p-1.5 rounded-lg bg-cyan-950 border border-cyan-800 text-cyan-300 hover:bg-cyan-900 transition-colors"
            title="Download CSV"
          >
            <Download className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Complete Indices Table */}
      <div className="bg-[#0b101c] border border-slate-800 rounded-xl p-3.5 shadow-xl space-y-3">
        <div className="flex items-center justify-between text-xs text-slate-400 border-b border-slate-800 pb-2">
          <div>
            Showing <span className="text-white font-bold">{sortedIndices.length}</span> indices with live ticks
          </div>
          <div className="text-[11px] text-cyan-400">
            Click column headers to sort by Return, Change, or LTP
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-xs font-mono border-collapse min-w-[980px]">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 uppercase bg-[#080d17] text-[10.5px]">
                <th
                  onClick={() => handleSort('name')}
                  className="py-2.5 px-3 text-left cursor-pointer hover:underline"
                >
                  Index Name
                </th>
                <th className="py-2.5 px-2 text-center text-slate-400">Exch</th>
                <th className="py-2.5 px-2 text-center text-slate-400 font-sans">Category</th>
                <th
                  onClick={() => handleSort('ltp')}
                  className="py-2.5 px-2 text-center text-cyan-300 font-black cursor-pointer hover:underline"
                >
                  LTP (₹)
                </th>
                <th
                  onClick={() => handleSort('change')}
                  className="py-2.5 px-2 text-center cursor-pointer hover:underline"
                >
                  Change
                </th>
                <th
                  onClick={() => handleSort('pChange')}
                  className="py-2.5 px-2 text-center cursor-pointer hover:underline"
                >
                  Change (%)
                </th>
                <th className="py-2.5 px-2 text-center text-slate-400">Open</th>
                <th className="py-2.5 px-2 text-center text-slate-400">Prev. Close</th>
                <th className="py-2.5 px-3 text-center text-slate-300">52W Range (Low - High)</th>
                <th
                  onClick={() => handleSort('return1Yr')}
                  className="py-2.5 px-2 text-center cursor-pointer hover:underline text-cyan-400"
                >
                  1 Yr Ret
                </th>
                <th
                  onClick={() => handleSort('return3Yr')}
                  className="py-2.5 px-2 text-center cursor-pointer hover:underline text-purple-400"
                >
                  3 Yr Ret
                </th>
                <th
                  onClick={() => handleSort('return5Yr')}
                  className="py-2.5 px-2 text-center cursor-pointer hover:underline text-amber-400 font-bold"
                >
                  5 Yr Ret
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {sortedIndices.map((idx) => {
                const isUp = idx.pChange > 0;
                const isDown = idx.pChange < 0;

                const colorClass = isUp
                  ? 'text-emerald-400'
                  : isDown
                  ? 'text-rose-400'
                  : 'text-amber-400';

                // 52W range progress
                const range52 = idx.week52High - idx.week52Low || 1;
                const progress52 = Math.min(
                  100,
                  Math.max(0, ((idx.ltp - idx.week52Low) / range52) * 100)
                );

                return (
                  <tr
                    key={idx.id}
                    className="hover:bg-slate-900/60 transition-colors group"
                  >
                    {/* Index Name */}
                    <td className="py-2.5 px-3 font-bold text-white">
                      <div className="flex items-center space-x-2">
                        <span
                          className={`w-2 h-2 rounded-full ${
                            idx.exchange === 'NSE' ? 'bg-cyan-400' : 'bg-amber-400'
                          }`}
                        />
                        <span className="text-slate-100 group-hover:text-cyan-300 transition-colors">
                          {idx.name}
                        </span>
                      </div>
                    </td>

                    {/* Exchange */}
                    <td className="py-2.5 px-2 text-center">
                      <span
                        className={`px-1.5 py-0.5 rounded text-[9.5px] font-black ${
                          idx.exchange === 'NSE'
                            ? 'bg-cyan-950 text-cyan-300 border border-cyan-800'
                            : 'bg-amber-950 text-amber-300 border border-amber-800'
                        }`}
                      >
                        {idx.exchange}
                      </span>
                    </td>

                    {/* Category */}
                    <td className="py-2.5 px-2 text-center font-sans">
                      <span className="text-[10px] px-1.5 py-0.5 rounded bg-slate-900 border border-slate-800 text-slate-300">
                        {idx.category}
                      </span>
                    </td>

                    {/* LTP with live tick arrow (▲ / ▼) */}
                    <td className="py-2.5 px-2 text-center font-black text-sm">
                      <div
                        className={`inline-flex items-center space-x-1 px-2 py-0.5 rounded transition-all ${
                          idx.lastTickDir === 'up'
                            ? 'bg-emerald-500/20 text-emerald-300'
                            : idx.lastTickDir === 'down'
                            ? 'bg-rose-500/20 text-rose-300'
                            : colorClass
                        }`}
                      >
                        <span className="text-[10px]">
                          {idx.lastTickDir === 'up'
                            ? '▲'
                            : idx.lastTickDir === 'down'
                            ? '▼'
                            : ''}
                        </span>
                        <span>
                          {idx.ltp.toLocaleString('en-IN', {
                            minimumFractionDigits: 2,
                            maximumFractionDigits: 2,
                          })}
                        </span>
                      </div>
                    </td>

                    {/* Change */}
                    <td className={`py-2.5 px-2 text-center font-bold ${colorClass}`}>
                      {idx.change >= 0 ? '+' : ''}
                      {idx.change.toFixed(2)}
                    </td>

                    {/* Change % */}
                    <td className="py-2.5 px-2 text-center font-bold">
                      <span
                        className={`inline-block px-1.5 py-0.5 rounded text-[11px] ${
                          isUp
                            ? 'bg-emerald-950/70 text-emerald-300 border border-emerald-800/60'
                            : isDown
                            ? 'bg-rose-950/70 text-rose-300 border border-rose-800/60'
                            : 'bg-amber-950/70 text-amber-300 border border-amber-800/60'
                        }`}
                      >
                        {idx.pChange >= 0 ? '+' : ''}
                        {idx.pChange.toFixed(2)}%
                      </span>
                    </td>

                    {/* Open */}
                    <td className="py-2.5 px-2 text-center text-slate-400">
                      {idx.open.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                    </td>

                    {/* Prev. Close */}
                    <td className="py-2.5 px-2 text-center text-slate-400">
                      {idx.prevClose.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                    </td>

                    {/* 52W Range Bar */}
                    <td className="py-2.5 px-3 text-center">
                      <div className="w-36 mx-auto">
                        <div className="flex items-center justify-between text-[9px] text-slate-400 font-mono mb-0.5">
                          <span>{idx.week52Low.toLocaleString('en-IN', { maximumFractionDigits: 0 })}</span>
                          <span>{idx.week52High.toLocaleString('en-IN', { maximumFractionDigits: 0 })}</span>
                        </div>
                        <div className="relative w-full h-1.5 bg-slate-900 rounded-full overflow-hidden">
                          <div
                            className="absolute top-0 bottom-0 bg-gradient-to-r from-rose-500 via-amber-400 to-emerald-400 rounded-full"
                            style={{ width: '100%' }}
                          />
                          <div
                            className="absolute top-0 bottom-0 w-2 bg-white border border-slate-950 rounded-full shadow-md -translate-x-1/2"
                            style={{ left: `${progress52}%` }}
                          />
                        </div>
                      </div>
                    </td>

                    {/* 1 Yr Returns */}
                    <td className="py-2.5 px-2 text-center font-bold">
                      <span
                        className={
                          idx.return1Yr >= 0 ? 'text-emerald-400' : 'text-rose-400'
                        }
                      >
                        {idx.return1Yr >= 0 ? '+' : ''}
                        {idx.return1Yr.toFixed(2)}%
                      </span>
                    </td>

                    {/* 3 Yr Returns */}
                    <td className="py-2.5 px-2 text-center font-bold">
                      <span
                        className={
                          idx.return3Yr >= 0 ? 'text-emerald-400' : 'text-rose-400'
                        }
                      >
                        {idx.return3Yr >= 0 ? '+' : ''}
                        {idx.return3Yr.toFixed(2)}%
                      </span>
                    </td>

                    {/* 5 Yr Returns */}
                    <td className="py-2.5 px-2 text-center font-black">
                      <span
                        className={
                          idx.return5Yr >= 0 ? 'text-emerald-400' : 'text-rose-400'
                        }
                      >
                        {idx.return5Yr >= 0 ? '+' : ''}
                        {idx.return5Yr.toLocaleString('en-IN', { minimumFractionDigits: 2 })}%
                      </span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
        </>
      )}
    </div>
  );
};
