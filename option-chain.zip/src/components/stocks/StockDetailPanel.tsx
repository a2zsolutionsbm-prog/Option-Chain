/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * Stock Detail Side Panel (TradingView style chart, fundamentals, alerts, 52W ranges)
 */

import React, { useState } from 'react';
import { StockQuote, stocksMarketWatch } from '../../services/stocksMarketWatch';
import {
  Activity,
  AlertCircle,
  ArrowDownRight,
  ArrowUpRight,
  Bell,
  Bookmark,
  Calendar,
  Check,
  ChevronRight,
  ExternalLink,
  Layers,
  LineChart,
  Maximize2,
  PieChart,
  Plus,
  Share2,
  TrendingDown,
  TrendingUp,
  X,
} from 'lucide-react';

interface StockDetailPanelProps {
  stock: StockQuote;
  onClose: () => void;
  activeWatchlist: string;
  isFavorite: boolean;
  onToggleFavorite: (symbol: string) => void;
}

type ChartTimeframe = '1m' | '5m' | '15m' | '1H' | '1D' | '1W' | '1M';

export const StockDetailPanel: React.FC<StockDetailPanelProps> = ({
  stock,
  onClose,
  activeWatchlist,
  isFavorite,
  onToggleFavorite,
}) => {
  const [timeframe, setTimeframe] = useState<ChartTimeframe>('1D');
  const [alertTargetPrice, setAlertTargetPrice] = useState<string>(stock.ltp.toString());
  const [alertCondition, setAlertCondition] = useState<'ABOVE' | 'BELOW' | '52W_BREAKOUT'>('ABOVE');
  const [showAlertModal, setShowAlertModal] = useState(false);
  const [alertSuccess, setAlertSuccess] = useState(false);

  const isPositive = stock.change >= 0;

  // Day range progress
  const dayRangeSpan = stock.high - stock.low || 1;
  const dayProgressPct = Math.min(100, Math.max(0, ((stock.ltp - stock.low) / dayRangeSpan) * 100));

  // 52 Week range progress
  const week52Span = stock.week52High - stock.week52Low || 1;
  const week52ProgressPct = Math.min(100, Math.max(0, ((stock.ltp - stock.week52Low) / week52Span) * 100));

  // Generate synthetic chart path based on timeframe
  const generateChartPoints = () => {
    const count = 35;
    const base = stock.prevClose;
    const points: { x: number; y: number; price: number }[] = [];
    const width = 500;
    const height = 180;
    const padding = 20;

    let current = stock.open;
    const prices: number[] = [stock.open];

    for (let i = 1; i < count; i++) {
      const volatility = stock.ltp * 0.003;
      const trend = (i / count) * (stock.ltp - stock.open);
      current = +(stock.open + trend + (Math.sin(i * 1.5) * volatility)).toFixed(2);
      prices.push(current);
    }
    // Make sure the last point matches current LTP
    prices[prices.length - 1] = stock.ltp;

    const minP = Math.min(...prices, stock.low);
    const maxP = Math.max(...prices, stock.high);
    const pRange = maxP - minP || 1;

    prices.forEach((p, idx) => {
      const x = padding + (idx / (count - 1)) * (width - padding * 2);
      const y = height - padding - ((p - minP) / pRange) * (height - padding * 2);
      points.push({ x, y, price: p });
    });

    return { points, minP, maxP, width, height };
  };

  const chartData = generateChartPoints();
  const svgPath = chartData.points.map((pt, i) => `${i === 0 ? 'M' : 'L'} ${pt.x} ${pt.y}`).join(' ');

  const handleSaveAlert = () => {
    const target = parseFloat(alertTargetPrice);
    if (!isNaN(target)) {
      stocksMarketWatch.addAlert(stock.symbol, target, alertCondition);
      setAlertSuccess(true);
      setTimeout(() => {
        setAlertSuccess(false);
        setShowAlertModal(false);
      }, 1500);
    }
  };

  return (
    <div className="fixed inset-y-0 right-0 z-50 w-full max-w-lg bg-[#0a0f1d] border-l border-slate-800 shadow-2xl flex flex-col justify-between text-slate-100 overflow-y-auto no-scrollbar animate-in slide-in-from-right duration-300">
      {/* Top Header */}
      <div>
        <div className="sticky top-0 z-20 bg-[#0a0f1d]/95 backdrop-blur-md border-b border-slate-800/90 p-4 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <button
              onClick={() => onToggleFavorite(stock.symbol)}
              className={`p-2 rounded-lg border transition-colors ${
                isFavorite
                  ? 'bg-amber-500/20 text-amber-400 border-amber-500/40'
                  : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-white'
              }`}
              title={isFavorite ? 'Remove from Watchlist' : 'Add to Watchlist'}
            >
              <Bookmark className={`w-4 h-4 ${isFavorite ? 'fill-amber-400' : ''}`} />
            </button>

            <div>
              <div className="flex items-center space-x-2">
                <h2 className="text-base font-black tracking-wide text-white">{stock.symbol}</h2>
                <span className="text-[10px] px-2 py-0.5 rounded bg-cyan-950 text-cyan-300 border border-cyan-800 font-mono font-bold">
                  {stock.sector}
                </span>
              </div>
              <div className="text-xs text-slate-400 truncate max-w-[240px]">{stock.name}</div>
            </div>
          </div>

          <div className="flex items-center space-x-1.5">
            <button
              onClick={() => setShowAlertModal(true)}
              className="p-2 rounded-lg bg-slate-900 border border-slate-800 text-slate-300 hover:text-cyan-300 transition-colors"
              title="Set Price Alert"
            >
              <Bell className="w-4 h-4" />
            </button>

            <button
              onClick={onClose}
              className="p-2 rounded-lg bg-slate-900 border border-slate-800 text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Live Price Hero */}
        <div className="p-4 bg-gradient-to-b from-slate-900/60 to-transparent border-b border-slate-800/60 space-y-3">
          <div className="flex items-baseline justify-between">
            <div className="flex items-baseline space-x-2">
              <span className="text-2xl font-black font-mono tracking-tight text-white">
                ₹{stock.ltp.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
              </span>
              <span
                className={`text-sm font-bold font-mono flex items-center ${
                  isPositive ? 'text-emerald-400' : 'text-rose-400'
                }`}
              >
                {isPositive ? '▲ +' : '▼ '}
                {stock.change.toFixed(2)} ({isPositive ? '+' : ''}{stock.pChange.toFixed(2)}%)
              </span>
            </div>

            <div className="text-right">
              <span className="text-[10px] uppercase text-slate-400 font-mono">VWAP</span>
              <div className="text-xs font-bold text-slate-200 font-mono">₹{stock.vwap.toFixed(2)}</div>
            </div>
          </div>

          {/* Timeframe selector */}
          <div className="flex items-center justify-between bg-slate-900/90 rounded-lg p-1 border border-slate-800 text-xs">
            {(['1m', '5m', '15m', '1H', '1D', '1W', '1M'] as ChartTimeframe[]).map((tf) => (
              <button
                key={tf}
                onClick={() => setTimeframe(tf)}
                className={`px-2.5 py-1 rounded font-bold transition-all ${
                  timeframe === tf
                    ? 'bg-cyan-500 text-slate-950 shadow-md'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {tf}
              </button>
            ))}
          </div>

          {/* Mini Interactive Chart */}
          <div className="relative bg-slate-950/70 border border-slate-800/80 rounded-xl p-2 overflow-hidden">
            <svg viewBox={`0 0 ${chartData.width} ${chartData.height}`} className="w-full h-40">
              <defs>
                <linearGradient id="priceGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor={isPositive ? '#10b981' : '#f43f5e'} stopOpacity="0.3" />
                  <stop offset="100%" stopColor={isPositive ? '#10b981' : '#f43f5e'} stopOpacity="0.0" />
                </linearGradient>
              </defs>

              {/* Area fill */}
              <path
                d={`${svgPath} L ${chartData.points[chartData.points.length - 1].x} ${chartData.height} L ${chartData.points[0].x} ${chartData.height} Z`}
                fill="url(#priceGradient)"
              />

              {/* Line */}
              <path
                d={svgPath}
                fill="none"
                stroke={isPositive ? '#10b981' : '#f43f5e'}
                strokeWidth="2.5"
                strokeLinecap="round"
                strokeLinejoin="round"
              />

              {/* Current Price Dot */}
              <circle
                cx={chartData.points[chartData.points.length - 1].x}
                cy={chartData.points[chartData.points.length - 1].y}
                r="4.5"
                fill={isPositive ? '#10b981' : '#f43f5e'}
                stroke="#ffffff"
                strokeWidth="1.5"
              />
            </svg>

            <div className="flex items-center justify-between text-[10px] text-slate-400 px-2 font-mono">
              <span>Low: ₹{chartData.minP.toFixed(2)}</span>
              <span className="text-cyan-400 font-bold">Live Stream ({timeframe})</span>
              <span>High: ₹{chartData.maxP.toFixed(2)}</span>
            </div>
          </div>
        </div>

        {/* Range Bars (Day & 52-Week) */}
        <div className="p-4 space-y-4 border-b border-slate-800/60">
          {/* Day Range */}
          <div>
            <div className="flex items-center justify-between text-xs mb-1.5 font-mono">
              <span className="text-slate-400">Day Low: ₹{stock.low.toFixed(2)}</span>
              <span className="text-slate-300 font-bold">Today's Range</span>
              <span className="text-slate-400">Day High: ₹{stock.high.toFixed(2)}</span>
            </div>
            <div className="relative w-full h-2 bg-slate-900 rounded-full overflow-hidden">
              <div
                className="absolute top-0 bottom-0 bg-gradient-to-r from-rose-500 via-amber-400 to-emerald-400 rounded-full"
                style={{ width: '100%' }}
              />
              <div
                className="absolute top-0 bottom-0 w-2.5 bg-white border border-slate-950 rounded-full shadow-md -translate-x-1/2"
                style={{ left: `${dayProgressPct}%` }}
              />
            </div>
          </div>

          {/* 52-Week Range */}
          <div>
            <div className="flex items-center justify-between text-xs mb-1.5 font-mono">
              <span className="text-slate-400">52W Low: ₹{stock.week52Low.toFixed(2)}</span>
              <span className="text-slate-300 font-bold">52-Week Range</span>
              <span className="text-slate-400">52W High: ₹{stock.week52High.toFixed(2)}</span>
            </div>
            <div className="relative w-full h-2 bg-slate-900 rounded-full overflow-hidden">
              <div
                className="absolute top-0 bottom-0 bg-gradient-to-r from-rose-500 via-amber-400 to-emerald-400 rounded-full"
                style={{ width: '100%' }}
              />
              <div
                className="absolute top-0 bottom-0 w-2.5 bg-cyan-300 border border-slate-950 rounded-full shadow-md -translate-x-1/2"
                style={{ left: `${week52ProgressPct}%` }}
              />
            </div>
          </div>
        </div>

        {/* Fundamental & Market Metrics Grid */}
        <div className="p-4 space-y-3">
          <div className="text-xs font-bold uppercase tracking-wider text-slate-300">
            Market Statistics & Fundamentals
          </div>

          <div className="grid grid-cols-2 gap-2.5 text-xs font-mono">
            <div className="bg-slate-900/60 border border-slate-800 rounded-lg p-2.5">
              <span className="text-slate-400 text-[10.5px]">Market Cap</span>
              <div className="text-sm font-bold text-white mt-0.5">
                ₹{(stock.marketCapCr).toLocaleString('en-IN')} Cr
              </div>
            </div>

            <div className="bg-slate-900/60 border border-slate-800 rounded-lg p-2.5">
              <span className="text-slate-400 text-[10.5px]">Traded Volume</span>
              <div className="text-sm font-bold text-slate-200 mt-0.5">
                {stock.volume.toLocaleString('en-IN')}
              </div>
            </div>

            <div className="bg-slate-900/60 border border-slate-800 rounded-lg p-2.5">
              <span className="text-slate-400 text-[10.5px]">Turnover (₹)</span>
              <div className="text-sm font-bold text-slate-200 mt-0.5">
                ₹{stock.turnoverCr.toLocaleString('en-IN')} Cr
              </div>
            </div>

            <div className="bg-slate-900/60 border border-slate-800 rounded-lg p-2.5">
              <span className="text-slate-400 text-[10.5px]">Total Trades</span>
              <div className="text-sm font-bold text-slate-200 mt-0.5">
                {stock.tradesCount.toLocaleString('en-IN')}
              </div>
            </div>

            <div className="bg-slate-900/60 border border-slate-800 rounded-lg p-2.5">
              <span className="text-slate-400 text-[10.5px]">P/E Ratio</span>
              <div className="text-sm font-bold text-cyan-300 mt-0.5">
                {stock.peRatio.toFixed(1)}x
              </div>
            </div>

            <div className="bg-slate-900/60 border border-slate-800 rounded-lg p-2.5">
              <span className="text-slate-400 text-[10.5px]">EPS (TTM)</span>
              <div className="text-sm font-bold text-emerald-300 mt-0.5">
                ₹{stock.eps.toFixed(2)}
              </div>
            </div>

            <div className="bg-slate-900/60 border border-slate-800 rounded-lg p-2.5">
              <span className="text-slate-400 text-[10.5px]">Dividend Yield</span>
              <div className="text-sm font-bold text-amber-300 mt-0.5">
                {stock.dividendYield.toFixed(2)}%
              </div>
            </div>

            <div className="bg-slate-900/60 border border-slate-800 rounded-lg p-2.5">
              <span className="text-slate-400 text-[10.5px]">Previous Close</span>
              <div className="text-sm font-bold text-slate-300 mt-0.5">
                ₹{stock.prevClose.toFixed(2)}
              </div>
            </div>
          </div>
        </div>

        {/* Index Memberships */}
        <div className="p-4 border-t border-slate-800/80 space-y-2">
          <div className="text-xs font-bold uppercase tracking-wider text-slate-400">
            Index Segments
          </div>
          <div className="flex flex-wrap gap-1.5">
            {stock.segments.map((seg) => (
              <span
                key={seg}
                className="px-2 py-0.5 rounded-full text-[10px] bg-slate-900 border border-slate-700 text-slate-300 font-mono"
              >
                {seg}
              </span>
            ))}
          </div>
        </div>
      </div>

      {/* Set Alert Modal */}
      {showAlertModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#0b101c] border border-cyan-800/70 rounded-xl p-5 w-full max-w-sm shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <span className="font-bold text-white text-sm flex items-center space-x-2">
                <Bell className="w-4 h-4 text-cyan-400" />
                <span>Set Alert for {stock.symbol}</span>
              </span>
              <button onClick={() => setShowAlertModal(false)} className="text-slate-400 hover:text-white">
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="text-slate-400 block mb-1">Alert Condition</label>
                <select
                  value={alertCondition}
                  onChange={(e) => setAlertCondition(e.target.value as any)}
                  className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2 text-white font-mono"
                >
                  <option value="ABOVE">Price reaches or goes ABOVE</option>
                  <option value="BELOW">Price falls or goes BELOW</option>
                  <option value="52W_BREAKOUT">52-Week High Breakout (₹{stock.week52High})</option>
                </select>
              </div>

              {alertCondition !== '52W_BREAKOUT' && (
                <div>
                  <label className="text-slate-400 block mb-1">Target Price (₹)</label>
                  <input
                    type="number"
                    step="0.05"
                    value={alertTargetPrice}
                    onChange={(e) => setAlertTargetPrice(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2 text-white font-mono text-sm"
                  />
                  <div className="text-[10px] text-slate-400 mt-1">
                    Current LTP: ₹{stock.ltp.toFixed(2)}
                  </div>
                </div>
              )}

              {alertSuccess ? (
                <div className="p-2 bg-emerald-950/80 border border-emerald-500 text-emerald-300 rounded text-center font-bold">
                  ✓ Alert Set Successfully!
                </div>
              ) : (
                <button
                  onClick={handleSaveAlert}
                  className="w-full py-2 bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold rounded-lg transition-colors shadow-lg"
                >
                  Confirm Alert Trigger
                </button>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
