/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * Global Indices Terminal View (Dhan Global Indices dataset)
 * Live world market quotes, regional filters, Indian market impact analysis & CSV export.
 */

import React, { useState, useEffect, useMemo } from 'react';
import {
  GlobalIndexRecord,
  GlobalRegion,
  globalIndicesService,
  GlobalSentimentSummary,
} from '../../services/globalIndicesData';
import {
  Activity,
  ArrowDownRight,
  ArrowUpRight,
  CheckCircle2,
  Clock,
  Compass,
  Download,
  Flame,
  Globe,
  HelpCircle,
  Layers,
  Search,
  SlidersHorizontal,
  Sparkles,
  TrendingDown,
  TrendingUp,
  X,
  Zap,
} from 'lucide-react';

interface GlobalIndicesViewProps {
  onSelectIndexForDetail?: (index: GlobalIndexRecord) => void;
}

export const GlobalIndicesView: React.FC<GlobalIndicesViewProps> = ({
  onSelectIndexForDetail,
}) => {
  const [indices, setIndices] = useState<GlobalIndexRecord[]>(
    globalIndicesService.getIndices()
  );
  const [sentiment, setSentiment] = useState<GlobalSentimentSummary>(
    globalIndicesService.computeSentimentSummary()
  );
  const [selectedRegion, setSelectedRegion] = useState<string>('ALL');
  const [statusFilter, setStatusFilter] = useState<'ALL' | 'OPEN'>('ALL');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [sortField, setSortField] = useState<keyof GlobalIndexRecord>('pChange');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('desc');
  const [exportNotice, setExportNotice] = useState<string | null>(null);

  useEffect(() => {
    const unsub = globalIndicesService.subscribe((updated) => {
      setIndices([...updated]);
      setSentiment(globalIndicesService.computeSentimentSummary());
    });
    return () => unsub();
  }, []);

  const handleExportCSV = () => {
    const csvData = globalIndicesService.exportCSV();
    const blob = new Blob([csvData], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `Dhan_Global_Indices_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    setExportNotice('Global Indices dataset downloaded successfully!');
    setTimeout(() => setExportNotice(null), 3000);
  };

  // Filtered list
  const filteredIndices = useMemo(() => {
    return indices.filter((idx) => {
      // Region filter
      if (selectedRegion !== 'ALL' && idx.region !== selectedRegion) {
        return false;
      }

      // Status filter
      if (statusFilter === 'OPEN' && idx.status !== 'OPEN') {
        return false;
      }

      // Search query
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchName = idx.name.toLowerCase().includes(q);
        const matchCountry = idx.country.toLowerCase().includes(q);
        const matchRegion = idx.region.toLowerCase().includes(q);
        const matchReason = idx.impactReason.toLowerCase().includes(q);
        if (!matchName && !matchCountry && !matchRegion && !matchReason) {
          return false;
        }
      }

      return true;
    });
  }, [indices, selectedRegion, statusFilter, searchQuery]);

  // Sorted list
  const sortedIndices = useMemo(() => {
    return [...filteredIndices].sort((a, b) => {
      const aVal = a[sortField];
      const bVal = b[sortField];
      if (typeof aVal === 'number' && typeof bVal === 'number') {
        return sortOrder === 'asc' ? aVal - bVal : bVal - aVal;
      }
      if (typeof aVal === 'string' && typeof bVal === 'string') {
        return sortOrder === 'asc'
          ? aVal.localeCompare(bVal)
          : bVal.localeCompare(aVal);
      }
      return 0;
    });
  }, [filteredIndices, sortField, sortOrder]);

  const handleSort = (field: keyof GlobalIndexRecord) => {
    if (sortField === field) {
      setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortOrder('desc');
    }
  };

  // Regional breakdown counts
  const totalCount = indices.length;
  const asiaCount = indices.filter((i) => i.region === 'Asia').length;
  const americasCount = indices.filter((i) => i.region === 'Americas').length;
  const europeCount = indices.filter((i) => i.region === 'Europe').length;
  const macroCount = indices.filter((i) => i.region === 'Macro & Commodities').length;
  const openCount = indices.filter((i) => i.status === 'OPEN').length;

  // Key hero indices for quick cards
  const gift = indices.find((i) => i.id === 'gift_nifty');
  const dow = indices.find((i) => i.id === 'dow_jones');
  const nikkei = indices.find((i) => i.id === 'nikkei_225');
  const dax = indices.find((i) => i.id === 'dax_40');
  const dxy = indices.find((i) => i.id === 'dollar_index');
  const brent = indices.find((i) => i.id === 'brent_crude');

  return (
    <div className="space-y-4">
      {/* 1. Global Market Pulse Summary Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2.5">
        {/* Sentiment Meter Card */}
        <div className="bg-[#0b101c] border border-cyan-800/40 rounded-xl p-3 shadow-lg col-span-2 sm:col-span-1">
          <div className="flex items-center justify-between">
            <span className="text-[10px] uppercase font-bold text-slate-400">Global Sentiment</span>
            <span className="px-1.5 py-0.5 rounded text-[9px] font-mono font-bold bg-cyan-950 text-cyan-300 border border-cyan-800">
              {sentiment.sentimentScore}/100
            </span>
          </div>
          <div className="text-base font-black text-emerald-400 mt-1 flex items-center space-x-1.5">
            <Sparkles className="w-4 h-4 text-emerald-400" />
            <span>{sentiment.sentimentLabel}</span>
          </div>
          <div className="text-[10px] text-slate-400 mt-1">
            Global market cues skewing risk-on
          </div>
        </div>

        {/* GIFT NIFTY & Gap Forecast */}
        <div className="bg-[#0b101c] border border-emerald-800/50 rounded-xl p-3 shadow-lg col-span-2 sm:col-span-2">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-1.5">
              <span className="text-base">🇮🇳</span>
              <span className="text-xs font-black text-white">GIFT NIFTY</span>
              <span className="px-1.5 py-0.2 rounded text-[9px] font-bold bg-emerald-950 text-emerald-300 border border-emerald-800">
                LIVE
              </span>
            </div>
            <div className="text-[10px] text-cyan-400 font-mono">
              Gap: <span className="font-bold text-emerald-400">{sentiment.projectedNiftyGap}</span>
            </div>
          </div>
          <div className="flex items-baseline space-x-2 mt-1">
            <span className="text-lg font-black text-white font-mono">
              {gift?.ltp.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
            </span>
            <span className="text-xs font-bold text-emerald-400 font-mono">
              +{gift?.change.toFixed(2)} (+{gift?.pChange.toFixed(2)}%)
            </span>
          </div>
          <div className="text-[10px] text-slate-400 truncate mt-0.5">
            NSE Nifty opening projected +{Math.round((gift?.change || 68) * 0.95)} pts higher
          </div>
        </div>

        {/* US Wall Street (Dow Jones) */}
        <div className="bg-[#0b101c] border border-blue-800/40 rounded-xl p-3 shadow-lg">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-1">
              <span className="text-xs">🇺🇸</span>
              <span className="text-[11px] font-bold text-slate-300">DOW JONES</span>
            </div>
            <span className="text-[9px] text-slate-500 font-mono">US 30</span>
          </div>
          <div className="text-sm font-black text-white font-mono mt-1">
            {dow?.ltp.toLocaleString('en-IN', { maximumFractionDigits: 0 })}
          </div>
          <div className="text-[10.5px] font-bold text-emerald-400 font-mono">
            +{dow?.change.toFixed(0)} (+{dow?.pChange.toFixed(2)}%)
          </div>
        </div>

        {/* Asia Pacific (Nikkei 225) */}
        <div className="bg-[#0b101c] border border-purple-800/40 rounded-xl p-3 shadow-lg">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-1">
              <span className="text-xs">🇯🇵</span>
              <span className="text-[11px] font-bold text-slate-300">NIKKEI 225</span>
            </div>
            <span className="text-[9px] text-emerald-400 font-mono animate-pulse">● OPEN</span>
          </div>
          <div className="text-sm font-black text-white font-mono mt-1">
            {nikkei?.ltp.toLocaleString('en-IN', { maximumFractionDigits: 0 })}
          </div>
          <div className="text-[10.5px] font-bold text-emerald-400 font-mono">
            +{nikkei?.change.toFixed(0)} (+{nikkei?.pChange.toFixed(2)}%)
          </div>
        </div>

        {/* Macro Health: Brent Crude & Dollar Index */}
        <div className="bg-[#0b101c] border border-amber-800/40 rounded-xl p-3 shadow-lg">
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-bold text-slate-400">CRUDE & DXY</span>
            <span className="text-[9px] text-emerald-400 font-bold">FAVORABLE</span>
          </div>
          <div className="text-xs font-mono font-bold text-slate-200 mt-1 flex justify-between">
            <span>🛢️ ${brent?.ltp.toFixed(2)}</span>
            <span className="text-emerald-400 font-normal">{brent?.pChange.toFixed(2)}%</span>
          </div>
          <div className="text-xs font-mono font-bold text-slate-200 mt-0.5 flex justify-between">
            <span>💵 DXY {dxy?.ltp.toFixed(2)}</span>
            <span className="text-emerald-400 font-normal">{dxy?.pChange.toFixed(2)}%</span>
          </div>
        </div>
      </div>

      {exportNotice && (
        <div className="bg-emerald-950/90 border border-emerald-500 text-emerald-200 px-4 py-2 rounded-lg text-xs font-medium flex items-center justify-between shadow-lg">
          <div className="flex items-center space-x-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            <span>{exportNotice}</span>
          </div>
          <span className="text-[10px] text-emerald-400 font-mono">Dhan_Global_Indices.csv</span>
        </div>
      )}

      {/* 2. Filter Bar, Regional Pills, Search & Export */}
      <div className="bg-[#0b101c] border border-slate-800 rounded-xl p-3 shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-3 text-xs">
        {/* Regional Filter Pills */}
        <div className="flex items-center flex-wrap gap-1.5">
          {[
            { id: 'ALL', label: `All Global (${totalCount})` },
            { id: 'Asia', label: `Asia-Pacific (${asiaCount})` },
            { id: 'Americas', label: `Americas (${americasCount})` },
            { id: 'Europe', label: `Europe (${europeCount})` },
            { id: 'Macro & Commodities', label: `Macro & Commodities (${macroCount})` },
          ].map((r) => (
            <button
              key={r.id}
              onClick={() => setSelectedRegion(r.id)}
              className={`px-2.5 py-1 rounded font-bold transition-all ${
                selectedRegion === r.id
                  ? 'bg-blue-600 text-white shadow-md ring-1 ring-blue-300'
                  : 'bg-slate-900 border border-slate-800 text-slate-400 hover:text-white hover:bg-slate-800'
              }`}
            >
              {r.label}
            </button>
          ))}

          {/* Open Markets Only Filter */}
          <button
            onClick={() => setStatusFilter(statusFilter === 'ALL' ? 'OPEN' : 'ALL')}
            className={`px-2.5 py-1 rounded font-bold transition-all flex items-center space-x-1 ${
              statusFilter === 'OPEN'
                ? 'bg-emerald-500 text-slate-950 ring-1 ring-emerald-300'
                : 'bg-slate-900 border border-slate-800 text-slate-400 hover:text-white'
            }`}
          >
            <span className={`w-1.5 h-1.5 rounded-full ${statusFilter === 'OPEN' ? 'bg-slate-950' : 'bg-emerald-400 animate-pulse'}`} />
            <span>Only Live/Open ({openCount})</span>
          </button>
        </div>

        {/* Search & Export Buttons */}
        <div className="flex items-center space-x-2 w-full md:w-auto">
          <div className="relative w-full md:w-64">
            <Search className="w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder="Search index, country, or cue..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-8 pr-3 py-1 bg-slate-900 border border-slate-800 rounded-lg text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500 transition-colors"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-2 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          <button
            onClick={handleExportCSV}
            className="flex items-center space-x-1.5 px-3 py-1 bg-cyan-950 hover:bg-cyan-900 border border-cyan-800 text-cyan-300 hover:text-white rounded-lg transition-colors font-bold whitespace-nowrap shadow-md"
            title="Download CSV of All Global Indices"
          >
            <Download className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Export Global CSV</span>
          </button>
        </div>
      </div>

      {/* 3. Comprehensive Global Indices Table */}
      <div className="bg-[#0b101c] border border-slate-800 rounded-xl p-3.5 shadow-xl space-y-3">
        <div className="flex items-center justify-between text-xs text-slate-400 border-b border-slate-800 pb-2">
          <div className="flex items-center space-x-2">
            <span>
              Tracking <span className="text-white font-bold">{sortedIndices.length}</span> global market indices
            </span>
            <span className="text-slate-600">|</span>
            <span className="text-emerald-400 font-mono font-bold">
              ▲ {sentiment.advances} Advancing
            </span>
            <span className="text-rose-400 font-mono font-bold">
              ▼ {sentiment.declines} Declining
            </span>
          </div>
          <div className="text-[11px] text-cyan-400 hidden sm:block">
            Real-time multi-market streaming ticks with Indian market correlation
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-xs font-mono border-collapse min-w-[1050px]">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 uppercase bg-[#080d17] text-[10px]">
                <th
                  onClick={() => handleSort('name')}
                  className="py-2.5 px-3 text-left cursor-pointer hover:underline"
                >
                  Global Index
                </th>
                <th className="py-2.5 px-2 text-center text-slate-400 font-sans">Country / Region</th>
                <th className="py-2.5 px-2 text-center text-slate-400">Status</th>
                <th
                  onClick={() => handleSort('ltp')}
                  className="py-2.5 px-2 text-center text-cyan-300 font-black cursor-pointer hover:underline"
                >
                  LTP
                </th>
                <th
                  onClick={() => handleSort('change')}
                  className="py-2.5 px-2 text-center cursor-pointer hover:underline"
                >
                  Change
                </th>
                <th
                  onClick={() => handleSort('pChange')}
                  className="py-2.5 px-2 text-center cursor-pointer hover:underline"
                >
                  Change (%)
                </th>
                <th className="py-2.5 px-2 text-center text-slate-400">Open</th>
                <th className="py-2.5 px-2 text-center text-slate-400">High</th>
                <th className="py-2.5 px-2 text-center text-slate-400">Low</th>
                <th className="py-2.5 px-2 text-center text-slate-400">Prev. Close</th>
                <th className="py-2.5 px-3 text-center text-slate-300">52W Range</th>
                <th className="py-2.5 px-3 text-left text-slate-300 font-sans">Impact on India & Strategic Cue</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {sortedIndices.map((idx) => {
                const isUp = idx.pChange > 0;
                const isDown = idx.pChange < 0;

                const colorClass = isUp
                  ? 'text-emerald-400'
                  : isDown
                  ? 'text-rose-400'
                  : 'text-amber-400';

                // 52W range progress
                const range52 = idx.week52High - idx.week52Low || 1;
                const progress52 = Math.min(
                  100,
                  Math.max(0, ((idx.ltp - idx.week52Low) / range52) * 100)
                );

                const isGift = idx.id === 'gift_nifty';

                return (
                  <tr
                    key={idx.id}
                    onClick={() => onSelectIndexForDetail?.(idx)}
                    className={`hover:bg-slate-900/70 transition-colors group cursor-pointer ${
                      isGift ? 'bg-cyan-950/20 border-l-2 border-l-cyan-400' : ''
                    }`}
                  >
                    {/* Index Name & Flag */}
                    <td className="py-2.5 px-3 font-bold text-white">
                      <div className="flex items-center space-x-2">
                        <span className="text-base select-none">{idx.flag}</span>
                        <div>
                          <div className="flex items-center space-x-1.5">
                            <span className="text-slate-100 group-hover:text-cyan-300 transition-colors font-sans font-black">
                              {idx.name}
                            </span>
                            {isGift && (
                              <span className="px-1.5 py-0.2 rounded text-[9px] font-black bg-cyan-950 text-cyan-300 border border-cyan-800">
                                GIFT IX
                              </span>
                            )}
                          </div>
                          <div className="text-[10px] text-slate-500 font-normal font-sans">
                            {idx.tradingHours}
                          </div>
                        </div>
                      </div>
                    </td>

                    {/* Country & Region */}
                    <td className="py-2.5 px-2 text-center font-sans">
                      <div className="text-xs text-slate-300 font-medium">{idx.country}</div>
                      <div className="text-[10px] text-slate-500">{idx.region}</div>
                    </td>

                    {/* Market Status */}
                    <td className="py-2.5 px-2 text-center">
                      <span
                        className={`inline-flex items-center space-x-1 px-1.5 py-0.5 rounded text-[9.5px] font-black ${
                          idx.status === 'OPEN'
                            ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                            : 'bg-slate-900 text-slate-400 border border-slate-800'
                        }`}
                      >
                        <span
                          className={`w-1.5 h-1.5 rounded-full ${
                            idx.status === 'OPEN' ? 'bg-emerald-400 animate-pulse' : 'bg-slate-500'
                          }`}
                        />
                        <span>{idx.status}</span>
                      </span>
                    </td>

                    {/* LTP with live tick arrow (▲ / ▼) */}
                    <td className="py-2.5 px-2 text-center font-black text-sm">
                      <div
                        className={`inline-flex items-center space-x-1 px-2 py-0.5 rounded transition-all ${
                          idx.lastTickDir === 'up'
                            ? 'bg-emerald-500/20 text-emerald-300'
                            : idx.lastTickDir === 'down'
                            ? 'bg-rose-500/20 text-rose-300'
                            : colorClass
                        }`}
                      >
                        <span className="text-[10px]">
                          {idx.lastTickDir === 'up'
                            ? '▲'
                            : idx.lastTickDir === 'down'
                            ? '▼'
                            : ''}
                        </span>
                        <span>
                          {idx.ltp.toLocaleString('en-US', {
                            minimumFractionDigits: 2,
                            maximumFractionDigits: 2,
                          })}
                        </span>
                        <span className="text-[9px] text-slate-500 font-normal">
                          {idx.currency}
                        </span>
                      </div>
                    </td>

                    {/* Change */}
                    <td className={`py-2.5 px-2 text-center font-bold ${colorClass}`}>
                      {idx.change >= 0 ? '+' : ''}
                      {idx.change.toFixed(2)}
                    </td>

                    {/* Change % */}
                    <td className="py-2.5 px-2 text-center font-bold">
                      <span
                        className={`inline-block px-1.5 py-0.5 rounded text-[11px] ${
                          isUp
                            ? 'bg-emerald-950/70 text-emerald-300 border border-emerald-800/60'
                            : isDown
                            ? 'bg-rose-950/70 text-rose-300 border border-rose-800/60'
                            : 'bg-amber-950/70 text-amber-300 border border-amber-800/60'
                        }`}
                      >
                        {idx.pChange >= 0 ? '+' : ''}
                        {idx.pChange.toFixed(2)}%
                      </span>
                    </td>

                    {/* Open */}
                    <td className="py-2.5 px-2 text-center text-slate-400">
                      {idx.open.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                    </td>

                    {/* High */}
                    <td className="py-2.5 px-2 text-center text-slate-400">
                      {idx.high.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                    </td>

                    {/* Low */}
                    <td className="py-2.5 px-2 text-center text-slate-400">
                      {idx.low.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                    </td>

                    {/* Prev Close */}
                    <td className="py-2.5 px-2 text-center text-slate-400">
                      {idx.prevClose.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                    </td>

                    {/* 52W Range Bar */}
                    <td className="py-2.5 px-3 text-center">
                      <div className="w-32 mx-auto">
                        <div className="flex items-center justify-between text-[9px] text-slate-400 font-mono mb-0.5">
                          <span>{idx.week52Low.toLocaleString('en-US', { maximumFractionDigits: 0 })}</span>
                          <span>{idx.week52High.toLocaleString('en-US', { maximumFractionDigits: 0 })}</span>
                        </div>
                        <div className="relative w-full h-1.5 bg-slate-900 rounded-full overflow-hidden">
                          <div
                            className="absolute top-0 bottom-0 bg-gradient-to-r from-rose-500 via-amber-400 to-emerald-400 rounded-full"
                            style={{ width: '100%' }}
                          />
                          <div
                            className="absolute top-0 bottom-0 w-2 bg-white border border-slate-950 rounded-full shadow-md -translate-x-1/2"
                            style={{ left: `${progress52}%` }}
                          />
                        </div>
                      </div>
                    </td>

                    {/* Strategic Impact Analysis on India */}
                    <td className="py-2.5 px-3 text-left font-sans max-w-[280px]">
                      <div className="flex items-center space-x-1.5 mb-0.5">
                        <span
                          className={`px-1.5 py-0.2 rounded text-[9px] font-black ${
                            idx.impactOnIndia === 'BULLISH'
                              ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                              : idx.impactOnIndia === 'BEARISH'
                              ? 'bg-rose-950 text-rose-300 border border-rose-800'
                              : 'bg-slate-900 text-slate-400 border border-slate-800'
                          }`}
                        >
                          {idx.impactOnIndia}
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-300 leading-snug truncate group-hover:whitespace-normal group-hover:overflow-visible transition-all">
                        {idx.impactReason}
                      </p>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
