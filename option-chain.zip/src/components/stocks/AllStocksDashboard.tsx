/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * Live Market Watch Terminal (All Stocks Dashboard)
 * Real-time 1s updates, Segments, Sectors, Top Gainers/Losers, Most Active, Heatmap & Watchlists.
 */

import React, { useState, useEffect, useMemo } from 'react';
import {
  MarketSegment,
  SectorType,
  StockQuote,
  StockAlert,
  SEGMENTS_LIST,
  SECTORS_LIST,
  stocksMarketWatch,
} from '../../services/stocksMarketWatch';
import { StockDetailPanel } from './StockDetailPanel';
import { SectorHeatmap } from './SectorHeatmap';
import { AllIndicesView } from './AllIndicesView';
import {
  Activity,
  AlertTriangle,
  ArrowDownRight,
  ArrowUpRight,
  BarChart2,
  Bell,
  Bookmark,
  ChevronDown,
  Eye,
  Filter,
  Flame,
  Globe,
  Grid,
  Layers,
  LineChart,
  List,
  Plus,
  RefreshCw,
  Search,
  SlidersHorizontal,
  Sparkles,
  TrendingDown,
  TrendingUp,
  X,
  Zap,
} from 'lucide-react';

type SubViewTab =
  | 'ALL_STOCKS'
  | 'ALL_INDICES'
  | 'TOP_GAINERS'
  | 'TOP_LOSERS'
  | 'MOST_ACTIVE'
  | 'HEATMAP'
  | 'WATCHLIST'
  | 'ALERTS';

export const AllStocksDashboard: React.FC = () => {
  const [stocks, setStocks] = useState<StockQuote[]>(stocksMarketWatch.getStocks());
  const [selectedSegment, setSelectedSegment] = useState<MarketSegment>('NIFTY 50');
  const [selectedSector, setSelectedSector] = useState<SectorType | 'ALL'>('ALL');
  const [subView, setSubView] = useState<SubViewTab>('ALL_STOCKS');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedStock, setSelectedStock] = useState<StockQuote | null>(null);
  const [activeWatchlist, setActiveWatchlist] = useState('Default Watchlist');
  const [newWatchlistName, setNewWatchlistName] = useState('');
  const [showAddWatchlistModal, setShowAddWatchlistModal] = useState(false);
  const [watchlists, setWatchlists] = useState(stocksMarketWatch.getWatchlists());
  const [alerts, setAlerts] = useState<StockAlert[]>(stocksMarketWatch.getAlerts());
  const [sortField, setSortField] = useState<keyof StockQuote>('marketCapCr');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('desc');

  // Real-time 1-second feed subscriber
  useEffect(() => {
    const unsub = stocksMarketWatch.subscribe((updated) => {
      setStocks([...updated]);
      setAlerts([...stocksMarketWatch.getAlerts()]);
      // If modal open, update current selected stock
      if (selectedStock) {
        const fresh = updated.find((s) => s.symbol === selectedStock.symbol);
        if (fresh) setSelectedStock({ ...fresh });
      }
    });
    return () => unsub();
  }, [selectedStock]);

  // Watchlist handlers
  const handleToggleFavorite = (symbol: string) => {
    stocksMarketWatch.toggleWatchlistStock(activeWatchlist, symbol);
    setWatchlists({ ...stocksMarketWatch.getWatchlists() });
  };

  const handleCreateWatchlist = () => {
    if (newWatchlistName.trim()) {
      stocksMarketWatch.createWatchlist(newWatchlistName.trim());
      setActiveWatchlist(newWatchlistName.trim());
      setWatchlists({ ...stocksMarketWatch.getWatchlists() });
      setNewWatchlistName('');
      setShowAddWatchlistModal(false);
    }
  };

  // Filter stocks based on segment, sector, and search query
  const filteredStocks = useMemo(() => {
    return stocks.filter((stock) => {
      // If Watchlist view, check active watchlist
      if (subView === 'WATCHLIST') {
        const watchlistSymbols = watchlists[activeWatchlist] || [];
        if (!watchlistSymbols.includes(stock.symbol)) return false;
      } else {
        // Market segment filter
        if (selectedSegment !== 'ALL NSE STOCKS' && !stock.segments.includes(selectedSegment)) {
          return false;
        }
      }

      // Sector filter
      if (selectedSector !== 'ALL' && stock.sector !== selectedSector) {
        return false;
      }

      // Search filter
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchSymbol = stock.symbol.toLowerCase().includes(q);
        const matchName = stock.name.toLowerCase().includes(q);
        const matchSector = stock.sector.toLowerCase().includes(q);
        if (!matchSymbol && !matchName && !matchSector) return false;
      }

      return true;
    });
  }, [stocks, selectedSegment, selectedSector, searchQuery, subView, activeWatchlist, watchlists]);

  // Sorted stocks
  const sortedStocks = useMemo(() => {
    return [...filteredStocks].sort((a, b) => {
      const aVal = a[sortField];
      const bVal = b[sortField];
      if (typeof aVal === 'number' && typeof bVal === 'number') {
        return sortOrder === 'asc' ? aVal - bVal : bVal - aVal;
      }
      return 0;
    });
  }, [filteredStocks, sortField, sortOrder]);

  // Top 20 Gainers
  const topGainers = useMemo(() => {
    return [...stocks]
      .filter((s) => s.pChange > 0)
      .sort((a, b) => b.pChange - a.pChange)
      .slice(0, 20);
  }, [stocks]);

  // Top 20 Losers
  const topLosers = useMemo(() => {
    return [...stocks]
      .filter((s) => s.pChange < 0)
      .sort((a, b) => a.pChange - b.pChange)
      .slice(0, 20);
  }, [stocks]);

  // Most Active
  const mostActiveVolume = useMemo(() => {
    return [...stocks].sort((a, b) => b.volume - a.volume).slice(0, 10);
  }, [stocks]);

  const mostActiveTurnover = useMemo(() => {
    return [...stocks].sort((a, b) => b.turnoverCr - a.turnoverCr).slice(0, 10);
  }, [stocks]);

  const mostActiveTrades = useMemo(() => {
    return [...stocks].sort((a, b) => b.tradesCount - a.tradesCount).slice(0, 10);
  }, [stocks]);

  // Handle column sorting
  const handleSort = (field: keyof StockQuote) => {
    if (sortField === field) {
      setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortOrder('desc');
    }
  };

  // Stats
  const advances = stocks.filter((s) => s.change > 0).length;
  const declines = stocks.filter((s) => s.change < 0).length;
  const unchanged = stocks.filter((s) => s.change === 0).length;

  return (
    <div className="flex-1 overflow-y-auto bg-[#070b13] text-slate-100 p-3 sm:p-5 space-y-4">
      {/* Top Banner: Market Watch Pulse & Market Breadth */}
      <div className="bg-[#0b101c] border border-slate-800/90 rounded-xl p-3.5 shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-3">
        <div className="flex items-center space-x-3">
          <div className="p-2 rounded-lg bg-cyan-950 border border-cyan-800 text-cyan-400">
            <LineChart className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <h1 className="text-base font-black tracking-wide text-white">LIVE MARKET WATCH</h1>
              <span className="flex items-center space-x-1 text-[10px] px-2 py-0.5 rounded-full bg-emerald-950 text-emerald-300 border border-emerald-800 font-mono font-bold">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                <span>1s LIVE STREAM</span>
              </span>
            </div>
            <p className="text-xs text-slate-400">
              Real-time NSE equities terminal with live tick flashes, sector heatmaps, and watchlists
            </p>
          </div>
        </div>

        {/* Market Breadth Pill Bar */}
        <div className="flex items-center flex-wrap gap-2 text-xs font-mono">
          <div className="flex items-center space-x-1.5 px-2.5 py-1 rounded-lg bg-slate-900 border border-slate-800">
            <span className="text-slate-400">Advances:</span>
            <span className="text-emerald-400 font-bold">▲ {advances}</span>
          </div>
          <div className="flex items-center space-x-1.5 px-2.5 py-1 rounded-lg bg-slate-900 border border-slate-800">
            <span className="text-slate-400">Declines:</span>
            <span className="text-rose-400 font-bold">▼ {declines}</span>
          </div>
          <div className="flex items-center space-x-1.5 px-2.5 py-1 rounded-lg bg-slate-900 border border-slate-800">
            <span className="text-slate-400">Unchanged:</span>
            <span className="text-amber-400 font-bold">■ {unchanged}</span>
          </div>
        </div>
      </div>

      {/* Primary Sub-View Navigation Tabs */}
      <div className="flex items-center justify-between flex-wrap gap-2 border-b border-slate-800/80 pb-2">
        <div className="flex items-center flex-wrap gap-1 text-xs">
          <button
            onClick={() => setSubView('ALL_STOCKS')}
            className={`px-3 py-1.5 rounded-lg font-bold transition-all flex items-center space-x-1.5 ${
              subView === 'ALL_STOCKS'
                ? 'bg-cyan-500 text-slate-950 shadow-md ring-1 ring-cyan-300'
                : 'text-slate-400 hover:text-white hover:bg-slate-900'
            }`}
          >
            <List className="w-3.5 h-3.5" />
            <span>All Stocks Table</span>
          </button>

          <button
            onClick={() => setSubView('ALL_INDICES')}
            className={`px-3 py-1.5 rounded-lg font-bold transition-all flex items-center space-x-1.5 ${
              subView === 'ALL_INDICES'
                ? 'bg-blue-600 text-white shadow-md ring-1 ring-blue-300'
                : 'text-slate-400 hover:text-blue-300 hover:bg-slate-900'
            }`}
          >
            <Globe className="w-3.5 h-3.5 text-blue-400" />
            <span>All Indices (31 Global & 23 Domestic)</span>
          </button>

          <button
            onClick={() => setSubView('TOP_GAINERS')}
            className={`px-3 py-1.5 rounded-lg font-bold transition-all flex items-center space-x-1.5 ${
              subView === 'TOP_GAINERS'
                ? 'bg-emerald-500 text-slate-950 shadow-md ring-1 ring-emerald-300'
                : 'text-slate-400 hover:text-emerald-300 hover:bg-slate-900'
            }`}
          >
            <TrendingUp className="w-3.5 h-3.5 text-emerald-400" />
            <span>Top Gainers (20)</span>
          </button>

          <button
            onClick={() => setSubView('TOP_LOSERS')}
            className={`px-3 py-1.5 rounded-lg font-bold transition-all flex items-center space-x-1.5 ${
              subView === 'TOP_LOSERS'
                ? 'bg-rose-500 text-white shadow-md ring-1 ring-rose-300'
                : 'text-slate-400 hover:text-rose-300 hover:bg-slate-900'
            }`}
          >
            <TrendingDown className="w-3.5 h-3.5 text-rose-400" />
            <span>Top Losers (20)</span>
          </button>

          <button
            onClick={() => setSubView('MOST_ACTIVE')}
            className={`px-3 py-1.5 rounded-lg font-bold transition-all flex items-center space-x-1.5 ${
              subView === 'MOST_ACTIVE'
                ? 'bg-purple-600 text-white shadow-md'
                : 'text-slate-400 hover:text-purple-300 hover:bg-slate-900'
            }`}
          >
            <Flame className="w-3.5 h-3.5 text-purple-400" />
            <span>Most Active</span>
          </button>

          <button
            onClick={() => setSubView('HEATMAP')}
            className={`px-3 py-1.5 rounded-lg font-bold transition-all flex items-center space-x-1.5 ${
              subView === 'HEATMAP'
                ? 'bg-cyan-500 text-slate-950 shadow-md ring-1 ring-cyan-300'
                : 'text-slate-400 hover:text-white hover:bg-slate-900'
            }`}
          >
            <Grid className="w-3.5 h-3.5" />
            <span>Sector Heatmap</span>
          </button>

          <button
            onClick={() => setSubView('WATCHLIST')}
            className={`px-3 py-1.5 rounded-lg font-bold transition-all flex items-center space-x-1.5 ${
              subView === 'WATCHLIST'
                ? 'bg-amber-500 text-slate-950 shadow-md ring-1 ring-amber-300'
                : 'text-slate-400 hover:text-amber-300 hover:bg-slate-900'
            }`}
          >
            <Bookmark className="w-3.5 h-3.5" />
            <span>My Watchlists ({Object.keys(watchlists).length})</span>
          </button>

          <button
            onClick={() => setSubView('ALERTS')}
            className={`px-3 py-1.5 rounded-lg font-bold transition-all flex items-center space-x-1.5 ${
              subView === 'ALERTS'
                ? 'bg-cyan-500 text-slate-950 shadow-md ring-1 ring-cyan-300'
                : 'text-slate-400 hover:text-white hover:bg-slate-900'
            }`}
          >
            <Bell className="w-3.5 h-3.5" />
            <span>Alerts ({alerts.length})</span>
          </button>
        </div>

        {/* Global Search Bar */}
        <div className="relative w-full sm:w-64">
          <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            placeholder="Search Symbol, Company, Sector..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-3 py-1.5 bg-slate-900/90 border border-slate-800 rounded-lg text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500 transition-colors"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      </div>

      {/* MARKET SEGMENTS TABS (Specified in prompt) */}
      {subView !== 'HEATMAP' && subView !== 'ALERTS' && subView !== 'WATCHLIST' && (
        <div className="flex items-center space-x-1 overflow-x-auto no-scrollbar pb-1 text-xs border-b border-slate-800/60">
          <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider pr-1">
            Segment:
          </span>
          {SEGMENTS_LIST.map((seg) => {
            const isSel = selectedSegment === seg;
            return (
              <button
                key={seg}
                onClick={() => setSelectedSegment(seg)}
                className={`px-2.5 py-1 rounded font-bold transition-all whitespace-nowrap ${
                  isSel
                    ? 'bg-cyan-950 text-cyan-300 border border-cyan-700 shadow-sm'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
                }`}
              >
                {seg}
              </button>
            );
          })}
        </div>
      )}

      {/* Watchlist Selector Bar (if in WATCHLIST view) */}
      {subView === 'WATCHLIST' && (
        <div className="bg-[#0b101c] border border-slate-800 rounded-xl p-3 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs">
          <div className="flex items-center space-x-2">
            <span className="text-slate-400 font-semibold">Active Watchlist:</span>
            <div className="flex items-center gap-1.5">
              {Object.keys(watchlists).map((wName) => (
                <button
                  key={wName}
                  onClick={() => setActiveWatchlist(wName)}
                  className={`px-2.5 py-1 rounded font-bold transition-all ${
                    activeWatchlist === wName
                      ? 'bg-amber-500 text-slate-950'
                      : 'bg-slate-900 text-slate-300 border border-slate-800 hover:bg-slate-800'
                  }`}
                >
                  {wName} ({watchlists[wName]?.length || 0})
                </button>
              ))}
            </div>
          </div>

          <button
            onClick={() => setShowAddWatchlistModal(true)}
            className="flex items-center space-x-1 px-3 py-1 rounded-lg bg-cyan-950 border border-cyan-800 text-cyan-300 hover:bg-cyan-900 transition-colors font-bold"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Create New Watchlist</span>
          </button>
        </div>
      )}

          {/* Sector filter pills (for table view) */}
      {subView === 'ALL_STOCKS' && (
        <div className="flex items-center space-x-1 overflow-x-auto no-scrollbar pb-1 text-xs">
          <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider pr-1">
            Sector:
          </span>
          <button
            onClick={() => setSelectedSector('ALL')}
            className={`px-2.5 py-0.5 rounded text-[11px] font-bold transition-all whitespace-nowrap ${
              selectedSector === 'ALL'
                ? 'bg-cyan-500 text-slate-950 shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
            }`}
          >
            All
          </button>
          {SECTORS_LIST.map((sec) => (
            <button
              key={sec}
              onClick={() => setSelectedSector(sec)}
              className={`px-2.5 py-0.5 rounded text-[11px] font-bold transition-all whitespace-nowrap ${
                selectedSector === sec
                  ? 'bg-cyan-500 text-slate-950 shadow-sm'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
              }`}
            >
              {sec}
            </button>
          ))}
        </div>
      )}

      {/* MAIN VIEW: LIVE STOCK TABLE */}
      {(subView === 'ALL_STOCKS' || subView === 'WATCHLIST') && (
        <div className="bg-[#0b101c] border border-slate-800 rounded-xl p-3.5 shadow-xl space-y-3">
          <div className="flex items-center justify-between text-xs text-slate-400 border-b border-slate-800 pb-2">
            <div>
              Showing <span className="text-white font-bold">{sortedStocks.length}</span> stocks in{' '}
              <span className="text-cyan-400 font-bold">{selectedSegment}</span>
            </div>
            <div className="text-[11px]">Click any row to open side chart & company stats</div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-xs font-mono border-collapse min-w-[920px]">
              <thead>
                <tr className="border-b border-slate-800 text-slate-400 uppercase bg-[#080d17] text-[10.5px]">
                  <th className="py-2.5 px-3 text-left">Symbol</th>
                  <th className="py-2.5 px-2 text-left font-sans">Company</th>
                  <th
                    onClick={() => handleSort('ltp')}
                    className="py-2.5 px-2 text-center text-cyan-300 font-black cursor-pointer hover:underline"
                    title="Last Traded Price"
                  >
                    LTP (₹)
                  </th>
                  <th
                    onClick={() => handleSort('change')}
                    className="py-2.5 px-2 text-center cursor-pointer hover:underline"
                  >
                    Change
                  </th>
                  <th
                    onClick={() => handleSort('pChange')}
                    className="py-2.5 px-2 text-center cursor-pointer hover:underline"
                  >
                    % Change
                  </th>
                  <th className="py-2.5 px-2 text-center text-slate-400">Open</th>
                  <th className="py-2.5 px-2 text-center text-emerald-400">High</th>
                  <th className="py-2.5 px-2 text-center text-rose-400">Low</th>
                  <th
                    onClick={() => handleSort('volume')}
                    className="py-2.5 px-2 text-center cursor-pointer hover:underline"
                  >
                    Volume
                  </th>
                  <th
                    onClick={() => handleSort('marketCapCr')}
                    className="py-2.5 px-2 text-center cursor-pointer hover:underline"
                  >
                    M.Cap (Cr)
                  </th>
                  <th className="py-2.5 px-2 text-center text-emerald-300">52W High</th>
                  <th className="py-2.5 px-2 text-center text-rose-300">52W Low</th>
                  <th className="py-2.5 px-2 text-center text-slate-300">VWAP</th>
                  <th className="py-2.5 px-2 text-center">Watch</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {sortedStocks.map((stock) => {
                  const isUp = stock.change > 0;
                  const isDown = stock.change < 0;
                  const isNeutral = stock.change === 0;

                  // Color system from prompt: Green = Price Up, Red = Price Down, Yellow = No Change
                  const colorClass = isUp
                    ? 'text-emerald-400'
                    : isDown
                    ? 'text-rose-400'
                    : 'text-amber-400';

                  const isFav = stocksMarketWatch.isInWatchlist(activeWatchlist, stock.symbol);

                  return (
                    <tr
                      key={stock.symbol}
                      onClick={() => setSelectedStock(stock)}
                      className="hover:bg-slate-900/60 cursor-pointer transition-colors group"
                    >
                      {/* Symbol */}
                      <td className="py-2.5 px-3 font-bold text-white">
                        <div className="flex items-center space-x-1.5">
                          <span className="text-cyan-300 group-hover:text-cyan-200 group-hover:underline">
                            {stock.symbol}
                          </span>
                          <span className="text-[9px] px-1 py-0.2 rounded bg-slate-800 text-slate-400 font-sans">
                            {stock.sector}
                          </span>
                        </div>
                      </td>

                      {/* Company Name */}
                      <td className="py-2.5 px-2 text-slate-300 font-sans truncate max-w-[150px]">
                        {stock.name}
                      </td>

                      {/* LTP with live tick arrow indicator (▲ / ▼) */}
                      <td className="py-2.5 px-2 text-center font-black text-sm">
                        <div
                          className={`inline-flex items-center space-x-1 px-2 py-0.5 rounded transition-all ${
                            stock.lastTickDir === 'up'
                              ? 'bg-emerald-500/20 text-emerald-300'
                              : stock.lastTickDir === 'down'
                              ? 'bg-rose-500/20 text-rose-300'
                              : colorClass
                          }`}
                        >
                          <span className="text-[10px]">
                            {stock.lastTickDir === 'up' ? '▲' : stock.lastTickDir === 'down' ? '▼' : ''}
                          </span>
                          <span>{stock.ltp.toLocaleString('en-IN', { minimumFractionDigits: 2 })}</span>
                        </div>
                      </td>

                      {/* Change */}
                      <td className={`py-2.5 px-2 text-center font-bold ${colorClass}`}>
                        {stock.change >= 0 ? '+' : ''}
                        {stock.change.toFixed(2)}
                      </td>

                      {/* % Change */}
                      <td className="py-2.5 px-2 text-center font-bold">
                        <span
                          className={`inline-block px-1.5 py-0.5 rounded text-[11px] ${
                            isUp
                              ? 'bg-emerald-950/70 text-emerald-300 border border-emerald-800/60'
                              : isDown
                              ? 'bg-rose-950/70 text-rose-300 border border-rose-800/60'
                              : 'bg-amber-950/70 text-amber-300 border border-amber-800/60'
                          }`}
                        >
                          {stock.pChange >= 0 ? '+' : ''}
                          {stock.pChange.toFixed(2)}%
                        </span>
                      </td>

                      {/* Open */}
                      <td className="py-2.5 px-2 text-center text-slate-400">
                        {stock.open.toFixed(2)}
                      </td>

                      {/* High */}
                      <td className="py-2.5 px-2 text-center text-emerald-400/90 font-semibold">
                        {stock.high.toFixed(2)}
                      </td>

                      {/* Low */}
                      <td className="py-2.5 px-2 text-center text-rose-400/90 font-semibold">
                        {stock.low.toFixed(2)}
                      </td>

                      {/* Volume */}
                      <td className="py-2.5 px-2 text-center text-slate-300">
                        {(stock.volume / 100000).toFixed(1)}L
                      </td>

                      {/* Market Cap */}
                      <td className="py-2.5 px-2 text-center text-slate-300">
                        ₹{(stock.marketCapCr).toLocaleString('en-IN')} Cr
                      </td>

                      {/* 52W High */}
                      <td className="py-2.5 px-2 text-center text-emerald-400">
                        {stock.week52High.toFixed(2)}
                      </td>

                      {/* 52W Low */}
                      <td className="py-2.5 px-2 text-center text-rose-400">
                        {stock.week52Low.toFixed(2)}
                      </td>

                      {/* VWAP */}
                      <td className="py-2.5 px-2 text-center text-slate-300">
                        {stock.vwap.toFixed(2)}
                      </td>

                      {/* Watchlist Bookmark */}
                      <td
                        onClick={(e) => {
                          e.stopPropagation();
                          handleToggleFavorite(stock.symbol);
                        }}
                        className="py-2.5 px-2 text-center"
                      >
                        <button
                          className={`p-1 rounded transition-colors ${
                            isFav ? 'text-amber-400' : 'text-slate-600 hover:text-slate-300'
                          }`}
                        >
                          <Bookmark className={`w-3.5 h-3.5 ${isFav ? 'fill-amber-400' : ''}`} />
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ALL INDICES FROM EXCEL VIEW */}
      {subView === 'ALL_INDICES' && (
        <AllIndicesView />
      )}

      {/* TOP GAINERS TAB (Top 20 specified in prompt) */}
      {subView === 'TOP_GAINERS' && (
        <div className="bg-[#0b101c] border border-emerald-800/40 rounded-xl p-4 shadow-xl space-y-3">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2.5">
            <div className="flex items-center space-x-2">
              <TrendingUp className="w-5 h-5 text-emerald-400" />
              <div>
                <h2 className="text-sm font-bold text-white uppercase tracking-wider">
                  TOP 20 GAINERS
                </h2>
                <span className="text-[10px] text-slate-400">
                  Highest percentage price surge across Indian equity markets today
                </span>
              </div>
            </div>
            <span className="text-xs px-2 py-0.5 rounded bg-emerald-950 text-emerald-300 font-mono font-bold">
              Bullish Momentum
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 font-mono">
            {topGainers.map((stk, idx) => (
              <div
                key={stk.symbol}
                onClick={() => setSelectedStock(stk)}
                className="bg-slate-900/70 border border-emerald-800/50 hover:border-emerald-500 rounded-xl p-3 flex flex-col justify-between cursor-pointer transition-all hover:scale-[1.02] shadow-md"
              >
                <div className="flex items-start justify-between">
                  <div>
                    <div className="flex items-center space-x-1.5">
                      <span className="text-[11px] font-bold text-emerald-400 font-sans">#{idx + 1}</span>
                      <span className="font-black text-white text-sm">{stk.symbol}</span>
                    </div>
                    <div className="text-[10px] text-slate-400 font-sans truncate max-w-[130px]">
                      {stk.name}
                    </div>
                  </div>
                  <span className="text-[9px] px-1.5 py-0.5 rounded bg-emerald-950 text-emerald-300 border border-emerald-800">
                    {stk.sector}
                  </span>
                </div>

                <div className="mt-3 flex items-baseline justify-between border-t border-slate-800/80 pt-2">
                  <div>
                    <span className="text-xs text-slate-400">Price</span>
                    <div className="text-sm font-extrabold text-white">
                      ₹{stk.ltp.toFixed(2)}
                    </div>
                  </div>
                  <div className="text-right">
                    <span className="text-[10px] text-slate-400">Gain</span>
                    <div className="text-sm font-black text-emerald-400">
                      +{stk.pChange.toFixed(2)}%
                    </div>
                  </div>
                </div>

                <div className="text-[10px] text-slate-400 mt-1 flex items-center justify-between">
                  <span>Volume: {(stk.volume / 100000).toFixed(1)}L</span>
                  <span className="text-emerald-400 font-bold">▲ +₹{stk.change.toFixed(2)}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TOP LOSERS TAB (Top 20 specified in prompt) */}
      {subView === 'TOP_LOSERS' && (
        <div className="bg-[#0b101c] border border-rose-800/40 rounded-xl p-4 shadow-xl space-y-3">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2.5">
            <div className="flex items-center space-x-2">
              <TrendingDown className="w-5 h-5 text-rose-400" />
              <div>
                <h2 className="text-sm font-bold text-white uppercase tracking-wider">
                  TOP 20 LOSERS
                </h2>
                <span className="text-[10px] text-slate-400">
                  Highest percentage price decline across Indian equity markets today
                </span>
              </div>
            </div>
            <span className="text-xs px-2 py-0.5 rounded bg-rose-950 text-rose-300 font-mono font-bold">
              Selling Pressure
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 font-mono">
            {topLosers.map((stk, idx) => (
              <div
                key={stk.symbol}
                onClick={() => setSelectedStock(stk)}
                className="bg-slate-900/70 border border-rose-800/50 hover:border-rose-500 rounded-xl p-3 flex flex-col justify-between cursor-pointer transition-all hover:scale-[1.02] shadow-md"
              >
                <div className="flex items-start justify-between">
                  <div>
                    <div className="flex items-center space-x-1.5">
                      <span className="text-[11px] font-bold text-rose-400 font-sans">#{idx + 1}</span>
                      <span className="font-black text-white text-sm">{stk.symbol}</span>
                    </div>
                    <div className="text-[10px] text-slate-400 font-sans truncate max-w-[130px]">
                      {stk.name}
                    </div>
                  </div>
                  <span className="text-[9px] px-1.5 py-0.5 rounded bg-rose-950 text-rose-300 border border-rose-800">
                    {stk.sector}
                  </span>
                </div>

                <div className="mt-3 flex items-baseline justify-between border-t border-slate-800/80 pt-2">
                  <div>
                    <span className="text-xs text-slate-400">Price</span>
                    <div className="text-sm font-extrabold text-white">
                      ₹{stk.ltp.toFixed(2)}
                    </div>
                  </div>
                  <div className="text-right">
                    <span className="text-[10px] text-slate-400">Loss</span>
                    <div className="text-sm font-black text-rose-400">
                      {stk.pChange.toFixed(2)}%
                    </div>
                  </div>
                </div>

                <div className="text-[10px] text-slate-400 mt-1 flex items-center justify-between">
                  <span>Volume: {(stk.volume / 100000).toFixed(1)}L</span>
                  <span className="text-rose-400 font-bold">▼ ₹{stk.change.toFixed(2)}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* MOST ACTIVE TAB (Volume, Turnover, Trades specified in prompt) */}
      {subView === 'MOST_ACTIVE' && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
            {/* By Volume */}
            <div className="bg-[#0b101c] border border-slate-800 rounded-xl p-4 shadow-xl space-y-3 font-mono">
              <div className="flex items-center space-x-2 border-b border-slate-800 pb-2">
                <BarChart2 className="w-4 h-4 text-cyan-400" />
                <span className="text-xs font-bold text-white uppercase tracking-wider">
                  Highest Volume Stocks
                </span>
              </div>
              <div className="divide-y divide-slate-800/70">
                {mostActiveVolume.map((stk) => (
                  <div
                    key={stk.symbol}
                    onClick={() => setSelectedStock(stk)}
                    className="py-2 flex items-center justify-between cursor-pointer hover:bg-slate-900/50 px-1 rounded transition-colors"
                  >
                    <div>
                      <div className="font-bold text-white text-xs">{stk.symbol}</div>
                      <div className="text-[10px] text-slate-400 font-sans">{stk.name.split(' ')[0]}</div>
                    </div>
                    <div className="text-right">
                      <div className="text-xs font-bold text-cyan-300">
                        {(stk.volume / 100000).toFixed(1)} Lakhs
                      </div>
                      <div className="text-[10px] text-slate-400">₹{stk.ltp.toFixed(2)}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* By Turnover */}
            <div className="bg-[#0b101c] border border-slate-800 rounded-xl p-4 shadow-xl space-y-3 font-mono">
              <div className="flex items-center space-x-2 border-b border-slate-800 pb-2">
                <Activity className="w-4 h-4 text-emerald-400" />
                <span className="text-xs font-bold text-white uppercase tracking-wider">
                  Highest Turnover (₹ Cr)
                </span>
              </div>
              <div className="divide-y divide-slate-800/70">
                {mostActiveTurnover.map((stk) => (
                  <div
                    key={stk.symbol}
                    onClick={() => setSelectedStock(stk)}
                    className="py-2 flex items-center justify-between cursor-pointer hover:bg-slate-900/50 px-1 rounded transition-colors"
                  >
                    <div>
                      <div className="font-bold text-white text-xs">{stk.symbol}</div>
                      <div className="text-[10px] text-slate-400 font-sans">{stk.name.split(' ')[0]}</div>
                    </div>
                    <div className="text-right">
                      <div className="text-xs font-bold text-emerald-400">
                        ₹{stk.turnoverCr.toLocaleString('en-IN')} Cr
                      </div>
                      <div className="text-[10px] text-slate-400">₹{stk.ltp.toFixed(2)}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* By Trades */}
            <div className="bg-[#0b101c] border border-slate-800 rounded-xl p-4 shadow-xl space-y-3 font-mono">
              <div className="flex items-center space-x-2 border-b border-slate-800 pb-2">
                <Flame className="w-4 h-4 text-purple-400" />
                <span className="text-xs font-bold text-white uppercase tracking-wider">
                  Highest Trades Count
                </span>
              </div>
              <div className="divide-y divide-slate-800/70">
                {mostActiveTrades.map((stk) => (
                  <div
                    key={stk.symbol}
                    onClick={() => setSelectedStock(stk)}
                    className="py-2 flex items-center justify-between cursor-pointer hover:bg-slate-900/50 px-1 rounded transition-colors"
                  >
                    <div>
                      <div className="font-bold text-white text-xs">{stk.symbol}</div>
                      <div className="text-[10px] text-slate-400 font-sans">{stk.name.split(' ')[0]}</div>
                    </div>
                    <div className="text-right">
                      <div className="text-xs font-bold text-purple-300">
                        {stk.tradesCount.toLocaleString('en-IN')} trades
                      </div>
                      <div className="text-[10px] text-slate-400">₹{stk.ltp.toFixed(2)}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* SECTOR HEATMAP TAB (TradingView Style) */}
      {subView === 'HEATMAP' && (
        <SectorHeatmap stocks={stocks} onSelectStock={(stk) => setSelectedStock(stk)} />
      )}

      {/* ALERTS TAB */}
      {subView === 'ALERTS' && (
        <div className="bg-[#0b101c] border border-slate-800 rounded-xl p-4 shadow-xl space-y-3 font-mono">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <div className="flex items-center space-x-2">
              <Bell className="w-4 h-4 text-cyan-400" />
              <span className="text-sm font-bold text-white uppercase">Active Stock Alerts</span>
            </div>
            <span className="text-xs text-slate-400">{alerts.length} Total Registered</span>
          </div>

          {alerts.length === 0 ? (
            <div className="p-8 text-center text-slate-400 text-xs">
              No active stock alerts yet. Click any stock in the table to set custom price & breakout alerts.
            </div>
          ) : (
            <div className="divide-y divide-slate-800/80">
              {alerts.map((alt) => (
                <div key={alt.id} className="py-2.5 flex items-center justify-between text-xs">
                  <div>
                    <span className="font-bold text-white">{alt.symbol}</span>
                    <span className="text-slate-400 text-[11px] ml-2">
                      Condition: {alt.condition} (₹{alt.targetPrice})
                    </span>
                  </div>
                  <div className="flex items-center space-x-3">
                    <span
                      className={`text-[10px] px-2 py-0.5 rounded font-bold ${
                        alt.triggered
                          ? 'bg-rose-950 text-rose-300 border border-rose-800'
                          : 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                      }`}
                    >
                      {alt.triggered ? 'TRIGGERED' : 'PENDING'}
                    </span>
                    <button
                      onClick={() => {
                        stocksMarketWatch.removeAlert(alt.id);
                        setAlerts([...stocksMarketWatch.getAlerts()]);
                      }}
                      className="text-slate-400 hover:text-rose-400"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Create Watchlist Modal */}
      {showAddWatchlistModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#0b101c] border border-cyan-800/70 rounded-xl p-5 w-full max-w-sm shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <span className="font-bold text-white text-sm">Create New Watchlist</span>
              <button
                onClick={() => setShowAddWatchlistModal(false)}
                className="text-slate-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="text-slate-400 block mb-1">Watchlist Name</label>
                <input
                  type="text"
                  placeholder="e.g. Bluechip Stocks, EV Sector"
                  value={newWatchlistName}
                  onChange={(e) => setNewWatchlistName(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2 text-white text-sm"
                />
              </div>

              <button
                onClick={handleCreateWatchlist}
                className="w-full py-2 bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold rounded-lg transition-colors shadow-lg"
              >
                Create Watchlist
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Stock Detail Side Panel */}
      {selectedStock && (
        <StockDetailPanel
          stock={selectedStock}
          onClose={() => setSelectedStock(null)}
          activeWatchlist={activeWatchlist}
          isFavorite={stocksMarketWatch.isInWatchlist(activeWatchlist, selectedStock.symbol)}
          onToggleFavorite={handleToggleFavorite}
        />
      )}
    </div>
  );
};
