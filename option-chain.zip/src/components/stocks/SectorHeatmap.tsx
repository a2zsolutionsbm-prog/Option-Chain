/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * Sector Heatmap (TradingView Treemap style)
 * Large responsive blocks with Size = Market Cap and Color = Change %
 */

import React, { useState } from 'react';
import { StockQuote, SectorType, SECTORS_LIST } from '../../services/stocksMarketWatch';
import { Layers, Sparkles } from 'lucide-react';

interface SectorHeatmapProps {
  stocks: StockQuote[];
  onSelectStock: (stock: StockQuote) => void;
}

export const SectorHeatmap: React.FC<SectorHeatmapProps> = ({ stocks, onSelectStock }) => {
  const [selectedSector, setSelectedSector] = useState<SectorType | 'ALL'>('ALL');

  const filteredStocks =
    selectedSector === 'ALL'
      ? stocks
      : stocks.filter((s) => s.sector === selectedSector);

  // Calculate total market cap
  const totalMarketCap = filteredStocks.reduce((acc, s) => acc + s.marketCapCr, 0) || 1;

  // Color helper based on percentage change
  const getTreemapColor = (pChange: number) => {
    if (pChange >= 3.0) return 'bg-emerald-600 border-emerald-400 text-white';
    if (pChange >= 1.5) return 'bg-emerald-700/90 border-emerald-500/60 text-white';
    if (pChange > 0.1) return 'bg-emerald-900/90 border-emerald-700/50 text-emerald-200';
    if (pChange >= -0.1 && pChange <= 0.1) return 'bg-slate-800/90 border-slate-700 text-slate-300';
    if (pChange <= -3.0) return 'bg-rose-600 border-rose-400 text-white';
    if (pChange <= -1.5) return 'bg-rose-700/90 border-rose-500/60 text-white';
    return 'bg-rose-900/90 border-rose-700/50 text-rose-200';
  };

  // Group by sector if ALL is selected
  const sectorGroups: Record<string, StockQuote[]> = {};
  filteredStocks.forEach((st) => {
    if (!sectorGroups[st.sector]) sectorGroups[st.sector] = [];
    sectorGroups[st.sector].push(st);
  });

  return (
    <div className="bg-[#0b101c] border border-slate-800 rounded-xl p-4 shadow-xl space-y-4">
      {/* Top Header & Sector Filter */}
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-3 border-b border-slate-800 pb-3">
        <div>
          <div className="text-sm font-bold text-white flex items-center space-x-2">
            <span>MARKET SECTOR HEATMAP</span>
            <span className="text-[10px] px-2 py-0.5 rounded bg-emerald-950 text-emerald-300 border border-emerald-800 font-mono">
              TradingView Style
            </span>
          </div>
          <div className="text-xs text-slate-400">
            Block size represents Market Capitalization, color reflects live daily price change %
          </div>
        </div>

        {/* Legend */}
        <div className="flex items-center flex-wrap gap-2 text-[10.5px]">
          <span className="flex items-center space-x-1">
            <span className="w-3 h-3 rounded bg-emerald-600 inline-block"></span>
            <span className="text-slate-300">&gt; +3%</span>
          </span>
          <span className="flex items-center space-x-1">
            <span className="w-3 h-3 rounded bg-emerald-800 inline-block"></span>
            <span className="text-slate-300">+0.1% to +3%</span>
          </span>
          <span className="flex items-center space-x-1">
            <span className="w-3 h-3 rounded bg-slate-800 border border-slate-700 inline-block"></span>
            <span className="text-slate-300">0% Neutral</span>
          </span>
          <span className="flex items-center space-x-1">
            <span className="w-3 h-3 rounded bg-rose-800 inline-block"></span>
            <span className="text-slate-300">-0.1% to -3%</span>
          </span>
          <span className="flex items-center space-x-1">
            <span className="w-3 h-3 rounded bg-rose-600 inline-block"></span>
            <span className="text-slate-300">&lt; -3%</span>
          </span>
        </div>
      </div>

      {/* Sector filter pills */}
      <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar pb-1 text-xs">
        <button
          onClick={() => setSelectedSector('ALL')}
          className={`px-3 py-1 rounded font-bold transition-all whitespace-nowrap ${
            selectedSector === 'ALL'
              ? 'bg-cyan-500 text-slate-950 shadow-md'
              : 'bg-slate-900 border border-slate-800 text-slate-400 hover:text-white'
          }`}
        >
          All Sectors
        </button>
        {SECTORS_LIST.map((sec) => (
          <button
            key={sec}
            onClick={() => setSelectedSector(sec)}
            className={`px-2.5 py-1 rounded font-bold transition-all whitespace-nowrap ${
              selectedSector === sec
                ? 'bg-cyan-500 text-slate-950 shadow-md'
                : 'bg-slate-900 border border-slate-800 text-slate-400 hover:text-white'
            }`}
          >
            {sec}
          </button>
        ))}
      </div>

      {/* Heatmap Blocks Grid (Weighted by Market Cap) */}
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-2.5 min-h-[380px]">
        {filteredStocks.map((stock) => {
          const capPct = (stock.marketCapCr / totalMarketCap) * 100;
          // Determine tile size class based on market cap dominance
          let spanClass = 'col-span-1 row-span-1 min-h-[85px]';
          if (capPct > 12) {
            spanClass = 'col-span-2 row-span-2 min-h-[160px]';
          } else if (capPct > 6) {
            spanClass = 'col-span-2 row-span-1 min-h-[105px]';
          }

          const colorClass = getTreemapColor(stock.pChange);

          return (
            <div
              key={stock.symbol}
              onClick={() => onSelectStock(stock)}
              className={`${spanClass} ${colorClass} rounded-xl border p-2.5 flex flex-col justify-between cursor-pointer transition-all hover:scale-[1.02] shadow-md hover:shadow-xl relative overflow-hidden group select-none`}
            >
              <div className="flex items-start justify-between">
                <div>
                  <div className="text-sm md:text-base font-black tracking-wide leading-none">
                    {stock.symbol}
                  </div>
                  <div className="text-[10px] opacity-80 truncate max-w-[130px] font-sans mt-0.5">
                    {stock.name}
                  </div>
                </div>
                <span className="text-[9.5px] px-1.5 py-0.5 rounded bg-black/30 font-mono font-bold">
                  {stock.sector}
                </span>
              </div>

              <div className="mt-2">
                <div className="flex items-baseline space-x-1 font-mono">
                  <span className="text-sm md:text-base font-extrabold">
                    ₹{stock.ltp.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                  </span>
                </div>
                <div className="flex items-center justify-between text-[11px] font-mono font-black mt-0.5">
                  <span>
                    {stock.change >= 0 ? '+' : ''}
                    {stock.change.toFixed(2)}
                  </span>
                  <span className="px-1.5 py-0.5 rounded bg-black/20 text-xs">
                    {stock.pChange >= 0 ? '+' : ''}
                    {stock.pChange.toFixed(2)}%
                  </span>
                </div>
              </div>

              {/* Hover overlay hint */}
              <div className="absolute inset-0 bg-cyan-950/80 backdrop-blur-xs opacity-0 group-hover:opacity-100 transition-opacity flex flex-col items-center justify-center p-2 text-center text-xs">
                <span className="font-bold text-white">Click to View Chart & Trades</span>
                <span className="text-[10px] text-cyan-300 font-mono mt-0.5">
                  MCap: ₹{stock.marketCapCr.toLocaleString('en-IN')} Cr
                </span>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
