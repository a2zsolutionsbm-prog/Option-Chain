import React from 'react';
import {
  Activity,
  BarChart2,
  Bell,
  Bookmark,
  Calendar,
  FileText,
  Globe,
  LineChart,
  Newspaper,
  PanelLeftClose,
  PanelLeftOpen,
  Settings,
  Shield,
  Sparkles,
  TrendingUp,
  User,
  Users,
} from 'lucide-react';
import { UserRole } from '../../types';

export type ActiveTab =
  | 'chain'
  | 'analytics'
  | 'maxpain'
  | 'stocks'
  | 'indices'
  | 'strategy'
  | 'participants'
  | 'eod'
  | 'nse_participant_oi'
  | 'charts'
  | 'heatmap'
  | 'scanner'
  | 'alerts'
  | 'news'
  | 'calendar'
  | 'admin';

interface NavTabItem {
  id: ActiveTab;
  label: string;
  sub: string;
  icon: React.ComponentType<{ className?: string }>;
  badge?: string;
  premium?: boolean;
  count?: number;
  adminOnly?: boolean;
}

interface NavigationProps {
  activeTab: ActiveTab;
  onTabChange: (tab: ActiveTab) => void;
  userRole: UserRole;
  pendingAlertsCount: number;
  onOpenModal?: (modal: 'profile' | 'settings' | 'reports' | 'login') => void;
  isSidebarHidden?: boolean;
  onToggleSidebar?: () => void;
}

export const Navigation: React.FC<NavigationProps> = ({
  activeTab,
  onTabChange,
  userRole,
  pendingAlertsCount,
  onOpenModal,
  isSidebarHidden = false,
  onToggleSidebar,
}) => {
  const tabs: NavTabItem[] = [
    {
      id: 'chain',
      label: 'Option Chain',
      sub: 'Live Depth & Greeks',
      icon: Activity,
      badge: 'LIVE',
    },
    {
      id: 'stocks',
      label: 'All Stocks',
      sub: 'NSE Equity Watch',
      icon: TrendingUp,
      badge: 'LIVE',
    },
    {
      id: 'indices',
      label: 'All Indices',
      sub: '31 Global & 23 Indian',
      icon: Globe,
    },
    {
      id: 'charts',
      label: 'Live Charts',
      sub: 'Technicals & Multi-TF',
      icon: LineChart,
    },
    {
      id: 'strategy',
      label: 'Strategy & Scanner',
      sub: 'Payoff, Max Pain & Radar',
      icon: Sparkles,
      badge: 'PRO',
      premium: true,
    },
    {
      id: 'participants',
      label: 'All Participants',
      sub: 'FII, DII, Pro & Client',
      icon: Users,
    },
    {
      id: 'eod',
      label: 'EOD Data',
      sub: 'Dashboard & NSE OI Data',
      icon: BarChart2,
      badge: 'EOD',
    },
    {
      id: 'alerts',
      label: 'Alerts & Watchlist',
      sub: 'Triggers & Saved Strikes',
      icon: Bell,
      count: pendingAlertsCount,
    },
    {
      id: 'news',
      label: 'Market News',
      sub: 'Global & India Wire',
      icon: Newspaper,
    },
    {
      id: 'calendar',
      label: 'Economic Calendar',
      sub: 'Events, Results & Holidays',
      icon: Calendar,
    },
    {
      id: 'admin',
      label: 'Admin Console',
      sub: 'Feeds, Users & System',
      icon: Shield,
      adminOnly: true,
    },
  ];

  return (
    <>
      {/* =================================================================
          DESKTOP SIDEBAR (Modern Institutional Sidebar — Full or Symbol-Only Rail)
          Background: #FFFFFF | Selected: #EFF6FF | Border: 4px solid #2563EB
         ================================================================= */}
      <aside
        className={`hidden lg:flex flex-col ${
          isSidebarHidden ? 'w-[54px]' : 'w-48 xl:w-56 2xl:w-60'
        } shrink-0 bg-[#FFFFFF] border-r border-[#E2E8F0] select-none justify-between overflow-y-auto transition-all`}
      >
        <div>
          {/* Top Sidebar Header Bar aligned with Top Index Ticker Bar */}
          <div
            className={`min-h-[54px] ${
              isSidebarHidden ? 'px-1.5 justify-center' : 'px-3 xl:px-4 justify-between'
            } py-1.5 border-b border-[#E2E8F0] flex items-center bg-[#FFFFFF] shrink-0`}
          >
            {!isSidebarHidden && (
              <span className="text-[10px] xl:text-[11px] font-semibold uppercase tracking-wider text-[#64748B]">
                Trading Desk
              </span>
            )}
            {onToggleSidebar && (
              <button
                onClick={onToggleSidebar}
                className={`inline-flex items-center justify-center ${
                  isSidebarHidden ? 'w-8 h-8' : 'gap-1 px-2 py-1'
                } rounded-[6px] bg-[#F8FAFC] hover:bg-[#EFF6FF] border border-[#E2E8F0] hover:border-[#BFDBFE] text-[#475569] hover:text-[#2563EB] text-[10px] xl:text-[11px] font-medium transition-colors cursor-pointer`}
                title={isSidebarHidden ? 'Show Sidebar Text' : 'Hide Sidebar Text (Show Symbols Only)'}
              >
                {isSidebarHidden ? (
                  <PanelLeftOpen className="w-4 h-4 shrink-0 text-[#2563EB]" />
                ) : (
                  <>
                    <PanelLeftClose className="w-3.5 h-3.5 shrink-0" />
                    <span>Hide</span>
                  </>
                )}
              </button>
            )}
          </div>

          <nav className="py-1.5 space-y-0.5">
            {tabs.map((tab) => {
              if (tab.adminOnly && userRole !== 'ADMIN') {
                return null;
              }
              const isActive = activeTab === tab.id;
              const Icon = tab.icon;

              return (
                <button
                  key={tab.id}
                  onClick={() => onTabChange(tab.id)}
                  title={`${tab.label} — ${tab.sub}`}
                  className={`w-full relative flex items-center ${
                    isSidebarHidden
                      ? 'justify-center px-0 py-3'
                      : 'justify-between px-3 xl:px-4 py-2 xl:py-2.5 text-left'
                  } transition-colors border-l-4 cursor-pointer ${
                    isActive
                      ? 'bg-[#EFF6FF] border-[#2563EB] text-[#2563EB]'
                      : 'border-transparent text-[#475569] hover:bg-[#F8FAFC] hover:text-[#0F172A]'
                  }`}
                >
                  <div
                    className={`flex items-center ${
                      isSidebarHidden ? 'justify-center' : 'gap-2.5 xl:gap-3 min-w-0'
                    }`}
                  >
                    <Icon
                      className={`w-4 h-4 shrink-0 ${
                        isActive ? 'text-[#2563EB]' : 'text-[#64748B]'
                      }`}
                    />
                    {!isSidebarHidden && (
                      <div className="truncate">
                        <div
                          className={`text-[11px] xl:text-xs leading-tight truncate ${
                            isActive ? 'font-semibold text-[#2563EB]' : 'font-medium text-[#0F172A]'
                          }`}
                        >
                          {tab.label}
                        </div>
                        <div className="text-[10px] xl:text-[11px] text-[#64748B] font-normal truncate mt-0.5">
                          {tab.sub}
                        </div>
                      </div>
                    )}
                  </div>

                  {!isSidebarHidden && tab.badge && (
                    <span
                      className={`text-[9px] xl:text-[10px] px-1.5 py-0.5 rounded font-semibold shrink-0 ml-1 ${
                        tab.badge === 'LIVE'
                          ? 'bg-[#DCFCE7] text-[#166534]'
                          : 'bg-[#DBEAFE] text-[#1E40AF]'
                      }`}
                    >
                      {tab.badge}
                    </span>
                  )}

                  {!isSidebarHidden && tab.count !== undefined && tab.count > 0 && (
                    <span className="bg-[#DC2626] text-white text-[9px] xl:text-[10px] px-1.5 py-0.5 rounded-full font-semibold shrink-0 ml-1">
                      {tab.count}
                    </span>
                  )}

                  {isSidebarHidden && tab.count !== undefined && tab.count > 0 && (
                    <span className="absolute top-1.5 right-1.5 min-w-[14px] h-[14px] px-1 bg-[#DC2626] text-white text-[8.5px] rounded-full font-bold flex items-center justify-center">
                      {tab.count}
                    </span>
                  )}
                </button>
              );
            })}
          </nav>

          {/* Secondary Institutional Utilities (Watchlist, Reports, Settings, Profile) */}
          <div className="mt-4 pt-3 border-t border-[#E2E8F0]">
            {!isSidebarHidden && (
              <div className="px-4 pb-2 text-[11px] font-semibold uppercase tracking-wider text-[#64748B]">
                Workspace &amp; Reports
              </div>
            )}
            <div className="space-y-0.5">
              <button
                onClick={() => onTabChange('alerts')}
                title="My Watchlist"
                className={`w-full flex items-center ${
                  isSidebarHidden ? 'justify-center px-0 py-2.5' : 'gap-3 px-4 py-2'
                } text-xs font-medium text-[#475569] hover:bg-[#F8FAFC] hover:text-[#0F172A] border-l-4 border-transparent transition-colors cursor-pointer`}
              >
                <Bookmark className="w-4 h-4 text-[#64748B] shrink-0" />
                {!isSidebarHidden && <span>My Watchlist</span>}
              </button>
              <button
                onClick={() => onOpenModal?.('reports')}
                title="Analytical Reports"
                className={`w-full flex items-center ${
                  isSidebarHidden ? 'justify-center px-0 py-2.5' : 'gap-3 px-4 py-2'
                } text-xs font-medium text-[#475569] hover:bg-[#F8FAFC] hover:text-[#0F172A] border-l-4 border-transparent transition-colors cursor-pointer`}
              >
                <FileText className="w-4 h-4 text-[#64748B] shrink-0" />
                {!isSidebarHidden && <span>Analytical Reports</span>}
              </button>
              <button
                onClick={() => onOpenModal?.('settings')}
                title="Terminal Settings"
                className={`w-full flex items-center ${
                  isSidebarHidden ? 'justify-center px-0 py-2.5' : 'gap-3 px-4 py-2'
                } text-xs font-medium text-[#475569] hover:bg-[#F8FAFC] hover:text-[#0F172A] border-l-4 border-transparent transition-colors cursor-pointer`}
              >
                <Settings className="w-4 h-4 text-[#64748B] shrink-0" />
                {!isSidebarHidden && <span>Terminal Settings</span>}
              </button>
              <button
                onClick={() => onOpenModal?.('profile')}
                title="Trader Profile"
                className={`w-full flex items-center ${
                  isSidebarHidden ? 'justify-center px-0 py-2.5' : 'gap-3 px-4 py-2'
                } text-xs font-medium text-[#475569] hover:bg-[#F8FAFC] hover:text-[#0F172A] border-l-4 border-transparent transition-colors cursor-pointer`}
              >
                <User className="w-4 h-4 text-[#64748B] shrink-0" />
                {!isSidebarHidden && <span>Trader Profile</span>}
              </button>
            </div>
          </div>
        </div>

        {/* Institutional Desk Footer */}
        {isSidebarHidden ? (
          <div
            className="py-3 mx-auto flex items-center justify-center"
            title="NSE / BSE Feed Connected • Black-Scholes IV & Greeks Engine v4.2"
          >
            <span className="w-2.5 h-2.5 rounded-full bg-[#16A34A]" />
          </div>
        ) : (
          <div className="p-3.5 m-3 rounded-[12px] bg-[#F8FAFC] border border-[#E2E8F0] text-xs">
            <div className="flex items-center justify-between">
              <span className="font-semibold text-[#0F172A]">NSE / BSE Feed</span>
              <span className="inline-flex items-center gap-1 text-[10px] font-semibold text-[#16A34A]">
                <span className="w-1.5 h-1.5 rounded-full bg-[#16A34A]" />
                Connected
              </span>
            </div>
            <div className="text-[11px] text-[#64748B] mt-1">
              Black-Scholes IV &amp; Greeks Engine v4.2
            </div>
          </div>
        )}
      </aside>

      {/* =================================================================
          MOBILE / TABLET NAVIGATION BAR (Below lg breakpoint)
         ================================================================= */}
      <nav className="lg:hidden bg-[#FFFFFF] border-b border-[#E2E8F0] px-2 flex items-center overflow-x-auto no-scrollbar gap-1 text-xs w-full shrink-0">
        {tabs.map((tab) => {
          if (tab.adminOnly && userRole !== 'ADMIN') {
            return null;
          }
          const isActive = activeTab === tab.id;
          const Icon = tab.icon;

          return (
            <button
              key={tab.id}
              onClick={() => onTabChange(tab.id)}
              className={`flex items-center gap-2 px-3 py-2.5 border-b-2 transition-colors whitespace-nowrap ${
                isActive
                  ? 'bg-[#EFF6FF] border-[#2563EB] text-[#2563EB] font-semibold'
                  : 'border-transparent text-[#475569] hover:text-[#0F172A] hover:bg-[#F8FAFC]'
              }`}
            >
              <Icon className={`w-4 h-4 ${isActive ? 'text-[#2563EB]' : 'text-[#64748B]'}`} />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </nav>
    </>
  );
};
