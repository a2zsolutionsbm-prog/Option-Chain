import React, { useState, useEffect } from 'react';
import { IndexMarketData, IndexSymbol, UserRole } from '../../types';
import {
  Bell,
  Calendar,
  ChevronDown,
  Clock,
  FileText,
  LogIn,
  Moon,
  PanelLeftClose,
  PanelLeftOpen,
  Search,
  Settings,
  Shield,
  Sparkles,
  Sun,
  TrendingDown,
  TrendingUp,
  User,
  Wifi,
  WifiOff,
  X,
} from 'lucide-react';
import { globalIndicesService, GlobalIndexRecord } from '../../services/globalIndicesData';

interface TopTickerProps {
  indices: Record<IndexSymbol, IndexMarketData>;
  activeSymbol: IndexSymbol;
  onSelectSymbol: (symbol: IndexSymbol) => void;
  onOpenIndices?: () => void;
  onOpenAlerts?: () => void;
  onOpenModal?: (modal: 'profile' | 'settings' | 'reports' | 'login') => void;
  pendingAlertsCount?: number;
  searchQuery?: string;
  onSearchChange?: (q: string) => void;
  latencyMs: number;
  packetsReceived: number;
  userRole: UserRole;
  onRoleChange: (role: UserRole) => void;
  theme: 'dark' | 'light';
  onThemeChange: (theme: 'dark' | 'light') => void;
  isSidebarHidden?: boolean;
  onToggleSidebar?: () => void;
}

export const TopTicker: React.FC<TopTickerProps> = ({
  onOpenAlerts,
  onOpenModal,
  pendingAlertsCount = 0,
  searchQuery = '',
  onSearchChange,
  latencyMs,
  packetsReceived,
  userRole,
  onRoleChange,
  theme,
  onThemeChange,
  isSidebarHidden = false,
  onToggleSidebar,
}) => {
  const [istTime, setIstTime] = useState<string>('');
  const [istDateWithDay, setIstDateWithDay] = useState<string>('');
  const [profileMenuOpen, setProfileMenuOpen] = useState<boolean>(false);

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      const timeOptions: Intl.DateTimeFormatOptions = {
        timeZone: 'Asia/Kolkata',
        hour12: true,
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
      };
      const dateOptions: Intl.DateTimeFormatOptions = {
        timeZone: 'Asia/Kolkata',
        weekday: 'long',
        day: '2-digit',
        month: 'short',
        year: 'numeric',
      };
      setIstTime(now.toLocaleTimeString('en-US', timeOptions) + ' IST');
      setIstDateWithDay(now.toLocaleDateString('en-GB', dateOptions));
    };
    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  return (
    <header className="bg-[#FFFFFF] border-b border-[#E2E8F0] select-none z-30 w-full shrink-0">
      {/* =================================================================
          1. INSTITUTIONAL HEADER BAR (Responsive, Single-Line, No Overlap)
         ================================================================= */}
      <div className="min-h-[60px] px-3 xl:px-4 py-1.5 flex items-center justify-between gap-2 xl:gap-3 bg-[#FFFFFF] shadow-[0_1px_2px_rgba(0,0,0,0.03)] overflow-x-auto no-scrollbar">
        {/* Left: Brand Logo, Market Status & Live Day + Date + Time */}
        <div className="flex items-center gap-2 xl:gap-3 shrink-0">
          {/* Logo */}
          <div className="flex items-center gap-2 shrink-0">
            <div className="w-8 h-8 xl:w-9 xl:h-9 rounded-[10px] bg-[#2563EB] flex items-center justify-center text-white font-semibold text-xs xl:text-sm shadow-xs shrink-0">
              DS
            </div>
            <div className="leading-tight whitespace-nowrap">
              <div className="flex items-center gap-1.5">
                <span className="font-semibold text-[#0F172A] text-xs xl:text-sm tracking-tight">
                  DigiService Chain Pro
                </span>
                <span className="bg-[#EFF6FF] text-[#2563EB] border border-[#BFDBFE] text-[9px] xl:text-[10px] font-semibold px-1.5 py-0.5 rounded uppercase">
                  TERMINAL
                </span>
              </div>
              <div className="text-[10px] xl:text-[11px] text-[#64748B] font-normal">
                Institutional Options &amp; Equities Desk
              </div>
            </div>
          </div>

          <div className="h-5 w-px bg-[#E2E8F0] hidden sm:block shrink-0" />

          {/* Market Status Pill (Strict single-line whitespace-nowrap) */}
          <div className="hidden sm:flex items-center gap-1.5 bg-[#ECFDF5] text-[#16A34A] border border-[#BBF7D0] px-2.5 py-1 rounded-[8px] text-[11px] font-medium whitespace-nowrap shrink-0">
            <span className="w-2 h-2 rounded-full bg-[#16A34A] shrink-0" />
            <span className="font-semibold text-[#166534]">MARKET OPEN</span>
            <span className="text-[10px] text-[#15803D] hidden 2xl:inline">| NSE &amp; BSE LIVE</span>
          </div>

          {/* Live Day + Date + Time + Feed Status (Strict single-line whitespace-nowrap) */}
          <div className="flex items-center gap-2 bg-[#F8FAFC] border border-[#E2E8F0] px-2.5 xl:px-3 py-1.5 rounded-[10px] text-[11px] xl:text-xs text-[#475569] whitespace-nowrap shrink-0">
            <div className="flex items-center gap-1.5 font-mono-num">
              <Calendar className="w-3.5 h-3.5 text-[#2563EB] shrink-0" />
              <span className="font-semibold text-[#0F172A]">
                {istDateWithDay || 'Saturday, 26 Sept 2026'}
              </span>
            </div>
            <span className="text-[#CBD5E1]">|</span>
            <div className="flex items-center gap-1.5 font-mono-num">
              <Clock className="w-3.5 h-3.5 text-[#2563EB] shrink-0" />
              <span className="font-semibold text-[#2563EB]">
                {istTime || '10:32:35 PM IST'}
              </span>
            </div>
            <span className="text-[#CBD5E1] hidden md:inline">|</span>
            <div
              className="hidden md:flex items-center gap-1 text-[11px] font-mono-num"
              title={`Packets: #${packetsReceived}`}
            >
              {latencyMs > 0 ? (
                <Wifi className="w-3.5 h-3.5 text-[#16A34A] shrink-0" />
              ) : (
                <WifiOff className="w-3.5 h-3.5 text-[#DC2626] shrink-0" />
              )}
              <span className="text-[#16A34A] font-medium">{latencyMs}ms</span>
            </div>
          </div>
        </div>

        {/* Right: Search, Role Tier, Notifications, Theme Toggle, User Profile */}
        <div className="flex items-center gap-2 shrink-0">
          {/* Global Strike / Symbol Search Input */}
          <div className="relative hidden lg:block w-40 xl:w-52 2xl:w-64">
            <Search className="w-3.5 h-3.5 text-[#64748B] absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => onSearchChange?.(e.target.value)}
              placeholder="Filter strike or symbol..."
              className="w-full h-[36px] pl-8 pr-6 bg-[#FFFFFF] border border-[#CBD5E1] focus:border-[#2563EB] rounded-[10px] text-[11px] xl:text-xs text-[#0F172A] placeholder-[#94A3B8] transition-colors"
            />
            {searchQuery && (
              <button
                onClick={() => onSearchChange?.('')}
                className="absolute right-2 top-1/2 -translate-y-1/2 text-[#64748B] hover:text-[#0F172A]"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {/* Role Tier Selector */}
          <div className="hidden xl:flex items-center bg-[#F8FAFC] border border-[#E2E8F0] p-0.5 rounded-[10px] shrink-0">
            {(['RETAIL', 'PREMIUM', 'ADMIN'] as UserRole[]).map((r) => {
              const active = userRole === r;
              return (
                <button
                  key={r}
                  onClick={() => onRoleChange(r)}
                  className={`px-2 py-1 rounded-[8px] text-[10.5px] font-medium transition-colors flex items-center gap-1 whitespace-nowrap ${
                    active
                      ? 'bg-[#2563EB] text-white font-semibold shadow-xs'
                      : 'text-[#475569] hover:text-[#0F172A] hover:bg-[#F1F5F9]'
                  }`}
                  title={`Switch workspace role to ${r}`}
                >
                  {r === 'ADMIN' && <Shield className="w-3 h-3 shrink-0" />}
                  {r === 'PREMIUM' && <Sparkles className="w-3 h-3 shrink-0" />}
                  {r === 'RETAIL' && <User className="w-3 h-3 shrink-0" />}
                  <span>{r}</span>
                </button>
              );
            })}
          </div>

          {/* Notifications Button */}
          <button
            onClick={onOpenAlerts}
            className="relative h-[36px] w-[36px] flex items-center justify-center rounded-[10px] bg-[#FFFFFF] border border-[#E2E8F0] hover:bg-[#F8FAFC] text-[#475569] hover:text-[#0F172A] transition-colors shrink-0"
            title="Price & PCR Alerts"
          >
            <Bell className="w-4 h-4" />
            {pendingAlertsCount > 0 && (
              <span className="absolute -top-1 -right-1 min-w-[16px] h-[16px] px-1 rounded-full bg-[#DC2626] text-white text-[9.5px] font-semibold flex items-center justify-center">
                {pendingAlertsCount}
              </span>
            )}
          </button>

          {/* Theme Toggle */}
          <button
            onClick={() => onThemeChange(theme === 'light' ? 'dark' : 'light')}
            className="h-[36px] px-2.5 flex items-center gap-1.5 rounded-[10px] bg-[#FFFFFF] border border-[#E2E8F0] hover:bg-[#F8FAFC] text-[#475569] hover:text-[#0F172A] text-[11px] xl:text-xs font-medium transition-colors whitespace-nowrap shrink-0"
            title={`Switch to ${theme === 'light' ? 'Dark' : 'Light'} Mode`}
          >
            {theme === 'light' ? (
              <>
                <Sun className="w-3.5 h-3.5 text-[#F59E0B] shrink-0" />
                <span className="hidden sm:inline">Light</span>
              </>
            ) : (
              <>
                <Moon className="w-3.5 h-3.5 text-[#2563EB] shrink-0" />
                <span className="hidden sm:inline">Dark</span>
              </>
            )}
          </button>

          {/* User Profile & Institutional Menu */}
          <div className="relative shrink-0">
            <button
              onClick={() => setProfileMenuOpen(!profileMenuOpen)}
              className="h-[36px] px-2.5 flex items-center gap-2 rounded-[10px] bg-[#FFFFFF] border border-[#E2E8F0] hover:bg-[#F8FAFC] text-xs font-medium text-[#0F172A] transition-colors whitespace-nowrap"
            >
              <div className="w-6 h-6 rounded-full bg-[#EFF6FF] border border-[#BFDBFE] text-[#2563EB] flex items-center justify-center font-semibold text-[10px] shrink-0">
                TR
              </div>
              <div className="hidden sm:block text-left leading-tight whitespace-nowrap">
                <div className="text-[11px] xl:text-xs font-semibold text-[#0F172A]">Desk Trader</div>
                <div className="text-[9.5px] text-[#64748B]">{userRole}</div>
              </div>
              <ChevronDown className="w-3.5 h-3.5 text-[#64748B] shrink-0" />
            </button>

            {profileMenuOpen && (
              <div className="absolute right-0 mt-1.5 w-56 bg-[#FFFFFF] border border-[#E2E8F0] rounded-[12px] shadow-lg py-1.5 z-50 text-xs">
                <div className="px-3.5 py-2 border-b border-[#E2E8F0]">
                  <div className="font-semibold text-[#0F172A]">Institutional Desk #04</div>
                  <div className="text-[11px] text-[#64748B]">NSE/BSE F&amp;O Terminal Active</div>
                </div>

                {/* Role switcher for mobile/compact */}
                <div className="px-3.5 py-2 border-b border-[#E2E8F0] xl:hidden">
                  <div className="text-[10px] font-semibold text-[#64748B] uppercase mb-1.5">
                    Active Tier
                  </div>
                  <div className="grid grid-cols-3 gap-1">
                    {(['RETAIL', 'PREMIUM', 'ADMIN'] as UserRole[]).map((r) => (
                      <button
                        key={r}
                        onClick={() => {
                          onRoleChange(r);
                          setProfileMenuOpen(false);
                        }}
                        className={`py-1 rounded text-[10px] font-semibold ${
                          userRole === r
                            ? 'bg-[#2563EB] text-white'
                            : 'bg-[#F8FAFC] text-[#475569] border border-[#E2E8F0]'
                        }`}
                      >
                        {r}
                      </button>
                    ))}
                  </div>
                </div>

                <button
                  onClick={() => {
                    setProfileMenuOpen(false);
                    onOpenModal?.('profile');
                  }}
                  className="w-full px-3.5 py-2 text-left text-[#0F172A] hover:bg-[#F8FAFC] flex items-center gap-2.5"
                >
                  <User className="w-4 h-4 text-[#475569]" />
                  <span>User Profile &amp; Account</span>
                </button>
                <button
                  onClick={() => {
                    setProfileMenuOpen(false);
                    onOpenModal?.('reports');
                  }}
                  className="w-full px-3.5 py-2 text-left text-[#0F172A] hover:bg-[#F8FAFC] flex items-center gap-2.5"
                >
                  <FileText className="w-4 h-4 text-[#475569]" />
                  <span>P&amp;L &amp; Analytics Reports</span>
                </button>
                <button
                  onClick={() => {
                    setProfileMenuOpen(false);
                    onOpenModal?.('settings');
                  }}
                  className="w-full px-3.5 py-2 text-left text-[#0F172A] hover:bg-[#F8FAFC] flex items-center gap-2.5"
                >
                  <Settings className="w-4 h-4 text-[#475569]" />
                  <span>Terminal Settings</span>
                </button>
                <div className="my-1 border-t border-[#E2E8F0]" />
                <button
                  onClick={() => {
                    setProfileMenuOpen(false);
                    onOpenModal?.('login');
                  }}
                  className="w-full px-3.5 py-2 text-left text-[#2563EB] font-medium hover:bg-[#EFF6FF] flex items-center gap-2.5"
                >
                  <LogIn className="w-4 h-4 text-[#2563EB]" />
                  <span>Broker Session / Login</span>
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </header>
  );
};

/* ============================================================================
   2. COMPACT NARROW NON-CLICKABLE INDEX TICKER BAR
      Placed inside the right workspace column so it starts right from the
      end of the Sidebar panel.
   ============================================================================ */
interface IndexTickerBarProps {
  indices: Record<IndexSymbol, IndexMarketData>;
  isSidebarHidden?: boolean;
  onToggleSidebar?: () => void;
}

export const IndexTickerBar: React.FC<IndexTickerBarProps> = ({
  indices,
  isSidebarHidden = false,
  onToggleSidebar,
}) => {
  const [globalIndices, setGlobalIndices] = useState<GlobalIndexRecord[]>(
    globalIndicesService.getIndices()
  );

  useEffect(() => {
    const unsub = globalIndicesService.subscribe((list) => {
      setGlobalIndices([...list]);
    });
    return () => unsub();
  }, []);

  const indexKeys: IndexSymbol[] = ['NIFTY', 'BANKNIFTY', 'FINNIFTY', 'MIDCPNIFTY', 'SENSEX'];

  return (
    <div className="min-h-[54px] px-3 xl:px-4 py-1.5 bg-[#F8FAFC] border-b border-[#E2E8F0] flex items-center gap-2.5 overflow-x-auto no-scrollbar w-full shrink-0 select-none">
      {indexKeys.map((sym) => {
        const item = indices[sym];
        if (!item) return null;
        const isPositive = item.change >= 0;

        return (
          <div
            key={sym}
            className="inline-flex flex-col justify-center px-3 py-1.5 rounded-[8px] bg-[#FFFFFF] border border-[#E2E8F0] shadow-[0_1px_2px_rgba(0,0,0,0.03)] text-left cursor-default whitespace-nowrap shrink-0 min-w-[148px] xl:min-w-[164px]"
          >
            <div className="flex items-center justify-between gap-3">
              <span className="text-[11px] xl:text-xs font-semibold text-[#0F172A]">
                {sym}
              </span>
              <span className="font-mono-num font-semibold text-[11.5px] xl:text-xs text-[#0F172A]">
                {item.spotPrice.toLocaleString('en-IN', {
                  minimumFractionDigits: 2,
                  maximumFractionDigits: 2,
                })}
              </span>
            </div>
            <div
              className={`font-mono-num text-[10px] xl:text-[10.5px] font-medium flex items-center justify-end gap-0.5 mt-0.5 ${
                isPositive ? 'text-[#16A34A]' : 'text-[#DC2626]'
              }`}
            >
              {isPositive ? (
                <TrendingUp className="w-2.5 h-2.5 text-[#16A34A] shrink-0" />
              ) : (
                <TrendingDown className="w-2.5 h-2.5 text-[#DC2626] shrink-0" />
              )}
              <span>
                {isPositive ? '+' : ''}
                {item.change.toFixed(2)} ({isPositive ? '+' : ''}
                {item.pChange.toFixed(2)}%)
              </span>
            </div>
          </div>
        );
      })}

      {/* 6th Card: Compact Live GIFT NIFTY Card (Non-clickable, normal narrow size) */}
      {(() => {
        const gift = globalIndices.find((i) => i.id === 'gift_nifty');
        if (!gift) return null;
        const isUp = gift.change >= 0;
        return (
          <div
            className="inline-flex flex-col justify-center px-3 py-1.5 rounded-[8px] bg-[#FFFFFF] border border-[#E2E8F0] shadow-[0_1px_2px_rgba(0,0,0,0.03)] text-left cursor-default whitespace-nowrap shrink-0 min-w-[148px] xl:min-w-[164px]"
          >
            <div className="flex items-center justify-between gap-3">
              <span className="text-[11px] xl:text-xs font-semibold text-[#0F172A]">
                GIFT NIFTY
              </span>
              <span className="font-mono-num font-semibold text-[11.5px] xl:text-xs text-[#0F172A]">
                {gift.ltp.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
              </span>
            </div>
            <div
              className={`font-mono-num text-[10px] xl:text-[10.5px] font-medium flex items-center justify-end gap-0.5 mt-0.5 ${
                isUp ? 'text-[#16A34A]' : 'text-[#DC2626]'
              }`}
            >
              {isUp ? (
                <TrendingUp className="w-2.5 h-2.5 text-[#16A34A] shrink-0" />
              ) : (
                <TrendingDown className="w-2.5 h-2.5 text-[#DC2626] shrink-0" />
              )}
              <span>
                {isUp ? '+' : ''}
                {gift.change.toFixed(2)} ({isUp ? '+' : ''}
                {gift.pChange.toFixed(2)}%)
              </span>
            </div>
          </div>
        );
      })()}
    </div>
  );
};

