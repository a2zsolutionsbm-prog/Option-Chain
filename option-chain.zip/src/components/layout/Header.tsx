import React from 'react';
import { IndexMarketData, IndexSymbol } from '../../types';
import {
  Bell,
  Calendar,
  Layers,
  Moon,
  Play,
  Pause,
  RefreshCw,
  Search,
  Sun,
  Volume2,
  VolumeX,
} from 'lucide-react';

interface HeaderProps {
  currentIndex: IndexMarketData;
  activeExpiry: string;
  onSelectExpiry: (exp: string) => void;
  strikeRange: number;
  onSelectStrikeRange: (range: number) => void;
  searchStrike: string;
  onSearchStrikeChange: (val: string) => void;
  isAutoUpdating: boolean;
  onToggleAutoUpdate: () => void;
  soundEnabled: boolean;
  onToggleSound: () => void;
  alertCount: number;
  onOpenAlerts: () => void;
  theme?: 'dark' | 'light';
  onToggleTheme?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentIndex,
  activeExpiry,
  onSelectExpiry,
  strikeRange,
  onSelectStrikeRange,
  searchStrike,
  onSearchStrikeChange,
  isAutoUpdating,
  onToggleAutoUpdate,
  soundEnabled,
  onToggleSound,
  alertCount,
  onOpenAlerts,
  theme = 'dark',
  onToggleTheme,
}) => {
  return (
    <header className="bg-[#0b0f19] border-b border-slate-800 px-3 py-2 flex flex-wrap items-center justify-between gap-3 text-xs">
      {/* Active Symbol & Spot Quote details */}
      <div className="flex items-center space-x-2.5">
        <div className="flex items-center space-x-2 bg-slate-900/90 border border-slate-800 px-3 py-1.5 rounded-lg shadow-sm">
          <div className="flex items-center space-x-1.5">
            <span className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse" />
            <span className="font-extrabold text-white text-xs tracking-wide">
              {currentIndex.name}
            </span>
          </div>
          <span className="text-slate-600 font-mono">|</span>
          <div className="flex items-center space-x-1">
            <span className="text-[10.5px] text-slate-400 font-bold uppercase">Spot:</span>
            <span className="font-mono-num font-extrabold text-cyan-400 text-xs">
              ₹{currentIndex.spotPrice.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
            </span>
          </div>
          <span className="text-slate-700 font-mono">|</span>
          <div className="flex items-center space-x-1">
            <span className="text-[10.5px] text-indigo-300 font-bold uppercase">Fut:</span>
            <span className="font-mono-num font-extrabold text-indigo-400 text-xs">
              ₹{(currentIndex.futurePrice || currentIndex.spotPrice + 54.3).toLocaleString('en-IN', { minimumFractionDigits: 2 })}
            </span>
          </div>
          <span
            className={`font-mono-num text-[11px] font-bold px-1.5 py-0.5 rounded ${
              currentIndex.change >= 0
                ? 'bg-emerald-950/70 text-emerald-400 border border-emerald-800/40'
                : 'bg-rose-950/70 text-rose-400 border border-rose-800/40'
            }`}
          >
            {currentIndex.change >= 0 ? '+' : ''}
            {currentIndex.change.toFixed(2)} ({currentIndex.change >= 0 ? '+' : ''}
            {currentIndex.pChange.toFixed(2)}%)
          </span>
          <span className="text-[10px] text-slate-400 font-mono-num hidden sm:inline border-l border-slate-800 pl-2">
            Lot: <strong className="text-slate-200">{currentIndex.lotSize}</strong>
          </span>
        </div>
      </div>

      {/* Expiry, Filters, Search & Controls */}
      <div className="flex items-center flex-wrap gap-2">
        {/* Expiry Selector */}
        <div className="flex items-center space-x-1 bg-slate-900 border border-slate-800 rounded px-2 py-1">
          <Calendar className="w-3.5 h-3.5 text-cyan-400" />
          <span className="text-[10px] text-slate-400 uppercase">Expiry:</span>
          <select
            value={activeExpiry}
            onChange={(e) => onSelectExpiry(e.target.value)}
            className="bg-transparent text-slate-100 font-medium focus:outline-none cursor-pointer text-xs"
          >
            {currentIndex.expiries.map((exp) => (
              <option key={exp} value={exp} className="bg-slate-900 text-slate-100">
                {exp}
              </option>
            ))}
          </select>
        </div>

        {/* Strike Range Filter */}
        <div className="flex items-center space-x-0.5 bg-slate-900 border border-slate-800 rounded p-0.5">
          <span className="text-[10px] text-slate-400 px-1.5 flex items-center space-x-1">
            <Layers className="w-3 h-3 text-slate-400" />
            <span className="hidden sm:inline">Strikes:</span>
          </span>
          {[5, 10, 20, 0].map((rng) => (
            <button
              key={rng}
              onClick={() => onSelectStrikeRange(rng)}
              className={`px-2 py-0.5 rounded text-[11px] font-medium transition-colors ${
                strikeRange === rng
                  ? 'bg-cyan-600 text-white font-semibold'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
              }`}
            >
              {rng === 0 ? 'All' : `±${rng}`}
            </button>
          ))}
        </div>

        {/* Search Strike */}
        <div className="relative">
          <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2 top-2" />
          <input
            type="text"
            placeholder="Search Strike (e.g. 24900)"
            value={searchStrike}
            onChange={(e) => onSearchStrikeChange(e.target.value)}
            className="bg-slate-900 border border-slate-800 rounded pl-7 pr-2 py-1 text-slate-200 placeholder-slate-500 focus:outline-none focus:border-cyan-500 w-36 sm:w-44 text-xs font-mono-num"
          />
        </div>

        {/* Live Auto-Update Switch */}
        <button
          onClick={onToggleAutoUpdate}
          className={`flex items-center space-x-1 px-2.5 py-1 rounded border transition-colors ${
            isAutoUpdating
              ? 'bg-emerald-950/60 border-emerald-800 text-emerald-400 hover:bg-emerald-900/60'
              : 'bg-rose-950/60 border-rose-800 text-rose-400 hover:bg-rose-900/60'
          }`}
          title={isAutoUpdating ? 'Auto-update running (1s tick)' : 'Updates paused'}
        >
          {isAutoUpdating ? (
            <>
              <RefreshCw className="w-3 h-3 animate-spin text-emerald-400" />
              <span className="font-semibold text-[11px]">1s Live</span>
            </>
          ) : (
            <>
              <Pause className="w-3 h-3 text-rose-400" />
              <span className="font-semibold text-[11px]">Paused</span>
            </>
          )}
        </button>

        {/* Audio Toggle */}
        <button
          onClick={onToggleSound}
          className={`p-1.5 rounded border ${
            soundEnabled
              ? 'border-slate-700 bg-slate-900 text-cyan-400 hover:text-cyan-300'
              : 'border-slate-800 bg-slate-900 text-slate-500 hover:text-slate-400'
          }`}
          title={soundEnabled ? 'Terminal audio alert enabled' : 'Terminal audio muted'}
        >
          {soundEnabled ? <Volume2 className="w-3.5 h-3.5" /> : <VolumeX className="w-3.5 h-3.5" />}
        </button>

        {/* Alerts Bell */}
        <button
          onClick={onOpenAlerts}
          className="relative p-1.5 rounded border border-slate-800 bg-slate-900 text-slate-300 hover:text-slate-100 hover:border-slate-700 transition-colors"
          title="Open Alerts & Triggers"
        >
          <Bell className="w-3.5 h-3.5 text-slate-300" />
          {alertCount > 0 && (
            <span className="absolute -top-1 -right-1 bg-rose-600 text-white font-bold rounded-full w-4 h-4 flex items-center justify-center text-[9px] shadow-sm animate-pulse">
              {alertCount}
            </span>
          )}
        </button>

        {/* Theme Toggle (Dark / Light) */}
        {onToggleTheme && (
          <button
            onClick={onToggleTheme}
            className="p-1.5 rounded border border-slate-800 bg-slate-900 text-slate-300 hover:text-slate-100 hover:border-slate-700 transition-colors"
            title={`Switch to ${theme === 'dark' ? 'Light' : 'Dark'} Theme`}
          >
            {theme === 'light' ? (
              <Sun className="w-3.5 h-3.5 text-amber-500" />
            ) : (
              <Moon className="w-3.5 h-3.5 text-cyan-400" />
            )}
          </button>
        )}
      </div>
    </header>
  );
};
