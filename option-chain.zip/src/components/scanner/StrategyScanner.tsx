import React, { useState } from 'react';
import { IndexSymbol, ScannerSignal, UserRole } from '../../types';
import {
  AlertTriangle,
  ArrowRight,
  Flame,
  Lock,
  Radar,
  RefreshCw,
  Search,
  Sparkles,
  TrendingDown,
  TrendingUp,
  Zap,
} from 'lucide-react';

interface StrategyScannerProps {
  userRole: UserRole;
  onUpgradeRole: (role: UserRole) => void;
  onSelectStrikeForStrategy: (symbol: IndexSymbol, strike: number, type: 'CE' | 'PE') => void;
}

export const MOCK_SIGNALS: ScannerSignal[] = [
  {
    id: 'sig_1',
    symbol: 'NIFTY',
    strike: 25000,
    type: 'CE',
    category: 'UNUSUAL_OI',
    title: 'Massive Call Writing at Psychological Level',
    description: 'NIFTY 25000 CE saw +280% OI surge (over 4.2M contracts added) creating formidable overhead resistance wall.',
    sentiment: 'BEARISH',
    oiChangePercent: 284,
    volumePercent: 195,
    timestamp: '2 mins ago',
  },
  {
    id: 'sig_2',
    symbol: 'BANKNIFTY',
    strike: 53000,
    type: 'PE',
    category: 'PUT_WRITING',
    title: 'Aggressive Put Writing Support Base',
    description: 'BANKNIFTY 53000 PE witnessed 180k lots added as bulls vigorously defend 53k benchmark level.',
    sentiment: 'BULLISH',
    oiChangePercent: 215,
    volumePercent: 160,
    timestamp: '5 mins ago',
  },
  {
    id: 'sig_3',
    symbol: 'NIFTY',
    strike: 24800,
    type: 'PE',
    category: 'SHORT_COVERING',
    title: 'Sharp Short Covering Rally Detected',
    description: 'PE writers actively squaring off positions with -42% OI reduction as spot crosses 24850.',
    sentiment: 'BULLISH',
    oiChangePercent: -42,
    volumePercent: 230,
    timestamp: '8 mins ago',
  },
  {
    id: 'sig_4',
    symbol: 'FINNIFTY',
    strike: 24200,
    type: 'CE',
    category: 'IV_SPIKE',
    title: 'Implied Volatility Expansion Ahead of Expiry',
    description: 'FINNIFTY 24200 CE IV surged +3.8% above historical mean, signalling imminent breakout momentum.',
    sentiment: 'NEUTRAL',
    oiChangePercent: 145,
    volumePercent: 210,
    timestamp: '12 mins ago',
  },
  {
    id: 'sig_5',
    symbol: 'SENSEX',
    strike: 81500,
    type: 'CE',
    category: 'BREAKOUT',
    title: 'High Gamma Squeeze Setup in Play',
    description: 'SENSEX 81500 Call Delta expanding from 0.38 to 0.52 rapidly with high dealer delta hedging demand.',
    sentiment: 'BULLISH',
    oiChangePercent: 175,
    volumePercent: 310,
    timestamp: '15 mins ago',
  },
];

export const StrategyScanner: React.FC<StrategyScannerProps> = ({
  userRole,
  onUpgradeRole,
  onSelectStrikeForStrategy,
}) => {
  const [filterCategory, setFilterCategory] = useState<string>('ALL');
  const [filterSentiment, setFilterSentiment] = useState<string>('ALL');

  const isLocked = userRole === 'RETAIL';

  const filteredSignals = MOCK_SIGNALS.filter((sig) => {
    if (filterCategory !== 'ALL' && sig.category !== filterCategory) return false;
    if (filterSentiment !== 'ALL' && sig.sentiment !== filterSentiment) return false;
    return true;
  });

  return (
    <div className="p-4 space-y-4 bg-[#0a0e17] overflow-y-auto text-slate-200 text-xs">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between bg-[#0f1422] border border-slate-800 rounded-xl p-3.5 gap-2 shadow-lg">
        <div>
          <div className="flex items-center space-x-2">
            <h3 className="text-sm font-bold text-white flex items-center space-x-2">
              <Radar className="w-4 h-4 text-cyan-400 animate-pulse" />
              <span>Institutional Strategy & OI Scanner</span>
            </h3>
            <span className="bg-amber-500/10 text-amber-400 border border-amber-500/30 text-[10px] font-bold px-2 py-0.5 rounded">
              PRO ALGORITHM
            </span>
          </div>
          <p className="text-[11px] text-slate-400 mt-0.5">
            Automated neural detection of unusual institutional blocks, rapid OI buildups, and gamma squeezes
          </p>
        </div>

        {/* Filters */}
        <div className="flex items-center space-x-2">
          <select
            value={filterCategory}
            onChange={(e) => setFilterCategory(e.target.value)}
            className="bg-slate-900 border border-slate-800 rounded px-2.5 py-1 text-slate-200 text-xs focus:outline-none"
          >
            <option value="ALL">All Categories</option>
            <option value="UNUSUAL_OI">Unusual OI Surge</option>
            <option value="PUT_WRITING">Put Writing Base</option>
            <option value="SHORT_COVERING">Short Covering</option>
            <option value="IV_SPIKE">IV Spike</option>
            <option value="BREAKOUT">Gamma Breakout</option>
          </select>

          <select
            value={filterSentiment}
            onChange={(e) => setFilterSentiment(e.target.value)}
            className="bg-slate-900 border border-slate-800 rounded px-2.5 py-1 text-slate-200 text-xs focus:outline-none"
          >
            <option value="ALL">All Sentiments</option>
            <option value="BULLISH">Bullish Signals</option>
            <option value="BEARISH">Bearish Signals</option>
            <option value="NEUTRAL">Neutral / Volatility</option>
          </select>
        </div>
      </div>

      {/* Role Gate Banner if Retail User */}
      {isLocked && (
        <div className="bg-gradient-to-r from-amber-950/40 via-purple-950/40 to-slate-900 border border-amber-500/40 rounded-xl p-4 flex flex-wrap items-center justify-between gap-3 shadow-xl">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-full bg-amber-500/20 flex items-center justify-center text-amber-400">
              <Lock className="w-5 h-5" />
            </div>
            <div>
              <div className="font-bold text-white text-sm">
                Strategy Scanner is a Premium Feature
              </div>
              <div className="text-[11px] text-slate-400">
                You are currently in Retail Free mode. Instant switch available below to test Pro & Institutional signals.
              </div>
            </div>
          </div>

          <button
            onClick={() => onUpgradeRole('PREMIUM')}
            className="bg-amber-500 hover:bg-amber-400 text-slate-950 font-black px-4 py-2 rounded-lg text-xs flex items-center space-x-1.5 shadow-lg shadow-amber-500/20 transition-all"
          >
            <Sparkles className="w-4 h-4" />
            <span>Unlock Pro Scanner Now</span>
          </button>
        </div>
      )}

      {/* Signals List */}
      <div className={`space-y-3 ${isLocked ? 'opacity-40 pointer-events-none select-none filter blur-[1px]' : ''}`}>
        {filteredSignals.map((signal) => {
          const isBull = signal.sentiment === 'BULLISH';
          const isBear = signal.sentiment === 'BEARISH';

          return (
            <div
              key={signal.id}
              className="bg-[#0f1422] border border-slate-800 hover:border-slate-700 rounded-xl p-4 transition-all shadow-md flex flex-wrap items-center justify-between gap-3"
            >
              <div className="space-y-1.5 max-w-2xl">
                <div className="flex items-center space-x-2">
                  <span className="font-bold text-white text-sm">{signal.symbol}</span>
                  <span className="font-mono-num font-bold text-cyan-400 text-xs">
                    {signal.strike}
                  </span>
                  <span
                    className={`px-1.5 py-0.2 rounded text-[10px] font-bold ${
                      signal.type === 'CE'
                        ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                        : 'bg-rose-950 text-rose-400 border border-rose-800'
                    }`}
                  >
                    {signal.type}
                  </span>
                  <span
                    className={`px-2 py-0.5 rounded text-[10px] font-bold flex items-center space-x-1 ${
                      isBull
                        ? 'bg-emerald-950/80 text-emerald-300 border border-emerald-700'
                        : isBear
                        ? 'bg-rose-950/80 text-rose-300 border border-rose-700'
                        : 'bg-amber-950/80 text-amber-300 border border-amber-700'
                    }`}
                  >
                    {isBull && <TrendingUp className="w-3 h-3" />}
                    {isBear && <TrendingDown className="w-3 h-3" />}
                    <span>{signal.sentiment}</span>
                  </span>
                  <span className="text-[10px] text-slate-500 font-mono-num">{signal.timestamp}</span>
                </div>

                <div className="font-bold text-slate-200 text-xs">{signal.title}</div>
                <div className="text-[11px] text-slate-400">{signal.description}</div>
              </div>

              {/* Stats & Action */}
              <div className="flex items-center space-x-4">
                <div className="text-right font-mono-num">
                  <div className="text-[10px] text-slate-400">OI Movement</div>
                  <div
                    className={`font-bold text-xs ${
                      signal.oiChangePercent >= 0 ? 'text-emerald-400' : 'text-rose-400'
                    }`}
                  >
                    {signal.oiChangePercent >= 0 ? '+' : ''}{signal.oiChangePercent}%
                  </div>
                  <div className="text-[10px] text-slate-500">
                    Vol: +{signal.volumePercent}%
                  </div>
                </div>

                <button
                  onClick={() =>
                    onSelectStrikeForStrategy(signal.symbol, signal.strike, signal.type)
                  }
                  className="bg-cyan-600 hover:bg-cyan-500 text-white px-3 py-2 rounded-lg font-bold flex items-center space-x-1 transition-colors text-xs"
                >
                  <span>Build Strategy</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
