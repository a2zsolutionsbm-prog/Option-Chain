import React, { useState } from 'react';
import { IndexMarketData, StrikeRow } from '../../types';
import {
  calculateMaxPain,
  calculatePCR,
  identifySupportResistance,
} from '../../utils/optionsAnalytics';
import {
  Activity,
  AlertTriangle,
  ArrowDownCircle,
  ArrowUpCircle,
  BarChart,
  HelpCircle,
  Layers,
  ShieldCheck,
  TrendingDown,
  TrendingUp,
} from 'lucide-react';

interface AnalyticsDashboardProps {
  currentIndex: IndexMarketData;
  strikes: StrikeRow[];
  focusSection?: 'OI' | 'MAX_PAIN';
}

export const AnalyticsDashboard: React.FC<AnalyticsDashboardProps> = ({
  currentIndex,
  strikes,
  focusSection,
}) => {
  const [selectedMetric, setSelectedMetric] = useState<'OI' | 'CHANGE_OI'>('OI');

  const { spotPrice } = currentIndex;
  const maxPain = calculateMaxPain(strikes, spotPrice);
  const pcr = calculatePCR(strikes);
  const srLevels = identifySupportResistance(strikes);

  // Calculate OI Buildup Breakdown
  let longBuildup = 0;
  let shortBuildup = 0;
  let longUnwinding = 0;
  let shortCovering = 0;

  strikes.forEach((r) => {
    // Calls
    if (r.call.buildup === 'LONG_BUILDUP') longBuildup += r.call.oi;
    if (r.call.buildup === 'SHORT_BUILDUP') shortBuildup += r.call.oi;
    if (r.call.buildup === 'LONG_UNWINDING') longUnwinding += r.call.oi;
    if (r.call.buildup === 'SHORT_COVERING') shortCovering += r.call.oi;
    // Puts
    if (r.put.buildup === 'LONG_BUILDUP') longBuildup += r.put.oi;
    if (r.put.buildup === 'SHORT_BUILDUP') shortBuildup += r.put.oi;
    if (r.put.buildup === 'LONG_UNWINDING') longUnwinding += r.put.oi;
    if (r.put.buildup === 'SHORT_COVERING') shortCovering += r.put.oi;
  });

  const totalBuildupLots = (longBuildup + shortBuildup + longUnwinding + shortCovering) / currentIndex.lotSize || 1;

  // Strikes subset for OI bar comparison (e.g. ±8 strikes around ATM)
  const atmStrike = Math.round(spotPrice / currentIndex.strikeStep) * currentIndex.strikeStep;
  const atmIndex = strikes.findIndex((r) => r.strike === atmStrike);
  const subsetStart = Math.max(0, atmIndex - 8);
  const subsetEnd = Math.min(strikes.length, atmIndex + 9);
  const displayStrikes = strikes.slice(subsetStart, subsetEnd);

  // Find max value in subset for scaling
  let maxSubsetOi = 1;
  displayStrikes.forEach((r) => {
    const valC = selectedMetric === 'OI' ? r.call.oi : Math.abs(r.call.changeOi);
    const valP = selectedMetric === 'OI' ? r.put.oi : Math.abs(r.put.changeOi);
    if (valC > maxSubsetOi) maxSubsetOi = valC;
    if (valP > maxSubsetOi) maxSubsetOi = valP;
  });

  return (
    <div className="p-4 space-y-5 bg-[#0a0e17] overflow-y-auto text-slate-200 text-xs">
      {/* Top row: Max Pain, PCR & S/R Quick Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Card 1: Max Pain */}
        <div className={`bg-[#0f1422] border rounded-xl p-4 shadow-lg relative overflow-hidden transition-all ${
          focusSection === 'MAX_PAIN'
            ? 'border-purple-500 ring-2 ring-purple-500/80 shadow-[0_0_24px_rgba(168,85,247,0.35)]'
            : 'border-slate-800'
        }`}>
          <div className="flex items-center justify-between">
            <span className="text-slate-400 font-semibold uppercase tracking-wider text-[11px] flex items-center space-x-1.5">
              <Activity className="w-3.5 h-3.5 text-purple-400" />
              <span>Max Pain Analysis</span>
            </span>
            <span className="bg-purple-950/80 border border-purple-700/60 text-purple-300 text-[10px] px-2 py-0.5 rounded font-bold">
              EXPIRY THEORY
            </span>
          </div>

          <div className="mt-3 flex items-baseline justify-between">
            <div>
              <div className="text-3xl font-extrabold font-mono-num text-white">
                {maxPain.maxPainStrike}
              </div>
              <div className="text-slate-400 text-[11px] mt-0.5">
                Distance from Spot:{' '}
                <span
                  className={`font-semibold font-mono-num ${
                    maxPain.distanceFromSpot >= 0 ? 'text-emerald-400' : 'text-rose-400'
                  }`}
                >
                  {maxPain.distanceFromSpot >= 0 ? '+' : ''}{maxPain.distanceFromSpot.toFixed(1)} pts ({maxPain.distancePercent}%)
                </span>
              </div>
            </div>
            <div className="text-right text-[11px]">
              <div className="text-slate-400">Current Spot</div>
              <div className="font-mono-num font-bold text-cyan-400 text-sm">
                {spotPrice.toFixed(1)}
              </div>
            </div>
          </div>

          <p className="mt-3 text-[11px] text-slate-400 bg-slate-900/80 p-2.5 rounded-lg border border-slate-800/80">
            {maxPain.distanceFromSpot > 100
              ? `Max Pain is above current market price. Option sellers expect spot to gravitate upwards toward ${maxPain.maxPainStrike} by expiry.`
              : maxPain.distanceFromSpot < -100
              ? `Max Pain is below spot. Option sellers expect spot to drift down toward ${maxPain.maxPainStrike} to minimize total option buyer payouts.`
              : `Spot is oscillating very close to Max Pain strike (${maxPain.maxPainStrike}). Expect high gamma theta decay.`}
          </p>
        </div>

        {/* Card 2: PCR (Put Call Ratio) */}
        <div className="bg-[#0f1422] border border-slate-800 rounded-xl p-4 shadow-lg relative overflow-hidden">
          <div className="flex items-center justify-between">
            <span className="text-slate-400 font-semibold uppercase tracking-wider text-[11px] flex items-center space-x-1.5">
              <TrendingUp className="w-3.5 h-3.5 text-cyan-400" />
              <span>Put Call Ratio (PCR)</span>
            </span>
            <span
              className={`text-[10px] px-2 py-0.5 rounded font-bold uppercase ${
                pcr.sentiment.includes('BULLISH')
                  ? 'bg-emerald-950 border border-emerald-700 text-emerald-300'
                  : pcr.sentiment.includes('BEARISH')
                  ? 'bg-rose-950 border border-rose-700 text-rose-300'
                  : 'bg-amber-950 border border-amber-700 text-amber-300'
              }`}
            >
              {pcr.sentiment.replace('_', ' ')}
            </span>
          </div>

          <div className="mt-3 flex items-baseline justify-between">
            <div>
              <div className="text-3xl font-extrabold font-mono-num text-white">
                {pcr.pcrOi}
              </div>
              <div className="text-slate-400 text-[11px] mt-0.5">
                OI PCR | Volume PCR: <span className="text-cyan-400 font-mono-num font-semibold">{pcr.pcrVol}</span>
              </div>
            </div>
            <div className="text-right text-[11px]">
              <div className="text-slate-400">Total PE OI / CE OI</div>
              <div className="font-mono-num text-xs text-slate-300">
                {(pcr.totalPeOi / 1000000).toFixed(2)}M / {(pcr.totalCeOi / 1000000).toFixed(2)}M
              </div>
            </div>
          </div>

          {/* Visual PCR Gauge Slider */}
          <div className="mt-3">
            <div className="flex justify-between text-[10px] text-slate-500 mb-1">
              <span>0.5 (Oversold)</span>
              <span>1.0 (Neutral)</span>
              <span>1.5+ (Overbought)</span>
            </div>
            <div className="w-full h-2.5 bg-slate-900 rounded-full overflow-hidden flex border border-slate-800 relative">
              <div className="w-1/3 bg-rose-500/60" />
              <div className="w-1/3 bg-amber-500/60" />
              <div className="w-1/3 bg-emerald-500/60" />
              {/* Pointer indicator */}
              <div
                className="absolute top-0 bottom-0 w-1.5 bg-white shadow-lg transition-all rounded"
                style={{
                  left: `${Math.min(95, Math.max(5, ((pcr.pcrOi - 0.4) / 1.2) * 100))}%`,
                }}
              />
            </div>
          </div>

          <p className="mt-2 text-[11px] text-slate-400 truncate" title={pcr.summary}>
            {pcr.summary}
          </p>
        </div>

        {/* Card 3: Support & Resistance */}
        <div className="bg-[#0f1422] border border-slate-800 rounded-xl p-4 shadow-lg">
          <div className="flex items-center justify-between">
            <span className="text-slate-400 font-semibold uppercase tracking-wider text-[11px] flex items-center space-x-1.5">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
              <span>Key Support & Resistance</span>
            </span>
            <span className="text-slate-500 text-[10px] font-mono-num">
              Based on OI Depth
            </span>
          </div>

          <div className="mt-3 grid grid-cols-2 gap-3">
            {/* Resistances (Call writing) */}
            <div className="bg-rose-950/20 border border-rose-900/40 rounded-lg p-2.5 space-y-1.5">
              <div className="text-rose-400 font-bold text-[11px] flex items-center space-x-1">
                <span>Resistance (Ceilings)</span>
              </div>
              {srLevels.resistances.map((r) => (
                <div key={r.label} className="flex justify-between items-center text-[11px]">
                  <span className="font-bold text-slate-200">{r.label}: {r.strike}</span>
                  <span className="text-slate-400 font-mono-num text-[10px]">
                    {(r.oi / currentIndex.lotSize / 1000).toFixed(0)}k L
                  </span>
                </div>
              ))}
            </div>

            {/* Supports (Put writing) */}
            <div className="bg-emerald-950/20 border border-emerald-900/40 rounded-lg p-2.5 space-y-1.5">
              <div className="text-emerald-400 font-bold text-[11px] flex items-center space-x-1">
                <span>Support (Floors)</span>
              </div>
              {srLevels.supports.map((s) => (
                <div key={s.label} className="flex justify-between items-center text-[11px]">
                  <span className="font-bold text-slate-200">{s.label}: {s.strike}</span>
                  <span className="text-slate-400 font-mono-num text-[10px]">
                    {(s.oi / currentIndex.lotSize / 1000).toFixed(0)}k L
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Row 2: OI Distribution Bar Chart (Call OI vs Put OI at each Strike) */}
      <div className="bg-[#0f1422] border border-slate-800 rounded-xl p-4 shadow-lg">
        <div className="flex flex-wrap items-center justify-between pb-3 border-b border-slate-800 gap-2">
          <div>
            <h3 className="text-sm font-bold text-white flex items-center space-x-2">
              <BarChart className="w-4 h-4 text-cyan-400" />
              <span>Multi-Strike Open Interest Profile</span>
            </h3>
            <p className="text-[11px] text-slate-400">
              Side-by-side comparison of Call OI (Green) vs Put OI (Red) across strikes
            </p>
          </div>

          <div className="flex items-center space-x-2">
            <div className="flex items-center space-x-2 text-[11px] bg-slate-900 border border-slate-800 p-1 rounded-md">
              <button
                onClick={() => setSelectedMetric('OI')}
                className={`px-2.5 py-0.5 rounded transition-colors ${
                  selectedMetric === 'OI' ? 'bg-cyan-600 text-white font-semibold' : 'text-slate-400'
                }`}
              >
                Total OI
              </button>
              <button
                onClick={() => setSelectedMetric('CHANGE_OI')}
                className={`px-2.5 py-0.5 rounded transition-colors ${
                  selectedMetric === 'CHANGE_OI' ? 'bg-cyan-600 text-white font-semibold' : 'text-slate-400'
                }`}
              >
                Change in OI
              </button>
            </div>
          </div>
        </div>

        {/* Visual Bar Chart */}
        <div className="mt-4 space-y-2">
          {displayStrikes.map((r) => {
            const isAtm = r.strike === atmStrike;
            const isMaxPain = r.strike === maxPain.maxPainStrike;

            const callVal = selectedMetric === 'OI' ? r.call.oi : Math.abs(r.call.changeOi);
            const putVal = selectedMetric === 'OI' ? r.put.oi : Math.abs(r.put.changeOi);

            const callWidth = Math.min(100, Math.round((callVal / maxSubsetOi) * 100));
            const putWidth = Math.min(100, Math.round((putVal / maxSubsetOi) * 100));

            return (
              <div
                key={r.strike}
                className={`flex items-center text-[11px] py-1 px-2 rounded ${
                  isAtm ? 'bg-cyan-950/40 border border-cyan-500/50' : 'hover:bg-slate-900/60'
                }`}
              >
                {/* Left side: Call OI Bar (aligned right towards strike) */}
                <div className="w-5/12 flex items-center justify-end space-x-2">
                  <span className="font-mono-num text-[10px] text-emerald-400">
                    {(callVal / currentIndex.lotSize / 1000).toFixed(1)}k
                  </span>
                  <div className="w-full bg-slate-900 h-4 rounded overflow-hidden flex justify-end">
                    <div
                      className="bg-emerald-500 h-full rounded-l transition-all"
                      style={{ width: `${callWidth}%` }}
                    />
                  </div>
                </div>

                {/* Center: Strike badge */}
                <div className="w-2/12 flex items-center justify-center space-x-1 font-bold font-mono-num text-xs">
                  <span className={isAtm ? 'text-cyan-300 font-extrabold' : 'text-slate-200'}>
                    {r.strike}
                  </span>
                  {isAtm && (
                    <span className="bg-cyan-500 text-slate-950 text-[8px] px-1 rounded font-bold">
                      ATM
                    </span>
                  )}
                  {isMaxPain && (
                    <span className="bg-purple-600 text-white text-[8px] px-1 rounded font-bold">
                      MP
                    </span>
                  )}
                </div>

                {/* Right side: Put OI Bar (aligned left away from strike) */}
                <div className="w-5/12 flex items-center justify-start space-x-2">
                  <div className="w-full bg-slate-900 h-4 rounded overflow-hidden flex justify-start">
                    <div
                      className="bg-rose-500 h-full rounded-r transition-all"
                      style={{ width: `${putWidth}%` }}
                    />
                  </div>
                  <span className="font-mono-num text-[10px] text-rose-400">
                    {(putVal / currentIndex.lotSize / 1000).toFixed(1)}k
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Row 3: OI Buildup Breakdown */}
      <div className="bg-[#0f1422] border border-slate-800 rounded-xl p-4 shadow-lg">
        <h3 className="text-sm font-bold text-white mb-1 flex items-center space-x-2">
          <Layers className="w-4 h-4 text-cyan-400" />
          <span>Open Interest Buildup Classification</span>
        </h3>
        <p className="text-[11px] text-slate-400 mb-4">
          Market participant positioning derived from continuous price and OI co-movement
        </p>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          {/* Long Buildup */}
          <div className="bg-emerald-950/20 border border-emerald-800/40 rounded-lg p-3">
            <div className="flex items-center justify-between">
              <span className="font-bold text-emerald-400">L. Buildup</span>
              <ArrowUpCircle className="w-4 h-4 text-emerald-400" />
            </div>
            <div className="text-[10px] text-slate-400 mt-1">Price ↑ & OI ↑ (Bullish Aggression)</div>
            <div className="text-lg font-mono-num font-bold text-slate-100 mt-2">
              {(longBuildup / currentIndex.lotSize).toLocaleString('en-IN')} Lots
            </div>
            <div className="text-[10px] text-emerald-400 font-semibold mt-0.5">
              {((longBuildup / currentIndex.lotSize / totalBuildupLots) * 100).toFixed(1)}% of total buildup
            </div>
          </div>

          {/* Short Buildup */}
          <div className="bg-rose-950/20 border border-rose-800/40 rounded-lg p-3">
            <div className="flex items-center justify-between">
              <span className="font-bold text-rose-400">S. Buildup</span>
              <ArrowDownCircle className="w-4 h-4 text-rose-400" />
            </div>
            <div className="text-[10px] text-slate-400 mt-1">Price ↓ & OI ↑ (Bearish Shorting)</div>
            <div className="text-lg font-mono-num font-bold text-slate-100 mt-2">
              {(shortBuildup / currentIndex.lotSize).toLocaleString('en-IN')} Lots
            </div>
            <div className="text-[10px] text-rose-400 font-semibold mt-0.5">
              {((shortBuildup / currentIndex.lotSize / totalBuildupLots) * 100).toFixed(1)}% of total buildup
            </div>
          </div>

          {/* Short Covering */}
          <div className="bg-cyan-950/20 border border-cyan-800/40 rounded-lg p-3">
            <div className="flex items-center justify-between">
              <span className="font-bold text-cyan-400">S. Covering</span>
              <TrendingUp className="w-4 h-4 text-cyan-400" />
            </div>
            <div className="text-[10px] text-slate-400 mt-1">Price ↑ & OI ↓ (Bear Panic / Squeeze)</div>
            <div className="text-lg font-mono-num font-bold text-slate-100 mt-2">
              {(shortCovering / currentIndex.lotSize).toLocaleString('en-IN')} Lots
            </div>
            <div className="text-[10px] text-cyan-400 font-semibold mt-0.5">
              {((shortCovering / currentIndex.lotSize / totalBuildupLots) * 100).toFixed(1)}% of total buildup
            </div>
          </div>

          {/* Long Unwinding */}
          <div className="bg-amber-950/20 border border-amber-800/40 rounded-lg p-3">
            <div className="flex items-center justify-between">
              <span className="font-bold text-amber-400">L. Unwinding</span>
              <TrendingDown className="w-4 h-4 text-amber-400" />
            </div>
            <div className="text-[10px] text-slate-400 mt-1">Price ↓ & OI ↓ (Bull Profit Booking)</div>
            <div className="text-lg font-mono-num font-bold text-slate-100 mt-2">
              {(longUnwinding / currentIndex.lotSize).toLocaleString('en-IN')} Lots
            </div>
            <div className="text-[10px] text-amber-400 font-semibold mt-0.5">
              {((longUnwinding / currentIndex.lotSize / totalBuildupLots) * 100).toFixed(1)}% of total buildup
            </div>
          </div>
        </div>
      </div>

      {/* Row 4: Max Pain Strike Loss Curve */}
      <div className="bg-[#0f1422] border border-slate-800 rounded-xl p-4 shadow-lg">
        <div className="flex items-center justify-between mb-3">
          <div>
            <h3 className="text-sm font-bold text-white flex items-center space-x-2">
              <Activity className="w-4 h-4 text-purple-400" />
              <span>Max Pain Payoff Distribution Curve</span>
            </h3>
            <p className="text-[11px] text-slate-400">
              Total financial liability of option writers across all candidate settlement strikes
            </p>
          </div>
          <div className="text-right">
            <span className="text-[11px] text-purple-400 font-bold bg-purple-950/80 px-2 py-0.5 rounded border border-purple-800">
              Minimum Pain: {maxPain.maxPainStrike}
            </span>
          </div>
        </div>

        {/* SVG Curve for Max Pain */}
        <div className="w-full h-48 bg-slate-900/80 rounded-lg p-2 border border-slate-800 relative">
          <svg className="w-full h-full" viewBox="0 0 800 200" preserveAspectRatio="none">
            {/* Grid lines */}
            <line x1="0" y1="50" x2="800" y2="50" stroke="#1e293b" strokeDasharray="3 3" />
            <line x1="0" y1="100" x2="800" y2="100" stroke="#1e293b" strokeDasharray="3 3" />
            <line x1="0" y1="150" x2="800" y2="150" stroke="#1e293b" strokeDasharray="3 3" />

            {/* Compute SVG Path */}
            {(() => {
              if (!maxPain.strikeLosses.length) return null;
              const maxL = Math.max(...maxPain.strikeLosses.map((x) => x.totalLoss)) || 1;
              const minL = Math.min(...maxPain.strikeLosses.map((x) => x.totalLoss)) || 0;
              const n = maxPain.strikeLosses.length;
              const denom = n > 1 ? n - 1 : 1;
              const lossRange = (maxL - minL) || 1;

              const points = maxPain.strikeLosses.map((item, idx) => {
                const rawX = (idx / denom) * 760 + 20;
                const rawY = 180 - ((item.totalLoss - minL) / lossRange) * 150;
                const x = Number.isFinite(rawX) ? rawX : 400;
                const y = Number.isFinite(rawY) ? rawY : 100;
                return { x, y, strike: item.strike, loss: item.totalLoss };
              });

              const d = points.reduce((acc, p, i) => `${acc} ${i === 0 ? 'M' : 'L'} ${p.x} ${p.y}`, '');
              const minPoint = points.find((p) => p.strike === maxPain.maxPainStrike) || points[0];

              return (
                <>
                  <path d={d} fill="none" stroke="#a855f7" strokeWidth="2.5" />
                  {/* Minimum pain marker */}
                  <circle cx={minPoint.x} cy={minPoint.y} r="5" fill="#f43f5e" stroke="#ffffff" strokeWidth="2" />
                  <text
                    x={minPoint.x}
                    y={minPoint.y - 12}
                    textAnchor="middle"
                    fill="#e2e8f0"
                    fontSize="11"
                    fontFamily="monospace"
                    fontWeight="bold"
                  >
                    Max Pain: {minPoint.strike}
                  </text>
                </>
              );
            })()}
          </svg>
        </div>
      </div>
    </div>
  );
};
