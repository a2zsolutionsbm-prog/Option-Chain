import React, { useState, useMemo } from 'react';
import {
  Calendar as CalendarIcon,
  ChevronDown,
  Filter,
  Info,
  X,
  Search,
  ExternalLink,
  Clock,
  Globe,
  TrendingUp,
  AlertCircle,
  Building2,
  CalendarDays,
} from 'lucide-react';
import {
  EconomicEvent,
  StockResultEvent,
  HolidayEvent,
  INITIAL_ECONOMIC_EVENTS,
  INITIAL_STOCK_RESULTS,
  INITIAL_HOLIDAYS,
} from '../../services/calendarData';

type CalendarSubTab = 'economic' | 'results' | 'holiday';

export const CalendarDashboard: React.FC = () => {
  const [subTab, setSubTab] = useState<CalendarSubTab>('economic');

  // Filter states
  const [selectedCountry, setSelectedCountry] = useState<string>('All');
  const [countryDropdownOpen, setCountryDropdownOpen] = useState<boolean>(false);

  const [selectedImpact, setSelectedImpact] = useState<string>('All');
  const [impactDropdownOpen, setImpactDropdownOpen] = useState<boolean>(false);

  const [dateRangePreset, setDateRangePreset] = useState<string>('25 Sep to 12 Oct');
  const [dateDropdownOpen, setDateDropdownOpen] = useState<boolean>(false);

  const [searchQuery, setSearchQuery] = useState<string>('');

  // Selected item modal for "View Details"
  const [selectedEvent, setSelectedEvent] = useState<EconomicEvent | null>(null);
  const [selectedResult, setSelectedResult] = useState<StockResultEvent | null>(null);
  const [selectedHoliday, setSelectedHoliday] = useState<HolidayEvent | null>(null);

  // Available countries
  const countries = ['All', 'India', 'USA', 'China', 'Eurozone'];
  const impacts = ['All', 'High', 'Medium', 'Low'];
  const datePresets = [
    '25 Sep to 12 Oct',
    'Today Only',
    'This Week (Sep 28 - Oct 04)',
    'Next Week (Oct 05 - Oct 11)',
    'Full Month (Oct 2026)',
    'All Dates',
  ];

  // Filtered Economic Events
  const filteredEconomicEvents = useMemo(() => {
    return INITIAL_ECONOMIC_EVENTS.filter((item) => {
      // Country filter
      if (selectedCountry !== 'All' && item.country !== selectedCountry) {
        return false;
      }
      // Impact filter
      if (selectedImpact !== 'All' && item.impact !== selectedImpact) {
        return false;
      }
      // Search query
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        return (
          item.event.toLowerCase().includes(q) ||
          item.country.toLowerCase().includes(q) ||
          item.category.toLowerCase().includes(q)
        );
      }
      return true;
    });
  }, [selectedCountry, selectedImpact, searchQuery]);

  // Filtered Results
  const filteredResults = useMemo(() => {
    return INITIAL_STOCK_RESULTS.filter((item) => {
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        return (
          item.company.toLowerCase().includes(q) ||
          item.symbol.toLowerCase().includes(q) ||
          item.sector.toLowerCase().includes(q)
        );
      }
      return true;
    });
  }, [searchQuery]);

  // Filtered Holidays
  const filteredHolidays = useMemo(() => {
    return INITIAL_HOLIDAYS.filter((item) => {
      // Country Filter
      if (selectedCountry !== 'All') {
        if (selectedCountry === 'India' && item.country !== 'India' && !item.country.includes('India')) return false;
        if (selectedCountry === 'USA' && item.country !== 'USA' && !item.country.includes('USA') && item.countryCode !== 'GLOBAL') return false;
      }

      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        return (
          item.holiday.toLowerCase().includes(q) ||
          item.day.toLowerCase().includes(q) ||
          item.country.toLowerCase().includes(q) ||
          item.exchanges.join(' ').toLowerCase().includes(q)
        );
      }
      return true;
    });
  }, [selectedCountry, searchQuery]);

  return (
    <div className="flex-1 overflow-y-auto bg-slate-900/60 p-3 sm:p-5">
      {/* Outer Card Container styled cleanly like the reference image */}
      <div className="bg-[#0e1420] border border-slate-800 rounded-xl shadow-2xl overflow-hidden">
        
        {/* Top Header / Sub Tab Pill Switcher (Matches exactly the 3 tabs in the screenshot) */}
        <div className="p-4 sm:p-5 border-b border-slate-800/80 bg-[#0a0f19]">
          <div className="inline-flex items-center gap-1.5 p-1 bg-slate-800/80 border border-slate-700/80 rounded-lg">
            <button
              onClick={() => {
                setSubTab('economic');
                setSearchQuery('');
              }}
              className={`px-4 py-2 text-xs sm:text-sm font-semibold rounded-md transition-all ${
                subTab === 'economic'
                  ? 'bg-blue-600 text-white shadow-md shadow-blue-600/30'
                  : 'text-slate-300 hover:text-white hover:bg-slate-700/50'
              }`}
            >
              Economic Calendar
            </button>
            <button
              onClick={() => {
                setSubTab('results');
                setSearchQuery('');
              }}
              className={`px-4 py-2 text-xs sm:text-sm font-semibold rounded-md transition-all ${
                subTab === 'results'
                  ? 'bg-blue-600 text-white shadow-md shadow-blue-600/30'
                  : 'text-slate-300 hover:text-white hover:bg-slate-700/50'
              }`}
            >
              Stock Results Calendar
            </button>
            <button
              onClick={() => {
                setSubTab('holiday');
                setSearchQuery('');
              }}
              className={`px-4 py-2 text-xs sm:text-sm font-semibold rounded-md transition-all ${
                subTab === 'holiday'
                  ? 'bg-blue-600 text-white shadow-md shadow-blue-600/30'
                  : 'text-slate-300 hover:text-white hover:bg-slate-700/50'
              }`}
            >
              Holiday Calendar
            </button>
          </div>
        </div>

        {/* Filters Row (Matches exactly the screenshot: Filters label, Country dropdown, Impact dropdown, Date range selector) */}
        <div className="px-4 py-3.5 border-b border-slate-800/80 bg-[#0d1320] flex flex-wrap items-center gap-3">
          <div className="flex items-center gap-2 text-slate-300 font-semibold text-xs sm:text-sm mr-1">
            <Filter className="w-4 h-4 text-blue-400" />
            <span>Filters</span>
          </div>

          {/* Country Dropdown */}
          {(subTab === 'economic' || subTab === 'holiday') && (
            <div className="relative">
              <button
                onClick={() => {
                  setCountryDropdownOpen(!countryDropdownOpen);
                  setImpactDropdownOpen(false);
                  setDateDropdownOpen(false);
                }}
                className="flex items-center justify-between gap-2 px-3.5 py-1.5 bg-[#141c2c] border border-slate-700 hover:border-slate-500 rounded-lg text-xs font-medium text-slate-200 transition-colors min-w-[120px]"
              >
                <span>{selectedCountry === 'All' ? 'Country' : selectedCountry}</span>
                <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
              </button>

              {countryDropdownOpen && (
                <div className="absolute left-0 mt-1 w-44 bg-[#162032] border border-slate-700 rounded-lg shadow-xl z-30 py-1 text-xs">
                  {(subTab === 'holiday' ? ['All', 'India', 'USA'] : countries).map((c) => (
                    <button
                      key={c}
                      onClick={() => {
                        setSelectedCountry(c);
                        setCountryDropdownOpen(false);
                      }}
                      className={`w-full text-left px-3 py-1.5 hover:bg-slate-700/60 transition-colors flex items-center gap-2 ${
                        selectedCountry === c ? 'text-blue-400 font-semibold bg-blue-500/10' : 'text-slate-300'
                      }`}
                    >
                      <span>
                        {c === 'India' ? '🇮🇳' : c === 'USA' ? '🇺🇸' : c === 'China' ? '🇨🇳' : c === 'Eurozone' ? '🇪🇺' : '🌐'}
                      </span>
                      <span>{c === 'All' ? 'All Countries' : c}</span>
                    </button>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* Impact Dropdown */}
          {subTab === 'economic' && (
            <div className="relative">
              <button
                onClick={() => {
                  setImpactDropdownOpen(!impactDropdownOpen);
                  setCountryDropdownOpen(false);
                  setDateDropdownOpen(false);
                }}
                className="flex items-center justify-between gap-2 px-3.5 py-1.5 bg-[#141c2c] border border-slate-700 hover:border-slate-500 rounded-lg text-xs font-medium text-slate-200 transition-colors min-w-[110px]"
              >
                <span>{selectedImpact === 'All' ? 'Impact' : `${selectedImpact} Impact`}</span>
                <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
              </button>

              {impactDropdownOpen && (
                <div className="absolute left-0 mt-1 w-36 bg-[#162032] border border-slate-700 rounded-lg shadow-xl z-30 py-1 text-xs">
                  {impacts.map((imp) => (
                    <button
                      key={imp}
                      onClick={() => {
                        setSelectedImpact(imp);
                        setImpactDropdownOpen(false);
                      }}
                      className={`w-full text-left px-3 py-1.5 hover:bg-slate-700/60 transition-colors ${
                        selectedImpact === imp ? 'text-blue-400 font-semibold bg-blue-500/10' : 'text-slate-300'
                      }`}
                    >
                      {imp}
                    </button>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* Date Range Selector Button with Calendar Icon (Matches "25 Sep to 12 Oct" in screenshot) */}
          <div className="relative">
            <button
              onClick={() => {
                setDateDropdownOpen(!dateDropdownOpen);
                setCountryDropdownOpen(false);
                setImpactDropdownOpen(false);
              }}
              className="flex items-center gap-2 px-3.5 py-1.5 bg-[#141c2c] border border-slate-700 hover:border-slate-500 rounded-lg text-xs font-medium text-slate-200 transition-colors"
            >
              <CalendarIcon className="w-3.5 h-3.5 text-slate-400" />
              <span>{dateRangePreset}</span>
              <ChevronDown className="w-3 h-3 text-slate-400 ml-1" />
            </button>

            {dateDropdownOpen && (
              <div className="absolute left-0 mt-1 w-56 bg-[#162032] border border-slate-700 rounded-lg shadow-xl z-30 py-1 text-xs">
                {datePresets.map((preset) => (
                  <button
                    key={preset}
                    onClick={() => {
                      setDateRangePreset(preset);
                      setDateDropdownOpen(false);
                    }}
                    className={`w-full text-left px-3 py-1.5 hover:bg-slate-700/60 transition-colors ${
                      dateRangePreset === preset ? 'text-blue-400 font-semibold bg-blue-500/10' : 'text-slate-300'
                    }`}
                  >
                    {preset}
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Quick Search */}
          <div className="relative ml-auto min-w-[200px]">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search event, company, or date..."
              className="w-full bg-[#141c2c] border border-slate-700 focus:border-blue-500 rounded-lg pl-8 pr-3 py-1.5 text-xs text-slate-200 placeholder-slate-500 focus:outline-none transition-colors"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {/* Reset Filters button if any filter is active */}
          {(selectedCountry !== 'All' || selectedImpact !== 'All' || searchQuery !== '') && (
            <button
              onClick={() => {
                setSelectedCountry('All');
                setSelectedImpact('All');
                setSearchQuery('');
              }}
              className="text-xs text-slate-400 hover:text-blue-400 transition-colors underline"
            >
              Reset
            </button>
          )}
        </div>

        {/* Content Section: 1. Economic Calendar */}
        {subTab === 'economic' && (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="bg-[#101726] border-b border-slate-800 text-slate-400 font-medium select-none">
                  <th className="py-3 px-4 w-[180px]">Date</th>
                  <th className="py-3 px-4 w-[140px]">Country</th>
                  <th className="py-3 px-4 min-w-[260px]">Event</th>
                  <th className="py-3 px-4 w-[110px] text-center">Impact</th>
                  <th className="py-3 px-4 w-[110px] text-center">Expected</th>
                  <th className="py-3 px-4 w-[110px] text-center">Actual</th>
                  <th className="py-3 px-4 w-[110px] text-center">Previous</th>
                  <th className="py-3 px-4 w-[110px] text-right">More</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {filteredEconomicEvents.length === 0 ? (
                  <tr>
                    <td colSpan={8} className="py-12 text-center text-slate-500">
                      No economic events matching current filters.
                    </td>
                  </tr>
                ) : (
                  filteredEconomicEvents.map((evt) => {
                    // Badge styling matching the pastel tones in screenshot
                    const impactBadge =
                      evt.impact === 'High' ? (
                        <span className="inline-block px-2.5 py-0.5 rounded text-[11px] font-medium bg-[#fee2e2] text-[#dc2626] dark:bg-rose-950/60 dark:text-rose-300 dark:border dark:border-rose-800/40">
                          High
                        </span>
                      ) : evt.impact === 'Medium' ? (
                        <span className="inline-block px-2.5 py-0.5 rounded text-[11px] font-medium bg-[#ffedd5] text-[#c2410c] dark:bg-amber-950/60 dark:text-amber-300 dark:border dark:border-amber-800/40">
                          Medium
                        </span>
                      ) : (
                        <span className="inline-block px-2.5 py-0.5 rounded text-[11px] font-medium bg-[#e0f2fe] text-[#0284c7] dark:bg-sky-950/60 dark:text-sky-300 dark:border dark:border-sky-800/40">
                          Low
                        </span>
                      );

                    return (
                      <tr
                        key={evt.id}
                        className="hover:bg-slate-800/40 transition-colors group"
                      >
                        {/* Date */}
                        <td className="py-3.5 px-4 font-mono-num text-slate-300 whitespace-nowrap">
                          {evt.date}
                        </td>

                        {/* Country */}
                        <td className="py-3.5 px-4">
                          <div className="flex items-center gap-2">
                            <span className="text-base select-none">{evt.flag}</span>
                            <span className="text-slate-200 font-medium">{evt.country}</span>
                          </div>
                        </td>

                        {/* Event */}
                        <td className="py-3.5 px-4 text-slate-200 font-medium">
                          {evt.event}
                        </td>

                        {/* Impact */}
                        <td className="py-3.5 px-4 text-center">
                          {impactBadge}
                        </td>

                        {/* Expected */}
                        <td className="py-3.5 px-4 text-center font-mono-num text-slate-400">
                          {evt.expected}
                        </td>

                        {/* Actual */}
                        <td className="py-3.5 px-4 text-center font-mono-num text-slate-400">
                          {evt.actual}
                        </td>

                        {/* Previous */}
                        <td className="py-3.5 px-4 text-center font-mono-num text-slate-300">
                          {evt.previous}
                        </td>

                        {/* More / View Details link */}
                        <td className="py-3.5 px-4 text-right">
                          <button
                            onClick={() => setSelectedEvent(evt)}
                            className="text-blue-500 hover:text-blue-400 font-semibold hover:underline transition-colors"
                          >
                            View Details
                          </button>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        )}

        {/* Content Section: 2. Stock Results Calendar */}
        {subTab === 'results' && (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="bg-[#101726] border-b border-slate-800 text-slate-400 font-medium select-none">
                  <th className="py-3 px-4 w-[160px]">Result Date</th>
                  <th className="py-3 px-4 w-[130px]">Timing</th>
                  <th className="py-3 px-4 min-w-[200px]">Company & Symbol</th>
                  <th className="py-3 px-4 w-[150px]">Sector</th>
                  <th className="py-3 px-4 w-[110px] text-center">Nifty Weight</th>
                  <th className="py-3 px-4 w-[110px] text-center">Est. EPS</th>
                  <th className="py-3 px-4 w-[120px] text-center">Est. Revenue</th>
                  <th className="py-3 px-4 w-[110px] text-right">More</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {filteredResults.length === 0 ? (
                  <tr>
                    <td colSpan={8} className="py-12 text-center text-slate-500">
                      No stock earnings events matching current filters.
                    </td>
                  </tr>
                ) : (
                  filteredResults.map((item) => (
                    <tr
                      key={item.id}
                      className="hover:bg-slate-800/40 transition-colors group"
                    >
                      <td className="py-3.5 px-4 font-mono-num text-slate-300 whitespace-nowrap">
                        {item.date}
                      </td>
                      <td className="py-3.5 px-4">
                        <span className="inline-block px-2 py-0.5 text-[11px] rounded bg-slate-800 text-slate-300 border border-slate-700">
                          {item.timeSlot}
                        </span>
                      </td>
                      <td className="py-3.5 px-4">
                        <div className="flex items-center gap-2">
                          <span className="font-semibold text-cyan-400 font-mono-num">
                            {item.symbol}
                          </span>
                          <span className="text-slate-300">{item.company}</span>
                        </div>
                      </td>
                      <td className="py-3.5 px-4 text-slate-400">{item.sector}</td>
                      <td className="py-3.5 px-4 text-center font-mono-num text-emerald-400 font-semibold">
                        {item.niftyWeight}
                      </td>
                      <td className="py-3.5 px-4 text-center font-mono-num text-slate-200">
                        {item.estEps}
                      </td>
                      <td className="py-3.5 px-4 text-center font-mono-num text-slate-200">
                        {item.estRevenue}
                      </td>
                      <td className="py-3.5 px-4 text-right">
                        <button
                          onClick={() => setSelectedResult(item)}
                          className="text-blue-500 hover:text-blue-400 font-semibold hover:underline transition-colors"
                        >
                          View Details
                        </button>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        )}

        {/* Content Section: 3. Holiday Calendar */}
        {subTab === 'holiday' && (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="bg-[#101726] border-b border-slate-800 text-slate-400 font-medium select-none">
                  <th className="py-3 px-4 w-[140px]">Date</th>
                  <th className="py-3 px-4 w-[110px]">Country</th>
                  <th className="py-3 px-4 w-[100px]">Day</th>
                  <th className="py-3 px-4 min-w-[220px]">Holiday Name</th>
                  <th className="py-3 px-4 w-[140px]">Exchanges</th>
                  <th className="py-3 px-4 w-[140px] text-center">Morning Trading</th>
                  <th className="py-3 px-4 w-[140px] text-center">Evening Trading</th>
                  <th className="py-3 px-4 w-[130px] text-center">Clearing</th>
                  <th className="py-3 px-4 w-[100px] text-right">More</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {filteredHolidays.length === 0 ? (
                  <tr>
                    <td colSpan={9} className="py-12 text-center text-slate-500">
                      No holiday items matching current search or country filter.
                    </td>
                  </tr>
                ) : (
                  filteredHolidays.map((hol) => (
                    <tr
                      key={hol.id}
                      className="hover:bg-slate-800/40 transition-colors group"
                    >
                      <td className="py-3.5 px-4 font-mono-num text-slate-300 whitespace-nowrap">
                        {hol.date}
                      </td>
                      <td className="py-3.5 px-4">
                        <div className="flex items-center gap-1.5 whitespace-nowrap">
                          <span className="text-sm">{hol.flag}</span>
                          <span className="text-slate-300 font-medium">{hol.country}</span>
                        </div>
                      </td>
                      <td className="py-3.5 px-4 text-slate-400">{hol.day}</td>
                      <td className="py-3.5 px-4 font-medium text-slate-200">
                        {hol.holiday}
                      </td>
                      <td className="py-3.5 px-4">
                        <div className="flex flex-wrap gap-1">
                          {hol.exchanges.map((ex) => (
                            <span
                              key={ex}
                              className={`px-1.5 py-0.5 text-[10px] font-semibold rounded border ${
                                ex.includes('NYSE') || ex.includes('NASDAQ') || ex.includes('CBOE') || ex.includes('CME') || ex.includes('SIFMA')
                                  ? 'bg-blue-950/60 text-blue-300 border-blue-800/50'
                                  : 'bg-slate-800 text-slate-300 border-slate-700'
                              }`}
                            >
                              {ex}
                            </span>
                          ))}
                        </div>
                      </td>
                      <td className="py-3.5 px-4 text-center">
                        <span className={`inline-block px-2 py-0.5 rounded text-[11px] font-medium ${
                          hol.tradingMorning.includes('Closed')
                            ? 'bg-rose-950/50 text-rose-300 border border-rose-800/40'
                            : 'bg-emerald-950/50 text-emerald-300 border border-emerald-800/40'
                        }`}>
                          {hol.tradingMorning}
                        </span>
                      </td>
                      <td className="py-3.5 px-4 text-center">
                        <span
                          className={`inline-block px-2 py-0.5 rounded text-[11px] font-medium ${
                            hol.tradingEvening.includes('Open')
                              ? 'bg-emerald-950/50 text-emerald-300 border border-emerald-800/40'
                              : hol.tradingEvening.includes('Muhurat')
                              ? 'bg-amber-950/50 text-amber-300 border border-amber-800/40 font-semibold'
                              : hol.tradingEvening.includes('Early Close')
                              ? 'bg-amber-950/40 text-amber-300 border border-amber-800/40'
                              : hol.tradingEvening.includes('Regular')
                              ? 'bg-emerald-950/50 text-emerald-300 border border-emerald-800/40'
                              : 'bg-rose-950/50 text-rose-300 border border-rose-800/40'
                          }`}
                        >
                          {hol.tradingEvening}
                        </span>
                      </td>
                      <td className="py-3.5 px-4 text-center">
                        <span className={`text-[11px] ${
                          hol.clearingStatus === 'Bond Market Closed'
                            ? 'text-amber-400 font-medium'
                            : 'text-slate-400'
                        }`}>
                          {hol.clearingStatus}
                        </span>
                      </td>
                      <td className="py-3.5 px-4 text-right">
                        <button
                          onClick={() => setSelectedHoliday(hol)}
                          className="text-blue-500 hover:text-blue-400 font-semibold hover:underline transition-colors"
                        >
                          View Details
                        </button>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        )}

        {/* Footer info strip */}
        <div className="p-3 bg-[#0a0f19] border-t border-slate-800 flex items-center justify-between text-[11px] text-slate-400">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <span>Economic & Corporate Events synchronized with Global Central Banks and Exchange Notifications</span>
          </div>
          <div>All Times in IST (Indian Standard Time, UTC+5:30)</div>
        </div>
      </div>

      {/* MODAL 1: Economic Event Detail Modal */}
      {selectedEvent && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#111726] border border-slate-700 rounded-xl max-w-xl w-full overflow-hidden shadow-2xl animate-in fade-in duration-150">
            <div className="p-4 border-b border-slate-700 flex items-center justify-between bg-[#0d1320]">
              <div className="flex items-center gap-2">
                <span className="text-2xl">{selectedEvent.flag}</span>
                <div>
                  <h3 className="font-semibold text-slate-100 text-sm sm:text-base">
                    {selectedEvent.event}
                  </h3>
                  <div className="text-xs text-slate-400 font-mono-num">
                    {selectedEvent.country} • {selectedEvent.date}
                  </div>
                </div>
              </div>
              <button
                onClick={() => setSelectedEvent(null)}
                className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-5 space-y-4 text-xs sm:text-sm">
              <div className="grid grid-cols-3 gap-3">
                <div className="p-3 bg-slate-800/60 rounded-lg border border-slate-700/60 text-center">
                  <div className="text-slate-400 text-xs">Expected</div>
                  <div className="font-mono-num font-semibold text-slate-200 mt-1">
                    {selectedEvent.expected}
                  </div>
                </div>
                <div className="p-3 bg-slate-800/60 rounded-lg border border-slate-700/60 text-center">
                  <div className="text-slate-400 text-xs">Actual</div>
                  <div className="font-mono-num font-semibold text-blue-400 mt-1">
                    {selectedEvent.actual}
                  </div>
                </div>
                <div className="p-3 bg-slate-800/60 rounded-lg border border-slate-700/60 text-center">
                  <div className="text-slate-400 text-xs">Previous</div>
                  <div className="font-mono-num font-semibold text-slate-300 mt-1">
                    {selectedEvent.previous}
                  </div>
                </div>
              </div>

              <div>
                <h4 className="font-semibold text-slate-300 mb-1 flex items-center gap-1.5">
                  <Info className="w-4 h-4 text-blue-400" />
                  Event Overview
                </h4>
                <p className="text-slate-300 leading-relaxed bg-slate-800/40 p-3 rounded-lg border border-slate-800">
                  {selectedEvent.description}
                </p>
              </div>

              <div>
                <h4 className="font-semibold text-slate-300 mb-1 flex items-center gap-1.5">
                  <TrendingUp className="w-4 h-4 text-emerald-400" />
                  Option Chain & Market Impact
                </h4>
                <p className="text-slate-300 leading-relaxed bg-emerald-950/20 p-3 rounded-lg border border-emerald-800/30 text-emerald-200">
                  {selectedEvent.marketImpact}
                </p>
              </div>
            </div>

            <div className="p-3 bg-[#0d1320] border-t border-slate-700 flex justify-end">
              <button
                onClick={() => setSelectedEvent(null)}
                className="px-4 py-1.5 bg-blue-600 hover:bg-blue-500 text-white rounded-lg text-xs font-semibold"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL 2: Stock Result Detail Modal */}
      {selectedResult && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#111726] border border-slate-700 rounded-xl max-w-xl w-full overflow-hidden shadow-2xl animate-in fade-in duration-150">
            <div className="p-4 border-b border-slate-700 flex items-center justify-between bg-[#0d1320]">
              <div className="flex items-center gap-2">
                <Building2 className="w-6 h-6 text-cyan-400" />
                <div>
                  <h3 className="font-semibold text-slate-100 text-sm sm:text-base">
                    {selectedResult.symbol} - {selectedResult.company}
                  </h3>
                  <div className="text-xs text-slate-400">
                    {selectedResult.sector} • Date: {selectedResult.date}
                  </div>
                </div>
              </div>
              <button
                onClick={() => setSelectedResult(null)}
                className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-5 space-y-4 text-xs sm:text-sm">
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                <div className="p-2.5 bg-slate-800/60 rounded border border-slate-700/60">
                  <div className="text-slate-400 text-xs">Est. EPS</div>
                  <div className="font-mono-num font-semibold text-slate-100 mt-0.5">
                    {selectedResult.estEps}
                  </div>
                </div>
                <div className="p-2.5 bg-slate-800/60 rounded border border-slate-700/60">
                  <div className="text-slate-400 text-xs">Est. Revenue</div>
                  <div className="font-mono-num font-semibold text-slate-100 mt-0.5">
                    {selectedResult.estRevenue}
                  </div>
                </div>
                <div className="p-2.5 bg-slate-800/60 rounded border border-slate-700/60">
                  <div className="text-slate-400 text-xs">Nifty Weight</div>
                  <div className="font-mono-num font-semibold text-emerald-400 mt-0.5">
                    {selectedResult.niftyWeight}
                  </div>
                </div>
                <div className="p-2.5 bg-slate-800/60 rounded border border-slate-700/60">
                  <div className="text-slate-400 text-xs">Market Cap</div>
                  <div className="font-mono-num font-semibold text-cyan-400 mt-0.5">
                    {selectedResult.marketCap}
                  </div>
                </div>
              </div>

              <div>
                <h4 className="font-semibold text-slate-300 mb-1 flex items-center gap-1.5">
                  <TrendingUp className="w-4 h-4 text-blue-400" />
                  Derivatives & Volatility Outlook
                </h4>
                <p className="text-slate-300 leading-relaxed bg-slate-800/40 p-3 rounded-lg border border-slate-800">
                  {selectedResult.derivativesOutlook}
                </p>
              </div>
            </div>

            <div className="p-3 bg-[#0d1320] border-t border-slate-700 flex justify-end">
              <button
                onClick={() => setSelectedResult(null)}
                className="px-4 py-1.5 bg-blue-600 hover:bg-blue-500 text-white rounded-lg text-xs font-semibold"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL 3: Holiday Detail Modal */}
      {selectedHoliday && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#111726] border border-slate-700 rounded-xl max-w-lg w-full overflow-hidden shadow-2xl animate-in fade-in duration-150">
            <div className="p-4 border-b border-slate-700 flex items-center justify-between bg-[#0d1320]">
              <div className="flex items-center gap-2">
                <CalendarDays className="w-5 h-5 text-amber-400" />
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-base">{selectedHoliday.flag}</span>
                    <h3 className="font-semibold text-slate-100 text-sm">
                      {selectedHoliday.holiday}
                    </h3>
                  </div>
                  <div className="text-xs text-slate-400 flex items-center gap-2 mt-0.5">
                    <span>{selectedHoliday.country}</span>
                    <span>•</span>
                    <span>{selectedHoliday.date} ({selectedHoliday.day})</span>
                  </div>
                </div>
              </div>
              <button
                onClick={() => setSelectedHoliday(null)}
                className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-5 space-y-3 text-xs sm:text-sm">
              <div className="flex flex-wrap items-center gap-2">
                <span className="text-xs text-slate-400">Impacted Exchanges:</span>
                {selectedHoliday.exchanges.map((ex) => (
                  <span
                    key={ex}
                    className="px-2 py-0.5 text-xs font-semibold rounded bg-slate-800 border border-slate-700 text-cyan-300"
                  >
                    {ex}
                  </span>
                ))}
              </div>
              <p className="text-slate-300 leading-relaxed bg-slate-800/40 p-3 rounded-lg border border-slate-800">
                {selectedHoliday.description}
              </p>
              <div className="grid grid-cols-2 gap-2 text-xs">
                <div className="p-2.5 bg-slate-800/60 rounded border border-slate-700/60">
                  <div className="text-slate-400">Morning Session</div>
                  <div className="font-semibold text-slate-200 mt-0.5">{selectedHoliday.tradingMorning}</div>
                </div>
                <div className="p-2.5 bg-slate-800/60 rounded border border-slate-700/60">
                  <div className="text-slate-400">Evening Session</div>
                  <div className="font-semibold text-slate-200 mt-0.5">{selectedHoliday.tradingEvening}</div>
                </div>
              </div>
              <div className="p-3 bg-amber-950/20 border border-amber-800/30 rounded-lg text-amber-200 text-xs">
                ⚠️ All Equity Cash, Derivatives (Futures & Options), and Currency Derivatives segments will follow the morning & evening schedules indicated above.
              </div>
            </div>

            <div className="p-3 bg-[#0d1320] border-t border-slate-700 flex justify-end">
              <button
                onClick={() => setSelectedHoliday(null)}
                className="px-4 py-1.5 bg-blue-600 hover:bg-blue-500 text-white rounded-lg text-xs font-semibold"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
