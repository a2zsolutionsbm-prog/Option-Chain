import React, { useState } from 'react';
import { IndexMarketData, StrikeRow } from '../../types';
import { Flame, Layers, Sliders } from 'lucide-react';

interface OptionHeatmapProps {
  currentIndex: IndexMarketData;
  strikes: StrikeRow[];
}

export const OptionHeatmap: React.FC<OptionHeatmapProps> = ({
  currentIndex,
  strikes,
}) => {
  const [metric, setMetric] = useState<'OI_CHANGE' | 'VOLUME' | 'DELTA' | 'THETA'>('OI_CHANGE');

  const { spotPrice, strikeStep } = currentIndex;
  const atmStrike = Math.round(spotPrice / strikeStep) * strikeStep;

  // Get max values for normalizations
  let maxOiChange = 1;
  let maxVolume = 1;

  strikes.forEach((r) => {
    if (Math.abs(r.call.changeOi) > maxOiChange) maxOiChange = Math.abs(r.call.changeOi);
    if (Math.abs(r.put.changeOi) > maxOiChange) maxOiChange = Math.abs(r.put.changeOi);
    if (r.call.volume > maxVolume) maxVolume = r.call.volume;
    if (r.put.volume > maxVolume) maxVolume = r.put.volume;
  });

  const getCellColor = (val: number, isCall: boolean) => {
    if (metric === 'OI_CHANGE') {
      const norm = Math.min(1, Math.abs(val) / maxOiChange);
      if (val >= 0) {
        // Green intensity
        return `rgba(16, 185, 129, ${0.15 + norm * 0.75})`;
      } else {
        // Red intensity (unwinding)
        return `rgba(244, 63, 94, ${0.15 + norm * 0.75})`;
      }
    } else if (metric === 'VOLUME') {
      const norm = Math.min(1, val / maxVolume);
      return `rgba(6, 182, 212, ${0.15 + norm * 0.75})`;
    } else if (metric === 'DELTA') {
      const norm = Math.abs(val); // 0 to 1
      return isCall
        ? `rgba(16, 185, 129, ${0.1 + norm * 0.8})`
        : `rgba(244, 63, 94, ${0.1 + norm * 0.8})`;
    } else {
      // THETA
      const norm = Math.min(1, Math.abs(val) / 40);
      return `rgba(245, 158, 11, ${0.15 + norm * 0.8})`;
    }
  };

  return (
    <div className="p-4 space-y-4 bg-[#0a0e17] overflow-y-auto text-slate-200 text-xs">
      {/* Heatmap Control Header */}
      <div className="flex flex-wrap items-center justify-between bg-[#0f1422] border border-slate-800 rounded-xl p-3.5 gap-2 shadow-lg">
        <div>
          <h3 className="text-sm font-bold text-white flex items-center space-x-2">
            <Flame className="w-4 h-4 text-amber-400" />
            <span>Option Chain Heatmap Matrix</span>
          </h3>
          <p className="text-[11px] text-slate-400">
            Rapid visual scanning of high-intensity liquidity, write activity, and greek exposure
          </p>
        </div>

        {/* Metric Selector Buttons */}
        <div className="flex items-center space-x-1 bg-slate-900 border border-slate-800 p-1 rounded-lg">
          <button
            onClick={() => setMetric('OI_CHANGE')}
            className={`px-3 py-1 rounded text-xs font-semibold transition-colors ${
              metric === 'OI_CHANGE'
                ? 'bg-cyan-600 text-white'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            OI Change
          </button>
          <button
            onClick={() => setMetric('VOLUME')}
            className={`px-3 py-1 rounded text-xs font-semibold transition-colors ${
              metric === 'VOLUME'
                ? 'bg-cyan-600 text-white'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Volume
          </button>
          <button
            onClick={() => setMetric('DELTA')}
            className={`px-3 py-1 rounded text-xs font-semibold transition-colors ${
              metric === 'DELTA'
                ? 'bg-cyan-600 text-white'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Delta Exposure
          </button>
          <button
            onClick={() => setMetric('THETA')}
            className={`px-3 py-1 rounded text-xs font-semibold transition-colors ${
              metric === 'THETA'
                ? 'bg-cyan-600 text-white'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Theta Decay
          </button>
        </div>
      </div>

      {/* Heatmap Matrix Display */}
      <div className="bg-[#0f1422] border border-slate-800 rounded-xl p-4 shadow-lg overflow-x-auto">
        <div className="grid grid-cols-12 gap-1.5 text-center text-[10px] font-mono-num min-w-[700px]">
          {/* Header Row */}
          <div className="col-span-5 font-bold uppercase text-emerald-400 py-1 bg-emerald-950/40 rounded">
            CALLS (CE)
          </div>
          <div className="col-span-2 font-bold uppercase text-cyan-300 py-1 bg-slate-900 rounded">
            STRIKE
          </div>
          <div className="col-span-5 font-bold uppercase text-rose-400 py-1 bg-rose-950/40 rounded">
            PUTS (PE)
          </div>

          {/* Matrix Rows */}
          {strikes.map((r) => {
            const isAtm = r.strike === atmStrike;

            let callValue = 0;
            let putValue = 0;
            let callLabel = '';
            let putLabel = '';

            if (metric === 'OI_CHANGE') {
              callValue = r.call.changeOi;
              putValue = r.put.changeOi;
              callLabel = `${(callValue / currentIndex.lotSize).toFixed(0)} L`;
              putLabel = `${(putValue / currentIndex.lotSize).toFixed(0)} L`;
            } else if (metric === 'VOLUME') {
              callValue = r.call.volume;
              putValue = r.put.volume;
              callLabel = `${(callValue / 1000).toFixed(0)}k`;
              putLabel = `${(putValue / 1000).toFixed(0)}k`;
            } else if (metric === 'DELTA') {
              callValue = r.call.greeks.delta;
              putValue = r.put.greeks.delta;
              callLabel = `Δ ${callValue.toFixed(2)}`;
              putLabel = `Δ ${putValue.toFixed(2)}`;
            } else {
              callValue = r.call.greeks.theta;
              putValue = r.put.greeks.theta;
              callLabel = `θ ${callValue.toFixed(1)}`;
              putLabel = `θ ${putValue.toFixed(1)}`;
            }

            return (
              <React.Fragment key={r.strike}>
                {/* Call cell */}
                <div
                  className="col-span-5 py-2 px-2 rounded font-bold transition-all hover:ring-1 hover:ring-white flex items-center justify-between"
                  style={{
                    backgroundColor: getCellColor(callValue, true),
                  }}
                  title={`CE ${r.strike}: ${callLabel} | LTP: ₹${r.call.ltp}`}
                >
                  <span className="text-slate-300 text-[10px]">LTP ₹{r.call.ltp}</span>
                  <span className="text-white font-extrabold">{callLabel}</span>
                </div>

                {/* Strike Center cell */}
                <div
                  className={`col-span-2 py-2 rounded font-black flex items-center justify-center space-x-1 ${
                    isAtm
                      ? 'bg-cyan-500 text-slate-950 font-black shadow-md'
                      : 'bg-slate-900/90 text-slate-100 border border-slate-800'
                  }`}
                >
                  <span>{r.strike}</span>
                  {isAtm && <span className="text-[8px] font-extrabold">(ATM)</span>}
                </div>

                {/* Put cell */}
                <div
                  className="col-span-5 py-2 px-2 rounded font-bold transition-all hover:ring-1 hover:ring-white flex items-center justify-between"
                  style={{
                    backgroundColor: getCellColor(putValue, false),
                  }}
                  title={`PE ${r.strike}: ${putLabel} | LTP: ₹${r.put.ltp}`}
                >
                  <span className="text-white font-extrabold">{putLabel}</span>
                  <span className="text-slate-300 text-[10px]">LTP ₹{r.put.ltp}</span>
                </div>
              </React.Fragment>
            );
          })}
        </div>
      </div>
    </div>
  );
};
