/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * Participant Heatmap: Matrix of Participants (Rows) vs Indices (Columns)
 * Dark Green = Strong Long, Light Green = Long, Grey = Neutral, Orange = Short, Red = Heavy Short
 */

import React from 'react';
import {
  ParticipantCategory,
  ParticipantIndexData,
  ParticipantIndexName,
  SUPPORTED_PARTICIPANT_INDICES,
} from '../../services/participantAnalytics';

interface ParticipantHeatmapProps {
  data: Record<ParticipantIndexName, ParticipantIndexData>;
  onSelectIndex: (index: ParticipantIndexName) => void;
  selectedIndex: ParticipantIndexName;
}

export const ParticipantHeatmap: React.FC<ParticipantHeatmapProps> = ({
  data,
  onSelectIndex,
  selectedIndex,
}) => {
  const participants: { key: ParticipantCategory; label: string; desc: string }[] = [
    { key: 'FII', label: 'FII (Foreign)', desc: 'Foreign Institutional Investors' },
    { key: 'DII', label: 'DII (Domestic)', desc: 'Domestic Mutual Funds & Insurers' },
    { key: 'PRO', label: 'PRO (Proprietary)', desc: 'Broker Prop Desks & Market Makers' },
    { key: 'CLIENT', label: 'CLIENT (Retail)', desc: 'Retail & HNI Individual Traders' },
  ];

  // Helper function to color code based on contract volume
  const getCellColor = (net: number) => {
    if (net >= 25000) {
      return {
        bg: 'bg-emerald-600/90 text-white border-emerald-400 font-black',
        label: 'Strong Long',
        icon: '▲▲',
      };
    }
    if (net >= 5000) {
      return {
        bg: 'bg-emerald-950/80 text-emerald-300 border-emerald-700/60 font-bold',
        label: 'Long',
        icon: '▲',
      };
    }
    if (net > -5000 && net < 5000) {
      return {
        bg: 'bg-slate-800/80 text-slate-300 border-slate-700 font-medium',
        label: 'Neutral',
        icon: '■',
      };
    }
    if (net <= -25000) {
      return {
        bg: 'bg-rose-600/90 text-white border-rose-400 font-black',
        label: 'Heavy Short',
        icon: '▼▼',
      };
    }
    return {
      bg: 'bg-amber-950/80 text-amber-300 border-amber-700/60 font-bold',
      label: 'Short',
      icon: '▼',
    };
  };

  return (
    <div className="bg-[#0b101c] border border-slate-800 rounded-xl p-4 shadow-lg space-y-4">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 border-b border-slate-800 pb-3">
        <div>
          <div className="text-sm font-bold text-white flex items-center space-x-2">
            <span>Participant Flow Heatmap</span>
            <span className="text-[10px] px-2 py-0.5 rounded bg-cyan-950 text-cyan-300 border border-cyan-800 uppercase font-mono">
              Matrix View
            </span>
          </div>
          <div className="text-xs text-slate-400">
            Real-time derivative bias matrix across all 6 major Indian market indices
          </div>
        </div>

        {/* Legend */}
        <div className="flex items-center flex-wrap gap-2 text-[10px]">
          <span className="flex items-center space-x-1">
            <span className="w-3 h-3 rounded bg-emerald-600 inline-block"></span>
            <span className="text-slate-300">Strong Long</span>
          </span>
          <span className="flex items-center space-x-1">
            <span className="w-3 h-3 rounded bg-emerald-950 border border-emerald-700 inline-block"></span>
            <span className="text-slate-300">Long</span>
          </span>
          <span className="flex items-center space-x-1">
            <span className="w-3 h-3 rounded bg-slate-800 border border-slate-700 inline-block"></span>
            <span className="text-slate-300">Neutral</span>
          </span>
          <span className="flex items-center space-x-1">
            <span className="w-3 h-3 rounded bg-amber-950 border border-amber-700 inline-block"></span>
            <span className="text-slate-300">Short</span>
          </span>
          <span className="flex items-center space-x-1">
            <span className="w-3 h-3 rounded bg-rose-600 inline-block"></span>
            <span className="text-slate-300">Heavy Short</span>
          </span>
        </div>
      </div>

      {/* Heatmap Table */}
      <div className="overflow-x-auto">
        <table className="w-full text-xs border-collapse">
          <thead>
            <tr className="border-b border-slate-800 text-slate-400">
              <th className="py-2.5 px-3 text-left font-bold bg-slate-900/60 rounded-tl-lg">
                Participant Category
              </th>
              {SUPPORTED_PARTICIPANT_INDICES.map((idx) => (
                <th
                  key={idx}
                  onClick={() => onSelectIndex(idx)}
                  className={`py-2.5 px-2 text-center font-bold cursor-pointer transition-colors ${
                    selectedIndex === idx
                      ? 'bg-cyan-950 text-cyan-300 border-b-2 border-cyan-400'
                      : 'hover:bg-slate-800/60 hover:text-slate-200'
                  }`}
                >
                  <div className="text-[11px] font-mono">{idx}</div>
                  <div className="text-[9px] font-normal text-slate-400">
                    ₹{data[idx]?.spotPrice.toLocaleString('en-IN') || '—'}
                  </div>
                </th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/80">
            {participants.map((p) => (
              <tr key={p.key} className="hover:bg-slate-900/40 transition-colors">
                <td className="py-3 px-3 font-semibold text-slate-200 bg-slate-900/30">
                  <div className="flex items-center space-x-2">
                    <span className="text-xs font-mono font-bold text-cyan-400">{p.key}</span>
                    <span className="text-[11px] text-slate-400 hidden md:inline">({p.label.split(' ')[0]})</span>
                  </div>
                  <div className="text-[9.5px] text-slate-400 font-normal">{p.desc}</div>
                </td>

                {SUPPORTED_PARTICIPANT_INDICES.map((idx) => {
                  const idxData = data[idx];
                  const pos = idxData?.participants[p.key];
                  if (!pos) {
                    return (
                      <td key={idx} className="p-1.5 text-center text-slate-600">
                        —
                      </td>
                    );
                  }

                  const colorInfo = getCellColor(pos.netPosition);
                  const isPos = pos.netPosition >= 0;

                  return (
                    <td
                      key={idx}
                      onClick={() => onSelectIndex(idx)}
                      className="p-1.5 cursor-pointer text-center"
                      title={`${p.label} in ${idx}: ${isPos ? '+' : ''}${pos.netPosition.toLocaleString('en-IN')} contracts (${colorInfo.label})`}
                    >
                      <div
                        className={`py-2 px-2 rounded-lg border flex flex-col items-center justify-center transition-transform hover:scale-105 ${colorInfo.bg}`}
                      >
                        <div className="flex items-center space-x-1 text-[11px] font-mono leading-tight">
                          <span>{colorInfo.icon}</span>
                          <span>
                            {isPos ? '+' : ''}
                            {(pos.netPosition / 1000).toFixed(1)}k
                          </span>
                        </div>
                        <div className="text-[8.5px] opacity-80 uppercase tracking-wider font-sans mt-0.5">
                          {colorInfo.label}
                        </div>
                      </div>
                    </td>
                  );
                })}
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Heatmap Insights */}
      <div className="bg-slate-900/60 border border-slate-800/80 rounded-lg p-3 text-xs flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-slate-300">
        <div className="flex items-center space-x-2">
          <span className="w-2 h-2 rounded-full bg-cyan-400 animate-ping"></span>
          <span className="font-semibold text-cyan-300">Smart Money Heatmap Takeaway:</span>
          <span className="text-slate-300">
            FIIs are strongly long in <span className="text-emerald-400 font-bold">NIFTY</span> and <span className="text-emerald-400 font-bold">BANKNIFTY</span>, while being cautious in <span className="text-amber-400 font-bold">MIDCAP</span>.
          </span>
        </div>
        <div className="text-[11px] text-slate-400">
          Click any column header or cell to load that index details.
        </div>
      </div>
    </div>
  );
};
