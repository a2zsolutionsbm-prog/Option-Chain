/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * Participant Position Chart: Interactive time-series chart
 * Supports FII, DII, PRO, CLIENT across 1D, 5D, 1M, 3M timeframes.
 */

import React, { useState } from 'react';
import {
  ParticipantCategory,
  ParticipantIndexData,
} from '../../services/participantAnalytics';

interface ParticipantChartProps {
  indexData: ParticipantIndexData;
}

type TimeframeOption = '1D' | '5D' | '1M' | '3M';

export const ParticipantChart: React.FC<ParticipantChartProps> = ({ indexData }) => {
  const [selectedParticipant, setSelectedParticipant] = useState<ParticipantCategory | 'ALL'>('FII');
  const [selectedTimeframe, setSelectedTimeframe] = useState<TimeframeOption>('1M');
  const [hoverIndex, setHoverIndex] = useState<number | null>(null);

  const participant =
    selectedParticipant !== 'ALL'
      ? indexData.participants[selectedParticipant]
      : indexData.participants.FII;

  // Filter history based on selected timeframe
  let historyData = participant.history;
  if (selectedTimeframe === '1D') {
    historyData = participant.history.slice(-3);
  } else if (selectedTimeframe === '5D') {
    historyData = participant.history.slice(-5);
  } else if (selectedTimeframe === '1M') {
    historyData = participant.history;
  } else if (selectedTimeframe === '3M') {
    historyData = participant.history;
  }

  // Calculate chart bounds
  const values = historyData.map((d) => d.netPosition);
  const minVal = Math.min(0, ...values);
  const maxVal = Math.max(0, ...values);
  const range = maxVal - minVal || 1;

  // Dimensions
  const chartHeight = 220;
  const chartWidth = 720;
  const paddingY = 25;
  const paddingX = 30;

  const getY = (val: number) => {
    const norm = (val - minVal) / range;
    return chartHeight - paddingY - norm * (chartHeight - paddingY * 2);
  };

  const getX = (idx: number) => {
    if (historyData.length <= 1) return chartWidth / 2;
    return paddingX + (idx / (historyData.length - 1)) * (chartWidth - paddingX * 2);
  };

  const zeroY = getY(0);

  // Build SVG path
  const points = historyData.map((d, i) => `${getX(i)},${getY(d.netPosition)}`).join(' ');

  // Colors per participant
  const getParticipantColor = (p: ParticipantCategory) => {
    switch (p) {
      case 'FII':
        return { stroke: '#06b6d4', fill: 'rgba(6, 182, 212, 0.15)', name: 'Foreign Institutions (FII)' };
      case 'DII':
        return { stroke: '#10b981', fill: 'rgba(16, 185, 129, 0.15)', name: 'Domestic Institutions (DII)' };
      case 'PRO':
        return { stroke: '#a855f7', fill: 'rgba(168, 85, 247, 0.15)', name: 'Proprietary Desks (PRO)' };
      case 'CLIENT':
        return { stroke: '#f59e0b', fill: 'rgba(245, 158, 11, 0.15)', name: 'Retail Clients' };
    }
  };

  const activeColor =
    selectedParticipant === 'ALL'
      ? { stroke: '#06b6d4', fill: 'rgba(6, 182, 212, 0.15)', name: 'Comparative Institutional Flow' }
      : getParticipantColor(selectedParticipant);

  return (
    <div className="bg-[#0b101c] border border-slate-800 rounded-xl p-4 shadow-lg space-y-4">
      {/* Header with participant buttons and timeframe toggles */}
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-3 border-b border-slate-800 pb-3">
        <div>
          <div className="text-sm font-bold text-white flex items-center space-x-2">
            <span>Participant Trend Charts ({indexData.index})</span>
            <span className="text-[10px] px-2 py-0.5 rounded bg-purple-950 text-purple-300 border border-purple-800 font-mono">
              Net Open Interest
            </span>
          </div>
          <div className="text-xs text-slate-400">
            Historical net contracts positioning over chosen timeframe
          </div>
        </div>

        {/* Participant Selectors */}
        <div className="flex items-center flex-wrap gap-1.5">
          {(['FII', 'DII', 'PRO', 'CLIENT'] as ParticipantCategory[]).map((p) => {
            const isSel = selectedParticipant === p;
            return (
              <button
                key={p}
                onClick={() => setSelectedParticipant(p)}
                className={`px-2.5 py-1 rounded text-xs font-semibold transition-all ${
                  isSel
                    ? 'bg-cyan-500 text-slate-950 shadow-md ring-1 ring-cyan-300'
                    : 'bg-slate-900 border border-slate-800 text-slate-300 hover:bg-slate-800 hover:text-white'
                }`}
              >
                {p}
              </button>
            );
          })}
        </div>

        {/* Timeframe Selectors */}
        <div className="flex items-center bg-slate-900 rounded-lg p-0.5 border border-slate-800 text-xs">
          {(['1D', '5D', '1M', '3M'] as TimeframeOption[]).map((tf) => (
            <button
              key={tf}
              onClick={() => setSelectedTimeframe(tf)}
              className={`px-2 py-0.5 rounded font-medium transition-colors ${
                selectedTimeframe === tf
                  ? 'bg-cyan-950 text-cyan-300 border border-cyan-800'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {tf}
            </button>
          ))}
        </div>
      </div>

      {/* Metric Highlights */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
        <div className="bg-slate-900/60 border border-slate-800 rounded-lg p-2.5">
          <div className="text-slate-400 text-[10.5px]">Current Net Position</div>
          <div
            className={`text-base font-extrabold font-mono mt-0.5 ${
              participant.netPosition >= 0 ? 'text-emerald-400' : 'text-rose-400'
            }`}
          >
            {participant.netPosition >= 0 ? '+' : ''}
            {participant.netPosition.toLocaleString('en-IN')}
          </div>
        </div>

        <div className="bg-slate-900/60 border border-slate-800 rounded-lg p-2.5">
          <div className="text-slate-400 text-[10.5px]">Net Change (1D)</div>
          <div
            className={`text-base font-extrabold font-mono mt-0.5 ${
              participant.netChange >= 0 ? 'text-emerald-400' : 'text-rose-400'
            }`}
          >
            {participant.netChange >= 0 ? '+' : ''}
            {participant.netChange.toLocaleString('en-IN')}
          </div>
        </div>

        <div className="bg-slate-900/60 border border-slate-800 rounded-lg p-2.5">
          <div className="text-slate-400 text-[10.5px]">Weekly Trend</div>
          <div
            className={`text-base font-extrabold font-mono mt-0.5 ${
              participant.weeklyChange >= 0 ? 'text-emerald-400' : 'text-rose-400'
            }`}
          >
            {participant.weeklyChange >= 0 ? '+' : ''}
            {participant.weeklyChange.toLocaleString('en-IN')}
          </div>
        </div>

        <div className="bg-slate-900/60 border border-slate-800 rounded-lg p-2.5">
          <div className="text-slate-400 text-[10.5px]">Monthly Bias</div>
          <div
            className={`text-base font-extrabold font-mono mt-0.5 ${
              participant.monthlyChange >= 0 ? 'text-emerald-400' : 'text-rose-400'
            }`}
          >
            {participant.monthlyChange >= 0 ? '+' : ''}
            {participant.monthlyChange.toLocaleString('en-IN')}
          </div>
        </div>
      </div>

      {/* SVG Responsive Chart */}
      <div className="relative w-full overflow-hidden bg-slate-950/60 border border-slate-800/80 rounded-lg p-2">
        <svg
          viewBox={`0 0 ${chartWidth} ${chartHeight}`}
          className="w-full h-48 md:h-56 select-none"
        >
          <defs>
            <linearGradient id="chartGradient" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor={activeColor.stroke} stopOpacity="0.4" />
              <stop offset="100%" stopColor={activeColor.stroke} stopOpacity="0.0" />
            </linearGradient>
          </defs>

          {/* Grid lines */}
          <line
            x1={paddingX}
            y1={zeroY}
            x2={chartWidth - paddingX}
            y2={zeroY}
            stroke="#475569"
            strokeDasharray="4 4"
            strokeWidth="1"
          />
          <text
            x={paddingX + 4}
            y={zeroY - 4}
            fill="#94a3b8"
            fontSize="9"
            fontFamily="monospace"
          >
            0 (Neutral Line)
          </text>

          {/* Area fill */}
          {historyData.length > 1 && (
            <polygon
              points={`${getX(0)},${zeroY} ${points} ${getX(historyData.length - 1)},${zeroY}`}
              fill="url(#chartGradient)"
            />
          )}

          {/* Primary Trend Line */}
          {historyData.length > 1 && (
            <polyline
              fill="none"
              stroke={activeColor.stroke}
              strokeWidth="2.5"
              strokeLinecap="round"
              strokeLinejoin="round"
              points={points}
            />
          )}

          {/* Data Points */}
          {historyData.map((d, i) => {
            const cx = getX(i);
            const cy = getY(d.netPosition);
            const isHovered = hoverIndex === i;

            return (
              <g key={i}>
                <circle
                  cx={cx}
                  cy={cy}
                  r={isHovered ? 6 : 3.5}
                  fill={d.netPosition >= 0 ? '#10b981' : '#f43f5e'}
                  stroke="#ffffff"
                  strokeWidth={isHovered ? '2' : '1'}
                  className="cursor-pointer transition-all"
                  onMouseEnter={() => setHoverIndex(i)}
                  onMouseLeave={() => setHoverIndex(null)}
                />
                {/* X Axis Label */}
                <text
                  x={cx}
                  y={chartHeight - 6}
                  fill="#64748b"
                  fontSize="8.5"
                  textAnchor="middle"
                  fontFamily="monospace"
                >
                  {d.label.replace(' Days Ago', 'd')}
                </text>
              </g>
            );
          })}
        </svg>

        {/* Hover Tooltip */}
        {hoverIndex !== null && historyData[hoverIndex] && (
          <div
            className="absolute top-4 left-1/2 -translate-x-1/2 bg-slate-900/95 border border-cyan-500/80 px-3 py-1.5 rounded-lg shadow-xl text-xs text-white pointer-events-none flex items-center space-x-3"
          >
            <span className="font-semibold text-cyan-300">
              {historyData[hoverIndex].label}:
            </span>
            <span
              className={`font-mono font-bold ${
                historyData[hoverIndex].netPosition >= 0
                  ? 'text-emerald-400'
                  : 'text-rose-400'
              }`}
            >
              {historyData[hoverIndex].netPosition >= 0 ? '+' : ''}
              {historyData[hoverIndex].netPosition.toLocaleString('en-IN')} contracts
            </span>
          </div>
        )}
      </div>
    </div>
  );
};
