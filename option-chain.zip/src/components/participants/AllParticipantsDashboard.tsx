/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * All Participants Analytics Dashboard
 * Real-time institutional derivatives positioning (FII, DII, PRO, CLIENT)
 */

import React, { useState, useEffect } from 'react';
import {
  ParticipantCategory,
  ParticipantIndexData,
  ParticipantIndexName,
  SUPPORTED_PARTICIPANT_INDICES,
  participantAnalytics,
} from '../../services/participantAnalytics';
import { ParticipantHeatmap } from './ParticipantHeatmap';
import { ParticipantChart } from './ParticipantChart';
import {
  Activity,
  AlertTriangle,
  ArrowDownRight,
  ArrowUpRight,
  BarChart2,
  ChevronDown,
  Download,
  FileSpreadsheet,
  FileText,
  Flame,
  Globe,
  Layers,
  LineChart,
  Printer,
  RefreshCw,
  ShieldAlert,
  Sparkles,
  TrendingDown,
  TrendingUp,
  UserCheck,
  Users,
} from 'lucide-react';

export const AllParticipantsDashboard: React.FC = () => {
  const [allData, setAllData] = useState<Record<ParticipantIndexName, ParticipantIndexData>>(
    participantAnalytics.getData() as Record<ParticipantIndexName, ParticipantIndexData>
  );
  const [selectedIndex, setSelectedIndex] = useState<ParticipantIndexName>('NIFTY');
  const [viewMode, setViewMode] = useState<'single' | 'all'>('single');
  const [activeSection, setActiveSection] = useState<'overview' | 'fii' | 'dii' | 'client' | 'charts' | 'heatmap' | 'alerts'>('overview');
  const [tableDetailMode, setTableDetailMode] = useState<'compact' | 'detailed'>('detailed');
  const [exportNotice, setExportNotice] = useState<string | null>(null);

  // Subscribe to live simulated institutional participant updates
  useEffect(() => {
    const unsub = participantAnalytics.subscribe((newData) => {
      setAllData({ ...newData });
    });
    return () => unsub();
  }, []);

  const activeIndexData = allData[selectedIndex] || allData.NIFTY;

  // Export handlers
  const handleExportCSV = () => {
    const csvContent = participantAnalytics.exportCSV(selectedIndex);
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `${selectedIndex}_Participant_OI_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    setExportNotice('CSV exported successfully!');
    setTimeout(() => setExportNotice(null), 3000);
  };

  const handleExportExcel = () => {
    const tsvContent = participantAnalytics.exportExcelTSV(selectedIndex);
    const blob = new Blob([tsvContent], { type: 'application/vnd.ms-excel;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `${selectedIndex}_Participant_Analytics_${new Date().toISOString().slice(0, 10)}.xls`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    setExportNotice('Excel report exported successfully!');
    setTimeout(() => setExportNotice(null), 3000);
  };

  const handlePrintPDF = () => {
    window.print();
  };

  // Interpretation styling helper
  const getChangeBadge = (type: string) => {
    switch (type) {
      case 'Long Addition':
        return 'bg-emerald-950/80 text-emerald-300 border border-emerald-700/60';
      case 'Short Covering':
        return 'bg-blue-950/80 text-blue-300 border border-blue-700/60';
      case 'Long Unwinding':
        return 'bg-amber-950/80 text-amber-300 border border-amber-700/60';
      case 'Short Addition':
        return 'bg-rose-950/80 text-rose-300 border border-rose-700/60';
      default:
        return 'bg-slate-800 text-slate-300';
    }
  };

  const categories: ParticipantCategory[] = ['FII', 'DII', 'PRO', 'CLIENT'];

  // Retail metrics calculation
  const clientPos = activeIndexData.participants.CLIENT;
  const totalContracts = clientPos.totalLong + clientPos.totalShort || 1;
  const retailLongPct = Math.round((clientPos.totalLong / totalContracts) * 100);
  const retailShortPct = 100 - retailLongPct;

  return (
    <div className="flex-1 overflow-y-auto bg-[#070b13] text-slate-100 p-3 sm:p-5 space-y-5">
      {/* Top Header & Index Selector */}
      <div className="bg-[#0b101c] border border-slate-800/90 rounded-xl p-4 shadow-xl flex flex-col lg:flex-row items-start lg:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <span className="p-1.5 rounded-lg bg-cyan-950/90 border border-cyan-800/80 text-cyan-300">
              <Globe className="w-5 h-5" />
            </span>
            <div>
              <h1 className="text-lg font-black tracking-wide text-white flex items-center space-x-2">
                <span>ALL PARTICIPANTS ANALYTICS</span>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 uppercase font-mono font-bold">
                  Institutional Flow
                </span>
              </h1>
              <p className="text-xs text-slate-400">
                NSE live participant derivative positioning (FII, DII, PRO, CLIENT) with Smart Money tracking
              </p>
            </div>
          </div>
        </div>

        {/* Index Selector & Export Tools */}
        <div className="flex items-center flex-wrap gap-2 w-full lg:w-auto justify-start lg:justify-end">
          {/* Quick Index Pills */}
          <div className="flex items-center bg-slate-900 border border-slate-800 rounded-lg p-1 overflow-x-auto no-scrollbar gap-1 text-xs">
            {SUPPORTED_PARTICIPANT_INDICES.map((idx) => {
              const isSelected = selectedIndex === idx && viewMode === 'single';
              return (
                <button
                  key={idx}
                  onClick={() => {
                    setSelectedIndex(idx);
                    setViewMode('single');
                  }}
                  className={`px-2.5 py-1 rounded font-bold transition-all whitespace-nowrap ${
                    isSelected
                      ? 'bg-cyan-500 text-slate-950 shadow-md ring-1 ring-cyan-300'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
                  }`}
                >
                  {idx}
                </button>
              );
            })}
            <button
              onClick={() => setViewMode(viewMode === 'all' ? 'single' : 'all')}
              className={`px-2.5 py-1 rounded font-bold transition-all whitespace-nowrap ${
                viewMode === 'all'
                  ? 'bg-purple-600 text-white shadow-md'
                  : 'text-slate-400 hover:text-purple-300 hover:bg-slate-800'
              }`}
            >
              All Indices
            </button>
          </div>

          {/* Export Buttons */}
          <div className="flex items-center space-x-1.5">
            <button
              onClick={handleExportExcel}
              className="flex items-center space-x-1 px-2.5 py-1.5 rounded-lg bg-emerald-950/60 border border-emerald-700/60 text-emerald-300 hover:bg-emerald-900/60 transition-colors text-xs font-semibold"
              title="Download Excel File (.xls)"
            >
              <FileSpreadsheet className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Excel</span>
            </button>
            <button
              onClick={handleExportCSV}
              className="flex items-center space-x-1 px-2.5 py-1.5 rounded-lg bg-cyan-950/60 border border-cyan-700/60 text-cyan-300 hover:bg-cyan-900/60 transition-colors text-xs font-semibold"
              title="Download CSV File (.csv)"
            >
              <Download className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">CSV</span>
            </button>
            <button
              onClick={handlePrintPDF}
              className="flex items-center space-x-1 px-2.5 py-1.5 rounded-lg bg-slate-900 border border-slate-700 text-slate-300 hover:bg-slate-800 transition-colors text-xs font-semibold"
              title="Print or Save as PDF"
            >
              <Printer className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">PDF</span>
            </button>
          </div>
        </div>
      </div>

      {/* Export notification popup */}
      {exportNotice && (
        <div className="bg-emerald-950/90 border border-emerald-500 text-emerald-200 px-4 py-2 rounded-lg text-xs font-medium flex items-center justify-between shadow-lg">
          <span>{exportNotice}</span>
          <span className="text-[10px] text-emerald-400">Ready</span>
        </div>
      )}

      {/* SMART MONEY TRACKER & MARKET SENTIMENT ENGINE HERO BANNER */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Smart Money Tracker Card */}
        <div className="lg:col-span-2 bg-[#0b101c] border border-cyan-800/40 rounded-xl p-4 shadow-xl relative overflow-hidden flex flex-col justify-between">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-slate-800/80 pb-3">
            <div className="flex items-center space-x-2">
              <span className="p-1 rounded bg-cyan-500/20 text-cyan-400">
                <Sparkles className="w-4 h-4" />
              </span>
              <div>
                <span className="text-xs uppercase font-extrabold text-cyan-400 tracking-wider">
                  Smart Money Tracker ({selectedIndex})
                </span>
                <div className="text-slate-400 text-[11px]">
                  Algorithmic interpretation of institutional FII + PRO combined position flow
                </div>
              </div>
            </div>

            {/* Smart Money Badge */}
            <div className="flex items-center space-x-2">
              <span
                className={`px-3 py-1 rounded-full text-xs font-black tracking-wider uppercase flex items-center space-x-1.5 shadow-lg ${
                  activeIndexData.smartMoney.direction === 'BULLISH'
                    ? 'bg-emerald-500 text-slate-950 ring-2 ring-emerald-400'
                    : activeIndexData.smartMoney.direction === 'BEARISH'
                    ? 'bg-rose-500 text-white ring-2 ring-rose-400'
                    : 'bg-amber-500 text-slate-950 ring-2 ring-amber-400'
                }`}
              >
                {activeIndexData.smartMoney.direction === 'BULLISH' ? (
                  <TrendingUp className="w-3.5 h-3.5" />
                ) : activeIndexData.smartMoney.direction === 'BEARISH' ? (
                  <TrendingDown className="w-3.5 h-3.5" />
                ) : (
                  <Activity className="w-3.5 h-3.5" />
                )}
                <span>SMART MONEY: {activeIndexData.smartMoney.direction}</span>
              </span>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 my-3">
            <div className="bg-slate-900/60 border border-slate-800 rounded-lg p-3">
              <div className="text-[10px] text-slate-400 uppercase font-semibold">Institutional Direction</div>
              <div className="text-lg font-black text-cyan-300 font-mono mt-0.5">
                {activeIndexData.smartMoney.direction}
              </div>
              <div className="text-[10px] text-slate-400 mt-1">
                Score: <span className="text-cyan-400 font-bold">{activeIndexData.smartMoney.score}/100</span>
              </div>
            </div>

            <div className="bg-slate-900/60 border border-slate-800 rounded-lg p-3">
              <div className="text-[10px] text-slate-400 uppercase font-semibold">FII + PRO Combined Net</div>
              <div
                className={`text-lg font-black font-mono mt-0.5 ${
                  activeIndexData.smartMoney.fiiProCombinedNet >= 0 ? 'text-emerald-400' : 'text-rose-400'
                }`}
              >
                {activeIndexData.smartMoney.fiiProCombinedNet >= 0 ? '+' : ''}
                {activeIndexData.smartMoney.fiiProCombinedNet.toLocaleString('en-IN')}
              </div>
              <div className="text-[10px] text-slate-400 mt-1">Contracts Net Long</div>
            </div>

            <div className="bg-slate-900/60 border border-slate-800 rounded-lg p-3">
              <div className="text-[10px] text-slate-400 uppercase font-semibold">Signal Confidence</div>
              <div className="text-lg font-black text-emerald-400 font-mono mt-0.5">
                {activeIndexData.smartMoney.confidence}%
              </div>
              <div className="text-[10px] text-slate-400 mt-1">High Institutional Sizing</div>
            </div>
          </div>

          {/* Reasoning & Contrarian Signal */}
          <div className="bg-cyan-950/20 border border-cyan-800/40 rounded-lg p-2.5 text-xs space-y-1">
            <div className="flex items-start space-x-1.5 text-slate-200">
              <span className="text-cyan-400 font-bold shrink-0">Rationale:</span>
              <span>{activeIndexData.smartMoney.reasoning}</span>
            </div>
            <div className="flex items-start space-x-1.5 text-amber-300/90 text-[11.5px]">
              <span className="font-bold shrink-0">Contrarian Watch:</span>
              <span>{activeIndexData.smartMoney.retailContrarianSignal}</span>
            </div>
          </div>
        </div>

        {/* Market Sentiment Engine Gauge Card */}
        <div className="bg-[#0b101c] border border-slate-800/90 rounded-xl p-4 shadow-xl flex flex-col justify-between">
          <div className="flex items-center justify-between border-b border-slate-800/80 pb-2.5">
            <span className="text-xs uppercase font-extrabold text-slate-300 tracking-wider flex items-center space-x-1.5">
              <Activity className="w-4 h-4 text-cyan-400" />
              <span>Market Sentiment Engine</span>
            </span>
            <span className="text-[10px] text-slate-400 font-mono">Real-time</span>
          </div>

          <div className="space-y-3.5 my-3">
            {/* Institutional Sentiment */}
            <div>
              <div className="flex items-center justify-between text-xs mb-1">
                <span className="text-slate-400">Institutional Sentiment (FII + DII)</span>
                <span className="font-extrabold text-emerald-400 font-mono">
                  {activeIndexData.sentiment.institutional} ({activeIndexData.sentiment.institutionalScore}%)
                </span>
              </div>
              <div className="w-full h-2 bg-slate-900 rounded-full overflow-hidden">
                <div
                  className="h-full bg-emerald-500 rounded-full transition-all"
                  style={{ width: `${Math.max(10, activeIndexData.sentiment.institutionalScore)}%` }}
                />
              </div>
            </div>

            {/* Retail Sentiment */}
            <div>
              <div className="flex items-center justify-between text-xs mb-1">
                <span className="text-slate-400">Retail Sentiment (Client)</span>
                <span className="font-extrabold text-rose-400 font-mono">
                  {activeIndexData.sentiment.retail} ({activeIndexData.sentiment.retailScore}%)
                </span>
              </div>
              <div className="w-full h-2 bg-slate-900 rounded-full overflow-hidden">
                <div
                  className="h-full bg-rose-500 rounded-full transition-all"
                  style={{ width: `${Math.max(10, Math.abs(activeIndexData.sentiment.retailScore))}%` }}
                />
              </div>
            </div>

            {/* Overall Market Sentiment */}
            <div>
              <div className="flex items-center justify-between text-xs mb-1">
                <span className="text-slate-200 font-semibold">Overall Market Bias</span>
                <span className="font-black text-cyan-300 font-mono">
                  {activeIndexData.sentiment.overall} ({activeIndexData.sentiment.overallScore}%)
                </span>
              </div>
              <div className="w-full h-2.5 bg-slate-900 rounded-full overflow-hidden p-0.5 border border-slate-800">
                <div
                  className="h-full bg-gradient-to-r from-cyan-500 to-emerald-400 rounded-full transition-all"
                  style={{ width: `${Math.max(15, activeIndexData.sentiment.overallScore)}%` }}
                />
              </div>
            </div>
          </div>

          <div className="text-[10px] text-slate-400 bg-slate-900/60 p-2 rounded border border-slate-800/80">
            Institutional positions hold 4x weight over retail in determining market direction.
          </div>
        </div>
      </div>

      {/* DASHBOARD SUMMARY CARDS (Specified in prompt) */}
      <div>
        <div className="text-xs font-bold text-slate-300 uppercase tracking-wider mb-2 flex items-center justify-between">
          <span>Participant Summary Cards — {selectedIndex}</span>
          <span className="text-slate-400 font-normal">Last Updated: {activeIndexData.lastUpdated}</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
          {/* FII Card */}
          <div className="bg-[#0e1526] border border-cyan-800/50 rounded-xl p-3.5 shadow-lg relative overflow-hidden">
            <div className="flex items-center justify-between text-xs">
              <span className="font-bold text-cyan-400">FII</span>
              <span className="text-[9.5px] px-1.5 py-0.5 rounded bg-cyan-950 text-cyan-300 border border-cyan-800 font-mono">
                Offshore
              </span>
            </div>
            <div className="mt-2">
              <div className="text-[10px] text-slate-400">Net Position</div>
              <div
                className={`text-lg font-black font-mono ${
                  activeIndexData.participants.FII.netPosition >= 0 ? 'text-emerald-400' : 'text-rose-400'
                }`}
              >
                {activeIndexData.participants.FII.netPosition >= 0 ? 'Net Long +' : 'Net Short '}
                {Math.abs(activeIndexData.participants.FII.netPosition).toLocaleString('en-IN')}
              </div>
            </div>
            <div className="text-[11px] text-slate-300 mt-1 flex items-center justify-between border-t border-slate-800/80 pt-1.5">
              <span className="text-slate-400">Day Change:</span>
              <span
                className={`font-semibold ${
                  activeIndexData.participants.FII.netChange >= 0 ? 'text-emerald-400' : 'text-rose-400'
                }`}
              >
                {activeIndexData.participants.FII.netChange >= 0 ? '+' : ''}
                {activeIndexData.participants.FII.netChange.toLocaleString('en-IN')}
              </span>
            </div>
          </div>

          {/* DII Card */}
          <div className="bg-[#0e1526] border border-emerald-800/50 rounded-xl p-3.5 shadow-lg relative overflow-hidden">
            <div className="flex items-center justify-between text-xs">
              <span className="font-bold text-emerald-400">DII</span>
              <span className="text-[9.5px] px-1.5 py-0.5 rounded bg-emerald-950 text-emerald-300 border border-emerald-800 font-mono">
                Domestic Inst.
              </span>
            </div>
            <div className="mt-2">
              <div className="text-[10px] text-slate-400">Net Position</div>
              <div
                className={`text-lg font-black font-mono ${
                  activeIndexData.participants.DII.netPosition >= 0 ? 'text-emerald-400' : 'text-rose-400'
                }`}
              >
                {activeIndexData.participants.DII.netPosition >= 0 ? 'Net Long +' : 'Net Short '}
                {Math.abs(activeIndexData.participants.DII.netPosition).toLocaleString('en-IN')}
              </div>
            </div>
            <div className="text-[11px] text-slate-300 mt-1 flex items-center justify-between border-t border-slate-800/80 pt-1.5">
              <span className="text-slate-400">Day Change:</span>
              <span
                className={`font-semibold ${
                  activeIndexData.participants.DII.netChange >= 0 ? 'text-emerald-400' : 'text-rose-400'
                }`}
              >
                {activeIndexData.participants.DII.netChange >= 0 ? '+' : ''}
                {activeIndexData.participants.DII.netChange.toLocaleString('en-IN')}
              </span>
            </div>
          </div>

          {/* PRO Card */}
          <div className="bg-[#0e1526] border border-purple-800/50 rounded-xl p-3.5 shadow-lg relative overflow-hidden">
            <div className="flex items-center justify-between text-xs">
              <span className="font-bold text-purple-400">PRO</span>
              <span className="text-[9.5px] px-1.5 py-0.5 rounded bg-purple-950 text-purple-300 border border-purple-800 font-mono">
                Proprietary
              </span>
            </div>
            <div className="mt-2">
              <div className="text-[10px] text-slate-400">Net Position</div>
              <div
                className={`text-lg font-black font-mono ${
                  activeIndexData.participants.PRO.netPosition >= 0 ? 'text-emerald-400' : 'text-rose-400'
                }`}
              >
                {activeIndexData.participants.PRO.netPosition >= 0 ? 'Net Long +' : 'Net Short '}
                {Math.abs(activeIndexData.participants.PRO.netPosition).toLocaleString('en-IN')}
              </div>
            </div>
            <div className="text-[11px] text-slate-300 mt-1 flex items-center justify-between border-t border-slate-800/80 pt-1.5">
              <span className="text-slate-400">Day Change:</span>
              <span
                className={`font-semibold ${
                  activeIndexData.participants.PRO.netChange >= 0 ? 'text-emerald-400' : 'text-rose-400'
                }`}
              >
                {activeIndexData.participants.PRO.netChange >= 0 ? '+' : ''}
                {activeIndexData.participants.PRO.netChange.toLocaleString('en-IN')}
              </span>
            </div>
          </div>

          {/* CLIENT Card */}
          <div className="bg-[#0e1526] border border-amber-800/50 rounded-xl p-3.5 shadow-lg relative overflow-hidden">
            <div className="flex items-center justify-between text-xs">
              <span className="font-bold text-amber-400">CLIENT</span>
              <span className="text-[9.5px] px-1.5 py-0.5 rounded bg-amber-950 text-amber-300 border border-amber-800 font-mono">
                Retail / HNI
              </span>
            </div>
            <div className="mt-2">
              <div className="text-[10px] text-slate-400">Net Position</div>
              <div
                className={`text-lg font-black font-mono ${
                  activeIndexData.participants.CLIENT.netPosition >= 0 ? 'text-emerald-400' : 'text-rose-400'
                }`}
              >
                {activeIndexData.participants.CLIENT.netPosition >= 0 ? 'Net Long +' : 'Net Short '}
                {Math.abs(activeIndexData.participants.CLIENT.netPosition).toLocaleString('en-IN')}
              </div>
            </div>
            <div className="text-[11px] text-slate-300 mt-1 flex items-center justify-between border-t border-slate-800/80 pt-1.5">
              <span className="text-slate-400">Day Change:</span>
              <span
                className={`font-semibold ${
                  activeIndexData.participants.CLIENT.netChange >= 0 ? 'text-emerald-400' : 'text-rose-400'
                }`}
              >
                {activeIndexData.participants.CLIENT.netChange >= 0 ? '+' : ''}
                {activeIndexData.participants.CLIENT.netChange.toLocaleString('en-IN')}
              </span>
            </div>
          </div>

          {/* Overall Sentiment Card */}
          <div className="bg-[#0e1526] border border-cyan-500/40 rounded-xl p-3.5 shadow-lg flex flex-col justify-between">
            <div className="flex items-center justify-between text-xs">
              <span className="font-bold text-white uppercase">{selectedIndex}</span>
              <span className="text-[9.5px] px-1.5 py-0.5 rounded bg-slate-800 text-slate-300 font-mono">
                Consensus
              </span>
            </div>
            <div className="my-1">
              <div className="text-[10px] text-slate-400 uppercase">Overall Bias</div>
              <div
                className={`text-xl font-black uppercase font-mono ${
                  activeIndexData.sentiment.overall === 'BULLISH'
                    ? 'text-emerald-400'
                    : activeIndexData.sentiment.overall === 'BEARISH'
                    ? 'text-rose-400'
                    : 'text-amber-400'
                }`}
              >
                {activeIndexData.sentiment.overall}
              </div>
            </div>
            <div className="text-[10px] text-slate-400 border-t border-slate-800/80 pt-1">
              FII + PRO driving direction
            </div>
          </div>
        </div>
      </div>

      {/* LIVE PARTICIPANT POSITION TABLE (Specified in prompt) */}
      <div className="bg-[#0b101c] border border-slate-800 rounded-xl p-4 shadow-xl space-y-4">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-slate-800 pb-3">
          <div>
            <div className="text-sm font-bold text-white flex items-center space-x-2">
              <span>LIVE PARTICIPANT POSITION TABLE</span>
              <span className="text-xs px-2 py-0.5 rounded bg-cyan-950 text-cyan-300 border border-cyan-800 font-mono">
                Index: {selectedIndex}
              </span>
            </div>
            <div className="text-xs text-slate-400">
              Contract breakdown for Futures, Call Options, Put Options, and Net Position
            </div>
          </div>

          {/* Toggle View: Compact vs Detailed */}
          <div className="flex items-center bg-slate-900 rounded-lg p-0.5 border border-slate-800 text-xs">
            <button
              onClick={() => setTableDetailMode('compact')}
              className={`px-3 py-1 rounded font-semibold transition-colors ${
                tableDetailMode === 'compact'
                  ? 'bg-cyan-500 text-slate-950'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Summary View
            </button>
            <button
              onClick={() => setTableDetailMode('detailed')}
              className={`px-3 py-1 rounded font-semibold transition-colors ${
                tableDetailMode === 'detailed'
                  ? 'bg-cyan-500 text-slate-950'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Full Breakdown (Fut & Options)
            </button>
          </div>
        </div>

        {/* Live Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-xs font-mono border-collapse min-w-[750px]">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 uppercase bg-[#080d17] text-[10.5px]">
                <th className="py-2.5 px-3 text-left">Participant</th>
                {tableDetailMode === 'detailed' && (
                  <>
                    <th className="py-2.5 px-2 text-center text-cyan-300" title="Futures Long / Short / Net">
                      Fut (Long / Short / Net)
                    </th>
                    <th className="py-2.5 px-2 text-center text-emerald-300" title="Call Options Long / Short / Net">
                      Calls (Long / Short / Net)
                    </th>
                    <th className="py-2.5 px-2 text-center text-rose-300" title="Put Options Long / Short / Net">
                      Puts (Long / Short / Net)
                    </th>
                  </>
                )}
                <th className="py-2.5 px-2.5 text-center text-slate-200">Total Long</th>
                <th className="py-2.5 px-2.5 text-center text-slate-200">Total Short</th>
                <th className="py-2.5 px-3 text-center text-cyan-300 font-extrabold">Net Position</th>
                <th className="py-2.5 px-2.5 text-center text-slate-200">Change (1D)</th>
                <th className="py-2.5 px-3 text-center text-slate-300 font-sans">Interpretation</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/70">
              {categories.map((cat) => {
                const pos = activeIndexData.participants[cat];
                const isNetLong = pos.netPosition >= 0;
                const isChangePos = pos.netChange >= 0;

                return (
                  <tr key={cat} className="hover:bg-slate-900/50 transition-colors">
                    {/* Participant Name */}
                    <td className="py-3 px-3 text-left font-bold text-white">
                      <div className="flex items-center space-x-2">
                        <span
                          className={`w-2 h-2 rounded-full ${
                            cat === 'FII'
                              ? 'bg-cyan-400'
                              : cat === 'DII'
                              ? 'bg-emerald-400'
                              : cat === 'PRO'
                              ? 'bg-purple-400'
                              : 'bg-amber-400'
                          }`}
                        />
                        <span className="text-sm">{pos.participant}</span>
                        <span className="text-[10px] text-slate-400 font-sans hidden sm:inline">
                          ({pos.name.split(' ')[0]})
                        </span>
                      </div>
                    </td>

                    {/* Detailed Columns if active */}
                    {tableDetailMode === 'detailed' && (
                      <>
                        {/* Futures: Long / Short / Net */}
                        <td className="py-3 px-2 text-center">
                          <div className="text-[11px] text-slate-300">
                            {pos.futLong.toLocaleString('en-IN')} / {pos.futShort.toLocaleString('en-IN')}
                          </div>
                          <div
                            className={`text-[10px] font-bold ${
                              pos.futNet >= 0 ? 'text-emerald-400' : 'text-rose-400'
                            }`}
                          >
                            Net: {pos.futNet >= 0 ? '+' : ''}{pos.futNet.toLocaleString('en-IN')}
                          </div>
                        </td>

                        {/* Calls: Long / Short / Net */}
                        <td className="py-3 px-2 text-center">
                          <div className="text-[11px] text-slate-300">
                            {pos.callLong.toLocaleString('en-IN')} / {pos.callShort.toLocaleString('en-IN')}
                          </div>
                          <div
                            className={`text-[10px] font-bold ${
                              pos.callNet >= 0 ? 'text-emerald-400' : 'text-rose-400'
                            }`}
                          >
                            Net: {pos.callNet >= 0 ? '+' : ''}{pos.callNet.toLocaleString('en-IN')}
                          </div>
                        </td>

                        {/* Puts: Long / Short / Net */}
                        <td className="py-3 px-2 text-center">
                          <div className="text-[11px] text-slate-300">
                            {pos.putLong.toLocaleString('en-IN')} / {pos.putShort.toLocaleString('en-IN')}
                          </div>
                          <div
                            className={`text-[10px] font-bold ${
                              pos.putNet >= 0 ? 'text-emerald-400' : 'text-rose-400'
                            }`}
                          >
                            Net: {pos.putNet >= 0 ? '+' : ''}{pos.putNet.toLocaleString('en-IN')}
                          </div>
                        </td>
                      </>
                    )}

                    {/* Total Long */}
                    <td className="py-3 px-2.5 text-center text-slate-300">
                      {pos.totalLong.toLocaleString('en-IN')}
                    </td>

                    {/* Total Short */}
                    <td className="py-3 px-2.5 text-center text-slate-300">
                      {pos.totalShort.toLocaleString('en-IN')}
                    </td>

                    {/* Net Position with Color Coding (Green = Net Long, Red = Net Short) */}
                    <td className="py-3 px-3 text-center">
                      <span
                        className={`inline-block px-2.5 py-1 rounded font-black text-xs ${
                          isNetLong
                            ? 'bg-emerald-950/80 text-emerald-400 border border-emerald-700/60'
                            : 'bg-rose-950/80 text-rose-400 border border-rose-700/60'
                        }`}
                      >
                        {isNetLong ? '+' : ''}
                        {pos.netPosition.toLocaleString('en-IN')}
                      </span>
                    </td>

                    {/* Change from previous day */}
                    <td className="py-3 px-2.5 text-center font-bold">
                      <span
                        className={`flex items-center justify-center space-x-0.5 ${
                          isChangePos ? 'text-emerald-400' : 'text-rose-400'
                        }`}
                      >
                        {isChangePos ? <ArrowUpRight className="w-3.5 h-3.5" /> : <ArrowDownRight className="w-3.5 h-3.5" />}
                        <span>
                          {isChangePos ? '+' : ''}
                          {pos.netChange.toLocaleString('en-IN')}
                        </span>
                      </span>
                    </td>

                    {/* Change Interpretation */}
                    <td className="py-3 px-3 text-center font-sans">
                      <span
                        className={`inline-block px-2 py-0.5 rounded text-[10.5px] font-bold tracking-wide ${getChangeBadge(
                          pos.changeType
                        )}`}
                      >
                        {pos.changeType}
                      </span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* CHANGE ANALYSIS BREAKDOWN (Specified in prompt) */}
      <div className="bg-[#0b101c] border border-slate-800 rounded-xl p-4 shadow-xl space-y-3">
        <div className="flex items-center justify-between border-b border-slate-800 pb-2.5">
          <div className="text-sm font-bold text-white flex items-center space-x-2">
            <span>CHANGE ANALYSIS</span>
            <span className="text-[10px] text-slate-400 font-normal">
              Decomposition into Long Addition, Short Addition, Short Covering, Long Unwinding
            </span>
          </div>
          <span className="text-xs text-cyan-400 font-mono font-bold">Index: {selectedIndex}</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
          {categories.map((cat) => {
            const pos = activeIndexData.participants[cat];
            return (
              <div key={cat} className="bg-slate-900/60 border border-slate-800 rounded-xl p-3.5 space-y-2">
                <div className="flex items-center justify-between border-b border-slate-800/80 pb-1.5">
                  <span className="font-extrabold text-white text-xs">{pos.name}</span>
                  <span className="text-[10px] px-1.5 rounded bg-slate-800 text-slate-300 font-mono font-bold">
                    {cat}
                  </span>
                </div>

                <div className="flex items-center justify-between text-xs">
                  <span className="text-slate-400">Previous Day:</span>
                  <span className="font-mono text-slate-300">
                    {pos.prevNetPosition.toLocaleString('en-IN')}
                  </span>
                </div>

                <div className="flex items-center justify-between text-xs">
                  <span className="text-slate-400">Current Day:</span>
                  <span
                    className={`font-mono font-bold ${
                      pos.netPosition >= 0 ? 'text-emerald-400' : 'text-rose-400'
                    }`}
                  >
                    {pos.netPosition.toLocaleString('en-IN')}
                  </span>
                </div>

                <div className="flex items-center justify-between text-xs border-t border-slate-800/60 pt-1">
                  <span className="text-slate-400">Net Change:</span>
                  <span
                    className={`font-mono font-extrabold ${
                      pos.netChange >= 0 ? 'text-emerald-400' : 'text-rose-400'
                    }`}
                  >
                    {pos.netChange >= 0 ? '+' : ''}
                    {pos.netChange.toLocaleString('en-IN')}
                  </span>
                </div>

                {/* Sub-breakdown */}
                <div className="grid grid-cols-2 gap-1 text-[10px] bg-slate-950/60 p-2 rounded border border-slate-800/60 mt-2">
                  <div>
                    <span className="text-emerald-400">Long Add:</span>{' '}
                    <span className="font-mono text-slate-300">{pos.longAddition.toLocaleString('en-IN')}</span>
                  </div>
                  <div>
                    <span className="text-rose-400">Short Add:</span>{' '}
                    <span className="font-mono text-slate-300">{pos.shortAddition.toLocaleString('en-IN')}</span>
                  </div>
                  <div>
                    <span className="text-blue-400">Short Cover:</span>{' '}
                    <span className="font-mono text-slate-300">{pos.shortCovering.toLocaleString('en-IN')}</span>
                  </div>
                  <div>
                    <span className="text-amber-400">Long Unwind:</span>{' '}
                    <span className="font-mono text-slate-300">{pos.longUnwinding.toLocaleString('en-IN')}</span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* SECTION TABS FOR DEEP DIVES: FII, DII, CLIENT, CHARTS, HEATMAP, ALERTS */}
      <div className="flex items-center flex-wrap gap-1 border-b border-slate-800 pb-1 text-xs">
        <button
          onClick={() => setActiveSection('overview')}
          className={`px-3 py-1.5 rounded-lg font-bold transition-all ${
            activeSection === 'overview'
              ? 'bg-cyan-500 text-slate-950'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
          }`}
        >
          All Insights
        </button>
        <button
          onClick={() => setActiveSection('fii')}
          className={`px-3 py-1.5 rounded-lg font-bold transition-all ${
            activeSection === 'fii'
              ? 'bg-cyan-500 text-slate-950'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
          }`}
        >
          FII Analytics
        </button>
        <button
          onClick={() => setActiveSection('dii')}
          className={`px-3 py-1.5 rounded-lg font-bold transition-all ${
            activeSection === 'dii'
              ? 'bg-cyan-500 text-slate-950'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
          }`}
        >
          DII Analytics
        </button>
        <button
          onClick={() => setActiveSection('client')}
          className={`px-3 py-1.5 rounded-lg font-bold transition-all ${
            activeSection === 'client'
              ? 'bg-cyan-500 text-slate-950'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
          }`}
        >
          Client / Retail
        </button>
        <button
          onClick={() => setActiveSection('charts')}
          className={`px-3 py-1.5 rounded-lg font-bold transition-all ${
            activeSection === 'charts'
              ? 'bg-cyan-500 text-slate-950'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
          }`}
        >
          Participant Charts
        </button>
        <button
          onClick={() => setActiveSection('heatmap')}
          className={`px-3 py-1.5 rounded-lg font-bold transition-all ${
            activeSection === 'heatmap'
              ? 'bg-cyan-500 text-slate-950'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
          }`}
        >
          Participant Heatmap
        </button>
        <button
          onClick={() => setActiveSection('alerts')}
          className={`px-3 py-1.5 rounded-lg font-bold transition-all ${
            activeSection === 'alerts'
              ? 'bg-cyan-500 text-slate-950'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
          }`}
        >
          Flow Alerts ({activeIndexData.alerts.length})
        </button>
      </div>

      {/* FII ANALYTICS TAB CONTENT (Specified in prompt) */}
      {(activeSection === 'overview' || activeSection === 'fii') && (
        <div className="bg-[#0b101c] border border-cyan-800/40 rounded-xl p-4 shadow-xl space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2.5">
            <div className="flex items-center space-x-2">
              <span className="p-1 rounded bg-cyan-950 text-cyan-300">
                <Globe className="w-4 h-4" />
              </span>
              <span className="text-sm font-bold text-white uppercase tracking-wider">
                FII ANALYTICS (Foreign Institutional Investors) — {selectedIndex}
              </span>
            </div>
            <span className="text-xs text-slate-400 font-mono">NSE Participant Report</span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
            <div className="bg-slate-900/60 border border-slate-800 rounded-lg p-3">
              <div className="text-[10px] text-slate-400">Total Futures Long</div>
              <div className="text-base font-extrabold text-emerald-400 font-mono mt-0.5">
                {activeIndexData.participants.FII.futLong.toLocaleString('en-IN')}
              </div>
            </div>
            <div className="bg-slate-900/60 border border-slate-800 rounded-lg p-3">
              <div className="text-[10px] text-slate-400">Total Futures Short</div>
              <div className="text-base font-extrabold text-rose-400 font-mono mt-0.5">
                {activeIndexData.participants.FII.futShort.toLocaleString('en-IN')}
              </div>
            </div>
            <div className="bg-slate-900/60 border border-slate-800 rounded-lg p-3">
              <div className="text-[10px] text-slate-400">Net Position</div>
              <div
                className={`text-base font-black font-mono mt-0.5 ${
                  activeIndexData.participants.FII.netPosition >= 0 ? 'text-emerald-400' : 'text-rose-400'
                }`}
              >
                {activeIndexData.participants.FII.netPosition >= 0 ? '+' : ''}
                {activeIndexData.participants.FII.netPosition.toLocaleString('en-IN')}
              </div>
            </div>
            <div className="bg-slate-900/60 border border-slate-800 rounded-lg p-3">
              <div className="text-[10px] text-slate-400">Daily Change</div>
              <div
                className={`text-base font-bold font-mono mt-0.5 ${
                  activeIndexData.participants.FII.dailyChange >= 0 ? 'text-emerald-400' : 'text-rose-400'
                }`}
              >
                {activeIndexData.participants.FII.dailyChange >= 0 ? '+' : ''}
                {activeIndexData.participants.FII.dailyChange.toLocaleString('en-IN')}
              </div>
            </div>
            <div className="bg-slate-900/60 border border-slate-800 rounded-lg p-3">
              <div className="text-[10px] text-slate-400">Weekly Change</div>
              <div
                className={`text-base font-bold font-mono mt-0.5 ${
                  activeIndexData.participants.FII.weeklyChange >= 0 ? 'text-emerald-400' : 'text-rose-400'
                }`}
              >
                {activeIndexData.participants.FII.weeklyChange >= 0 ? '+' : ''}
                {activeIndexData.participants.FII.weeklyChange.toLocaleString('en-IN')}
              </div>
            </div>
            <div className="bg-slate-900/60 border border-slate-800 rounded-lg p-3">
              <div className="text-[10px] text-slate-400">Monthly Change</div>
              <div
                className={`text-base font-bold font-mono mt-0.5 ${
                  activeIndexData.participants.FII.monthlyChange >= 0 ? 'text-emerald-400' : 'text-rose-400'
                }`}
              >
                {activeIndexData.participants.FII.monthlyChange >= 0 ? '+' : ''}
                {activeIndexData.participants.FII.monthlyChange.toLocaleString('en-IN')}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* DII & CLIENT ANALYTICS (Specified in prompt) */}
      {(activeSection === 'overview' || activeSection === 'dii' || activeSection === 'client') && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* DII Analytics */}
          <div className="bg-[#0b101c] border border-emerald-800/40 rounded-xl p-4 shadow-xl space-y-3">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <span className="text-sm font-bold text-white uppercase tracking-wider">
                DII ANALYTICS (Domestic Institutions)
              </span>
              <span className="text-xs text-emerald-400 font-mono font-bold">Mutual Funds & LIC</span>
            </div>

            <div className="grid grid-cols-2 gap-3 text-xs">
              <div className="bg-slate-900/60 border border-slate-800 rounded-lg p-3">
                <div className="text-slate-400 text-[10px]">Net Long Position</div>
                <div className="text-base font-extrabold text-emerald-400 font-mono mt-0.5">
                  +{activeIndexData.participants.DII.netPosition.toLocaleString('en-IN')}
                </div>
              </div>
              <div className="bg-slate-900/60 border border-slate-800 rounded-lg p-3">
                <div className="text-slate-400 text-[10px]">Trend Direction</div>
                <div className="text-base font-extrabold text-emerald-300 font-mono mt-0.5">
                  Accumulating
                </div>
              </div>
            </div>

            <div className="bg-slate-900/40 border border-slate-800 p-2.5 rounded-lg text-xs flex items-center justify-between">
              <span className="text-slate-300">Institutional Sentiment:</span>
              <span className="font-extrabold text-emerald-400 uppercase">
                {activeIndexData.sentiment.institutional}
              </span>
            </div>
          </div>

          {/* Client Analytics */}
          <div className="bg-[#0b101c] border border-amber-800/40 rounded-xl p-4 shadow-xl space-y-3">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <span className="text-sm font-bold text-white uppercase tracking-wider">
                CLIENT ANALYTICS (Retail Traders)
              </span>
              <span className="text-xs text-amber-400 font-mono font-bold">Contrarian Indicator</span>
            </div>

            <div className="grid grid-cols-2 gap-3 text-xs">
              <div className="bg-slate-900/60 border border-slate-800 rounded-lg p-3">
                <div className="text-slate-400 text-[10px]">Retail Long %</div>
                <div className="text-base font-extrabold text-amber-400 font-mono mt-0.5">
                  {retailLongPct}%
                </div>
              </div>
              <div className="bg-slate-900/60 border border-slate-800 rounded-lg p-3">
                <div className="text-slate-400 text-[10px]">Retail Short %</div>
                <div className="text-base font-extrabold text-rose-400 font-mono mt-0.5">
                  {retailShortPct}%
                </div>
              </div>
            </div>

            <div className="bg-slate-900/40 border border-slate-800 p-2.5 rounded-lg text-xs flex items-center justify-between">
              <span className="text-slate-300">Retail Bias:</span>
              <span className="font-extrabold text-rose-400 uppercase">
                {activeIndexData.sentiment.retail} (Trapped in Puts)
              </span>
            </div>
          </div>
        </div>
      )}

      {/* PARTICIPANT CHARTS (Specified in prompt) */}
      {(activeSection === 'overview' || activeSection === 'charts') && (
        <ParticipantChart indexData={activeIndexData} />
      )}

      {/* HEATMAP MATRIX (Specified in prompt) */}
      {(activeSection === 'overview' || activeSection === 'heatmap') && (
        <ParticipantHeatmap
          data={allData}
          selectedIndex={selectedIndex}
          onSelectIndex={(idx) => {
            setSelectedIndex(idx);
            setViewMode('single');
          }}
        />
      )}

      {/* FLOW ALERTS (Specified in prompt: Alert when FII Change > 10%, DII Change > 10%, etc.) */}
      {(activeSection === 'overview' || activeSection === 'alerts') && (
        <div className="bg-[#0b101c] border border-slate-800 rounded-xl p-4 shadow-xl space-y-3">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2.5">
            <div className="text-sm font-bold text-white flex items-center space-x-2">
              <ShieldAlert className="w-4 h-4 text-cyan-400" />
              <span>FLOW ALERTS & SMART MONEY REVERSALS</span>
            </div>
            <span className="text-xs text-slate-400">Trigger Thresholds: &gt; 10% Position Shifts</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            {activeIndexData.alerts.length > 0 ? (
              activeIndexData.alerts.map((alt) => (
                <div
                  key={alt.id}
                  className={`p-3 rounded-lg border flex flex-col justify-between ${
                    alt.severity === 'HIGH'
                      ? 'bg-rose-950/30 border-rose-700/60'
                      : alt.severity === 'MEDIUM'
                      ? 'bg-amber-950/30 border-amber-700/60'
                      : 'bg-cyan-950/30 border-cyan-700/60'
                  }`}
                >
                  <div>
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-bold text-white">{alt.title}</span>
                      <span className="text-[10px] text-slate-400 font-mono">{alt.timestamp}</span>
                    </div>
                    <p className="text-xs text-slate-300 mt-1">{alt.message}</p>
                  </div>
                  <div className="mt-2 text-[10px] uppercase font-mono font-bold tracking-wider text-cyan-400">
                    Active Signal
                  </div>
                </div>
              ))
            ) : (
              <div className="col-span-3 text-center py-4 text-xs text-slate-500">
                No active threshold alerts triggered on {selectedIndex} currently.
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
