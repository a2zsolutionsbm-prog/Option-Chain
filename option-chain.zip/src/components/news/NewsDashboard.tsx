import React, { useState, useMemo, useEffect } from 'react';
import {
  Globe,
  TrendingUp,
  TrendingDown,
  Minus,
  Search,
  Filter,
  RefreshCw,
  Bookmark,
  BookmarkCheck,
  Share2,
  ExternalLink,
  Flame,
  Clock,
  Sparkles,
  CheckCircle,
  Building2,
  DollarSign,
  Layers,
  ChevronRight,
  X,
  Volume2,
  VolumeX,
} from 'lucide-react';
import {
  MarketNewsItem,
  NewsRegion,
  NewsCategory,
  NewsSentiment,
  INITIAL_NEWS_ITEMS,
} from '../../services/newsData';
import { soundEngine } from '../../utils/audioAlert';

export const NewsDashboard: React.FC = () => {
  const [news, setNews] = useState<MarketNewsItem[]>(INITIAL_NEWS_ITEMS);
  const [selectedRegion, setSelectedRegion] = useState<'ALL' | 'GLOBAL' | 'INDIA' | 'USA' | 'EUROPE' | 'ASIA_PACIFIC'>('ALL');
  const [selectedCategory, setSelectedCategory] = useState<NewsCategory>('ALL');
  const [selectedSentiment, setSelectedSentiment] = useState<'ALL' | NewsSentiment>('ALL');
  const [highImpactOnly, setHighImpactOnly] = useState<boolean>(false);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [bookmarkedOnly, setBookmarkedOnly] = useState<boolean>(false);
  const [bookmarkedIds, setBookmarkedIds] = useState<Set<string>>(new Set());
  const [selectedArticle, setSelectedArticle] = useState<MarketNewsItem | null>(null);
  const [isRefreshing, setIsRefreshing] = useState<boolean>(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  // Region tabs
  const regionTabs = [
    { id: 'ALL', label: 'All News', icon: '🌐' },
    { id: 'GLOBAL', label: 'Global News', icon: '🌍' },
    { id: 'INDIA', label: 'Country News (India)', icon: '🇮🇳' },
    { id: 'USA', label: 'United States', icon: '🇺🇸' },
    { id: 'EUROPE', label: 'Europe & UK', icon: '🇪🇺' },
    { id: 'ASIA_PACIFIC', label: 'Asia-Pacific', icon: '🇯🇵' },
  ] as const;

  // Category filters
  const categoryFilters: { id: NewsCategory; label: string }[] = [
    { id: 'ALL', label: 'All Categories' },
    { id: 'INDIA', label: '🇮🇳 India Domestic' },
    { id: 'GLOBAL', label: '🌐 Global Markets' },
    { id: 'CENTRAL_BANKS', label: '🏦 Central Banks & Macro' },
    { id: 'DERIVATIVES', label: '⚡ Derivatives & F&O' },
    { id: 'COMMODITIES_FX', label: '🛢️ Commodities & FX' },
    { id: 'EARNINGS_SECTOR', label: '📊 Corporate & Earnings' },
  ];

  // Toggle bookmark
  const toggleBookmark = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setBookmarkedIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) {
        next.delete(id);
      } else {
        next.add(id);
        soundEngine.playClickSound();
      }
      return next;
    });
  };

  // Copy headline
  const handleCopy = (item: MarketNewsItem, e: React.MouseEvent) => {
    e.stopPropagation();
    navigator.clipboard?.writeText(`${item.title}\nSource: ${item.source}`);
    setCopiedId(item.id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  // Manual refresh animation
  const handleRefresh = () => {
    setIsRefreshing(true);
    soundEngine.playClickSound();
    setTimeout(() => {
      setIsRefreshing(false);
    }, 600);
  };

  // Breaking news ticker items
  const breakingNews = useMemo(() => {
    return news.filter((n) => n.isBreaking || n.impact === 'HIGH').slice(0, 3);
  }, [news]);

  // Filtered news items
  const filteredNews = useMemo(() => {
    return news.filter((item) => {
      // Region filter
      if (selectedRegion === 'GLOBAL' && item.region === 'INDIA') return false;
      if (selectedRegion === 'INDIA' && item.region !== 'INDIA') return false;
      if (selectedRegion === 'USA' && item.region !== 'USA') return false;
      if (selectedRegion === 'EUROPE' && item.region !== 'EUROPE') return false;
      if (selectedRegion === 'ASIA_PACIFIC' && item.region !== 'ASIA_PACIFIC') return false;

      // Category filter
      if (selectedCategory !== 'ALL' && item.category !== selectedCategory) return false;

      // Sentiment filter
      if (selectedSentiment !== 'ALL' && item.sentiment !== selectedSentiment) return false;

      // High impact filter
      if (highImpactOnly && item.impact !== 'HIGH') return false;

      // Bookmarked filter
      if (bookmarkedOnly && !bookmarkedIds.has(item.id)) return false;

      // Search query
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchesTitle = item.title.toLowerCase().includes(q);
        const matchesSummary = item.summary.toLowerCase().includes(q);
        const matchesSource = item.source.toLowerCase().includes(q);
        const matchesTicker = item.tickers.some((t) => t.toLowerCase().includes(q));
        if (!matchesTitle && !matchesSummary && !matchesSource && !matchesTicker) return false;
      }

      return true;
    });
  }, [news, selectedRegion, selectedCategory, selectedSentiment, highImpactOnly, bookmarkedOnly, bookmarkedIds, searchQuery]);

  // Sentiment counts
  const stats = useMemo(() => {
    const total = news.length;
    const bullish = news.filter((n) => n.sentiment === 'BULLISH').length;
    const bearish = news.filter((n) => n.sentiment === 'BEARISH').length;
    const neutral = news.filter((n) => n.sentiment === 'NEUTRAL').length;
    const high = news.filter((n) => n.impact === 'HIGH').length;
    return { total, bullish, bearish, neutral, high };
  }, [news]);

  return (
    <div className="flex-1 flex flex-col h-full bg-[#070b13] overflow-y-auto">
      {/* 1. Breaking News Wire Bar */}
      <div className="bg-[#0b111e] border-b border-slate-800/80 px-4 py-2 flex items-center justify-between gap-3 text-xs">
        <div className="flex items-center space-x-2 shrink-0">
          <span className="flex h-2 w-2 relative">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-rose-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2 w-2 bg-rose-500"></span>
          </span>
          <span className="bg-rose-500/10 border border-rose-500/30 text-rose-400 font-bold px-2 py-0.5 rounded text-[10px] tracking-wider uppercase flex items-center space-x-1">
            <Flame className="w-3 h-3 mr-1 text-rose-400" />
            LIVE WIRE
          </span>
        </div>

        <div className="flex-1 overflow-hidden">
          <div className="flex items-center space-x-6 text-slate-300 overflow-x-auto no-scrollbar whitespace-nowrap">
            {breakingNews.map((item, idx) => (
              <button
                key={item.id}
                onClick={() => setSelectedArticle(item)}
                className="hover:text-cyan-400 text-left transition-colors flex items-center space-x-2"
              >
                <span className="text-slate-400 text-[11px]">[{item.timestamp}]</span>
                <span className="font-medium text-xs">{item.title}</span>
                {idx < breakingNews.length - 1 && (
                  <span className="text-slate-600 font-bold">|</span>
                )}
              </button>
            ))}
          </div>
        </div>

        <div className="flex items-center space-x-2 shrink-0">
          <button
            onClick={handleRefresh}
            title="Refresh News Feed"
            className="p-1 text-slate-400 hover:text-cyan-400 transition-colors rounded hover:bg-slate-800/60"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isRefreshing ? 'animate-spin text-cyan-400' : ''}`} />
          </button>
        </div>
      </div>

      {/* 2. Top Header & Stats Summary */}
      <div className="p-4 sm:p-5 border-b border-slate-800/80 bg-gradient-to-b from-[#0b101c] to-[#070b13]">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center space-x-2">
              <span className="text-2xl">📰</span>
              <h1 className="text-xl font-bold text-white tracking-tight flex items-center space-x-2">
                <span>Global & Country News</span>
                <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
                  REAL-TIME DISPATCH
                </span>
              </h1>
            </div>
            <p className="text-xs text-slate-400 mt-1">
              Live market intelligence covering India macro, RBI policy, global central banks, F&O derivatives, commodities & forex.
            </p>
          </div>

          {/* Quick Metrics Bar */}
          <div className="flex items-center gap-3 overflow-x-auto no-scrollbar">
            <div className="bg-slate-900/80 border border-slate-800 px-3 py-1.5 rounded-lg flex items-center space-x-2">
              <span className="text-[11px] text-slate-400">Total Updates:</span>
              <span className="text-xs font-bold text-white">{stats.total}</span>
            </div>
            <div className="bg-slate-900/80 border border-emerald-900/40 px-3 py-1.5 rounded-lg flex items-center space-x-2">
              <TrendingUp className="w-3.5 h-3.5 text-emerald-400" />
              <span className="text-[11px] text-emerald-400 font-semibold">{stats.bullish} Bullish</span>
            </div>
            <div className="bg-slate-900/80 border border-rose-900/40 px-3 py-1.5 rounded-lg flex items-center space-x-2">
              <TrendingDown className="w-3.5 h-3.5 text-rose-400" />
              <span className="text-[11px] text-rose-400 font-semibold">{stats.bearish} Bearish</span>
            </div>
            <div className="bg-slate-900/80 border border-amber-900/40 px-3 py-1.5 rounded-lg flex items-center space-x-2">
              <Flame className="w-3.5 h-3.5 text-amber-400" />
              <span className="text-[11px] text-amber-400 font-semibold">{stats.high} High Impact</span>
            </div>
          </div>
        </div>

        {/* 3. Primary Region Switcher (Global vs Country/India) */}
        <div className="max-w-7xl mx-auto mt-5">
          <div className="flex items-center space-x-2 overflow-x-auto no-scrollbar pb-1">
            {regionTabs.map((tab) => {
              const isSelected = selectedRegion === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => {
                    setSelectedRegion(tab.id as any);
                    soundEngine.playClickSound();
                  }}
                  className={`flex items-center space-x-2 px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all whitespace-nowrap ${
                    isSelected
                      ? 'bg-cyan-500 text-slate-950 border border-cyan-400 shadow-sm'
                      : 'bg-slate-900/60 text-slate-400 border border-slate-800/80 hover:text-slate-200 hover:bg-slate-800/60'
                  }`}
                >
                  <span>{tab.icon}</span>
                  <span>{tab.label}</span>
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* 4. Controls: Categories, Sentiment, Impact, Search */}
      <div className="px-4 sm:px-5 py-3 border-b border-slate-800/60 bg-[#090e18]">
        <div className="max-w-7xl mx-auto flex flex-col lg:flex-row items-stretch lg:items-center justify-between gap-3">
          {/* Category Chips */}
          <div className="flex items-center space-x-1.5 overflow-x-auto no-scrollbar py-1">
            {categoryFilters.map((cat) => {
              const isSelected = selectedCategory === cat.id;
              return (
                <button
                  key={cat.id}
                  onClick={() => {
                    setSelectedCategory(cat.id);
                    soundEngine.playClickSound();
                  }}
                  className={`px-2.5 py-1 rounded text-[11px] transition-all whitespace-nowrap ${
                    isSelected
                      ? 'bg-cyan-500 text-slate-950 font-bold shadow-sm'
                      : 'bg-slate-900 text-slate-400 border border-slate-800/80 hover:text-slate-200 hover:bg-slate-800 font-medium'
                  }`}
                >
                  {cat.label}
                </button>
              );
            })}
          </div>

          {/* Search & Sentiment Filters */}
          <div className="flex items-center space-x-2 shrink-0">
            {/* Search Input */}
            <div className="relative flex-1 sm:w-60">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search news, tickers (e.g. NIFTY, RBI)..."
                className="w-full bg-slate-950 border border-slate-800 rounded-lg pl-8 pr-3 py-1 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500/60"
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
                >
                  <X className="w-3 h-3" />
                </button>
              )}
            </div>

            {/* High Impact Toggle */}
            <button
              onClick={() => {
                setHighImpactOnly(!highImpactOnly);
                soundEngine.playClickSound();
              }}
              className={`flex items-center space-x-1 px-2.5 py-1 rounded text-xs border transition-colors ${
                highImpactOnly
                  ? 'bg-amber-500/15 border-amber-500/40 text-amber-300 font-semibold'
                  : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-slate-200'
              }`}
            >
              <Flame className="w-3 h-3 text-amber-400" />
              <span>High Impact</span>
            </button>

            {/* Bookmarks Toggle */}
            <button
              onClick={() => {
                setBookmarkedOnly(!bookmarkedOnly);
                soundEngine.playClickSound();
              }}
              className={`p-1.5 rounded text-xs border transition-colors ${
                bookmarkedOnly
                  ? 'bg-cyan-500/15 border-cyan-500/40 text-cyan-300 font-semibold'
                  : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-slate-200'
              }`}
              title="Saved Articles"
            >
              <Bookmark className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>

      {/* 5. Main News Grid / Feed */}
      <div className="flex-1 p-4 sm:p-5 max-w-7xl mx-auto w-full">
        {filteredNews.length === 0 ? (
          <div className="text-center py-16 bg-[#0a0f1d] rounded-xl border border-slate-800/80 p-8">
            <Globe className="w-12 h-12 text-slate-600 mx-auto mb-3" />
            <h3 className="text-base font-semibold text-slate-300">No news articles found</h3>
            <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
              Try adjusting your search criteria, region filters, or resetting high-impact filters.
            </p>
            <button
              onClick={() => {
                setSelectedRegion('ALL');
                setSelectedCategory('ALL');
                setSelectedSentiment('ALL');
                setHighImpactOnly(false);
                setBookmarkedOnly(false);
                setSearchQuery('');
              }}
              className="mt-4 px-3.5 py-1.5 bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-semibold rounded-lg transition-colors"
            >
              Reset All Filters
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {filteredNews.map((item) => {
              const isSaved = bookmarkedIds.has(item.id);
              return (
                <div
                  key={item.id}
                  onClick={() => setSelectedArticle(item)}
                  className="bg-[#0b101c] hover:bg-[#0e1526] border border-slate-800/80 hover:border-slate-700 rounded-xl p-4 transition-all duration-150 flex flex-col justify-between group cursor-pointer shadow-sm hover:shadow-cyan-950/20"
                >
                  <div>
                    {/* Top Row: Region & Category & Impact Badges */}
                    <div className="flex items-center justify-between gap-2 mb-2.5">
                      <div className="flex items-center space-x-1.5 flex-wrap gap-y-1">
                        {/* Region pill */}
                        <span className="text-[10px] font-semibold px-2 py-0.5 rounded bg-slate-900 border border-slate-700/80 text-slate-300 flex items-center space-x-1">
                          <span>
                            {item.region === 'INDIA' && '🇮🇳 India'}
                            {item.region === 'GLOBAL' && '🌐 Global'}
                            {item.region === 'USA' && '🇺🇸 USA'}
                            {item.region === 'EUROPE' && '🇪🇺 Europe'}
                            {item.region === 'ASIA_PACIFIC' && '🇯🇵 Asia'}
                          </span>
                        </span>

                        {/* Impact pill */}
                        {item.impact === 'HIGH' && (
                          <span className="text-[9px] font-bold px-1.5 py-0.5 rounded bg-rose-500/15 border border-rose-500/30 text-rose-300 flex items-center space-x-1">
                            <Flame className="w-2.5 h-2.5 text-rose-400" />
                            <span>HIGH IMPACT</span>
                          </span>
                        )}

                        {/* Sentiment pill */}
                        <span
                          className={`text-[9px] font-bold px-1.5 py-0.5 rounded border flex items-center space-x-0.5 ${
                            item.sentiment === 'BULLISH'
                              ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400'
                              : item.sentiment === 'BEARISH'
                              ? 'bg-rose-500/10 border-rose-500/30 text-rose-400'
                              : 'bg-slate-800 border-slate-700 text-slate-400'
                          }`}
                        >
                          {item.sentiment === 'BULLISH' && <TrendingUp className="w-2.5 h-2.5" />}
                          {item.sentiment === 'BEARISH' && <TrendingDown className="w-2.5 h-2.5" />}
                          {item.sentiment === 'NEUTRAL' && <Minus className="w-2.5 h-2.5" />}
                          <span>{item.sentiment}</span>
                        </span>
                      </div>

                      {/* Time Ago */}
                      <div className="flex items-center space-x-1 text-[11px] text-slate-400 shrink-0">
                        <Clock className="w-3 h-3 text-slate-400" />
                        <span>{item.timeAgo}</span>
                      </div>
                    </div>

                    {/* Headline */}
                    <h3 className="text-sm font-semibold text-white group-hover:text-cyan-300 transition-colors leading-snug">
                      {item.title}
                    </h3>

                    {/* Summary */}
                    <p className="text-xs text-slate-400 mt-2 line-clamp-3 leading-relaxed">
                      {item.summary}
                    </p>

                    {/* Market Implications for Derivatives */}
                    {item.marketImpactDetail && (
                      <div className="mt-3 p-2.5 rounded-lg bg-[#070b13] border border-cyan-900/30 text-xs">
                        <div className="flex items-center space-x-1 text-[11px] font-bold text-cyan-400 mb-1">
                          <Sparkles className="w-3 h-3 text-cyan-400" />
                          <span>Derivatives & Strike Impact:</span>
                        </div>
                        <p className="text-slate-300 text-[11px] leading-relaxed">
                          {item.marketImpactDetail}
                        </p>
                      </div>
                    )}
                  </div>

                  {/* Bottom Row: Source, Tickers, Action buttons */}
                  <div className="mt-4 pt-3 border-t border-slate-800/80 flex items-center justify-between gap-2">
                    <div className="flex items-center space-x-1.5 flex-wrap gap-y-1">
                      <span className="text-[10px] text-slate-400 font-medium">
                        {item.source}
                      </span>
                      {item.tickers.slice(0, 3).map((t) => (
                        <span
                          key={t}
                          className="text-[9px] font-mono font-bold bg-slate-900 px-1.5 py-0.5 rounded text-slate-300 border border-slate-800"
                        >
                          {t}
                        </span>
                      ))}
                    </div>

                    <div className="flex items-center space-x-2">
                      {/* Copy button */}
                      <button
                        onClick={(e) => handleCopy(item, e)}
                        title="Copy News"
                        className="p-1 text-slate-400 hover:text-slate-200 hover:bg-slate-800 rounded transition-colors"
                      >
                        {copiedId === item.id ? (
                          <CheckCircle className="w-3.5 h-3.5 text-emerald-400" />
                        ) : (
                          <Share2 className="w-3.5 h-3.5" />
                        )}
                      </button>

                      {/* Bookmark button */}
                      <button
                        onClick={(e) => toggleBookmark(item.id, e)}
                        title="Bookmark"
                        className={`p-1 rounded transition-colors ${
                          isSaved
                            ? 'text-cyan-400 bg-cyan-950/40'
                            : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
                        }`}
                      >
                        {isSaved ? (
                          <BookmarkCheck className="w-3.5 h-3.5" />
                        ) : (
                          <Bookmark className="w-3.5 h-3.5" />
                        )}
                      </button>

                      {/* Read More button */}
                      <span className="text-[11px] text-cyan-400 font-medium flex items-center group-hover:translate-x-0.5 transition-transform">
                        <span>Details</span>
                        <ChevronRight className="w-3.5 h-3.5 ml-0.5" />
                      </span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* 6. Article Details Modal */}
      {selectedArticle && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm">
          <div className="bg-[#0b101c] border border-slate-700 rounded-xl max-w-2xl w-full max-h-[85vh] flex flex-col shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-150">
            {/* Modal Header */}
            <div className="px-5 py-4 border-b border-slate-800 flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-slate-900 border border-slate-700 text-slate-300">
                  {selectedArticle.region === 'INDIA' ? '🇮🇳 India Market' : '🌐 Global Market'}
                </span>
                <span
                  className={`text-[9px] font-bold px-2 py-0.5 rounded border ${
                    selectedArticle.sentiment === 'BULLISH'
                      ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400'
                      : selectedArticle.sentiment === 'BEARISH'
                      ? 'bg-rose-500/10 border-rose-500/30 text-rose-400'
                      : 'bg-slate-800 border-slate-700 text-slate-400'
                  }`}
                >
                  {selectedArticle.sentiment} SENTIMENT
                </span>
              </div>
              <button
                onClick={() => setSelectedArticle(null)}
                className="p-1 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Body */}
            <div className="p-5 overflow-y-auto space-y-4">
              <h2 className="text-lg font-bold text-white leading-snug">
                {selectedArticle.title}
              </h2>

              <div className="flex items-center space-x-3 text-xs text-slate-400 border-b border-slate-800/80 pb-3">
                <span>Source: <strong className="text-slate-300">{selectedArticle.source}</strong></span>
                <span>•</span>
                <span>Published: {selectedArticle.timestamp}</span>
              </div>

              <div>
                <h4 className="text-xs font-semibold text-slate-300 mb-1.5">Executive Summary</h4>
                <p className="text-xs text-slate-300 leading-relaxed bg-[#070b13] p-3 rounded-lg border border-slate-800">
                  {selectedArticle.summary}
                </p>
              </div>

              {selectedArticle.fullContent && (
                <div>
                  <h4 className="text-xs font-semibold text-slate-300 mb-1.5">Comprehensive Market Analysis</h4>
                  <p className="text-xs text-slate-300 leading-relaxed whitespace-pre-line">
                    {selectedArticle.fullContent}
                  </p>
                </div>
              )}

              {selectedArticle.marketImpactDetail && (
                <div className="p-3.5 rounded-lg bg-cyan-950/20 border border-cyan-500/30">
                  <h4 className="text-xs font-bold text-cyan-400 flex items-center space-x-1.5 mb-1.5">
                    <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
                    <span>Options & Trading Strategy Takeaways</span>
                  </h4>
                  <p className="text-xs text-slate-200 leading-relaxed">
                    {selectedArticle.marketImpactDetail}
                  </p>
                </div>
              )}

              {/* Related Tickers */}
              <div>
                <h4 className="text-xs font-semibold text-slate-400 mb-1.5">Related Instruments & Underlying:</h4>
                <div className="flex items-center space-x-2 flex-wrap gap-y-1">
                  {selectedArticle.tickers.map((t) => (
                    <span
                      key={t}
                      className="px-2.5 py-1 bg-slate-900 border border-slate-700 rounded-md text-xs font-mono font-bold text-cyan-300"
                    >
                      ${t}
                    </span>
                  ))}
                </div>
              </div>
            </div>

            {/* Modal Footer */}
            <div className="px-5 py-3 border-t border-slate-800 bg-[#080d17] flex items-center justify-between">
              <span className="text-[11px] text-slate-400">
                Verified financial intelligence feed
              </span>
              <button
                onClick={() => setSelectedArticle(null)}
                className="px-4 py-1.5 bg-slate-800 hover:bg-slate-700 text-white rounded-lg text-xs font-semibold transition-colors"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
