export type IndexSymbol = 'NIFTY' | 'BANKNIFTY' | 'FINNIFTY' | 'MIDCPNIFTY' | 'SENSEX';

export type UserRole = 'ADMIN' | 'PREMIUM' | 'RETAIL';

export type OptionType = 'CE' | 'PE';
export type LegAction = 'BUY' | 'SELL';

export type OIBuildupType = 
  | 'LONG_BUILDUP' 
  | 'SHORT_BUILDUP' 
  | 'LONG_UNWINDING' 
  | 'SHORT_COVERING' 
  | 'NEUTRAL';

export interface Greeks {
  delta: number;
  gamma: number;
  theta: number;
  vega: number;
  rho: number;
  iv: number; // in percentage e.g. 14.5
}

export interface OptionContractData {
  strike: number;
  type: OptionType;
  ltp: number;
  prevClose: number;
  change: number;
  pChange: number;
  oi: number; // in contracts
  prevOi: number;
  changeOi: number;
  pChangeOi: number;
  volume: number;
  iv: number;
  greeks: Greeks;
  bid: number;
  ask: number;
  buildup: OIBuildupType;
  lastTickDir?: 'up' | 'down' | 'same';
}

export interface StrikeRow {
  strike: number;
  call: OptionContractData;
  put: OptionContractData;
  isAtm: boolean;
  isItmCall: boolean;
  isItmPut: boolean;
  isMaxPain: boolean;
  isHighestCeOi: boolean;
  isHighestPeOi: boolean;
}

export interface IndexMarketData {
  symbol: IndexSymbol;
  name: string;
  spotPrice: number;
  futurePrice: number;
  prevClose: number;
  change: number;
  pChange: number;
  high: number;
  low: number;
  open: number;
  lotSize: number;
  strikeStep: number;
  vix: number;
  expiries: string[];
  currentExpiry: string;
  marketStatus: 'OPEN' | 'CLOSED';
}

export interface StrategyLeg {
  id: string;
  type: OptionType;
  action: LegAction;
  strike: number;
  lots: number;
  lotSize: number;
  price: number;
  iv: number;
  greeks: Greeks;
}

export interface StrategyMetrics {
  netCreditDebit: number; // positive = credit received, negative = debit paid
  maxProfit: number | 'UNLIMITED';
  maxLoss: number | 'UNLIMITED';
  riskRewardRatio: string;
  breakevens: number[];
  probabilityOfProfit: number; // percentage
  netDelta: number;
  netTheta: number;
  netGamma: number;
  netVega: number;
  estimatedMargin: number;
}

export interface PayoffPoint {
  spotPrice: number;
  expiryPayoff: number;
  t0Payoff: number;
}

export interface AlertItem {
  id: string;
  type: 'PRICE' | 'OI' | 'PCR' | 'MAX_PAIN';
  symbol: IndexSymbol;
  strike?: number;
  optionType?: OptionType;
  condition: 'ABOVE' | 'BELOW' | 'CROSSES';
  threshold: number;
  createdAt: string;
  active: boolean;
  triggered: boolean;
  triggeredAt?: string;
  telegramEnabled: boolean;
  note: string;
}

export interface WatchlistItem {
  id: string;
  symbol: IndexSymbol;
  expiry: string;
  strike: number;
  type: OptionType;
  addedAt: string;
  targetPrice?: number;
  stopLoss?: number;
}

export interface ScannerSignal {
  id: string;
  symbol: IndexSymbol;
  strike: number;
  type: OptionType;
  title: string;
  category: 'UNUSUAL_OI' | 'IV_SPIKE' | 'SHORT_COVERING' | 'PUT_WRITING' | 'BREAKOUT';
  description: string;
  sentiment: 'BULLISH' | 'BEARISH' | 'NEUTRAL';
  oiChangePercent: number;
  volumePercent: number;
  timestamp: string;
}

export interface UserAccount {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  plan: 'Retail Free' | 'Pro Monthly' | 'Institutional Annual';
  status: 'ACTIVE' | 'SUSPENDED';
  joinedDate: string;
  lastLogin: string;
  maxAlerts: number;
}

export interface SystemBroadcast {
  id: string;
  title: string;
  message: string;
  level: 'INFO' | 'WARNING' | 'CRITICAL';
  timestamp: string;
  active: boolean;
}

export interface MarketHoliday {
  date: string;
  day: string;
  occasion: string;
  status: 'CLOSED' | 'SPECIAL_TRADING';
}
