-- ============================================================================
-- DIGISERVICE OPTION CHAIN PRO - DATABASE SCHEMA & SQL MIGRATIONS
-- Compatible with PostgreSQL 15+ & Supabase
-- ============================================================================

-- Enable required extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- 1. USERS & PROFILES TABLE
CREATE TYPE user_role AS ENUM ('ADMIN', 'PREMIUM', 'RETAIL');
CREATE TYPE account_status AS ENUM ('ACTIVE', 'SUSPENDED', 'PENDING');

CREATE TABLE IF NOT EXISTS users (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    email VARCHAR(255) UNIQUE NOT NULL,
    encrypted_password TEXT NOT NULL,
    full_name VARCHAR(150),
    role user_role DEFAULT 'RETAIL' NOT NULL,
    status account_status DEFAULT 'ACTIVE' NOT NULL,
    telegram_chat_id VARCHAR(100),
    telegram_alerts_enabled BOOLEAN DEFAULT FALSE,
    browser_alerts_enabled BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP NOT NULL
);

-- 2. SUBSCRIPTIONS & ENTITLEMENTS
CREATE TYPE subscription_tier AS ENUM ('FREE_RETAIL', 'PRO_MONTHLY', 'PRO_ANNUAL', 'INSTITUTIONAL');

CREATE TABLE IF NOT EXISTS subscriptions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES users(id) ON DELETE CASCADE NOT NULL,
    tier subscription_tier DEFAULT 'FREE_RETAIL' NOT NULL,
    starts_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP NOT NULL,
    expires_at TIMESTAMPTZ,
    auto_renew BOOLEAN DEFAULT TRUE,
    payment_status VARCHAR(50) DEFAULT 'ACTIVE',
    features JSONB DEFAULT '{
        "realtime_refresh_seconds": 1,
        "max_strategies": 50,
        "max_alerts": 100,
        "advanced_greeks": true,
        "strategy_scanner": true,
        "historical_oi": true
    }'::jsonb,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP NOT NULL
);

-- 3. OPTION CONTRACTS CATALOG
CREATE TYPE option_right AS ENUM ('CE', 'PE');

CREATE TABLE IF NOT EXISTS option_contracts (
    id SERIAL PRIMARY KEY,
    symbol VARCHAR(30) NOT NULL, -- e.g. NIFTY, BANKNIFTY
    strike_price NUMERIC(10, 2) NOT NULL,
    option_type option_right NOT NULL,
    expiry_date DATE NOT NULL,
    lot_size INT NOT NULL DEFAULT 50,
    tick_size NUMERIC(6, 2) DEFAULT 0.05,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT unique_contract UNIQUE(symbol, strike_price, option_type, expiry_date)
);

-- 4. MARKET TICKS & SPOT PRICES
CREATE TABLE IF NOT EXISTS market_ticks (
    id BIGSERIAL PRIMARY KEY,
    symbol VARCHAR(30) NOT NULL,
    spot_price NUMERIC(12, 2) NOT NULL,
    change_value NUMERIC(10, 2) NOT NULL,
    p_change NUMERIC(6, 2) NOT NULL,
    day_high NUMERIC(12, 2),
    day_low NUMERIC(12, 2),
    vix NUMERIC(6, 2),
    tick_timestamp TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_market_ticks_symbol_time ON market_ticks(symbol, tick_timestamp DESC);

-- 5. LIVE OPTION CHAIN SNAPSHOTS (For Historical OI & Heatmap Analytics)
CREATE TABLE IF NOT EXISTS option_chain_snapshots (
    id BIGSERIAL PRIMARY KEY,
    symbol VARCHAR(30) NOT NULL,
    expiry_date DATE NOT NULL,
    strike_price NUMERIC(10, 2) NOT NULL,
    spot_price NUMERIC(12, 2) NOT NULL,
    ce_ltp NUMERIC(10, 2),
    ce_oi BIGINT,
    ce_change_oi BIGINT,
    ce_volume BIGINT,
    ce_iv NUMERIC(6, 2),
    ce_delta NUMERIC(6, 4),
    ce_theta NUMERIC(8, 2),
    ce_gamma NUMERIC(8, 4),
    ce_vega NUMERIC(8, 2),
    pe_ltp NUMERIC(10, 2),
    pe_oi BIGINT,
    pe_change_oi BIGINT,
    pe_volume BIGINT,
    pe_iv NUMERIC(6, 2),
    pe_delta NUMERIC(6, 4),
    pe_theta NUMERIC(8, 2),
    pe_gamma NUMERIC(8, 4),
    pe_vega NUMERIC(8, 2),
    snapshot_time TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_chain_snapshots_query ON option_chain_snapshots(symbol, expiry_date, snapshot_time DESC);

-- 6. USER STRATEGIES & PORTFOLIO
CREATE TABLE IF NOT EXISTS user_strategies (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES users(id) ON DELETE CASCADE NOT NULL,
    name VARCHAR(150) NOT NULL,
    symbol VARCHAR(30) NOT NULL,
    expiry_date DATE,
    legs JSONB NOT NULL, -- Array of StrategyLeg objects
    net_credit_debit NUMERIC(12, 2) DEFAULT 0,
    max_profit TEXT,
    max_loss TEXT,
    breakevens NUMERIC(12, 2)[],
    notes TEXT,
    is_paper_trade BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP NOT NULL
);

-- 7. ALERTS ENGINE
CREATE TYPE alert_metric AS ENUM ('PRICE', 'OI', 'PCR', 'MAX_PAIN');
CREATE TYPE alert_condition AS ENUM ('ABOVE', 'BELOW', 'CROSSES');

CREATE TABLE IF NOT EXISTS alerts (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES users(id) ON DELETE CASCADE NOT NULL,
    symbol VARCHAR(30) NOT NULL,
    alert_type alert_metric NOT NULL,
    strike NUMERIC(10, 2),
    option_type option_right,
    condition alert_condition NOT NULL,
    threshold_value NUMERIC(12, 2) NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    triggered BOOLEAN DEFAULT FALSE,
    triggered_at TIMESTAMPTZ,
    trigger_message TEXT,
    telegram_enabled BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP NOT NULL
);

-- 8. WATCHLISTS
CREATE TABLE IF NOT EXISTS watchlists (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES users(id) ON DELETE CASCADE NOT NULL,
    symbol VARCHAR(30) NOT NULL,
    strike NUMERIC(10, 2) NOT NULL,
    option_type option_right NOT NULL,
    expiry_date DATE NOT NULL,
    target_price NUMERIC(10, 2),
    stop_loss NUMERIC(10, 2),
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP NOT NULL
);

-- 9. AUDIT LOGS & ADMIN ACTIONS
CREATE TABLE IF NOT EXISTS audit_logs (
    id BIGSERIAL PRIMARY KEY,
    user_id UUID REFERENCES users(id) ON DELETE SET NULL,
    action_type VARCHAR(100) NOT NULL,
    target_resource VARCHAR(100),
    details JSONB,
    ip_address INET,
    user_agent TEXT,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP NOT NULL
);

-- 10. SYSTEM NOTIFICATIONS & BROADCASTS
CREATE TABLE IF NOT EXISTS broadcasts (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    title VARCHAR(200) NOT NULL,
    message TEXT NOT NULL,
    severity VARCHAR(20) DEFAULT 'INFO', -- INFO, WARNING, CRITICAL
    starts_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP NOT NULL,
    expires_at TIMESTAMPTZ,
    created_by UUID REFERENCES users(id)
);

-- ROW LEVEL SECURITY (RLS) POLICIES
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE subscriptions ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_strategies ENABLE ROW LEVEL SECURITY;
ALTER TABLE alerts ENABLE ROW LEVEL SECURITY;
ALTER TABLE watchlists ENABLE ROW LEVEL SECURITY;

CREATE POLICY user_read_own ON users FOR SELECT USING (auth.uid() = id);
CREATE POLICY user_manage_strategies ON user_strategies FOR ALL USING (auth.uid() = user_id);
CREATE POLICY user_manage_alerts ON alerts FOR ALL USING (auth.uid() = user_id);
CREATE POLICY user_manage_watchlists ON watchlists FOR ALL USING (auth.uid() = user_id);
