import {
  OptionType,
  PayoffPoint,
  StrategyLeg,
  StrategyMetrics,
  StrikeRow,
  OIBuildupType,
} from '../types';
import { calculateGreeks } from './blackScholes';

export interface MaxPainResult {
  maxPainStrike: number;
  distanceFromSpot: number;
  distancePercent: number;
  strikeLosses: { strike: number; callLoss: number; putLoss: number; totalLoss: number }[];
}

export interface PCRResult {
  totalCeOi: number;
  totalPeOi: number;
  pcrOi: number;
  totalCeVol: number;
  totalPeVol: number;
  pcrVol: number;
  sentiment: 'EXTREME_BULLISH' | 'BULLISH' | 'NEUTRAL' | 'BEARISH' | 'EXTREME_BEARISH';
  summary: string;
}

export interface SupportResistanceLevels {
  resistances: { strike: number; oi: number; label: string }[];
  supports: { strike: number; oi: number; label: string }[];
  highestCeStrike: number;
  highestPeStrike: number;
}

/**
 * Determine OI Buildup type based on price change and OI change
 */
export function determineBuildup(
  priceChange: number,
  oiChange: number
): OIBuildupType {
  if (Math.abs(priceChange) < 0.05 && Math.abs(oiChange) < 50) return 'NEUTRAL';
  if (priceChange >= 0 && oiChange >= 0) return 'LONG_BUILDUP';
  if (priceChange < 0 && oiChange >= 0) return 'SHORT_BUILDUP';
  if (priceChange < 0 && oiChange < 0) return 'LONG_UNWINDING';
  if (priceChange >= 0 && oiChange < 0) return 'SHORT_COVERING';
  return 'NEUTRAL';
}

/**
 * Calculate Max Pain strike and distribution
 */
export function calculateMaxPain(strikes: StrikeRow[], spotPrice: number): MaxPainResult {
  if (!strikes.length) {
    return {
      maxPainStrike: spotPrice,
      distanceFromSpot: 0,
      distancePercent: 0,
      strikeLosses: [],
    };
  }

  const strikeLosses = strikes.map((target) => {
    const s = target.strike;
    let callLoss = 0;
    let putLoss = 0;

    strikes.forEach((row) => {
      // If index expires at s:
      // Call buyers profit if s > row.strike
      if (s > row.strike) {
        callLoss += (s - row.strike) * row.call.oi;
      }
      // Put buyers profit if s < row.strike
      if (s < row.strike) {
        putLoss += (row.strike - s) * row.put.oi;
      }
    });

    const totalLoss = callLoss + putLoss;
    return {
      strike: s,
      callLoss,
      putLoss,
      totalLoss,
    };
  });

  // Strike where total loss (payout by option writers) is minimal
  let minLoss = Number.MAX_VALUE;
  let maxPainStrike = strikes[0].strike;

  strikeLosses.forEach((item) => {
    if (item.totalLoss < minLoss) {
      minLoss = item.totalLoss;
      maxPainStrike = item.strike;
    }
  });

  const distanceFromSpot = maxPainStrike - spotPrice;
  const distancePercent = Number(((distanceFromSpot / spotPrice) * 100).toFixed(2));

  return {
    maxPainStrike,
    distanceFromSpot,
    distancePercent,
    strikeLosses,
  };
}

/**
 * Calculate PCR (Put Call Ratio) and Sentiment
 */
export function calculatePCR(strikes: StrikeRow[]): PCRResult {
  let totalCeOi = 0;
  let totalPeOi = 0;
  let totalCeVol = 0;
  let totalPeVol = 0;

  strikes.forEach((row) => {
    totalCeOi += row.call.oi;
    totalPeOi += row.put.oi;
    totalCeVol += row.call.volume;
    totalPeVol += row.put.volume;
  });

  const pcrOi = totalCeOi > 0 ? Number((totalPeOi / totalCeOi).toFixed(2)) : 1.0;
  const pcrVol = totalCeVol > 0 ? Number((totalPeVol / totalCeVol).toFixed(2)) : 1.0;

  let sentiment: PCRResult['sentiment'] = 'NEUTRAL';
  let summary = 'Market is balanced between Put and Call writers.';

  if (pcrOi > 1.35) {
    sentiment = 'EXTREME_BULLISH';
    summary = 'Heavily Bullish / Potential Overbought zone. Put writing exceeds call writing significantly.';
  } else if (pcrOi >= 1.05) {
    sentiment = 'BULLISH';
    summary = 'Bullish bias. Higher Put OI suggests solid downside support.';
  } else if (pcrOi >= 0.85) {
    sentiment = 'NEUTRAL';
    summary = 'Neutral / Range-bound expectations. Calls and Puts are evenly matched.';
  } else if (pcrOi >= 0.65) {
    sentiment = 'BEARISH';
    summary = 'Bearish bias. Heavy Call writing creates overhead ceiling.';
  } else {
    sentiment = 'EXTREME_BEARISH';
    summary = 'Heavily Bearish / Potential Oversold bounce zone. High call writing concentration.';
  }

  return {
    totalCeOi,
    totalPeOi,
    pcrOi,
    totalCeVol,
    totalPeVol,
    pcrVol,
    sentiment,
    summary,
  };
}

/**
 * Extract Key Resistance and Support levels from OI clusters
 */
export function identifySupportResistance(strikes: StrikeRow[]): SupportResistanceLevels {
  const sortedCalls = [...strikes].sort((a, b) => b.call.oi - a.call.oi);
  const sortedPuts = [...strikes].sort((a, b) => b.put.oi - a.put.oi);

  const resistances = sortedCalls.slice(0, 3).map((r, i) => ({
    strike: r.strike,
    oi: r.call.oi,
    label: `R${i + 1}`,
  }));

  const supports = sortedPuts.slice(0, 3).map((r, i) => ({
    strike: r.strike,
    oi: r.put.oi,
    label: `S${i + 1}`,
  }));

  return {
    resistances,
    supports,
    highestCeStrike: resistances[0]?.strike || 0,
    highestPeStrike: supports[0]?.strike || 0,
  };
}

/**
 * Calculate full strategy payoff profile and metrics
 */
export function calculateStrategyMetrics(
  legs: StrategyLeg[],
  spotPrice: number,
  daysToExpiry: number = 4
): { metrics: StrategyMetrics; payoffPoints: PayoffPoint[] } {
  if (!legs.length) {
    return {
      metrics: {
        netCreditDebit: 0,
        maxProfit: 0,
        maxLoss: 0,
        riskRewardRatio: '1:1',
        breakevens: [],
        probabilityOfProfit: 50,
        netDelta: 0,
        netTheta: 0,
        netGamma: 0,
        netVega: 0,
        estimatedMargin: 0,
      },
      payoffPoints: [],
    };
  }

  // Calculate Net Premium
  let netCreditDebit = 0;
  let netDelta = 0;
  let netTheta = 0;
  let netGamma = 0;
  let netVega = 0;
  let estimatedMargin = 0;

  legs.forEach((leg) => {
    const totalQty = leg.lots * leg.lotSize;
    const direction = leg.action === 'BUY' ? -1 : 1;
    netCreditDebit += direction * leg.price * totalQty;

    const greeksDir = leg.action === 'BUY' ? 1 : -1;
    netDelta += greeksDir * leg.greeks.delta * totalQty;
    netTheta += greeksDir * leg.greeks.theta * totalQty;
    netGamma += greeksDir * leg.greeks.gamma * totalQty;
    netVega += greeksDir * leg.greeks.vega * totalQty;

    // Margin estimation: selling options requires ~1.2L per lot in India index options
    if (leg.action === 'SELL') {
      estimatedMargin += leg.lots * 125000;
    } else {
      estimatedMargin += leg.lots * leg.lotSize * leg.price;
    }
  });

  // Generate Spot Price sweep: Spot - 10% to Spot + 10%
  const minSpot = Math.round(spotPrice * 0.90);
  const maxSpot = Math.round(spotPrice * 1.10);
  const step = Math.max(10, Math.round((maxSpot - minSpot) / 80));

  const payoffPoints: PayoffPoint[] = [];
  let minExpiryPayoff = Number.MAX_VALUE;
  let maxExpiryPayoff = -Number.MAX_VALUE;
  const breakevens: number[] = [];

  let prevPayoff: number | null = null;
  let prevPrice: number | null = null;

  for (let s = minSpot; s <= maxSpot; s += step) {
    let expiryPayoff = 0;
    let t0Payoff = 0;

    legs.forEach((leg) => {
      const qty = leg.lots * leg.lotSize;
      let intrinsic = 0;
      if (leg.type === 'CE') {
        intrinsic = Math.max(0, s - leg.strike);
      } else {
        intrinsic = Math.max(0, leg.strike - s);
      }

      // Expiry Payoff
      if (leg.action === 'BUY') {
        expiryPayoff += (intrinsic - leg.price) * qty;
      } else {
        expiryPayoff += (leg.price - intrinsic) * qty;
      }

      // T+0 Payoff using Black-Scholes theoretical value today vs entry price
      const t0Eval = calculateGreeks(s, leg.strike, daysToExpiry / 365, 0.068, leg.iv / 100, leg.type);
      if (leg.action === 'BUY') {
        t0Payoff += (t0Eval.price - leg.price) * qty;
      } else {
        t0Payoff += (leg.price - t0Eval.price) * qty;
      }
    });

    payoffPoints.push({
      spotPrice: s,
      expiryPayoff: Number(expiryPayoff.toFixed(2)),
      t0Payoff: Number(t0Payoff.toFixed(2)),
    });

    if (expiryPayoff < minExpiryPayoff) minExpiryPayoff = expiryPayoff;
    if (expiryPayoff > maxExpiryPayoff) maxExpiryPayoff = expiryPayoff;

    // Detect zero crossings for breakevens
    if (prevPayoff !== null && prevPrice !== null) {
      if ((prevPayoff <= 0 && expiryPayoff >= 0) || (prevPayoff >= 0 && expiryPayoff <= 0)) {
        // Linear interpolation
        const fraction = Math.abs(prevPayoff) / (Math.abs(prevPayoff) + Math.abs(expiryPayoff) || 1);
        const bePrice = Math.round(prevPrice + fraction * (s - prevPrice));
        if (!breakevens.includes(bePrice)) {
          breakevens.push(bePrice);
        }
      }
    }

    prevPayoff = expiryPayoff;
    prevPrice = s;
  }

  // Check if payoffs explode at bounds (unlimited)
  const leftEnd = payoffPoints[0].expiryPayoff;
  const leftSecond = payoffPoints[1].expiryPayoff;
  const rightEnd = payoffPoints[payoffPoints.length - 1].expiryPayoff;
  const rightSecond = payoffPoints[payoffPoints.length - 2].expiryPayoff;

  let maxProfit: number | 'UNLIMITED' = Number(maxExpiryPayoff.toFixed(0));
  let maxLoss: number | 'UNLIMITED' = Number(Math.abs(minExpiryPayoff).toFixed(0));

  if (rightEnd > rightSecond && rightEnd > maxExpiryPayoff * 0.95 && rightEnd > 100000) {
    maxProfit = 'UNLIMITED';
  } else if (leftEnd > leftSecond && leftEnd > maxExpiryPayoff * 0.95 && leftEnd > 100000) {
    maxProfit = 'UNLIMITED';
  }

  if (rightEnd < rightSecond && rightEnd < minExpiryPayoff * 0.95 && rightEnd < -100000) {
    maxLoss = 'UNLIMITED';
  } else if (leftEnd < leftSecond && leftEnd < minExpiryPayoff * 0.95 && leftEnd < -100000) {
    maxLoss = 'UNLIMITED';
  }

  // Risk reward calculation
  let riskRewardRatio = '1:1.5';
  if (typeof maxProfit === 'number' && typeof maxLoss === 'number') {
    if (maxLoss > 0) {
      riskRewardRatio = `1:${(maxProfit / maxLoss).toFixed(2)}`;
    } else {
      riskRewardRatio = '1:∞';
    }
  } else if (maxProfit === 'UNLIMITED') {
    riskRewardRatio = '1:∞';
  } else if (maxLoss === 'UNLIMITED') {
    riskRewardRatio = 'High Risk';
  }

  // Estimate Probability of Profit (POP) based on profitable range under normal distribution
  let profitableSamples = payoffPoints.filter((p) => p.expiryPayoff >= 0).length;
  let pop = Math.round((profitableSamples / payoffPoints.length) * 100);
  if (pop < 5) pop = 5;
  if (pop > 95) pop = 95;

  return {
    metrics: {
      netCreditDebit: Number(netCreditDebit.toFixed(2)),
      maxProfit,
      maxLoss,
      riskRewardRatio,
      breakevens,
      probabilityOfProfit: pop,
      netDelta: Number(netDelta.toFixed(2)),
      netTheta: Number(netTheta.toFixed(2)),
      netGamma: Number(netGamma.toFixed(4)),
      netVega: Number(netVega.toFixed(2)),
      estimatedMargin: Math.round(estimatedMargin),
    },
    payoffPoints,
  };
}
