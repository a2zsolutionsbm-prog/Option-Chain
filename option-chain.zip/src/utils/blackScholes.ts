import { Greeks, OptionType } from '../types';

/**
 * Standard Normal Cumulative Distribution Function (Abramowitz & Stegun approximation)
 */
export function normalCDF(x: number): number {
  const b1 = 0.319381530;
  const b2 = -0.356563782;
  const b3 = 1.781477937;
  const b4 = -1.821255978;
  const b5 = 1.330274429;
  const p = 0.2316419;
  const c = 0.39894228;

  if (x >= 0.0) {
    const t = 1.0 / (1.0 + p * x);
    return (
      1.0 -
      c *
        Math.exp((-x * x) / 2.0) *
        t *
        (t * (t * (t * (t * b5 + b4) + b3) + b2) + b1)
    );
  } else {
    const t = 1.0 / (1.0 - p * x);
    return (
      c *
      Math.exp((-x * x) / 2.0) *
      t *
      (t * (t * (t * (t * b5 + b4) + b3) + b2) + b1)
    );
  }
}

/**
 * Standard Normal Probability Density Function
 */
export function normalPDF(x: number): number {
  return (1.0 / Math.sqrt(2 * Math.PI)) * Math.exp(-0.5 * x * x);
}

/**
 * Calculate Black-Scholes Greeks and theoretical price
 * @param S Current Spot Price
 * @param K Strike Price
 * @param T Time to expiration in years (e.g., days / 365)
 * @param r Risk-free rate (e.g. 0.068 for 6.8% Indian RBI repo rate)
 * @param sigma Implied Volatility (e.g. 0.14 for 14%)
 * @param type 'CE' or 'PE'
 */
export function calculateGreeks(
  S: number,
  K: number,
  T: number,
  r: number = 0.068,
  sigma: number = 0.14,
  type: OptionType = 'CE'
): { price: number; greeks: Greeks } {
  // Prevent division by zero or negative T
  const adjustedT = Math.max(T, 0.0001);
  const adjustedSigma = Math.max(sigma, 0.01);

  const sqrtT = Math.sqrt(adjustedT);
  const d1 =
    (Math.log(S / K) + (r + (adjustedSigma * adjustedSigma) / 2.0) * adjustedT) /
    (adjustedSigma * sqrtT);
  const d2 = d1 - adjustedSigma * sqrtT;

  const nd1 = normalCDF(d1);
  const nd2 = normalCDF(d2);
  const nNegD1 = normalCDF(-d1);
  const nNegD2 = normalCDF(-d2);
  const pdfD1 = normalPDF(d1);

  let price = 0;
  let delta = 0;
  let theta = 0;
  let rho = 0;

  // Gamma and Vega are identical for Calls and Puts
  const gamma = pdfD1 / (S * adjustedSigma * sqrtT);
  // Vega per 1% change in volatility
  const vega = (S * sqrtT * pdfD1) / 100;

  if (type === 'CE') {
    price = S * nd1 - K * Math.exp(-r * adjustedT) * nd2;
    delta = nd1;
    // Theta per day (annual theta / 365)
    const annualTheta =
      -(S * pdfD1 * adjustedSigma) / (2 * sqrtT) -
      r * K * Math.exp(-r * adjustedT) * nd2;
    theta = annualTheta / 365;
    // Rho per 1% change in rate
    rho = (K * adjustedT * Math.exp(-r * adjustedT) * nd2) / 100;
  } else {
    price = K * Math.exp(-r * adjustedT) * nNegD2 - S * nNegD1;
    delta = nd1 - 1; // negative for puts
    const annualTheta =
      -(S * pdfD1 * adjustedSigma) / (2 * sqrtT) +
      r * K * Math.exp(-r * adjustedT) * nNegD2;
    theta = annualTheta / 365;
    rho = (-K * adjustedT * Math.exp(-r * adjustedT) * nNegD2) / 100;
  }

  // Ensure positive price
  price = Math.max(price, 0.05);

  return {
    price: Number(price.toFixed(2)),
    greeks: {
      delta: Number(delta.toFixed(3)),
      gamma: Number((gamma * 100).toFixed(4)), // scaled per 100 pts move
      theta: Number(theta.toFixed(2)),
      vega: Number(vega.toFixed(2)),
      rho: Number(rho.toFixed(3)),
      iv: Number((adjustedSigma * 100).toFixed(1)),
    },
  };
}

/**
 * Estimate Implied Volatility given market price using Newton-Raphson
 */
export function estimateIV(
  marketPrice: number,
  S: number,
  K: number,
  T: number,
  r: number = 0.068,
  type: OptionType = 'CE'
): number {
  let sigma = 0.2; // initial guess 20%
  const maxIterations = 50;
  const tolerance = 0.01;

  for (let i = 0; i < maxIterations; i++) {
    const { price, greeks } = calculateGreeks(S, K, T, r, sigma, type);
    const diff = price - marketPrice;
    if (Math.abs(diff) < tolerance) {
      return sigma * 100;
    }
    // Vega is derivative w.r.t sigma (scaled)
    const vegaRaw = greeks.vega * 100;
    if (Math.abs(vegaRaw) < 0.0001) break;
    sigma = sigma - diff / vegaRaw;
    if (sigma <= 0.01) sigma = 0.01;
    if (sigma > 2.0) sigma = 2.0;
  }
  return sigma * 100;
}
