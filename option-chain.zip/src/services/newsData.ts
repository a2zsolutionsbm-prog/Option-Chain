export type NewsRegion = 'GLOBAL' | 'INDIA' | 'USA' | 'EUROPE' | 'ASIA_PACIFIC';

export type NewsCategory = 
  | 'ALL'
  | 'GLOBAL'
  | 'INDIA'
  | 'CENTRAL_BANKS'
  | 'DERIVATIVES'
  | 'COMMODITIES_FX'
  | 'EARNINGS_SECTOR';

export type NewsSentiment = 'BULLISH' | 'BEARISH' | 'NEUTRAL';
export type NewsImpact = 'HIGH' | 'MEDIUM' | 'LOW';

export interface MarketNewsItem {
  id: string;
  title: string;
  summary: string;
  fullContent?: string;
  marketImpactDetail?: string;
  region: NewsRegion;
  category: 'GLOBAL' | 'INDIA' | 'CENTRAL_BANKS' | 'DERIVATIVES' | 'COMMODITIES_FX' | 'EARNINGS_SECTOR';
  source: string;
  timestamp: string;
  timeAgo: string;
  sentiment: NewsSentiment;
  impact: NewsImpact;
  tickers: string[];
  isBreaking?: boolean;
  bookmarked?: boolean;
}

export const INITIAL_NEWS_ITEMS: MarketNewsItem[] = [
  {
    id: 'news_1',
    title: 'RBI Monetary Policy Committee Keeps Repo Rate at 6.50%, Stance Shifted to Neutral',
    summary: 'Governor highlights resilient domestic economic growth and softening core inflation. Liquidity conditions to be actively managed through VRR operations as external risks remain moderate.',
    fullContent: 'The Reserve Bank of India Monetary Policy Committee voted unanimously to keep the policy repo rate unchanged at 6.50% while shifting its stance to neutral. The decision aligns with street expectations as inflation trajectory hovers near the 4% target band while real GDP growth for the fiscal is projected at 7.2%. The MPC reiterated its commitment to aligning inflation with the target on a durable basis while supporting growth.',
    marketImpactDetail: 'Strong positive for Bank Nifty and Rate-Sensitive Auto/Realty sectors. Nifty 50 options indicate heavy Put writing at 24,800-25,000 strikes as downside risk perceived limited.',
    region: 'INDIA',
    category: 'INDIA',
    source: 'RBI Press Release / CNBC-TV18',
    timestamp: '09:48 AM IST',
    timeAgo: '4 mins ago',
    sentiment: 'BULLISH',
    impact: 'HIGH',
    tickers: ['NIFTY', 'BANKNIFTY', 'USDINR', 'HDFCBANK', 'ICICIBANK'],
    isBreaking: true,
  },
  {
    id: 'news_2',
    title: 'US Federal Reserve Signals Measured 25 bps Rate Cuts as Core PCE Moderates to 2.4%',
    summary: 'Fed Chairman comments emphasize a balanced approach between cooling labor demand and sustainable inflation return towards the 2% objective. Dot plot points to further calibrated reductions.',
    fullContent: 'Federal Reserve Chairman Jerome Powell outlined that the risk to the dual mandate—maximum employment and stable prices—is moving into balance. The Core Personal Consumption Expenditures (PCE) price index softened to 2.4% annualized, bolstering expectations for calibrated monetary easing. US 10-year Treasury yields eased 6 basis points to 3.84%, putting downward pressure on the US Dollar Index (DXY).',
    marketImpactDetail: 'Eases global cost of capital and sparks liquidity inflows into emerging market equities. DXY softening below 101.20 provides strong tailwind for Indian Rupee and tech multiples.',
    region: 'USA',
    category: 'GLOBAL',
    source: 'Bloomberg Terminal / Federal Reserve Board',
    timestamp: '09:32 AM IST',
    timeAgo: '20 mins ago',
    sentiment: 'BULLISH',
    impact: 'HIGH',
    tickers: ['SPX', 'NDX', 'DXY', 'US10Y', 'NIFTY'],
    isBreaking: true,
  },
  {
    id: 'news_3',
    title: 'FIIs Turn Net Buyers in Indian Equities with ₹3,840 Cr Inflow; DIIs Absorb ₹2,150 Cr',
    summary: 'Foreign Institutional Investors reverse three-day selling spree, targeting private lenders, energy majors, and frontline IT bellwethers. Index futures long-short ratio jumps to 61%.',
    fullContent: 'Provisional exchange data reveals aggressive institutional buying in cash market and index derivatives. FIIs bought equities worth ₹3,842.15 crore while Domestic Institutional Investors bought ₹2,155.40 crore. In the F&O segment, FIIs added 28,400 long contracts in Nifty and Bank Nifty futures, lowering gross short exposure.',
    marketImpactDetail: 'Sharp short covering expected in Nifty 24,900 and 25,000 Call contracts. Highest Call OI unwinding seen in early morning trades.',
    region: 'INDIA',
    category: 'DERIVATIVES',
    source: 'NSE Provisional / Moneycontrol',
    timestamp: '09:15 AM IST',
    timeAgo: '37 mins ago',
    sentiment: 'BULLISH',
    impact: 'HIGH',
    tickers: ['NIFTY', 'BANKNIFTY', 'RELIANCE', 'TCS', 'INFY'],
  },
  {
    id: 'news_4',
    title: 'Brent Crude Slips Below $74/bbl as OPEC+ Weighs Phased Supply Restoration & China Demand Softens',
    summary: 'Crude futures fell 1.8% to $73.40 per barrel following inventory additions in Cushing and subdued manufacturing PMIs across East Asian hubs.',
    fullContent: 'Global oil benchmark Brent crude fell beneath $74 a barrel amid reports that OPEC+ producers may gradually unwind voluntary output cuts starting next quarter. Chinese customs data indicated crude imports slipped 4.1% month-on-month. The slump provides immediate relief to energy import-dependent nations, lowering current account deficit pressures.',
    marketImpactDetail: 'Net positive for Indian macroeconomic health, FMCG, paints, and airline stocks (InterGlobe Aviation, Asian Paints). Modest margin drag on domestic upstream producers (ONGC, Oil India).',
    region: 'GLOBAL',
    category: 'COMMODITIES_FX',
    source: 'Reuters Commodities / Platts',
    timestamp: '08:50 AM IST',
    timeAgo: '1 hr ago',
    sentiment: 'BULLISH',
    impact: 'MEDIUM',
    tickers: ['BRENT', 'CRUDEOIL', 'USDINR', 'INDIGO', 'ASIANPAINT'],
  },
  {
    id: 'news_5',
    title: 'SEBI Clarifies Index Derivative Framework: Weekly Expiry Rationalization Implemented Smoothly',
    summary: 'Market regulator notes that calibrated lot size adjustments and single benchmark weekly contract per exchange have stabilized retail risk exposure without hurting institutional liquidity.',
    fullContent: 'The Securities and Exchange Board of India stated in its monthly review that the updated derivatives framework has achieved its primary goal of reducing systemic retail over-leverage while preserving deep price discovery. Exchange turnover metrics demonstrate robust participation from institutional algo desks and market makers across monthly and weekly contracts.',
    marketImpactDetail: 'Dispels market speculation over further sudden restrictions. High volume concentration remains focused on Nifty Thursday expiries and Bank Nifty monthly cycles.',
    region: 'INDIA',
    category: 'DERIVATIVES',
    source: 'SEBI Official / Economic Times',
    timestamp: '08:25 AM IST',
    timeAgo: '1 hr 27 mins ago',
    sentiment: 'NEUTRAL',
    impact: 'MEDIUM',
    tickers: ['NIFTY', 'BANKNIFTY', 'FINNIFTY', 'BSE'],
  },
  {
    id: 'news_6',
    title: 'European Central Bank Cuts Deposit Facility Rate to 3.25% as Eurozone Inflation Drops to 1.8%',
    summary: 'Christine Lagarde points to sluggish manufacturing activity across Germany and France, confirming that disinflationary trends are well entrenched across the bloc.',
    fullContent: 'The Governing Council of the ECB reduced its key interest rate by 25 basis points to 3.25%. Eurozone economic output has stagnated with composite PMIs signaling mild contraction in Germany. Lagarde stated monetary policy will stay data-dependent with meeting-by-meeting determination of rates.',
    marketImpactDetail: 'Euro slipped 0.3% against the US Dollar. DAX and CAC 40 index futures gained 0.6%, providing positive handoff to Asian session.',
    region: 'EUROPE',
    category: 'CENTRAL_BANKS',
    source: 'Financial Times / ECB',
    timestamp: '07:45 AM IST',
    timeAgo: '2 hrs ago',
    sentiment: 'NEUTRAL',
    impact: 'MEDIUM',
    tickers: ['EURUSD', 'DAX', 'CAC40', 'DXY'],
  },
  {
    id: 'news_7',
    title: 'Asian Markets Rally: Nikkei 225 Surges 1.6% on Tech Rally; Hang Seng Rebounds on Stimulus Talk',
    summary: 'Tokyo equities climbed higher tracked by semiconductor chip equipment makers following stellar earnings from US AI hardware leaders. People Bank of China injects liquidity via reverse repos.',
    fullContent: 'Equities across Tokyo, Seoul, and Taipei witnessed broad-based buying. Tokyo Electron and Advantest led the Nikkei higher by over 600 points. In Hong Kong, the Hang Seng index advanced 1.2% as property and consumer tech shares rebounded on expectations of further local government bond quota expansions.',
    marketImpactDetail: 'GIFT Nifty futures traded with a 75-point premium ahead of market opening, hinting at a strong gap-up opening for domestic benchmarks.',
    region: 'ASIA_PACIFIC',
    category: 'GLOBAL',
    source: 'Nikkei Asia / Bloomberg',
    timestamp: '07:15 AM IST',
    timeAgo: '2 hrs 35 mins ago',
    sentiment: 'BULLISH',
    impact: 'MEDIUM',
    tickers: ['NIKKEI225', 'HSI', 'GIFTNIFTY', 'KOSPI'],
  },
  {
    id: 'news_8',
    title: 'India Gross Direct Tax Collections Rise 12.8% YoY; Net Mop-up Crosses ₹11.2 Lakh Crore Mark',
    summary: 'Robust corporate earnings and higher compliance fuel strong direct tax revenue mop-up, reinforcing central government fiscal deficit target adherence of 4.9% of GDP.',
    fullContent: 'Official figures released by the Ministry of Finance showed gross tax collections maintained double-digit growth. Advance tax payments from top corporate conglomerates grew 14.2% year-on-year, indicating steady private sector profitability and operational cash flows.',
    marketImpactDetail: 'Assures sovereign bond yields will remain anchored below 6.80%. Reduces the risk of additional government borrowing in Q4.',
    region: 'INDIA',
    category: 'INDIA',
    source: 'Ministry of Finance / PIB Delhi',
    timestamp: '06:40 AM IST',
    timeAgo: '3 hrs ago',
    sentiment: 'BULLISH',
    impact: 'LOW',
    tickers: ['IN10Y', 'NIFTY', 'USDINR'],
  },
  {
    id: 'news_9',
    title: 'Gold Holds Near Record $2,660/oz on Safe-Haven Bids and Rate Cut Momentum',
    summary: 'Bullion holds firm near all-time highs as central bank gold reserves continue accumulative trend. Silver tracks higher at $31.80/oz supported by industrial solar demand.',
    fullContent: 'Spot gold held firm at $2,658.40 an ounce, supported by safe-haven flows amid Middle East diplomatic uncertainties and anticipated Western monetary easing cycles. The World Gold Council reported ongoing sovereign reserve purchases across central banks in Asia and Eastern Europe.',
    marketImpactDetail: 'MCX Gold futures opened positive. Jewellery and gold loan finance companies (Titan, Muthoot Finance) in focus.',
    region: 'GLOBAL',
    category: 'COMMODITIES_FX',
    source: 'WGC / Kitco Metals',
    timestamp: '06:10 AM IST',
    timeAgo: '3 hrs 40 mins ago',
    sentiment: 'NEUTRAL',
    impact: 'MEDIUM',
    tickers: ['GOLD', 'SILVER', 'TITAN', 'MUTHOOTFIN'],
  },
  {
    id: 'news_10',
    title: 'IT Sector Q2 Preview: BFSI Spending Rebound & GenAI Contract Ramp-Ups to Support Valuations',
    summary: 'Tier-1 tech bellwethers expected to post 1.2% to 2.4% sequential constant currency revenue growth. Deal wins robust with $2.5B+ total contract values in North American pipeline.',
    fullContent: 'Leading brokerage reports suggest the Indian IT services sector is turning the corner after a prolonged cycle of client budget deferrals. Cloud migration projects and GenAI enterprise pilots are converting into multi-year application modernization deals, with banking and financial services clients leading discretionary spend recovery.',
    marketImpactDetail: 'NIFTY IT index consolidating at key support of 41,800. Strong Put OI buildup observed at 41,500 and 42,000 strikes.',
    region: 'INDIA',
    category: 'EARNINGS_SECTOR',
    source: 'Kotak Institutional Equities / Livemint',
    timestamp: '05:30 AM IST',
    timeAgo: '4 hrs ago',
    sentiment: 'BULLISH',
    impact: 'MEDIUM',
    tickers: ['NIFTYIT', 'TCS', 'INFY', 'WIPRO', 'HCLTECH'],
  }
];
