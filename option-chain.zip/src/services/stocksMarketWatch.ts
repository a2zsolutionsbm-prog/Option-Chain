/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * Live Stock Market Watch Engine (NSE Real-time Equity Feeds)
 * Real-time updates every 1 second, sectors, segments, market cap, and analytics.
 */

export type MarketSegment =
  | 'NIFTY 50'
  | 'NIFTY NEXT 50'
  | 'NIFTY 100'
  | 'NIFTY 200'
  | 'NIFTY 500'
  | 'BANKNIFTY STOCKS'
  | 'FINNIFTY STOCKS'
  | 'MIDCAP 100'
  | 'SMALLCAP 100'
  | 'ALL NSE STOCKS';

export type SectorType =
  | 'IT'
  | 'BANKING'
  | 'FINANCIAL SERVICES'
  | 'AUTO'
  | 'PHARMA'
  | 'METAL'
  | 'ENERGY'
  | 'FMCG'
  | 'REALTY'
  | 'TELECOM'
  | 'CHEMICAL'
  | 'INFRA'
  | 'CONSUMPTION';

export interface StockQuote {
  symbol: string;
  name: string;
  sector: SectorType;
  segments: MarketSegment[];
  ltp: number;
  prevClose: number;
  change: number;
  pChange: number;
  open: number;
  high: number;
  low: number;
  volume: number;
  turnoverCr: number;
  tradesCount: number;
  marketCapCr: number; // in Crores INR
  week52High: number;
  week52Low: number;
  vwap: number;
  peRatio: number;
  eps: number;
  dividendYield: number;
  lastTickDir: 'up' | 'down' | 'none';
  sparkline: number[];
}

export interface StockAlert {
  id: string;
  symbol: string;
  targetPrice: number;
  condition: 'ABOVE' | 'BELOW' | 'VOLUME' | '52W_BREAKOUT';
  triggered: boolean;
  createdAt: string;
}

export const SECTORS_LIST: SectorType[] = [
  'IT',
  'BANKING',
  'FINANCIAL SERVICES',
  'AUTO',
  'PHARMA',
  'METAL',
  'ENERGY',
  'FMCG',
  'REALTY',
  'TELECOM',
  'CHEMICAL',
];

export const SEGMENTS_LIST: MarketSegment[] = [
  'NIFTY 50',
  'NIFTY NEXT 50',
  'NIFTY 100',
  'NIFTY 200',
  'NIFTY 500',
  'BANKNIFTY STOCKS',
  'FINNIFTY STOCKS',
  'MIDCAP 100',
  'SMALLCAP 100',
  'ALL NSE STOCKS',
];

// Curated comprehensive initial universe of NSE stocks across sectors and segments
export const INITIAL_STOCKS: StockQuote[] = [
  {
    symbol: 'RELIANCE',
    name: 'Reliance Industries Ltd.',
    sector: 'ENERGY',
    segments: ['NIFTY 50', 'NIFTY 100', 'NIFTY 200', 'NIFTY 500', 'ALL NSE STOCKS'],
    ltp: 2984.50,
    prevClose: 2955.10,
    change: 29.40,
    pChange: 0.99,
    open: 2960.00,
    high: 2992.40,
    low: 2952.10,
    volume: 6420500,
    turnoverCr: 1912.4,
    tradesCount: 245000,
    marketCapCr: 2018500,
    week52High: 3024.90,
    week52Low: 2220.30,
    vwap: 2978.20,
    peRatio: 28.4,
    eps: 105.2,
    dividendYield: 0.35,
    lastTickDir: 'up',
    sparkline: [2955, 2962, 2958, 2970, 2981, 2975, 2984.5],
  },
  {
    symbol: 'TCS',
    name: 'Tata Consultancy Services Ltd.',
    sector: 'IT',
    segments: ['NIFTY 50', 'NIFTY 100', 'NIFTY 200', 'NIFTY 500', 'ALL NSE STOCKS'],
    ltp: 4280.20,
    prevClose: 4235.60,
    change: 44.60,
    pChange: 1.05,
    open: 4240.00,
    high: 4295.00,
    low: 4230.10,
    volume: 2150400,
    turnoverCr: 918.5,
    tradesCount: 168000,
    marketCapCr: 1548200,
    week52High: 4585.90,
    week52Low: 3313.00,
    vwap: 4272.10,
    peRatio: 32.1,
    eps: 133.4,
    dividendYield: 1.25,
    lastTickDir: 'up',
    sparkline: [4235, 4242, 4250, 4268, 4274, 4270, 4280.2],
  },
  {
    symbol: 'HDFCBANK',
    name: 'HDFC Bank Ltd.',
    sector: 'BANKING',
    segments: ['NIFTY 50', 'NIFTY 100', 'NIFTY 200', 'NIFTY 500', 'BANKNIFTY STOCKS', 'FINNIFTY STOCKS', 'ALL NSE STOCKS'],
    ltp: 1672.40,
    prevClose: 1658.20,
    change: 14.20,
    pChange: 0.86,
    open: 1660.00,
    high: 1678.90,
    low: 1654.50,
    volume: 18450200,
    turnoverCr: 3085.1,
    tradesCount: 385000,
    marketCapCr: 1271400,
    week52High: 1794.00,
    week52Low: 1363.55,
    vwap: 1668.40,
    peRatio: 19.8,
    eps: 84.5,
    dividendYield: 1.15,
    lastTickDir: 'up',
    sparkline: [1658, 1662, 1660, 1668, 1675, 1670, 1672.4],
  },
  {
    symbol: 'ICICIBANK',
    name: 'ICICI Bank Ltd.',
    sector: 'BANKING',
    segments: ['NIFTY 50', 'NIFTY 100', 'NIFTY 200', 'NIFTY 500', 'BANKNIFTY STOCKS', 'FINNIFTY STOCKS', 'ALL NSE STOCKS'],
    ltp: 1248.80,
    prevClose: 1238.10,
    change: 10.70,
    pChange: 0.86,
    open: 1240.00,
    high: 1254.00,
    low: 1236.20,
    volume: 12400300,
    turnoverCr: 1548.2,
    tradesCount: 210000,
    marketCapCr: 878400,
    week52High: 1332.00,
    week52Low: 913.80,
    vwap: 1245.50,
    peRatio: 18.2,
    eps: 68.6,
    dividendYield: 0.82,
    lastTickDir: 'up',
    sparkline: [1238, 1242, 1240, 1246, 1251, 1247, 1248.8],
  },
  {
    symbol: 'INFY',
    name: 'Infosys Ltd.',
    sector: 'IT',
    segments: ['NIFTY 50', 'NIFTY 100', 'NIFTY 200', 'NIFTY 500', 'ALL NSE STOCKS'],
    ltp: 1912.30,
    prevClose: 1894.50,
    change: 17.80,
    pChange: 0.94,
    open: 1900.00,
    high: 1920.00,
    low: 1892.40,
    volume: 7850200,
    turnoverCr: 1502.8,
    tradesCount: 195000,
    marketCapCr: 794200,
    week52High: 1990.90,
    week52Low: 1358.35,
    vwap: 1910.10,
    peRatio: 29.5,
    eps: 64.8,
    dividendYield: 2.10,
    lastTickDir: 'up',
    sparkline: [1894, 1902, 1898, 1908, 1916, 1911, 1912.3],
  },
  {
    symbol: 'BHARTIARTL',
    name: 'Bharti Airtel Ltd.',
    sector: 'TELECOM',
    segments: ['NIFTY 50', 'NIFTY 100', 'NIFTY 200', 'NIFTY 500', 'ALL NSE STOCKS'],
    ltp: 1684.50,
    prevClose: 1670.00,
    change: 14.50,
    pChange: 0.87,
    open: 1672.00,
    high: 1695.00,
    low: 1668.20,
    volume: 5210000,
    turnoverCr: 878.2,
    tradesCount: 142000,
    marketCapCr: 978500,
    week52High: 1779.00,
    week52Low: 890.00,
    vwap: 1682.00,
    peRatio: 64.2,
    eps: 26.2,
    dividendYield: 0.48,
    lastTickDir: 'up',
    sparkline: [1670, 1675, 1672, 1680, 1688, 1683, 1684.5],
  },
  {
    symbol: 'SBIN',
    name: 'State Bank of India',
    sector: 'BANKING',
    segments: ['NIFTY 50', 'NIFTY 100', 'NIFTY 200', 'NIFTY 500', 'BANKNIFTY STOCKS', 'FINNIFTY STOCKS', 'ALL NSE STOCKS'],
    ltp: 792.40,
    prevClose: 804.80,
    change: -12.40,
    pChange: -1.54,
    open: 802.00,
    high: 805.50,
    low: 789.20,
    volume: 16200400,
    turnoverCr: 1288.6,
    tradesCount: 284000,
    marketCapCr: 707100,
    week52High: 912.00,
    week52Low: 543.20,
    vwap: 795.30,
    peRatio: 10.4,
    eps: 76.2,
    dividendYield: 1.74,
    lastTickDir: 'down',
    sparkline: [804, 801, 798, 794, 791, 793, 792.4],
  },
  {
    symbol: 'LICI',
    name: 'Life Insurance Corporation of India',
    sector: 'FINANCIAL SERVICES',
    segments: ['NIFTY 50', 'NIFTY 100', 'NIFTY 200', 'NIFTY 500', 'FINNIFTY STOCKS', 'ALL NSE STOCKS'],
    ltp: 965.80,
    prevClose: 978.40,
    change: -12.60,
    pChange: -1.29,
    open: 975.00,
    high: 981.00,
    low: 962.00,
    volume: 4120000,
    turnoverCr: 399.8,
    tradesCount: 112000,
    marketCapCr: 610800,
    week52High: 1222.00,
    week52Low: 597.65,
    vwap: 968.20,
    peRatio: 14.8,
    eps: 65.2,
    dividendYield: 1.05,
    lastTickDir: 'down',
    sparkline: [978, 974, 971, 966, 963, 967, 965.8],
  },
  {
    symbol: 'ITC',
    name: 'ITC Ltd.',
    sector: 'FMCG',
    segments: ['NIFTY 50', 'NIFTY 100', 'NIFTY 200', 'NIFTY 500', 'ALL NSE STOCKS'],
    ltp: 512.40,
    prevClose: 508.10,
    change: 4.30,
    pChange: 0.85,
    open: 509.00,
    high: 515.80,
    low: 507.20,
    volume: 14800200,
    turnoverCr: 758.3,
    tradesCount: 220000,
    marketCapCr: 641200,
    week52High: 528.50,
    week52Low: 399.30,
    vwap: 511.90,
    peRatio: 31.4,
    eps: 16.3,
    dividendYield: 2.68,
    lastTickDir: 'up',
    sparkline: [508, 510, 509, 513, 515, 511, 512.4],
  },
  {
    symbol: 'HINDUNILVR',
    name: 'Hindustan Unilever Ltd.',
    sector: 'FMCG',
    segments: ['NIFTY 50', 'NIFTY 100', 'NIFTY 200', 'NIFTY 500', 'ALL NSE STOCKS'],
    ltp: 2842.10,
    prevClose: 2818.40,
    change: 23.70,
    pChange: 0.84,
    open: 2822.00,
    high: 2855.00,
    low: 2815.00,
    volume: 2450000,
    turnoverCr: 695.2,
    tradesCount: 135000,
    marketCapCr: 667800,
    week52High: 3035.00,
    week52Low: 2172.05,
    vwap: 2838.50,
    peRatio: 64.5,
    eps: 44.1,
    dividendYield: 1.48,
    lastTickDir: 'up',
    sparkline: [2818, 2825, 2830, 2840, 2848, 2839, 2842.1],
  },
  {
    symbol: 'LT',
    name: 'Larsen & Toubro Ltd.',
    sector: 'INFRA',
    segments: ['NIFTY 50', 'NIFTY 100', 'NIFTY 200', 'NIFTY 500', 'ALL NSE STOCKS'],
    ltp: 3624.50,
    prevClose: 3588.00,
    change: 36.50,
    pChange: 1.02,
    open: 3595.00,
    high: 3640.00,
    low: 3585.00,
    volume: 3200100,
    turnoverCr: 1158.4,
    tradesCount: 174000,
    marketCapCr: 498500,
    week52High: 3919.90,
    week52Low: 2862.00,
    vwap: 3618.20,
    peRatio: 37.8,
    eps: 95.8,
    dividendYield: 0.94,
    lastTickDir: 'up',
    sparkline: [3588, 3598, 3605, 3620, 3632, 3622, 3624.5],
  },
  {
    symbol: 'TATAMOTORS',
    name: 'Tata Motors Ltd.',
    sector: 'AUTO',
    segments: ['NIFTY 50', 'NIFTY 100', 'NIFTY 200', 'NIFTY 500', 'ALL NSE STOCKS'],
    ltp: 968.40,
    prevClose: 994.20,
    change: -25.80,
    pChange: -2.60,
    open: 990.00,
    high: 992.50,
    low: 962.00,
    volume: 18900400,
    turnoverCr: 1845.6,
    tradesCount: 395000,
    marketCapCr: 356200,
    week52High: 1179.05,
    week52Low: 616.00,
    vwap: 974.20,
    peRatio: 11.2,
    eps: 86.4,
    dividendYield: 0.62,
    lastTickDir: 'down',
    sparkline: [994, 988, 980, 974, 966, 970, 968.4],
  },
  {
    symbol: 'MARUTI',
    name: 'Maruti Suzuki India Ltd.',
    sector: 'AUTO',
    segments: ['NIFTY 50', 'NIFTY 100', 'NIFTY 200', 'NIFTY 500', 'ALL NSE STOCKS'],
    ltp: 12480.00,
    prevClose: 12350.00,
    change: 130.00,
    pChange: 1.05,
    open: 12380.00,
    high: 12540.00,
    low: 12320.00,
    volume: 680200,
    turnoverCr: 846.1,
    tradesCount: 115000,
    marketCapCr: 392400,
    week52High: 13680.00,
    week52Low: 9250.00,
    vwap: 12440.00,
    peRatio: 28.5,
    eps: 438.0,
    dividendYield: 1.00,
    lastTickDir: 'up',
    sparkline: [12350, 12380, 12410, 12470, 12510, 12460, 12480],
  },
  {
    symbol: 'SUNPHARMA',
    name: 'Sun Pharmaceutical Industries Ltd.',
    sector: 'PHARMA',
    segments: ['NIFTY 50', 'NIFTY 100', 'NIFTY 200', 'NIFTY 500', 'ALL NSE STOCKS'],
    ltp: 1895.40,
    prevClose: 1862.00,
    change: 33.40,
    pChange: 1.79,
    open: 1868.00,
    high: 1908.00,
    low: 1864.00,
    volume: 3840000,
    turnoverCr: 726.5,
    tradesCount: 142000,
    marketCapCr: 454800,
    week52High: 1960.00,
    week52Low: 1098.00,
    vwap: 1890.20,
    peRatio: 44.8,
    eps: 42.3,
    dividendYield: 0.71,
    lastTickDir: 'up',
    sparkline: [1862, 1872, 1878, 1888, 1898, 1892, 1895.4],
  },
  {
    symbol: 'CIPLA',
    name: 'Cipla Ltd.',
    sector: 'PHARMA',
    segments: ['NIFTY 50', 'NIFTY 100', 'NIFTY 200', 'NIFTY 500', 'ALL NSE STOCKS'],
    ltp: 1642.50,
    prevClose: 1618.00,
    change: 24.50,
    pChange: 1.51,
    open: 1622.00,
    high: 1650.00,
    low: 1615.00,
    volume: 2420000,
    turnoverCr: 397.4,
    tradesCount: 98000,
    marketCapCr: 132600,
    week52High: 1702.00,
    week52Low: 1131.00,
    vwap: 1638.00,
    peRatio: 30.2,
    eps: 54.4,
    dividendYield: 0.79,
    lastTickDir: 'up',
    sparkline: [1618, 1625, 1630, 1638, 1645, 1640, 1642.5],
  },
  {
    symbol: 'TATASTEEL',
    name: 'Tata Steel Ltd.',
    sector: 'METAL',
    segments: ['NIFTY 50', 'NIFTY 100', 'NIFTY 200', 'NIFTY 500', 'ALL NSE STOCKS'],
    ltp: 154.20,
    prevClose: 151.10,
    change: 3.10,
    pChange: 2.05,
    open: 151.50,
    high: 156.40,
    low: 150.80,
    volume: 48200500,
    turnoverCr: 742.3,
    tradesCount: 345000,
    marketCapCr: 192500,
    week52High: 184.60,
    week52Low: 114.60,
    vwap: 153.80,
    peRatio: 48.6,
    eps: 3.17,
    dividendYield: 2.33,
    lastTickDir: 'up',
    sparkline: [151, 152, 153, 155, 156, 154, 154.2],
  },
  {
    symbol: 'JSWSTEEL',
    name: 'JSW Steel Ltd.',
    sector: 'METAL',
    segments: ['NIFTY 50', 'NIFTY 100', 'NIFTY 200', 'NIFTY 500', 'ALL NSE STOCKS'],
    ltp: 988.50,
    prevClose: 968.00,
    change: 20.50,
    pChange: 2.12,
    open: 972.00,
    high: 996.00,
    low: 966.50,
    volume: 4850000,
    turnoverCr: 479.5,
    tradesCount: 145000,
    marketCapCr: 241800,
    week52High: 1045.00,
    week52Low: 735.00,
    vwap: 984.00,
    peRatio: 32.5,
    eps: 30.4,
    dividendYield: 0.74,
    lastTickDir: 'up',
    sparkline: [968, 975, 978, 985, 992, 986, 988.5],
  },
  {
    symbol: 'BAJFINANCE',
    name: 'Bajaj Finance Ltd.',
    sector: 'FINANCIAL SERVICES',
    segments: ['NIFTY 50', 'NIFTY 100', 'NIFTY 200', 'NIFTY 500', 'FINNIFTY STOCKS', 'ALL NSE STOCKS'],
    ltp: 7480.00,
    prevClose: 7390.00,
    change: 90.00,
    pChange: 1.22,
    open: 7410.00,
    high: 7520.00,
    low: 7380.00,
    volume: 1650000,
    turnoverCr: 1234.2,
    tradesCount: 185000,
    marketCapCr: 462800,
    week52High: 8192.00,
    week52Low: 6360.00,
    vwap: 7465.00,
    peRatio: 31.8,
    eps: 235.0,
    dividendYield: 0.48,
    lastTickDir: 'up',
    sparkline: [7390, 7420, 7440, 7490, 7510, 7470, 7480],
  },
  {
    symbol: 'DLF',
    name: 'DLF Ltd.',
    sector: 'REALTY',
    segments: ['NIFTY 100', 'NIFTY 200', 'NIFTY 500', 'ALL NSE STOCKS'],
    ltp: 884.20,
    prevClose: 868.00,
    change: 16.20,
    pChange: 1.87,
    open: 871.00,
    high: 894.00,
    low: 866.00,
    volume: 6850000,
    turnoverCr: 605.5,
    tradesCount: 172000,
    marketCapCr: 218900,
    week52High: 967.60,
    week52Low: 490.00,
    vwap: 881.00,
    peRatio: 72.4,
    eps: 12.2,
    dividendYield: 0.57,
    lastTickDir: 'up',
    sparkline: [868, 874, 876, 882, 890, 882, 884.2],
  },
  {
    symbol: 'PIDILITIND',
    name: 'Pidilite Industries Ltd.',
    sector: 'CHEMICAL',
    segments: ['NIFTY 100', 'NIFTY 200', 'NIFTY 500', 'ALL NSE STOCKS'],
    ltp: 3120.40,
    prevClose: 3145.00,
    change: -24.60,
    pChange: -0.78,
    open: 3140.00,
    high: 3155.00,
    low: 3110.00,
    volume: 820000,
    turnoverCr: 256.4,
    tradesCount: 68000,
    marketCapCr: 158700,
    week52High: 3340.00,
    week52Low: 2280.00,
    vwap: 3128.00,
    peRatio: 88.5,
    eps: 35.2,
    dividendYield: 0.51,
    lastTickDir: 'down',
    sparkline: [3145, 3138, 3132, 3125, 3115, 3122, 3120.4],
  },
  {
    symbol: 'ZOMATO',
    name: 'Zomato Ltd.',
    sector: 'CONSUMPTION',
    segments: ['NIFTY NEXT 50', 'NIFTY 100', 'NIFTY 200', 'NIFTY 500', 'ALL NSE STOCKS'],
    ltp: 278.40,
    prevClose: 268.20,
    change: 10.20,
    pChange: 3.80,
    open: 270.00,
    high: 282.50,
    low: 268.00,
    volume: 54200000,
    turnoverCr: 1495.8,
    tradesCount: 485000,
    marketCapCr: 245600,
    week52High: 298.20,
    week52Low: 98.60,
    vwap: 276.50,
    peRatio: 124.5,
    eps: 2.23,
    dividendYield: 0.00,
    lastTickDir: 'up',
    sparkline: [268, 272, 274, 278, 281, 277, 278.4],
  },
  {
    symbol: 'TRENT',
    name: 'Trent Ltd.',
    sector: 'CONSUMPTION',
    segments: ['NIFTY 50', 'NIFTY 100', 'NIFTY 200', 'NIFTY 500', 'ALL NSE STOCKS'],
    ltp: 7420.50,
    prevClose: 7210.00,
    change: 210.50,
    pChange: 2.92,
    open: 7250.00,
    high: 7480.00,
    low: 7230.00,
    volume: 2450000,
    turnoverCr: 1812.5,
    tradesCount: 265000,
    marketCapCr: 263800,
    week52High: 8345.00,
    week52Low: 2040.00,
    vwap: 7390.00,
    peRatio: 180.2,
    eps: 41.2,
    dividendYield: 0.04,
    lastTickDir: 'up',
    sparkline: [7210, 7260, 7310, 7380, 7450, 7410, 7420.5],
  },
  {
    symbol: 'BEL',
    name: 'Bharat Electronics Ltd.',
    sector: 'INFRA',
    segments: ['NIFTY 50', 'NIFTY 100', 'NIFTY 200', 'NIFTY 500', 'ALL NSE STOCKS'],
    ltp: 298.60,
    prevClose: 291.40,
    change: 7.20,
    pChange: 2.47,
    open: 293.00,
    high: 301.80,
    low: 291.00,
    volume: 28400000,
    turnoverCr: 845.2,
    tradesCount: 312000,
    marketCapCr: 218200,
    week52High: 340.50,
    week52Low: 130.20,
    vwap: 296.80,
    peRatio: 48.2,
    eps: 6.19,
    dividendYield: 0.74,
    lastTickDir: 'up',
    sparkline: [291, 294, 295, 298, 301, 297, 298.6],
  },
  {
    symbol: 'SUZLON',
    name: 'Suzlon Energy Ltd.',
    sector: 'ENERGY',
    segments: ['MIDCAP 100', 'NIFTY 200', 'NIFTY 500', 'ALL NSE STOCKS'],
    ltp: 81.40,
    prevClose: 84.60,
    change: -3.20,
    pChange: -3.78,
    open: 84.00,
    high: 85.20,
    low: 80.50,
    volume: 68400000,
    turnoverCr: 562.4,
    tradesCount: 520000,
    marketCapCr: 110800,
    week52High: 86.00,
    week52Low: 23.50,
    vwap: 82.20,
    peRatio: 98.4,
    eps: 0.82,
    dividendYield: 0.00,
    lastTickDir: 'down',
    sparkline: [84.6, 83.8, 83.1, 82.2, 81.0, 81.8, 81.4],
  },
  {
    symbol: 'IREDA',
    name: 'Indian Renewable Energy Development Agency',
    sector: 'FINANCIAL SERVICES',
    segments: ['MIDCAP 100', 'NIFTY 200', 'NIFTY 500', 'ALL NSE STOCKS'],
    ltp: 228.50,
    prevClose: 235.00,
    change: -6.50,
    pChange: -2.77,
    open: 234.00,
    high: 236.80,
    low: 226.40,
    volume: 24500000,
    turnoverCr: 565.4,
    tradesCount: 380000,
    marketCapCr: 61400,
    week52High: 310.00,
    week52Low: 50.00,
    vwap: 230.10,
    peRatio: 48.6,
    eps: 4.70,
    dividendYield: 0.00,
    lastTickDir: 'down',
    sparkline: [235, 233, 231, 229, 227, 229, 228.5],
  },
  {
    symbol: 'KALYANKJIL',
    name: 'Kalyan Jewellers India Ltd.',
    sector: 'CONSUMPTION',
    segments: ['MIDCAP 100', 'NIFTY 200', 'NIFTY 500', 'ALL NSE STOCKS'],
    ltp: 724.80,
    prevClose: 698.00,
    change: 26.80,
    pChange: 3.84,
    open: 702.00,
    high: 735.00,
    low: 699.00,
    volume: 8400000,
    turnoverCr: 608.2,
    tradesCount: 165000,
    marketCapCr: 74600,
    week52High: 748.00,
    week52Low: 218.00,
    vwap: 718.50,
    peRatio: 112.4,
    eps: 6.44,
    dividendYield: 0.17,
    lastTickDir: 'up',
    sparkline: [698, 706, 712, 720, 728, 722, 724.8],
  },
  {
    symbol: 'CDSL',
    name: 'Central Depository Services (India) Ltd.',
    sector: 'FINANCIAL SERVICES',
    segments: ['MIDCAP 100', 'NIFTY 500', 'ALL NSE STOCKS'],
    ltp: 1482.00,
    prevClose: 1445.00,
    change: 37.00,
    pChange: 2.56,
    open: 1450.00,
    high: 1496.00,
    low: 1442.00,
    volume: 4120000,
    turnoverCr: 610.5,
    tradesCount: 198000,
    marketCapCr: 30980,
    week52High: 1664.00,
    week52Low: 642.00,
    vwap: 1475.00,
    peRatio: 64.5,
    eps: 22.9,
    dividendYield: 1.15,
    lastTickDir: 'up',
    sparkline: [1445, 1455, 1462, 1474, 1488, 1479, 1482],
  },
  {
    symbol: 'BSE',
    name: 'BSE Ltd.',
    sector: 'FINANCIAL SERVICES',
    segments: ['MIDCAP 100', 'NIFTY 200', 'NIFTY 500', 'ALL NSE STOCKS'],
    ltp: 4120.00,
    prevClose: 3980.00,
    change: 140.00,
    pChange: 3.52,
    open: 4000.00,
    high: 4180.00,
    low: 3990.00,
    volume: 3820000,
    turnoverCr: 1572.4,
    tradesCount: 310000,
    marketCapCr: 55800,
    week52High: 4250.00,
    week52Low: 1120.00,
    vwap: 4095.00,
    peRatio: 78.2,
    eps: 52.6,
    dividendYield: 0.36,
    lastTickDir: 'up',
    sparkline: [3980, 4010, 4050, 4090, 4150, 4110, 4120],
  },
  {
    symbol: 'ZOMATO',
    name: 'Zomato Ltd.',
    sector: 'CONSUMPTION',
    segments: ['NIFTY NEXT 50', 'NIFTY 100', 'NIFTY 200', 'NIFTY 500', 'ALL NSE STOCKS'],
    ltp: 278.40,
    prevClose: 268.20,
    change: 10.20,
    pChange: 3.80,
    open: 270.00,
    high: 282.50,
    low: 268.00,
    volume: 54200000,
    turnoverCr: 1495.8,
    tradesCount: 485000,
    marketCapCr: 245600,
    week52High: 298.20,
    week52Low: 98.60,
    vwap: 276.50,
    peRatio: 124.5,
    eps: 2.23,
    dividendYield: 0.00,
    lastTickDir: 'up',
    sparkline: [268, 272, 274, 278, 281, 277, 278.4],
  },
  {
    symbol: 'OLECTRA',
    name: 'Olectra Greentech Ltd.',
    sector: 'AUTO',
    segments: ['SMALLCAP 100', 'NIFTY 500', 'ALL NSE STOCKS'],
    ltp: 1680.00,
    prevClose: 1640.00,
    change: 40.00,
    pChange: 2.44,
    open: 1645.00,
    high: 1710.00,
    low: 1638.00,
    volume: 1850000,
    turnoverCr: 310.8,
    tradesCount: 94000,
    marketCapCr: 13800,
    week52High: 2222.00,
    week52Low: 1020.00,
    vwap: 1672.00,
    peRatio: 125.0,
    eps: 13.4,
    dividendYield: 0.02,
    lastTickDir: 'up',
    sparkline: [1640, 1650, 1665, 1690, 1705, 1675, 1680],
  },
  {
    symbol: 'MAPMYINDIA',
    name: 'CE Info Systems Ltd.',
    sector: 'IT',
    segments: ['SMALLCAP 100', 'NIFTY 500', 'ALL NSE STOCKS'],
    ltp: 2185.00,
    prevClose: 2240.00,
    change: -55.00,
    pChange: -2.46,
    open: 2235.00,
    high: 2250.00,
    low: 2170.00,
    volume: 980000,
    turnoverCr: 216.5,
    tradesCount: 78000,
    marketCapCr: 11850,
    week52High: 2745.00,
    week52Low: 1720.00,
    vwap: 2202.00,
    peRatio: 82.5,
    eps: 26.4,
    dividendYield: 0.16,
    lastTickDir: 'down',
    sparkline: [2240, 2225, 2210, 2195, 2180, 2190, 2185],
  },
  {
    symbol: 'KEC',
    name: 'KEC International Ltd.',
    sector: 'INFRA',
    segments: ['SMALLCAP 100', 'NIFTY 500', 'ALL NSE STOCKS'],
    ltp: 984.50,
    prevClose: 945.00,
    change: 39.50,
    pChange: 4.18,
    open: 950.00,
    high: 998.00,
    low: 946.00,
    volume: 3200000,
    turnoverCr: 312.4,
    tradesCount: 112000,
    marketCapCr: 25300,
    week52High: 1045.00,
    week52Low: 565.00,
    vwap: 976.00,
    peRatio: 52.4,
    eps: 18.7,
    dividendYield: 0.41,
    lastTickDir: 'up',
    sparkline: [945, 955, 968, 982, 995, 980, 984.5],
  },
  {
    symbol: 'DEEPAKNTR',
    name: 'Deepak Nitrite Ltd.',
    sector: 'CHEMICAL',
    segments: ['MIDCAP 100', 'NIFTY 200', 'NIFTY 500', 'ALL NSE STOCKS'],
    ltp: 2840.00,
    prevClose: 2885.00,
    change: -45.00,
    pChange: -1.56,
    open: 2880.00,
    high: 2895.00,
    low: 2825.00,
    volume: 1240000,
    turnoverCr: 352.8,
    tradesCount: 92000,
    marketCapCr: 38750,
    week52High: 3125.00,
    week52Low: 1965.00,
    vwap: 2848.00,
    peRatio: 46.8,
    eps: 60.6,
    dividendYield: 0.26,
    lastTickDir: 'down',
    sparkline: [2885, 2870, 2860, 2845, 2835, 2842, 2840],
  },
];

/**
 * Service managing live stock quotes and real-time 1-second price ticks
 */
class StocksMarketWatchService {
  private stocks: Map<string, StockQuote> = new Map();
  private subscribers: ((stocks: StockQuote[]) => void)[] = [];
  private tickInterval: NodeJS.Timeout | null = null;
  private watchlists: Record<string, string[]> = {
    'Default Watchlist': ['RELIANCE', 'TCS', 'HDFCBANK', 'ICICIBANK', 'INFY', 'BHARTIARTL', 'TATAMOTORS'],
    'Banking Titans': ['HDFCBANK', 'ICICIBANK', 'SBIN'],
    'High Growth': ['ZOMATO', 'TRENT', 'BSE', 'CDSL', 'KEC'],
  };
  private alerts: StockAlert[] = [];

  constructor() {
    INITIAL_STOCKS.forEach((s) => this.stocks.set(s.symbol, { ...s }));
    this.loadWatchlists();
    this.startStreaming();
  }

  public getStocks(): StockQuote[] {
    return Array.from(this.stocks.values());
  }

  public getStock(symbol: string): StockQuote | undefined {
    return this.stocks.get(symbol);
  }

  public subscribe(cb: (stocks: StockQuote[]) => void) {
    this.subscribers.push(cb);
    cb(this.getStocks());
    return () => {
      this.subscribers = this.subscribers.filter((s) => s !== cb);
    };
  }

  private notify() {
    const list = this.getStocks();
    this.subscribers.forEach((cb) => cb(list));
  }

  private startStreaming() {
    // 1-second real-time streaming updates
    this.tickInterval = setInterval(() => {
      const all = Array.from(this.stocks.values());
      // Randomly update 3 to 6 stocks every 1 second
      const updateCount = Math.floor(Math.random() * 4) + 3;
      for (let i = 0; i < updateCount; i++) {
        const randStock = all[Math.floor(Math.random() * all.length)];
        if (!randStock) continue;

        const maxTick = Math.max(0.05, randStock.ltp * 0.0015);
        const tickDelta = +( (Math.random() * (maxTick * 2) - maxTick).toFixed(2) );
        const newPrice = +(Math.max(1, randStock.ltp + tickDelta).toFixed(2));

        const dir = tickDelta > 0 ? 'up' : tickDelta < 0 ? 'down' : 'none';
        randStock.ltp = newPrice;
        randStock.change = +(newPrice - randStock.prevClose).toFixed(2);
        randStock.pChange = +(((randStock.change) / randStock.prevClose) * 100).toFixed(2);

        if (newPrice > randStock.high) randStock.high = newPrice;
        if (newPrice < randStock.low) randStock.low = newPrice;

        randStock.volume += Math.floor(Math.random() * 500) + 50;
        randStock.tradesCount += Math.floor(Math.random() * 20) + 1;
        randStock.lastTickDir = dir;

        // Sparkline update
        randStock.sparkline = [...randStock.sparkline.slice(-10), newPrice];

        // Check alerts
        this.checkAlerts(randStock);
      }

      this.notify();
    }, 1000);
  }

  // Watchlist Management
  public getWatchlists(): Record<string, string[]> {
    return this.watchlists;
  }

  public createWatchlist(name: string) {
    if (!this.watchlists[name]) {
      this.watchlists[name] = [];
      this.saveWatchlists();
    }
  }

  public toggleWatchlistStock(watchlistName: string, symbol: string) {
    if (!this.watchlists[watchlistName]) {
      this.watchlists[watchlistName] = [];
    }
    const list = this.watchlists[watchlistName];
    const idx = list.indexOf(symbol);
    if (idx >= 0) {
      list.splice(idx, 1);
    } else {
      list.push(symbol);
    }
    this.saveWatchlists();
  }

  public isInWatchlist(watchlistName: string, symbol: string): boolean {
    return !!this.watchlists[watchlistName]?.includes(symbol);
  }

  private saveWatchlists() {
    try {
      localStorage.setItem('marketwatch_watchlists', JSON.stringify(this.watchlists));
    } catch {
      // ignore
    }
  }

  private loadWatchlists() {
    try {
      const saved = localStorage.getItem('marketwatch_watchlists');
      if (saved) {
        this.watchlists = { ...this.watchlists, ...JSON.parse(saved) };
      }
    } catch {
      // ignore
    }
  }

  // Alerts Management
  public addAlert(symbol: string, targetPrice: number, condition: 'ABOVE' | 'BELOW' | 'VOLUME' | '52W_BREAKOUT') {
    const alert: StockAlert = {
      id: 'alt_' + Date.now() + '_' + Math.random().toString(36).substr(2, 4),
      symbol,
      targetPrice,
      condition,
      triggered: false,
      createdAt: new Date().toLocaleTimeString(),
    };
    this.alerts.push(alert);
  }

  public getAlerts(): StockAlert[] {
    return this.alerts;
  }

  public removeAlert(id: string) {
    this.alerts = this.alerts.filter((a) => a.id !== id);
  }

  private checkAlerts(stock: StockQuote) {
    this.alerts.forEach((alt) => {
      if (alt.symbol === stock.symbol && !alt.triggered) {
        if (alt.condition === 'ABOVE' && stock.ltp >= alt.targetPrice) {
          alt.triggered = true;
        } else if (alt.condition === 'BELOW' && stock.ltp <= alt.targetPrice) {
          alt.triggered = true;
        } else if (alt.condition === '52W_BREAKOUT' && stock.ltp >= stock.week52High) {
          alt.triggered = true;
        }
      }
    });
  }

  public destroy() {
    if (this.tickInterval) {
      clearInterval(this.tickInterval);
    }
  }
}

export const stocksMarketWatch = new StocksMarketWatchService();
