import {
  Greeks,
  IndexMarketData,
  IndexSymbol,
  OptionContractData,
  StrikeRow,
  OIBuildupType,
} from '../types';
import { calculateGreeks } from '../utils/blackScholes';
import { determineBuildup } from '../utils/optionsAnalytics';

// Base index configurations
export const INITIAL_INDICES: Record<IndexSymbol, IndexMarketData> = {
  NIFTY: {
    symbol: 'NIFTY',
    name: 'NIFTY 50',
    spotPrice: 24864.20,
    futurePrice: 24918.50,
    prevClose: 24792.80,
    change: 71.40,
    pChange: 0.29,
    high: 24915.60,
    low: 24780.10,
    open: 24805.30,
    lotSize: 50,
    strikeStep: 50,
    vix: 13.42,
    expiries: ['01 OCT 2026', '08 OCT 2026', '15 OCT 2026', '29 OCT 2026', '26 NOV 2026'],
    currentExpiry: '01 OCT 2026',
    marketStatus: 'OPEN',
  },
  BANKNIFTY: {
    symbol: 'BANKNIFTY',
    name: 'NIFTY BANK',
    spotPrice: 53285.50,
    futurePrice: 53420.75,
    prevClose: 52940.10,
    change: 345.40,
    pChange: 0.65,
    high: 53420.00,
    low: 52890.30,
    open: 52990.00,
    lotSize: 15,
    strikeStep: 100,
    vix: 14.85,
    expiries: ['01 OCT 2026', '08 OCT 2026', '29 OCT 2026'],
    currentExpiry: '01 OCT 2026',
    marketStatus: 'OPEN',
  },
  FINNIFTY: {
    symbol: 'FINNIFTY',
    name: 'NIFTY FINANCIAL',
    spotPrice: 24190.75,
    futurePrice: 24245.20,
    prevClose: 24085.30,
    change: 105.45,
    pChange: 0.44,
    high: 24240.00,
    low: 24060.00,
    open: 24110.20,
    lotSize: 40,
    strikeStep: 50,
    vix: 13.90,
    expiries: ['01 OCT 2026', '08 OCT 2026', '29 OCT 2026'],
    currentExpiry: '01 OCT 2026',
    marketStatus: 'OPEN',
  },
  MIDCPNIFTY: {
    symbol: 'MIDCPNIFTY',
    name: 'NIFTY MIDCAP SELECT',
    spotPrice: 13125.60,
    futurePrice: 13156.40,
    prevClose: 13180.20,
    change: -54.60,
    pChange: -0.41,
    high: 13210.40,
    low: 13090.80,
    open: 13195.00,
    lotSize: 75,
    strikeStep: 25,
    vix: 15.20,
    expiries: ['01 OCT 2026', '08 OCT 2026', '29 OCT 2026'],
    currentExpiry: '01 OCT 2026',
    marketStatus: 'OPEN',
  },
  SENSEX: {
    symbol: 'SENSEX',
    name: 'BSE SENSEX',
    spotPrice: 81452.30,
    futurePrice: 81615.80,
    prevClose: 81210.90,
    change: 241.40,
    pChange: 0.30,
    high: 81650.00,
    low: 81180.00,
    open: 81290.00,
    lotSize: 10,
    strikeStep: 100,
    vix: 13.10,
    expiries: ['01 OCT 2026', '08 OCT 2026', '29 OCT 2026'],
    currentExpiry: '01 OCT 2026',
    marketStatus: 'OPEN',
  },
};

/**
 * Generate full strike chain for given index and spot
 */
export function generateOptionChain(
  indexData: IndexMarketData,
  daysToExpiry: number = 4
): StrikeRow[] {
  const { spotPrice, strikeStep } = indexData;
  const atmStrike = Math.round(spotPrice / strikeStep) * strikeStep;
  const numStrikes = 24; // 24 strikes above and below
  const strikes: StrikeRow[] = [];

  const baseIV = indexData.vix / 100;
  const T = Math.max(daysToExpiry / 365, 0.002);

  // First pass: generate strikes and raw metrics
  let highestCeOi = 0;
  let highestPeOi = 0;
  let highestCeStrike = 0;
  let highestPeStrike = 0;

  for (let i = -numStrikes; i <= numStrikes; i++) {
    const strike = atmStrike + i * strikeStep;
    const distancePercent = (strike - spotPrice) / spotPrice;

    // Volatility smile: OTM options have higher implied volatility
    const callIV = baseIV + Math.pow(Math.max(0, distancePercent), 2) * 2.5 + Math.pow(Math.min(0, distancePercent), 2) * 4.0;
    const putIV = baseIV + Math.pow(Math.min(0, distancePercent), 2) * 5.0 + Math.pow(Math.max(0, distancePercent), 2) * 2.0;

    // Calculate Black-Scholes theoretical prices & greeks
    const callEval = calculateGreeks(spotPrice, strike, T, 0.068, callIV, 'CE');
    const putEval = calculateGreeks(spotPrice, strike, T, 0.068, putIV, 'PE');

    // Generate realistic Open Interest with spikes at round numbers
    const isRound1000 = strike % 1000 === 0;
    const isRound500 = strike % 500 === 0;
    const multiplier = isRound1000 ? 2.8 : isRound500 ? 1.9 : 1.0;
    
    // Normal distribution decay of OI away from spot
    const decay = Math.exp(-Math.pow(strike - spotPrice, 2) / (2 * Math.pow(strikeStep * 9, 2)));

    // Calls have higher OI above spot (resistance), Puts have higher OI below spot (support)
    const ceBias = strike >= spotPrice ? 1.4 : 0.6;
    const peBias = strike <= spotPrice ? 1.4 : 0.6;

    const baseOiLots = Math.max(500, Math.round(18000 * decay * multiplier));
    const ceOi = Math.round(baseOiLots * ceBias * indexData.lotSize);
    const peOi = Math.round(baseOiLots * peBias * indexData.lotSize);

    const ceChangeOi = Math.round((Math.sin(i * 1.5) * 0.22 + 0.05) * ceOi);
    const peChangeOi = Math.round((Math.cos(i * 1.5) * 0.25 + 0.08) * peOi);

    const ceVol = Math.round(ceOi * (0.8 + Math.random() * 0.6));
    const peVol = Math.round(peOi * (0.8 + Math.random() * 0.6));

    const callChange = Number(((Math.random() - 0.45) * (callEval.price * 0.08)).toFixed(2));
    const putChange = Number(((Math.random() - 0.48) * (putEval.price * 0.08)).toFixed(2));

    const callPrevClose = Number((callEval.price - callChange).toFixed(2));
    const putPrevClose = Number((putEval.price - putChange).toFixed(2));

    const callBuildup = determineBuildup(callChange, ceChangeOi);
    const putBuildup = determineBuildup(putChange, peChangeOi);

    if (ceOi > highestCeOi) {
      highestCeOi = ceOi;
      highestCeStrike = strike;
    }
    if (peOi > highestPeOi) {
      highestPeOi = peOi;
      highestPeStrike = strike;
    }

    const callData: OptionContractData = {
      strike,
      type: 'CE',
      ltp: callEval.price,
      prevClose: callPrevClose,
      change: callChange,
      pChange: Number(((callChange / (callPrevClose || 1)) * 100).toFixed(2)),
      oi: ceOi,
      prevOi: ceOi - ceChangeOi,
      changeOi: ceChangeOi,
      pChangeOi: Number(((ceChangeOi / ((ceOi - ceChangeOi) || 1)) * 100).toFixed(2)),
      volume: ceVol,
      iv: callEval.greeks.iv,
      greeks: callEval.greeks,
      bid: Number((callEval.price * 0.995).toFixed(2)),
      ask: Number((callEval.price * 1.005).toFixed(2)),
      buildup: callBuildup,
    };

    const putData: OptionContractData = {
      strike,
      type: 'PE',
      ltp: putEval.price,
      prevClose: putPrevClose,
      change: putChange,
      pChange: Number(((putChange / (putPrevClose || 1)) * 100).toFixed(2)),
      oi: peOi,
      prevOi: peOi - peChangeOi,
      changeOi: peChangeOi,
      pChangeOi: Number(((peChangeOi / ((peOi - peChangeOi) || 1)) * 100).toFixed(2)),
      volume: peVol,
      iv: putEval.greeks.iv,
      greeks: putEval.greeks,
      bid: Number((putEval.price * 0.995).toFixed(2)),
      ask: Number((putEval.price * 1.005).toFixed(2)),
      buildup: putBuildup,
    };

    strikes.push({
      strike,
      call: callData,
      put: putData,
      isAtm: strike === atmStrike,
      isItmCall: strike < spotPrice,
      isItmPut: strike > spotPrice,
      isMaxPain: false, // will mark in second pass
      isHighestCeOi: false,
      isHighestPeOi: false,
    });
  }

  // Second pass: mark highest OI & Max Pain strike
  strikes.forEach((row) => {
    if (row.strike === highestCeStrike) row.isHighestCeOi = true;
    if (row.strike === highestPeStrike) row.isHighestPeOi = true;
  });

  return strikes;
}

export type MarketFeedListener = (state: {
  indices: Record<IndexSymbol, IndexMarketData>;
  currentChain: StrikeRow[];
  lastUpdate: Date;
  latencyMs: number;
  packetsReceived: number;
}) => void;

class MarketFeedService {
  private indices: Record<IndexSymbol, IndexMarketData> = { ...INITIAL_INDICES };
  private activeSymbol: IndexSymbol = 'NIFTY';
  private activeExpiry: string = '01 OCT 2026';
  private optionChains: Record<string, StrikeRow[]> = {};
  private listeners: Set<MarketFeedListener> = new Set();
  private timer: number | null = null;
  private isRunning: boolean = false;
  private updateIntervalMs: number = 1000;
  private packetsReceived: number = 0;
  private latencyMs: number = 14;

  constructor() {
    this.initializeAllChains();
  }

  private initializeAllChains() {
    Object.keys(this.indices).forEach((key) => {
      const sym = key as IndexSymbol;
      const data = this.indices[sym];
      this.optionChains[`${sym}_${data.currentExpiry}`] = generateOptionChain(data, 4);
    });
  }

  public getIndices(): Record<IndexSymbol, IndexMarketData> {
    return this.indices;
  }

  public getActiveSymbol(): IndexSymbol {
    return this.activeSymbol;
  }

  public setActiveSymbol(symbol: IndexSymbol) {
    this.activeSymbol = symbol;
    const currentExpiry = this.indices[symbol].currentExpiry;
    this.activeExpiry = currentExpiry;
    if (!this.optionChains[`${symbol}_${currentExpiry}`]) {
      this.optionChains[`${symbol}_${currentExpiry}`] = generateOptionChain(this.indices[symbol], 4);
    }
    this.notify();
  }

  public getActiveExpiry(): string {
    return this.activeExpiry;
  }

  public setActiveExpiry(expiry: string) {
    this.activeExpiry = expiry;
    const cacheKey = `${this.activeSymbol}_${expiry}`;
    if (!this.optionChains[cacheKey]) {
      const days = expiry.includes('01 OCT') ? 4 : expiry.includes('08 OCT') ? 11 : 28;
      this.optionChains[cacheKey] = generateOptionChain(this.indices[this.activeSymbol], days);
    }
    this.notify();
  }

  public getCurrentChain(): StrikeRow[] {
    const key = `${this.activeSymbol}_${this.activeExpiry}`;
    if (!this.optionChains[key]) {
      this.optionChains[key] = generateOptionChain(this.indices[this.activeSymbol], 4);
    }
    return this.optionChains[key];
  }

  public subscribe(listener: MarketFeedListener): () => void {
    this.listeners.add(listener);
    listener({
      indices: this.indices,
      currentChain: this.getCurrentChain(),
      lastUpdate: new Date(),
      latencyMs: this.latencyMs,
      packetsReceived: this.packetsReceived,
    });
    return () => {
      this.listeners.delete(listener);
    };
  }

  private notify() {
    const currentChain = this.getCurrentChain();
    const now = new Date();
    this.listeners.forEach((fn) =>
      fn({
        indices: this.indices,
        currentChain,
        lastUpdate: now,
        latencyMs: this.latencyMs,
        packetsReceived: this.packetsReceived,
      })
    );
  }

  public start() {
    if (this.isRunning) return;
    this.isRunning = true;
    this.tick();
  }

  public stop() {
    if (this.timer) {
      clearTimeout(this.timer);
      this.timer = null;
    }
    this.isRunning = false;
  }

  public setSpeed(intervalMs: number) {
    this.updateIntervalMs = intervalMs;
  }

  private tick = () => {
    if (!this.isRunning) return;

    // Simulate minor spot jitter for each index
    Object.keys(this.indices).forEach((key) => {
      const sym = key as IndexSymbol;
      const item = this.indices[sym];
      // Random walk with mean reversion
      const drift = (Math.random() - 0.49) * (sym === 'BANKNIFTY' ? 4.5 : sym === 'SENSEX' ? 6.5 : 2.2);
      const newSpot = Number((item.spotPrice + drift).toFixed(2));
      const basis = (item.futurePrice && item.spotPrice) ? (item.futurePrice - item.spotPrice) : 50;
      const futJitter = (Math.random() - 0.5) * 0.6;
      const newFuture = Number((newSpot + basis + futJitter).toFixed(2));
      const change = Number((newSpot - item.prevClose).toFixed(2));
      const pChange = Number(((change / item.prevClose) * 100).toFixed(2));
      const high = Math.max(item.high, newSpot);
      const low = Math.min(item.low, newSpot);

      this.indices[sym] = {
        ...item,
        spotPrice: newSpot,
        futurePrice: newFuture,
        change,
        pChange,
        high,
        low,
      };
    });

    // Update active chain strikes
    const chainKey = `${this.activeSymbol}_${this.activeExpiry}`;
    const chain = this.optionChains[chainKey];
    const spot = this.indices[this.activeSymbol].spotPrice;

    if (chain) {
      // Pick 3-5 random strikes to actively update prices & OI
      for (let k = 0; k < 5; k++) {
        const randIdx = Math.floor(Math.random() * chain.length);
        const row = chain[randIdx];
        if (!row) continue;

        // Call update
        const callDeltaMove = (spot - row.strike > 0 ? 0.7 : 0.3) * (Math.random() - 0.48);
        const newCallLtp = Math.max(0.05, Number((row.call.ltp + callDeltaMove).toFixed(2)));
        const callDir = newCallLtp > row.call.ltp ? 'up' : newCallLtp < row.call.ltp ? 'down' : 'same';
        
        // Put update
        const putDeltaMove = (row.strike - spot > 0 ? 0.7 : 0.3) * (Math.random() - 0.48);
        const newPutLtp = Math.max(0.05, Number((row.put.ltp + putDeltaMove).toFixed(2)));
        const putDir = newPutLtp > row.put.ltp ? 'up' : newPutLtp < row.put.ltp ? 'down' : 'same';

        // Minor OI shift
        const ceOiShift = Math.floor((Math.random() - 0.45) * 150);
        const peOiShift = Math.floor((Math.random() - 0.45) * 150);

        const callChange = Number((newCallLtp - row.call.prevClose).toFixed(2));
        const callChangeOi = row.call.changeOi + ceOiShift;
        row.call = {
          ...row.call,
          ltp: newCallLtp,
          change: callChange,
          oi: Math.max(500, row.call.oi + ceOiShift),
          changeOi: callChangeOi,
          volume: row.call.volume + Math.floor(Math.random() * 250),
          lastTickDir: callDir,
          buildup: determineBuildup(callChange, callChangeOi),
        };

        const putChange = Number((newPutLtp - row.put.prevClose).toFixed(2));
        const putChangeOi = row.put.changeOi + peOiShift;
        row.put = {
          ...row.put,
          ltp: newPutLtp,
          change: putChange,
          oi: Math.max(500, row.put.oi + peOiShift),
          changeOi: putChangeOi,
          volume: row.put.volume + Math.floor(Math.random() * 250),
          lastTickDir: putDir,
          buildup: determineBuildup(putChange, putChangeOi),
        };
      }

      // Check ATM marker
      const strikeStep = this.indices[this.activeSymbol].strikeStep;
      const atmStrike = Math.round(spot / strikeStep) * strikeStep;
      chain.forEach((row) => {
        row.isAtm = row.strike === atmStrike;
        row.isItmCall = row.strike < spot;
        row.isItmPut = row.strike > spot;
      });
    }

    this.packetsReceived += 1;
    this.latencyMs = Math.round(12 + Math.random() * 6);
    this.notify();

    this.timer = window.setTimeout(this.tick, this.updateIntervalMs);
  };
}

export const marketFeed = new MarketFeedService();
