/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * Live All Participants Analytics Engine (NSE & BSE Derivatives Positioning)
 * Tracks FII, DII, PRO and CLIENT positions across indices.
 */

export type ParticipantCategory = 'FII' | 'DII' | 'PRO' | 'CLIENT';

export type ParticipantIndexName =
  | 'NIFTY'
  | 'BANKNIFTY'
  | 'FINNIFTY'
  | 'MIDCPNIFTY'
  | 'NIFTY NEXT 50'
  | 'SENSEX';

export interface ParticipantDetailedPosition {
  participant: ParticipantCategory;
  name: string;
  description: string;

  // Futures
  futLong: number;
  futShort: number;
  futNet: number;
  futChange: number;

  // Calls
  callLong: number;
  callShort: number;
  callNet: number;
  callChange: number;

  // Puts
  putLong: number;
  putShort: number;
  putNet: number;
  putChange: number;

  // Net Aggregates
  totalLong: number;
  totalShort: number;
  netPosition: number; // totalLong - totalShort
  prevNetPosition: number;
  netChange: number;

  // Change Interpretation
  changeType: 'Long Addition' | 'Short Addition' | 'Short Covering' | 'Long Unwinding';
  longAddition: number;
  shortAddition: number;
  shortCovering: number;
  longUnwinding: number;

  // Trend / Multi-timeframe changes
  dailyChange: number;
  weeklyChange: number;
  monthlyChange: number;

  // Historical data points for charts (1D, 5D, 1M, 3M)
  history: {
    label: string;
    timestamp: string;
    netPosition: number;
    futNet: number;
    callNet: number;
    putNet: number;
  }[];
}

export interface ParticipantIndexData {
  index: ParticipantIndexName;
  spotPrice: number;
  change: number;
  pChange: number;
  lastUpdated: string;
  participants: Record<ParticipantCategory, ParticipantDetailedPosition>;
  smartMoney: {
    direction: 'BULLISH' | 'BEARISH' | 'NEUTRAL';
    score: number; // -100 to +100
    confidence: number; // percentage
    reasoning: string;
    fiiProCombinedNet: number;
    retailContrarianSignal: string;
  };
  sentiment: {
    institutional: 'BULLISH' | 'BEARISH' | 'NEUTRAL';
    retail: 'BULLISH' | 'BEARISH' | 'NEUTRAL';
    overall: 'BULLISH' | 'BEARISH' | 'NEUTRAL';
    institutionalScore: number;
    retailScore: number;
    overallScore: number;
  };
  alerts: {
    id: string;
    type: 'FII_CHANGE' | 'DII_CHANGE' | 'CLIENT_REVERSAL' | 'SMART_MONEY_REVERSAL';
    title: string;
    message: string;
    severity: 'HIGH' | 'MEDIUM' | 'INFO';
    timestamp: string;
  }[];
}

export const SUPPORTED_PARTICIPANT_INDICES: ParticipantIndexName[] = [
  'NIFTY',
  'BANKNIFTY',
  'FINNIFTY',
  'MIDCPNIFTY',
  'NIFTY NEXT 50',
  'SENSEX',
];

// Helper to generate realistic historical trend points
function generateHistory(baseNet: number, volatility: number) {
  const points = [];
  const dates = [
    '30 Days Ago',
    '25 Days Ago',
    '20 Days Ago',
    '15 Days Ago',
    '10 Days Ago',
    '5 Days Ago',
    '3 Days Ago',
    'Yesterday',
    'Today',
  ];

  let current = baseNet * 0.75;
  for (let i = 0; i < dates.length; i++) {
    const delta = (Math.sin(i) * 0.3 + (i / dates.length) * 0.25) * volatility;
    current = Math.round(current + delta);
    points.push({
      label: dates[i],
      timestamp: dates[i],
      netPosition: i === dates.length - 1 ? baseNet : current,
      futNet: Math.round((i === dates.length - 1 ? baseNet : current) * 0.45),
      callNet: Math.round((i === dates.length - 1 ? baseNet : current) * 0.35),
      putNet: -Math.round((i === dates.length - 1 ? baseNet : current) * 0.2),
    });
  }
  return points;
}

// Initial realistic NSE participant derivative positioning
export const INITIAL_PARTICIPANT_DATA: Record<ParticipantIndexName, ParticipantIndexData> = {
  NIFTY: {
    index: 'NIFTY',
    spotPrice: 24864.20,
    change: 71.40,
    pChange: 0.29,
    lastUpdated: '15:30:00 IST (NSE End of Day)',
    participants: {
      FII: {
        participant: 'FII',
        name: 'Foreign Institutional Investors',
        description: 'Global offshore institutions & FPI hedge funds',
        futLong: 148520,
        futShort: 82410,
        futNet: 66110,
        futChange: 14200,
        callLong: 285400,
        callShort: 165200,
        callNet: 120200,
        callChange: 22400,
        putLong: 195300,
        putShort: 310500,
        putNet: -115200, // Short put = bullish
        putChange: -18500,
        totalLong: 629220,
        totalShort: 558110,
        netPosition: 71110,
        prevNetPosition: 46110,
        netChange: 25000,
        changeType: 'Long Addition',
        longAddition: 18450,
        shortAddition: 0,
        shortCovering: 6550,
        longUnwinding: 0,
        dailyChange: 25000,
        weeklyChange: 48500,
        monthlyChange: 84200,
        history: generateHistory(71110, 18000),
      },
      DII: {
        participant: 'DII',
        name: 'Domestic Institutional Investors',
        description: 'Mutual Funds, Insurance companies, Pension funds',
        futLong: 64200,
        futShort: 56100,
        futNet: 8100,
        futChange: 3200,
        callLong: 78500,
        callShort: 84200,
        callNet: -5700,
        callChange: -1400,
        putLong: 110400,
        putShort: 89500,
        putNet: 20900,
        putChange: 6200,
        totalLong: 253100,
        totalShort: 229800,
        netPosition: 23300,
        prevNetPosition: 15300,
        netChange: 8000,
        changeType: 'Long Addition',
        longAddition: 5800,
        shortAddition: 0,
        shortCovering: 2200,
        longUnwinding: 0,
        dailyChange: 8000,
        weeklyChange: 16500,
        monthlyChange: 31200,
        history: generateHistory(23300, 8000),
      },
      PRO: {
        participant: 'PRO',
        name: 'Proprietary Traders & Brokers',
        description: 'Domestic brokers, prop trading desks, algorithmic market makers',
        futLong: 98400,
        futShort: 86300,
        futNet: 12100,
        futChange: 4500,
        callLong: 245000,
        callShort: 215000,
        callNet: 30000,
        callChange: 9800,
        putLong: 172000,
        putShort: 202000,
        putNet: -30000, // Short put = bullish
        putChange: -7300,
        totalLong: 515400,
        totalShort: 503300,
        netPosition: 12100,
        prevNetPosition: 100,
        netChange: 12000,
        changeType: 'Short Covering',
        longAddition: 4200,
        shortAddition: 0,
        shortCovering: 7800,
        longUnwinding: 0,
        dailyChange: 12000,
        weeklyChange: 21400,
        monthlyChange: -8400,
        history: generateHistory(12100, 11000),
      },
      CLIENT: {
        participant: 'CLIENT',
        name: 'Retail Traders & HNI Clients',
        description: 'Individual retail investors, traders, and high net worth clients',
        futLong: 185000,
        futShort: 203000,
        futNet: -18000,
        futChange: -12500,
        callLong: 580000,
        callShort: 645000,
        callNet: -65000,
        callChange: -32000,
        putLong: 480000,
        putShort: 415000,
        putNet: 65000, // Long put = bearish
        putChange: 26500,
        totalLong: 1245000,
        totalShort: 1263000,
        netPosition: -18000,
        prevNetPosition: 0,
        netChange: -18000,
        changeType: 'Short Addition',
        longAddition: 0,
        shortAddition: 14200,
        shortCovering: 0,
        longUnwinding: 3800,
        dailyChange: -18000,
        weeklyChange: -39000,
        monthlyChange: -64000,
        history: generateHistory(-18000, 15000),
      },
    },
    smartMoney: {
      direction: 'BULLISH',
      score: 78,
      confidence: 86,
      reasoning: 'FIIs aggressively bought index futures (+14.2k) and call options (+22.4k) while writing puts. PRO desks are net long.',
      fiiProCombinedNet: 83210,
      retailContrarianSignal: 'Bullish Confirmation: Retail clients are net short (-18k), creating strong short-squeeze fuel for Smart Money.',
    },
    sentiment: {
      institutional: 'BULLISH',
      retail: 'BEARISH',
      overall: 'BULLISH',
      institutionalScore: 82,
      retailScore: -45,
      overallScore: 68,
    },
    alerts: [
      {
        id: 'alt_fii_nifty',
        type: 'FII_CHANGE',
        title: 'FII Futures Surge > +10%',
        message: 'FIIs added +14,200 Long Index Futures today (+22.1% net surge).',
        severity: 'HIGH',
        timestamp: '15:28 IST',
      },
      {
        id: 'alt_pro_covering',
        type: 'SMART_MONEY_REVERSAL',
        title: 'PRO Desks Short Covering',
        message: 'PRO traders covered 7,800 short contracts, flipping their net bias to Long.',
        severity: 'MEDIUM',
        timestamp: '15:15 IST',
      },
      {
        id: 'alt_client_bearish',
        type: 'CLIENT_REVERSAL',
        title: 'Retail Trapped in Put Buying',
        message: 'Clients bought +26.5k Put options, heavily skewed bearish against institutional flow.',
        severity: 'INFO',
        timestamp: '14:45 IST',
      },
    ],
  },

  BANKNIFTY: {
    index: 'BANKNIFTY',
    spotPrice: 53285.50,
    change: 345.40,
    pChange: 0.65,
    lastUpdated: '15:30:00 IST (NSE End of Day)',
    participants: {
      FII: {
        participant: 'FII',
        name: 'Foreign Institutional Investors',
        description: 'Global offshore institutions',
        futLong: 94200,
        futShort: 48100,
        futNet: 46100,
        futChange: 11400,
        callLong: 184000,
        callShort: 95000,
        callNet: 89000,
        callChange: 16500,
        putLong: 112000,
        putShort: 198000,
        putNet: -86000,
        putChange: -14200,
        totalLong: 390200,
        totalShort: 341100,
        netPosition: 49100,
        prevNetPosition: 32600,
        netChange: 16500,
        changeType: 'Long Addition',
        longAddition: 12800,
        shortAddition: 0,
        shortCovering: 3700,
        longUnwinding: 0,
        dailyChange: 16500,
        weeklyChange: 32400,
        monthlyChange: 54100,
        history: generateHistory(49100, 14000),
      },
      DII: {
        participant: 'DII',
        name: 'Domestic Institutional Investors',
        description: 'Mutual Funds & Insurance',
        futLong: 41200,
        futShort: 36800,
        futNet: 4400,
        futChange: 1800,
        callLong: 45000,
        callShort: 49000,
        callNet: -4000,
        callChange: -800,
        putLong: 68000,
        putShort: 54000,
        putNet: 14000,
        putChange: 2100,
        totalLong: 154200,
        totalShort: 139800,
        netPosition: 14400,
        prevNetPosition: 11200,
        netChange: 3200,
        changeType: 'Long Addition',
        longAddition: 2500,
        shortAddition: 0,
        shortCovering: 700,
        longUnwinding: 0,
        dailyChange: 3200,
        weeklyChange: 8400,
        monthlyChange: 17800,
        history: generateHistory(14400, 5000),
      },
      PRO: {
        participant: 'PRO',
        name: 'Proprietary Traders & Brokers',
        description: 'Prop desks & market makers',
        futLong: 62400,
        futShort: 51200,
        futNet: 11200,
        futChange: 5200,
        callLong: 145000,
        callShort: 128000,
        callNet: 17000,
        callChange: 7400,
        putLong: 104000,
        putShort: 132000,
        putNet: -28000,
        putChange: -8900,
        totalLong: 311400,
        totalShort: 311200,
        netPosition: 200,
        prevNetPosition: -8400,
        netChange: 8600,
        changeType: 'Short Covering',
        longAddition: 3200,
        shortAddition: 0,
        shortCovering: 5400,
        longUnwinding: 0,
        dailyChange: 8600,
        weeklyChange: 14200,
        monthlyChange: -2400,
        history: generateHistory(200, 8000),
      },
      CLIENT: {
        participant: 'CLIENT',
        name: 'Retail Traders & HNI Clients',
        description: 'Retail participants',
        futLong: 112000,
        futShort: 134000,
        futNet: -22000,
        futChange: -11200,
        callLong: 340000,
        callShort: 385000,
        callNet: -45000,
        callChange: -19500,
        putLong: 298000,
        putShort: 245000,
        putNet: 53000,
        putChange: 18400,
        totalLong: 750000,
        totalShort: 764000,
        netPosition: -14000,
        prevNetPosition: 8200,
        netChange: -22200,
        changeType: 'Short Addition',
        longAddition: 0,
        shortAddition: 15400,
        shortCovering: 0,
        longUnwinding: 6800,
        dailyChange: -22200,
        weeklyChange: -31200,
        monthlyChange: -48000,
        history: generateHistory(-14000, 12000),
      },
    },
    smartMoney: {
      direction: 'BULLISH',
      score: 84,
      confidence: 88,
      reasoning: 'FIIs hold aggressive net long banking futures (+46k) and wrote heavy OTM puts. Bank Nifty outperformance expected.',
      fiiProCombinedNet: 49300,
      retailContrarianSignal: 'Strong Bullish: Retail clients went heavily short banking indices on breakdown fears.',
    },
    sentiment: {
      institutional: 'BULLISH',
      retail: 'BEARISH',
      overall: 'BULLISH',
      institutionalScore: 86,
      retailScore: -58,
      overallScore: 74,
    },
    alerts: [
      {
        id: 'alt_fii_bank',
        type: 'FII_CHANGE',
        title: 'FII Banking Longs +16.5k',
        message: 'FIIs increased Banking long positions across major private sector lenders.',
        severity: 'HIGH',
        timestamp: '15:20 IST',
      },
    ],
  },

  FINNIFTY: {
    index: 'FINNIFTY',
    spotPrice: 24190.75,
    change: 105.45,
    pChange: 0.44,
    lastUpdated: '15:30:00 IST',
    participants: {
      FII: {
        participant: 'FII',
        name: 'Foreign Institutional Investors',
        description: 'Global offshore institutions',
        futLong: 42100,
        futShort: 24500,
        futNet: 17600,
        futChange: 4800,
        callLong: 82000,
        callShort: 48000,
        callNet: 34000,
        callChange: 6500,
        putLong: 54000,
        putShort: 86000,
        putNet: -32000,
        putChange: -5400,
        totalLong: 178100,
        totalShort: 158500,
        netPosition: 19600,
        prevNetPosition: 12400,
        netChange: 7200,
        changeType: 'Long Addition',
        longAddition: 5400,
        shortAddition: 0,
        shortCovering: 1800,
        longUnwinding: 0,
        dailyChange: 7200,
        weeklyChange: 14200,
        monthlyChange: 24800,
        history: generateHistory(19600, 6000),
      },
      DII: {
        participant: 'DII',
        name: 'Domestic Institutional Investors',
        description: 'Mutual Funds & Insurance',
        futLong: 18400,
        futShort: 16200,
        futNet: 2200,
        futChange: 600,
        callLong: 21000,
        callShort: 23000,
        callNet: -2000,
        callChange: -400,
        putLong: 31000,
        putShort: 26000,
        putNet: 5000,
        putChange: 800,
        totalLong: 70400,
        totalShort: 65200,
        netPosition: 5200,
        prevNetPosition: 4100,
        netChange: 1100,
        changeType: 'Long Addition',
        longAddition: 800,
        shortAddition: 0,
        shortCovering: 300,
        longUnwinding: 0,
        dailyChange: 1100,
        weeklyChange: 3800,
        monthlyChange: 8200,
        history: generateHistory(5200, 2500),
      },
      PRO: {
        participant: 'PRO',
        name: 'Proprietary Traders & Brokers',
        description: 'Prop desks & market makers',
        futLong: 28500,
        futShort: 24200,
        futNet: 4300,
        futChange: 1800,
        callLong: 64000,
        callShort: 58000,
        callNet: 6000,
        callChange: 2600,
        putLong: 48000,
        putShort: 59000,
        putNet: -11000,
        putChange: -3200,
        totalLong: 140500,
        totalShort: 141200,
        netPosition: -700,
        prevNetPosition: -4200,
        netChange: 3500,
        changeType: 'Short Covering',
        longAddition: 1200,
        shortAddition: 0,
        shortCovering: 2300,
        longUnwinding: 0,
        dailyChange: 3500,
        weeklyChange: 6400,
        monthlyChange: 1200,
        history: generateHistory(-700, 4000),
      },
      CLIENT: {
        participant: 'CLIENT',
        name: 'Retail Traders & HNI Clients',
        description: 'Retail participants',
        futLong: 51000,
        futShort: 58000,
        futNet: -7000,
        futChange: -4200,
        callLong: 154000,
        callShort: 172000,
        callNet: -18000,
        callChange: -8400,
        putLong: 135000,
        putShort: 115000,
        putNet: 20000,
        putChange: 7600,
        totalLong: 340000,
        totalShort: 345000,
        netPosition: -5000,
        prevNetPosition: 3800,
        netChange: -8800,
        changeType: 'Short Addition',
        longAddition: 0,
        shortAddition: 6200,
        shortCovering: 0,
        longUnwinding: 2600,
        dailyChange: -8800,
        weeklyChange: -12400,
        monthlyChange: -19200,
        history: generateHistory(-5000, 5000),
      },
    },
    smartMoney: {
      direction: 'BULLISH',
      score: 72,
      confidence: 80,
      reasoning: 'Financial services showing steady institutional accumulation with FII Call net positive (+34k).',
      fiiProCombinedNet: 18900,
      retailContrarianSignal: 'Bullish: Moderate retail hedging via Put options.',
    },
    sentiment: {
      institutional: 'BULLISH',
      retail: 'NEUTRAL',
      overall: 'BULLISH',
      institutionalScore: 74,
      retailScore: -28,
      overallScore: 61,
    },
    alerts: [],
  },

  MIDCPNIFTY: {
    index: 'MIDCPNIFTY',
    spotPrice: 13125.60,
    change: -54.60,
    pChange: -0.41,
    lastUpdated: '15:30:00 IST',
    participants: {
      FII: {
        participant: 'FII',
        name: 'Foreign Institutional Investors',
        description: 'Global offshore institutions',
        futLong: 22100,
        futShort: 26400,
        futNet: -4300,
        futChange: -1800,
        callLong: 41000,
        callShort: 48000,
        callNet: -7000,
        callChange: -2400,
        putLong: 38000,
        putShort: 34000,
        putNet: 4000,
        putChange: 1200,
        totalLong: 101100,
        totalShort: 108400,
        netPosition: -7300,
        prevNetPosition: -4500,
        netChange: -2800,
        changeType: 'Short Addition',
        longAddition: 0,
        shortAddition: 2100,
        shortCovering: 0,
        longUnwinding: 700,
        dailyChange: -2800,
        weeklyChange: -6400,
        monthlyChange: -11200,
        history: generateHistory(-7300, 3500),
      },
      DII: {
        participant: 'DII',
        name: 'Domestic Institutional Investors',
        description: 'Mutual Funds & Insurance',
        futLong: 14200,
        futShort: 12100,
        futNet: 2100,
        futChange: 400,
        callLong: 18000,
        callShort: 16000,
        callNet: 2000,
        callChange: 300,
        putLong: 21000,
        putShort: 19000,
        putNet: 2000,
        putChange: 200,
        totalLong: 53200,
        totalShort: 47100,
        netPosition: 6100,
        prevNetPosition: 5400,
        netChange: 700,
        changeType: 'Long Addition',
        longAddition: 500,
        shortAddition: 0,
        shortCovering: 200,
        longUnwinding: 0,
        dailyChange: 700,
        weeklyChange: 2100,
        monthlyChange: 5400,
        history: generateHistory(6100, 1800),
      },
      PRO: {
        participant: 'PRO',
        name: 'Proprietary Traders & Brokers',
        description: 'Prop desks & market makers',
        futLong: 18500,
        futShort: 21200,
        futNet: -2700,
        futChange: -1200,
        callLong: 38000,
        callShort: 44000,
        callNet: -6000,
        callChange: -1800,
        putLong: 32000,
        putShort: 28000,
        putNet: 4000,
        putChange: 900,
        totalLong: 88500,
        totalShort: 93200,
        netPosition: -4700,
        prevNetPosition: -2800,
        netChange: -1900,
        changeType: 'Long Unwinding',
        longAddition: 0,
        shortAddition: 1100,
        shortCovering: 0,
        longUnwinding: 800,
        dailyChange: -1900,
        weeklyChange: -3800,
        monthlyChange: -7200,
        history: generateHistory(-4700, 2800),
      },
      CLIENT: {
        participant: 'CLIENT',
        name: 'Retail Traders & HNI Clients',
        description: 'Retail participants',
        futLong: 34000,
        futShort: 28000,
        futNet: 6000,
        futChange: 2400,
        callLong: 92000,
        callShort: 78000,
        callNet: 14000,
        callChange: 4200,
        putLong: 68000,
        putShort: 74000,
        putNet: -6000,
        putChange: -2100,
        totalLong: 194000,
        totalShort: 180000,
        netPosition: 14000,
        prevNetPosition: 9800,
        netChange: 4200,
        changeType: 'Long Addition',
        longAddition: 3200,
        shortAddition: 0,
        shortCovering: 1000,
        longUnwinding: 0,
        dailyChange: 4200,
        weeklyChange: 8400,
        monthlyChange: 14200,
        history: generateHistory(14000, 4000),
      },
    },
    smartMoney: {
      direction: 'BEARISH',
      score: -64,
      confidence: 76,
      reasoning: 'FII and PRO both building short futures and short calls in Midcap index. Cautious bias.',
      fiiProCombinedNet: -12000,
      retailContrarianSignal: 'Caution: Retail is net Long (+14k) while institutions are unloading midcap exposures.',
    },
    sentiment: {
      institutional: 'BEARISH',
      retail: 'BULLISH',
      overall: 'BEARISH',
      institutionalScore: -68,
      retailScore: 54,
      overallScore: -48,
    },
    alerts: [
      {
        id: 'alt_midcap_warning',
        type: 'SMART_MONEY_REVERSAL',
        title: 'Institutional Profit Taking in Midcap',
        message: 'FIIs trimmed midcap long exposure by -2.8k contracts.',
        severity: 'MEDIUM',
        timestamp: '15:10 IST',
      },
    ],
  },

  'NIFTY NEXT 50': {
    index: 'NIFTY NEXT 50',
    spotPrice: 71840.10,
    change: 182.30,
    pChange: 0.25,
    lastUpdated: '15:30:00 IST',
    participants: {
      FII: {
        participant: 'FII',
        name: 'Foreign Institutional Investors',
        description: 'Global offshore institutions',
        futLong: 16400,
        futShort: 11200,
        futNet: 5200,
        futChange: 1400,
        callLong: 28000,
        callShort: 21000,
        callNet: 7000,
        callChange: 1800,
        putLong: 19000,
        putShort: 26000,
        putNet: -7000,
        putChange: -1200,
        totalLong: 63400,
        totalShort: 58200,
        netPosition: 5200,
        prevNetPosition: 3400,
        netChange: 1800,
        changeType: 'Long Addition',
        longAddition: 1400,
        shortAddition: 0,
        shortCovering: 400,
        longUnwinding: 0,
        dailyChange: 1800,
        weeklyChange: 4200,
        monthlyChange: 8400,
        history: generateHistory(5200, 2000),
      },
      DII: {
        participant: 'DII',
        name: 'Domestic Institutional Investors',
        description: 'Mutual Funds & Insurance',
        futLong: 12400,
        futShort: 9800,
        futNet: 2600,
        futChange: 500,
        callLong: 14000,
        callShort: 13000,
        callNet: 1000,
        callChange: 200,
        putLong: 16000,
        putShort: 14000,
        putNet: 2000,
        putChange: 100,
        totalLong: 42400,
        totalShort: 36800,
        netPosition: 5600,
        prevNetPosition: 4900,
        netChange: 700,
        changeType: 'Long Addition',
        longAddition: 500,
        shortAddition: 0,
        shortCovering: 200,
        longUnwinding: 0,
        dailyChange: 700,
        weeklyChange: 1900,
        monthlyChange: 4200,
        history: generateHistory(5600, 1500),
      },
      PRO: {
        participant: 'PRO',
        name: 'Proprietary Traders & Brokers',
        description: 'Prop desks & market makers',
        futLong: 14200,
        futShort: 13800,
        futNet: 400,
        futChange: 200,
        callLong: 22000,
        callShort: 21000,
        callNet: 1000,
        callChange: 400,
        putLong: 18000,
        putShort: 19000,
        putNet: -1000,
        putChange: -300,
        totalLong: 54200,
        totalShort: 53800,
        netPosition: 400,
        prevNetPosition: 100,
        netChange: 300,
        changeType: 'Short Covering',
        longAddition: 100,
        shortAddition: 0,
        shortCovering: 200,
        longUnwinding: 0,
        dailyChange: 300,
        weeklyChange: 800,
        monthlyChange: -400,
        history: generateHistory(400, 1000),
      },
      CLIENT: {
        participant: 'CLIENT',
        name: 'Retail Traders & HNI Clients',
        description: 'Retail participants',
        futLong: 24000,
        futShort: 26000,
        futNet: -2000,
        futChange: -1200,
        callLong: 48000,
        callShort: 51000,
        callNet: -3000,
        callChange: -1600,
        putLong: 42000,
        putShort: 39000,
        putNet: 3000,
        putChange: 1400,
        totalLong: 114000,
        totalShort: 116000,
        netPosition: -2000,
        prevNetPosition: 400,
        netChange: -2400,
        changeType: 'Short Addition',
        longAddition: 0,
        shortAddition: 1800,
        shortCovering: 0,
        longUnwinding: 600,
        dailyChange: -2400,
        weeklyChange: -3800,
        monthlyChange: -5200,
        history: generateHistory(-2000, 1800),
      },
    },
    smartMoney: {
      direction: 'BULLISH',
      score: 65,
      confidence: 74,
      reasoning: 'Steady long addition in high quality large-cap growth stocks in Nifty Junior.',
      fiiProCombinedNet: 5600,
      retailContrarianSignal: 'Mild Bullish: Retail slightly cautious on large-cap index.',
    },
    sentiment: {
      institutional: 'BULLISH',
      retail: 'NEUTRAL',
      overall: 'BULLISH',
      institutionalScore: 68,
      retailScore: -18,
      overallScore: 54,
    },
    alerts: [],
  },

  SENSEX: {
    index: 'SENSEX',
    spotPrice: 81452.30,
    change: 241.40,
    pChange: 0.30,
    lastUpdated: '15:30:00 IST',
    participants: {
      FII: {
        participant: 'FII',
        name: 'Foreign Institutional Investors',
        description: 'Global offshore institutions',
        futLong: 48500,
        futShort: 28400,
        futNet: 20100,
        futChange: 4200,
        callLong: 88000,
        callShort: 54000,
        callNet: 34000,
        callChange: 7200,
        putLong: 62000,
        putShort: 98000,
        putNet: -36000,
        putChange: -5800,
        totalLong: 198500,
        totalShort: 180400,
        netPosition: 18100,
        prevNetPosition: 11500,
        netChange: 6600,
        changeType: 'Long Addition',
        longAddition: 4800,
        shortAddition: 0,
        shortCovering: 1800,
        longUnwinding: 0,
        dailyChange: 6600,
        weeklyChange: 13800,
        monthlyChange: 26400,
        history: generateHistory(18100, 6500),
      },
      DII: {
        participant: 'DII',
        name: 'Domestic Institutional Investors',
        description: 'Mutual Funds & Insurance',
        futLong: 21000,
        futShort: 18200,
        futNet: 2800,
        futChange: 600,
        callLong: 26000,
        callShort: 28000,
        callNet: -2000,
        callChange: -300,
        putLong: 34000,
        putShort: 31000,
        putNet: 3000,
        putChange: 400,
        totalLong: 81000,
        totalShort: 77200,
        netPosition: 3800,
        prevNetPosition: 3100,
        netChange: 700,
        changeType: 'Long Addition',
        longAddition: 500,
        shortAddition: 0,
        shortCovering: 200,
        longUnwinding: 0,
        dailyChange: 700,
        weeklyChange: 2400,
        monthlyChange: 6800,
        history: generateHistory(3800, 2200),
      },
      PRO: {
        participant: 'PRO',
        name: 'Proprietary Traders & Brokers',
        description: 'Prop desks & market makers',
        futLong: 32000,
        futShort: 28500,
        futNet: 3500,
        futChange: 1400,
        callLong: 74000,
        callShort: 68000,
        callNet: 6000,
        callChange: 2800,
        putLong: 56000,
        putShort: 65000,
        putNet: -9000,
        putChange: -2400,
        totalLong: 162000,
        totalShort: 161500,
        netPosition: 500,
        prevNetPosition: -2800,
        netChange: 3300,
        changeType: 'Short Covering',
        longAddition: 1200,
        shortAddition: 0,
        shortCovering: 2100,
        longUnwinding: 0,
        dailyChange: 3300,
        weeklyChange: 7400,
        monthlyChange: 1800,
        history: generateHistory(500, 3500),
      },
      CLIENT: {
        participant: 'CLIENT',
        name: 'Retail Traders & HNI Clients',
        description: 'Retail participants',
        futLong: 58000,
        futShort: 65000,
        futNet: -7000,
        futChange: -4400,
        callLong: 168000,
        callShort: 186000,
        callNet: -18000,
        callChange: -8600,
        putLong: 154000,
        putShort: 135000,
        putNet: 19000,
        putChange: 7400,
        totalLong: 380000,
        totalShort: 386000,
        netPosition: -6000,
        prevNetPosition: 2600,
        netChange: -8600,
        changeType: 'Short Addition',
        longAddition: 0,
        shortAddition: 6100,
        shortCovering: 0,
        longUnwinding: 2500,
        dailyChange: -8600,
        weeklyChange: -14200,
        monthlyChange: -22400,
        history: generateHistory(-6000, 5200),
      },
    },
    smartMoney: {
      direction: 'BULLISH',
      score: 75,
      confidence: 82,
      reasoning: 'Strong institutional support on BSE flagship index led by heavyweights (RIL, HDFC Bank, ICICI Bank).',
      fiiProCombinedNet: 23600,
      retailContrarianSignal: 'Bullish Confirmation: Retail clients net short on BSE derivative expiry.',
    },
    sentiment: {
      institutional: 'BULLISH',
      retail: 'BEARISH',
      overall: 'BULLISH',
      institutionalScore: 78,
      retailScore: -34,
      overallScore: 64,
    },
    alerts: [],
  },
};

/**
 * Class managing participant analytics with simulated live updates
 */
class ParticipantAnalyticsService {
  private data: Record<ParticipantIndexName, ParticipantIndexData> = {
    ...INITIAL_PARTICIPANT_DATA,
  };
  private subscribers: ((data: Record<ParticipantIndexName, ParticipantIndexData>) => void)[] = [];
  private timer: NodeJS.Timeout | null = null;

  constructor() {
    this.startLiveSimulation();
  }

  public getData(index?: ParticipantIndexName): ParticipantIndexData | Record<ParticipantIndexName, ParticipantIndexData> {
    if (index) {
      return this.data[index] || this.data.NIFTY;
    }
    return this.data;
  }

  public subscribe(cb: (data: Record<ParticipantIndexName, ParticipantIndexData>) => void) {
    this.subscribers.push(cb);
    cb(this.data);
    return () => {
      this.subscribers = this.subscribers.filter((s) => s !== cb);
    };
  }

  private notify() {
    this.subscribers.forEach((cb) => cb(this.data));
  }

  private startLiveSimulation() {
    // Periodically update participant numbers slightly to simulate active institutional block flows
    this.timer = setInterval(() => {
      const indices: ParticipantIndexName[] = ['NIFTY', 'BANKNIFTY'];
      const targetIndex = indices[Math.floor(Math.random() * indices.length)];
      const current = this.data[targetIndex];
      if (!current) return;

      const delta = (Math.floor(Math.random() * 20) - 8) * 10; // small tick update
      const p = current.participants.FII;

      p.futLong += delta > 0 ? delta : 0;
      p.futShort += delta < 0 ? Math.abs(delta) : 0;
      p.futNet = p.futLong - p.futShort;
      p.netPosition = p.totalLong - p.totalShort + delta;
      p.netChange += delta;

      current.lastUpdated = `${new Date().toLocaleTimeString()} IST (Live Streaming)`;
      this.notify();
    }, 4000);
  }

  public destroy() {
    if (this.timer) {
      clearInterval(this.timer);
    }
  }

  // Export utility for CSV
  public exportCSV(indexName: ParticipantIndexName): string {
    const d = this.data[indexName];
    if (!d) return '';

    const headers = [
      'Participant',
      'Long Futures',
      'Short Futures',
      'Net Futures',
      'Long Calls',
      'Short Calls',
      'Net Calls',
      'Long Puts',
      'Short Puts',
      'Net Puts',
      'Total Long',
      'Total Short',
      'Net Position',
      'Prev Day Net',
      'Net Change',
      'Interpretation',
    ];

    const rows = (['FII', 'DII', 'PRO', 'CLIENT'] as ParticipantCategory[]).map((cat) => {
      const p = d.participants[cat];
      return [
        p.participant,
        p.futLong,
        p.futShort,
        p.futNet,
        p.callLong,
        p.callShort,
        p.callNet,
        p.putLong,
        p.putShort,
        p.putNet,
        p.totalLong,
        p.totalShort,
        p.netPosition,
        p.prevNetPosition,
        p.netChange,
        `"${p.changeType}"`,
      ].join(',');
    });

    return [headers.join(','), ...rows].join('\n');
  }

  // Export utility for Excel TSV format
  public exportExcelTSV(indexName: ParticipantIndexName): string {
    const d = this.data[indexName];
    if (!d) return '';

    const headers = [
      'Participant Category',
      'Long Futures',
      'Short Futures',
      'Net Futures',
      'Long Calls',
      'Short Calls',
      'Net Calls',
      'Long Puts',
      'Short Puts',
      'Net Puts',
      'Total Long',
      'Total Short',
      'Net Position',
      'Prev Day Net',
      'Net Change',
      'Interpretation',
    ];

    const rows = (['FII', 'DII', 'PRO', 'CLIENT'] as ParticipantCategory[]).map((cat) => {
      const p = d.participants[cat];
      return [
        p.name,
        p.futLong,
        p.futShort,
        p.futNet,
        p.callLong,
        p.callShort,
        p.callNet,
        p.putLong,
        p.putShort,
        p.putNet,
        p.totalLong,
        p.totalShort,
        p.netPosition,
        p.prevNetPosition,
        p.netChange,
        p.changeType,
      ].join('\t');
    });

    return [headers.join('\t'), ...rows].join('\n');
  }
}

export const participantAnalytics = new ParticipantAnalyticsService();
