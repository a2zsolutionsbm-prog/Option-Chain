/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * Live Market Indices Engine
 * Includes all 23 indices from Excel data with live updates, 1Y/3Y/5Y returns, and 52W range analytics.
 */

export interface MarketIndexRecord {
  id: string;
  name: string;
  exchange: 'NSE' | 'BSE';
  category: 'Broad Market' | 'Sectoral' | 'Factor / Strategy' | 'Thematic' | 'SME';
  ltp: number;
  change: number;
  pChange: number;
  open: number;
  prevClose: number;
  week52High: number;
  week52Low: number;
  return1Yr: number; // in percentage
  return3Yr: number;
  return5Yr: number;
  lastTickDir: 'up' | 'down' | 'none';
}

export const EXCEL_INDICES: MarketIndexRecord[] = [
  {
    id: 'bse_auto',
    name: 'BSE Auto',
    exchange: 'BSE',
    category: 'Sectoral',
    ltp: 59648.38,
    change: 561.12,
    pChange: 0.95,
    open: 59019.21,
    prevClose: 59087.26,
    week52High: 65675.73,
    week52Low: 52099.69,
    return1Yr: -0.29,
    return3Yr: 62.25,
    return5Yr: 146.43,
    lastTickDir: 'up',
  },
  {
    id: 'bse_bankex',
    name: 'BSE BANKEX',
    exchange: 'BSE',
    category: 'Sectoral',
    ltp: 62833.13,
    change: 112.98,
    pChange: 0.18,
    open: 62686.80,
    prevClose: 62720.15,
    week52High: 69406.97,
    week52Low: 56230.38,
    return1Yr: 1.40,
    return3Yr: 24.80,
    return5Yr: 44.17,
    lastTickDir: 'up',
  },
  {
    id: 'bse_capgoods',
    name: 'BSE Capital Goods',
    exchange: 'BSE',
    category: 'Sectoral',
    ltp: 75958.84,
    change: 204.60,
    pChange: 0.27,
    open: 75897.52,
    prevClose: 75754.24,
    week52High: 84777.05,
    week52Low: 61099.75,
    return1Yr: 9.16,
    return3Yr: 63.06,
    return5Yr: 189.88,
    lastTickDir: 'up',
  },
  {
    id: 'bse_consdur',
    name: 'BSE Consumer Durables',
    exchange: 'BSE',
    category: 'Sectoral',
    ltp: 61053.01,
    change: 687.90,
    pChange: 1.14,
    open: 60479.54,
    prevClose: 60365.11,
    week52High: 66148.63,
    week52Low: 51821.68,
    return1Yr: 2.59,
    return3Yr: 32.30,
    return5Yr: 50.22,
    lastTickDir: 'up',
  },
  {
    id: 'bse_health',
    name: 'BSE Healthcare',
    exchange: 'BSE',
    category: 'Sectoral',
    ltp: 51596.10,
    change: -259.28,
    pChange: -0.50,
    open: 51951.89,
    prevClose: 51855.38,
    week52High: 52293.87,
    week52Low: 40239.45,
    return1Yr: 17.30,
    return3Yr: 85.59,
    return5Yr: 99.16,
    lastTickDir: 'down',
  },
  {
    id: 'bse_metals',
    name: 'BSE Metals',
    exchange: 'BSE',
    category: 'Sectoral',
    ltp: 41357.81,
    change: -12.41,
    pChange: -0.03,
    open: 41327.66,
    prevClose: 41370.22,
    week52High: 45388.14,
    week52Low: 32700.62,
    return1Yr: 23.84,
    return3Yr: 81.86,
    return5Yr: 110.08,
    lastTickDir: 'down',
  },
  {
    id: 'bse_sme',
    name: 'BSE SME IPO',
    exchange: 'BSE',
    category: 'SME',
    ltp: 121243.82,
    change: 1117.20,
    pChange: 0.93,
    open: 120145.83,
    prevClose: 120126.62,
    week52High: 121008.86,
    week52Low: 73866.86,
    return1Yr: 12.58,
    return3Yr: 239.00,
    return5Yr: 1485.99,
    lastTickDir: 'up',
  },
  {
    id: 'bse_sensex_next30',
    name: 'BSE Sensex Next 30',
    exchange: 'BSE',
    category: 'Broad Market',
    ltp: 41041.34,
    change: 8.20,
    pChange: 0.02,
    open: 40964.96,
    prevClose: 41033.14,
    week52High: 43479.87,
    week52Low: 36415.87,
    return1Yr: 6.18,
    return3Yr: 21.79,
    return5Yr: 21.79,
    lastTickDir: 'up',
  },
  {
    id: 'nifty_alpha50',
    name: 'NIFTY ALPHA 50',
    exchange: 'NSE',
    category: 'Factor / Strategy',
    ltp: 55024.65,
    change: -44.02,
    pChange: -0.08,
    open: 55142.20,
    prevClose: 55068.67,
    week52High: 57921.40,
    week52Low: 44107.70,
    return1Yr: 9.08,
    return3Yr: 53.86,
    return5Yr: 74.31,
    lastTickDir: 'down',
  },
  {
    id: 'nifty_energy',
    name: 'NIFTY Energy',
    exchange: 'NSE',
    category: 'Sectoral',
    ltp: 37440.35,
    change: 78.50,
    pChange: 0.21,
    open: 37381.75,
    prevClose: 37361.85,
    week52High: 41828.55,
    week52Low: 32890.30,
    return1Yr: 6.20,
    return3Yr: 38.13,
    return5Yr: 70.14,
    lastTickDir: 'up',
  },
  {
    id: 'nifty_fmcg',
    name: 'NIFTY FMCG',
    exchange: 'NSE',
    category: 'Sectoral',
    ltp: 45941.30,
    change: 183.10,
    pChange: 0.40,
    open: 45766.20,
    prevClose: 45758.20,
    week52High: 57445.20,
    week52Low: 44825.60,
    return1Yr: -16.63,
    return3Yr: -11.04,
    return5Yr: 12.82,
    lastTickDir: 'up',
  },
  {
    id: 'nifty_midcap100',
    name: 'NIFTY Midcap 100',
    exchange: 'NSE',
    category: 'Broad Market',
    ltp: 60906.00,
    change: -85.27,
    pChange: -0.14,
    open: 60970.05,
    prevClose: 60991.27,
    week52High: 64450.90,
    week52Low: 52032.85,
    return1Yr: 5.82,
    return3Yr: 50.74,
    return5Yr: 101.99,
    lastTickDir: 'down',
  },
  {
    id: 'nifty_500_mom50',
    name: 'Nifty 500 Momentum 50',
    exchange: 'NSE',
    category: 'Factor / Strategy',
    ltp: 54033.05,
    change: -16.21,
    pChange: -0.03,
    open: 54156.50,
    prevClose: 54049.26,
    week52High: 56142.85,
    week52Low: 45696.80,
    return1Yr: 4.96,
    return3Yr: 15.14,
    return5Yr: 15.14,
    lastTickDir: 'down',
  },
  {
    id: 'nifty_500_multicap_mq50',
    name: 'Nifty 500 Multicap Momentum Quality 50',
    exchange: 'NSE',
    category: 'Factor / Strategy',
    ltp: 40940.50,
    change: 81.70,
    pChange: 0.20,
    open: 40992.65,
    prevClose: 40858.80,
    week52High: 43414.45,
    week52Low: 36179.25,
    return1Yr: -0.87,
    return3Yr: 10.40,
    return5Yr: 10.40,
    lastTickDir: 'up',
  },
  {
    id: 'nifty_bank',
    name: 'Nifty Bank',
    exchange: 'NSE',
    category: 'Sectoral',
    ltp: 55580.40,
    change: 144.15,
    pChange: 0.26,
    open: 55373.75,
    prevClose: 55436.25,
    week52High: 61764.85,
    week52Low: 49954.85,
    return1Yr: 1.10,
    return3Yr: 24.16,
    return5Yr: 45.61,
    lastTickDir: 'up',
  },
  {
    id: 'nifty_consumer_durable',
    name: 'Nifty Consumer Durable',
    exchange: 'NSE',
    category: 'Sectoral',
    ltp: 38278.60,
    change: 360.20,
    pChange: 0.95,
    open: 37961.15,
    prevClose: 37918.40,
    week52High: 40964.55,
    week52Low: 32587.95,
    return1Yr: -0.19,
    return3Yr: 23.26,
    return5Yr: 23.26,
    lastTickDir: 'up',
  },
  {
    id: 'nifty_maatr',
    name: 'Nifty India Select 5 Corp Grps (MAATR)',
    exchange: 'NSE',
    category: 'Thematic',
    ltp: 37221.95,
    change: 181.60,
    pChange: 0.49,
    open: 37000.80,
    prevClose: 37040.35,
    week52High: 40288.80,
    week52Low: 33247.90,
    return1Yr: 0.94,
    return3Yr: 4.19,
    return5Yr: 4.19,
    lastTickDir: 'up',
  },
  {
    id: 'nifty_midsmall_health',
    name: 'Nifty MidSmall Healthcare',
    exchange: 'NSE',
    category: 'Sectoral',
    ltp: 52417.80,
    change: -465.10,
    pChange: -0.88,
    open: 52922.55,
    prevClose: 52882.90,
    week52High: 53415.10,
    week52Low: 40352.90,
    return1Yr: 18.92,
    return3Yr: 23.68,
    return5Yr: 23.68,
    lastTickDir: 'down',
  },
  {
    id: 'nifty_midcap150_mom50',
    name: 'Nifty Midcap150 Momentum 50',
    exchange: 'NSE',
    category: 'Factor / Strategy',
    ltp: 62422.90,
    change: -194.10,
    pChange: -0.31,
    open: 62694.25,
    prevClose: 62617.00,
    week52High: 65309.35,
    week52Low: 53888.80,
    return1Yr: 4.03,
    return3Yr: -5.40,
    return5Yr: -5.40,
    lastTickDir: 'down',
  },
  {
    id: 'nifty_next50',
    name: 'Nifty Next 50',
    exchange: 'NSE',
    category: 'Broad Market',
    ltp: 71778.65,
    change: 399.20,
    pChange: 0.56,
    open: 71387.45,
    prevClose: 71379.45,
    week52High: 75000.40,
    week52Low: 59896.10,
    return1Yr: 5.10,
    return3Yr: 59.26,
    return5Yr: 67.12,
    lastTickDir: 'up',
  },
  {
    id: 'nifty_smallcap250_mq100',
    name: 'Nifty Smallcap250 Momentum Quality 100',
    exchange: 'NSE',
    category: 'Factor / Strategy',
    ltp: 48654.65,
    change: 184.20,
    pChange: 0.38,
    open: 48562.20,
    prevClose: 48470.45,
    week52High: 49647.10,
    week52Low: 37360.95,
    return1Yr: 6.73,
    return3Yr: 19.23,
    return5Yr: 19.23,
    lastTickDir: 'up',
  },
  {
    id: 'sensex_core',
    name: 'Sensex',
    exchange: 'BSE',
    category: 'Broad Market',
    ltp: 73895.74,
    change: 316.20,
    pChange: 0.43,
    open: 73525.92,
    prevClose: 73579.54,
    week52High: 86159.02,
    week52Low: 71545.81,
    return1Yr: -8.95,
    return3Yr: 11.92,
    return5Yr: 23.00,
    lastTickDir: 'up',
  },
  {
    id: 'sensex_next50',
    name: 'Sensex Next 50 Index',
    exchange: 'BSE',
    category: 'Broad Market',
    ltp: 84882.24,
    change: 50.90,
    pChange: 0.06,
    open: 84770.07,
    prevClose: 84831.34,
    week52High: 90092.89,
    week52Low: 74029.08,
    return1Yr: 1.31,
    return3Yr: 49.17,
    return5Yr: 72.87,
    lastTickDir: 'up',
  },
];

class MarketIndicesService {
  private indices: MarketIndexRecord[] = [...EXCEL_INDICES];
  private subscribers: ((indices: MarketIndexRecord[]) => void)[] = [];
  private tickTimer: NodeJS.Timeout | null = null;

  constructor() {
    this.startStreaming();
  }

  public getIndices(): MarketIndexRecord[] {
    return this.indices;
  }

  public subscribe(cb: (indices: MarketIndexRecord[]) => void) {
    this.subscribers.push(cb);
    cb(this.indices);
    return () => {
      this.subscribers = this.subscribers.filter((s) => s !== cb);
    };
  }

  private notify() {
    this.subscribers.forEach((cb) => cb(this.indices));
  }

  private startStreaming() {
    this.tickTimer = setInterval(() => {
      const idxToUpdate = Math.floor(Math.random() * this.indices.length);
      const item = this.indices[idxToUpdate];
      if (!item) return;

      const delta = +((Math.random() * 8 - 4).toFixed(2));
      item.ltp = +(item.ltp + delta).toFixed(2);
      item.change = +(item.ltp - item.prevClose).toFixed(2);
      item.pChange = +(((item.change) / item.prevClose) * 100).toFixed(2);
      item.lastTickDir = delta > 0 ? 'up' : delta < 0 ? 'down' : 'none';

      if (item.ltp > item.week52High) item.week52High = item.ltp;
      if (item.ltp < item.week52Low) item.week52Low = item.ltp;

      this.notify();
    }, 1500);
  }

  public exportCSV(): string {
    const headers = [
      'Name',
      'Exchange',
      'Category',
      'LTP',
      'Change',
      'Change(%)',
      'Open',
      'Prev. Close',
      '52W High',
      '52W Low',
      '1 Yr Returns',
      '3 Yr Returns',
      '5 Yr Returns',
    ];

    const rows = this.indices.map((idx) => [
      `"${idx.name}"`,
      `"${idx.exchange}"`,
      `"${idx.category}"`,
      idx.ltp.toFixed(2),
      idx.change.toFixed(2),
      `"${idx.pChange >= 0 ? '+' : ''}${idx.pChange.toFixed(2)}%"`,
      idx.open.toFixed(2),
      idx.prevClose.toFixed(2),
      idx.week52High.toFixed(2),
      idx.week52Low.toFixed(2),
      `"${idx.return1Yr >= 0 ? '+' : ''}${idx.return1Yr.toFixed(2)}%"`,
      `"${idx.return3Yr >= 0 ? '+' : ''}${idx.return3Yr.toFixed(2)}%"`,
      `"${idx.return5Yr >= 0 ? '+' : ''}${idx.return5Yr.toFixed(2)}%"`,
    ]);

    return [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
  }

  public destroy() {
    if (this.tickTimer) clearInterval(this.tickTimer);
  }
}

export const marketIndicesService = new MarketIndicesService();
