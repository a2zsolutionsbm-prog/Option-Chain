/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * Live Global Indices & World Markets Data Engine (Dhan Global Indices dataset)
 * Real-time quotes, regional categorizations, market sentiment impact, and CSV export.
 */

export type GlobalRegion = 'Americas' | 'Asia' | 'Europe' | 'Macro & Commodities';
export type MarketStatus = 'OPEN' | 'CLOSED' | 'PRE-MARKET';
export type MarketImpact = 'BULLISH' | 'BEARISH' | 'NEUTRAL';

export interface GlobalIndexRecord {
  id: string;
  name: string;
  country: string;
  flag: string;
  region: GlobalRegion;
  currency: string;
  ltp: number;
  change: number;
  pChange: number;
  open: number;
  high: number;
  low: number;
  prevClose: number;
  week52High: number;
  week52Low: number;
  status: MarketStatus;
  tradingHours: string; // e.g. "06:30 - 02:45 IST"
  impactOnIndia: MarketImpact;
  impactReason: string;
  lastTickDir: 'up' | 'down' | 'none';
}

export const DHAN_GLOBAL_INDICES: GlobalIndexRecord[] = [
  // --- 1. Asian Markets ---
  {
    id: 'gift_nifty',
    name: 'GIFT NIFTY',
    country: 'India (NSE IX)',
    flag: '🇮🇳',
    region: 'Asia',
    currency: 'USD',
    ltp: 25842.50,
    change: 68.50,
    pChange: 0.27,
    open: 25780.00,
    high: 25890.00,
    low: 25765.00,
    prevClose: 25774.00,
    week52High: 26315.00,
    week52Low: 19100.00,
    status: 'OPEN',
    tradingHours: '06:30 - 02:45 IST',
    impactOnIndia: 'BULLISH',
    impactReason: 'Leading early indicator: predicts +70 pts positive gap opening on NSE Nifty',
    lastTickDir: 'up',
  },
  {
    id: 'nikkei_225',
    name: 'NIKKEI 225',
    country: 'Japan',
    flag: '🇯🇵',
    region: 'Asia',
    currency: 'JPY',
    ltp: 37723.91,
    change: 568.58,
    pChange: 1.53,
    open: 37350.00,
    high: 37880.00,
    low: 37300.00,
    prevClose: 37155.33,
    week52High: 42426.77,
    week52Low: 30538.29,
    status: 'OPEN',
    tradingHours: '05:30 - 11:30 IST',
    impactOnIndia: 'BULLISH',
    impactReason: 'Strong Tokyo risk-on rally lifting semiconductor and auto exporters',
    lastTickDir: 'up',
  },
  {
    id: 'hang_seng',
    name: 'HANG SENG',
    country: 'Hong Kong',
    flag: '🇭🇰',
    region: 'Asia',
    currency: 'HKD',
    ltp: 19924.58,
    change: 707.72,
    pChange: 3.68,
    open: 19300.00,
    high: 19980.00,
    low: 19250.00,
    prevClose: 19216.86,
    week52High: 20200.00,
    week52Low: 14794.16,
    status: 'OPEN',
    tradingHours: '06:45 - 13:30 IST',
    impactOnIndia: 'BULLISH',
    impactReason: 'Massive China monetary stimulus packages boosting broad Asian liquidity',
    lastTickDir: 'up',
  },
  {
    id: 'shanghai_comp',
    name: 'SHANGHAI COMPOSITE',
    country: 'China',
    flag: '🇨🇳',
    region: 'Asia',
    currency: 'CNY',
    ltp: 3000.95,
    change: 84.64,
    pChange: 2.90,
    open: 2930.00,
    high: 3015.00,
    low: 2925.00,
    prevClose: 2916.31,
    week52High: 3174.27,
    week52Low: 2635.09,
    status: 'OPEN',
    tradingHours: '07:00 - 12:30 IST',
    impactOnIndia: 'BULLISH',
    impactReason: 'Reclaimed psychologically crucial 3,000 barrier after PBOC rate reductions',
    lastTickDir: 'up',
  },
  {
    id: 'taiwan_taiex',
    name: 'TAIWAN TAIEX',
    country: 'Taiwan',
    flag: '🇹🇼',
    region: 'Asia',
    currency: 'TWD',
    ltp: 22822.79,
    change: 97.21,
    pChange: 0.43,
    open: 22750.00,
    high: 22910.00,
    low: 22710.00,
    prevClose: 22725.58,
    week52High: 24416.67,
    week52Low: 15975.18,
    status: 'OPEN',
    tradingHours: '06:30 - 11:00 IST',
    impactOnIndia: 'BULLISH',
    impactReason: 'TSMC and hardware supply chain gains aiding Indian IT & electronics',
    lastTickDir: 'up',
  },
  {
    id: 'kospi',
    name: 'KOSPI',
    country: 'South Korea',
    flag: '🇰🇷',
    region: 'Asia',
    currency: 'KRW',
    ltp: 2649.78,
    change: 28.92,
    pChange: 1.10,
    open: 2625.00,
    high: 2658.00,
    low: 2620.00,
    prevClose: 2620.86,
    week52High: 2896.43,
    week52Low: 2273.97,
    status: 'OPEN',
    tradingHours: '05:30 - 12:00 IST',
    impactOnIndia: 'BULLISH',
    impactReason: 'Samsung Electronics & SK Hynix semiconductor rebound',
    lastTickDir: 'up',
  },
  {
    id: 'straits_times',
    name: 'STRAITS TIMES',
    country: 'Singapore',
    flag: '🇸🇬',
    region: 'Asia',
    currency: 'SGD',
    ltp: 3582.23,
    change: -10.15,
    pChange: -0.28,
    open: 3595.00,
    high: 3605.00,
    low: 3578.00,
    prevClose: 3592.38,
    week52High: 3624.78,
    week52Low: 3042.40,
    status: 'OPEN',
    tradingHours: '06:30 - 14:30 IST',
    impactOnIndia: 'NEUTRAL',
    impactReason: 'Mild profit taking after hitting multi-year highs',
    lastTickDir: 'down',
  },
  {
    id: 'jakarta_comp',
    name: 'JAKARTA COMPOSITE (IDX)',
    country: 'Indonesia',
    flag: '🇮🇩',
    region: 'Asia',
    currency: 'IDR',
    ltp: 7744.52,
    change: -28.10,
    pChange: -0.36,
    open: 7780.00,
    high: 7795.00,
    low: 7730.00,
    prevClose: 7772.62,
    week52High: 7910.56,
    week52Low: 6639.23,
    status: 'OPEN',
    tradingHours: '07:30 - 14:30 IST',
    impactOnIndia: 'NEUTRAL',
    impactReason: 'Consolidating near record highs in ASEAN banking majors',
    lastTickDir: 'down',
  },
  {
    id: 'set_composite',
    name: 'SET COMPOSITE',
    country: 'Thailand',
    flag: '🇹🇭',
    region: 'Asia',
    currency: 'THB',
    ltp: 1455.03,
    change: 7.80,
    pChange: 0.54,
    open: 1448.00,
    high: 1460.00,
    low: 1445.00,
    prevClose: 1447.23,
    week52High: 1465.10,
    week52Low: 1288.66,
    status: 'OPEN',
    tradingHours: '08:30 - 15:00 IST',
    impactOnIndia: 'NEUTRAL',
    impactReason: 'Tourism and consumer spending boost supporting domestic sentiment',
    lastTickDir: 'up',
  },
  {
    id: 'klci_malaysia',
    name: 'FTSE BURSA MALAYSIA KLCI',
    country: 'Malaysia',
    flag: '🇲🇾',
    region: 'Asia',
    currency: 'MYR',
    ltp: 1671.32,
    change: 6.10,
    pChange: 0.37,
    open: 1666.00,
    high: 1675.00,
    low: 1664.00,
    prevClose: 1665.22,
    week52High: 1684.68,
    week52Low: 1419.60,
    status: 'OPEN',
    tradingHours: '06:30 - 14:30 IST',
    impactOnIndia: 'NEUTRAL',
    impactReason: 'Ringgit strength stabilizing emerging market currencies',
    lastTickDir: 'up',
  },
  {
    id: 'psei_composite',
    name: 'PSEi COMPOSITE',
    country: 'Philippines',
    flag: '🇵🇭',
    region: 'Asia',
    currency: 'PHP',
    ltp: 7411.20,
    change: 35.40,
    pChange: 0.48,
    open: 7380.00,
    high: 7430.00,
    low: 7370.00,
    prevClose: 7375.80,
    week52High: 7480.00,
    week52Low: 5920.00,
    status: 'OPEN',
    tradingHours: '07:00 - 12:30 IST',
    impactOnIndia: 'NEUTRAL',
    impactReason: 'Local central bank dovish rate cut stance',
    lastTickDir: 'up',
  },

  // --- 2. US & Americas Markets ---
  {
    id: 'dow_jones',
    name: 'DOW JONES (DJIA)',
    country: 'United States',
    flag: '🇺🇸',
    region: 'Americas',
    currency: 'USD',
    ltp: 42175.11,
    change: 260.36,
    pChange: 0.62,
    open: 41980.00,
    high: 42250.00,
    low: 41920.00,
    prevClose: 41914.75,
    week52High: 42418.36,
    week52Low: 32327.42,
    status: 'CLOSED',
    tradingHours: '19:00 - 01:30 IST',
    impactOnIndia: 'BULLISH',
    impactReason: 'Fresh all-time high close on Wall Street provides solid tailwind for Indian cyclicals',
    lastTickDir: 'up',
  },
  {
    id: 'sp_500',
    name: 'S&P 500',
    country: 'United States',
    flag: '🇺🇸',
    region: 'Americas',
    currency: 'USD',
    ltp: 5745.37,
    change: 23.11,
    pChange: 0.40,
    open: 5730.00,
    high: 5760.00,
    low: 5720.00,
    prevClose: 5722.26,
    week52High: 5767.37,
    week52Low: 4103.78,
    status: 'CLOSED',
    tradingHours: '19:00 - 01:30 IST',
    impactOnIndia: 'BULLISH',
    impactReason: 'Broad market expansion beyond MegaCap tech indicates healthy macroeconomic soft landing',
    lastTickDir: 'up',
  },
  {
    id: 'nasdaq_100',
    name: 'NASDAQ 100',
    country: 'United States',
    flag: '🇺🇸',
    region: 'Americas',
    currency: 'USD',
    ltp: 20116.20,
    change: 120.40,
    pChange: 0.60,
    open: 20010.00,
    high: 20180.00,
    low: 19980.00,
    prevClose: 19995.80,
    week52High: 20690.97,
    week52Low: 14058.31,
    status: 'CLOSED',
    tradingHours: '19:00 - 01:30 IST',
    impactOnIndia: 'BULLISH',
    impactReason: 'Positive momentum in Nvidia, Microsoft, Apple lifts NIFTY IT companies',
    lastTickDir: 'up',
  },
  {
    id: 'nasdaq_composite',
    name: 'NASDAQ COMPOSITE',
    country: 'United States',
    flag: '🇺🇸',
    region: 'Americas',
    currency: 'USD',
    ltp: 18190.29,
    change: 108.09,
    pChange: 0.60,
    open: 18100.00,
    high: 18240.00,
    low: 18070.00,
    prevClose: 18082.20,
    week52High: 18671.07,
    week52Low: 12543.86,
    status: 'CLOSED',
    tradingHours: '19:00 - 01:30 IST',
    impactOnIndia: 'BULLISH',
    impactReason: 'Growth & innovation stocks rallying on Fed rate cut roadmap',
    lastTickDir: 'up',
  },
  {
    id: 'russell_2000',
    name: 'RUSSELL 2000',
    country: 'United States',
    flag: '🇺🇸',
    region: 'Americas',
    currency: 'USD',
    ltp: 2221.15,
    change: 13.50,
    pChange: 0.61,
    open: 2210.00,
    high: 2230.00,
    low: 2205.00,
    prevClose: 2207.65,
    week52High: 2299.16,
    week52Low: 1633.67,
    status: 'CLOSED',
    tradingHours: '19:00 - 01:30 IST',
    impactOnIndia: 'BULLISH',
    impactReason: 'Smallcap risk appetite surging, positive for Indian Mid & Smallcap indices',
    lastTickDir: 'up',
  },
  {
    id: 'cboe_vix',
    name: 'CBOE VIX (Volatility)',
    country: 'United States',
    flag: '🇺🇸',
    region: 'Americas',
    currency: 'Points',
    ltp: 15.37,
    change: -0.85,
    pChange: -5.24,
    open: 16.10,
    high: 16.45,
    low: 15.20,
    prevClose: 16.22,
    week52High: 65.73,
    week52Low: 11.52,
    status: 'CLOSED',
    tradingHours: '19:00 - 01:30 IST',
    impactOnIndia: 'BULLISH',
    impactReason: 'Sub-16 VIX reading indicates complacency and absent systemic fear in global equities',
    lastTickDir: 'down',
  },
  {
    id: 'tsx_composite',
    name: 'S&P/TSX COMPOSITE',
    country: 'Canada',
    flag: '🇨🇦',
    region: 'Americas',
    currency: 'CAD',
    ltp: 23989.50,
    change: 95.20,
    pChange: 0.40,
    open: 23900.00,
    high: 24020.00,
    low: 23880.00,
    prevClose: 23894.30,
    week52High: 24050.00,
    week52Low: 18690.00,
    status: 'CLOSED',
    tradingHours: '19:00 - 01:30 IST',
    impactOnIndia: 'NEUTRAL',
    impactReason: 'Mining and natural resource shares trading near records',
    lastTickDir: 'up',
  },
  {
    id: 'bovespa',
    name: 'IBOVESPA',
    country: 'Brazil',
    flag: '🇧🇷',
    region: 'Americas',
    currency: 'BRL',
    ltp: 133010.20,
    change: 1240.50,
    pChange: 0.94,
    open: 131900.00,
    high: 133400.00,
    low: 131800.00,
    prevClose: 131769.70,
    week52High: 137469.00,
    week52Low: 111300.00,
    status: 'CLOSED',
    tradingHours: '18:30 - 01:30 IST',
    impactOnIndia: 'BULLISH',
    impactReason: 'Emerging market inflows strengthening Latin American and Asian equities alike',
    lastTickDir: 'up',
  },

  // --- 3. European Markets ---
  {
    id: 'ftse_100',
    name: 'FTSE 100',
    country: 'United Kingdom',
    flag: '🇬🇧',
    region: 'Europe',
    currency: 'GBP',
    ltp: 8284.91,
    change: 22.82,
    pChange: 0.28,
    open: 8265.00,
    high: 8310.00,
    low: 8250.00,
    prevClose: 8262.09,
    week52High: 8474.41,
    week52Low: 7257.64,
    status: 'OPEN',
    tradingHours: '12:30 - 21:00 IST',
    impactOnIndia: 'NEUTRAL',
    impactReason: 'Moderate positive tone in London bluechips, stabilizing currency cross GBP/INR',
    lastTickDir: 'up',
  },
  {
    id: 'dax_40',
    name: 'DAX 40',
    country: 'Germany',
    flag: '🇩🇪',
    region: 'Europe',
    currency: 'EUR',
    ltp: 19238.09,
    change: 126.15,
    pChange: 0.66,
    open: 19150.00,
    high: 19280.00,
    low: 19120.00,
    prevClose: 19111.94,
    week52High: 19285.20,
    week52Low: 14630.21,
    status: 'OPEN',
    tradingHours: '12:30 - 21:00 IST',
    impactOnIndia: 'BULLISH',
    impactReason: 'Record highs in German industrial and enterprise software companies (SAP, Siemens)',
    lastTickDir: 'up',
  },
  {
    id: 'cac_40',
    name: 'CAC 40',
    country: 'France',
    flag: '🇫🇷',
    region: 'Europe',
    currency: 'EUR',
    ltp: 7742.09,
    change: 78.43,
    pChange: 1.02,
    open: 7680.00,
    high: 7770.00,
    low: 7670.00,
    prevClose: 7663.66,
    week52High: 8259.19,
    week52Low: 6773.82,
    status: 'OPEN',
    tradingHours: '12:30 - 21:00 IST',
    impactOnIndia: 'BULLISH',
    impactReason: 'Luxury and aerospace rebound in Paris post-Chinese stimulus announcements',
    lastTickDir: 'up',
  },
  {
    id: 'euro_stoxx_50',
    name: 'EURO STOXX 50',
    country: 'Eurozone',
    flag: '🇪🇺',
    region: 'Europe',
    currency: 'EUR',
    ltp: 5032.55,
    change: 51.20,
    pChange: 1.03,
    open: 4990.00,
    high: 5050.00,
    low: 4980.00,
    prevClose: 4981.35,
    week52High: 5121.71,
    week52Low: 3993.41,
    status: 'OPEN',
    tradingHours: '12:30 - 21:00 IST',
    impactOnIndia: 'BULLISH',
    impactReason: 'Broad Eurozone index breaks above 5,000 psychological milestone',
    lastTickDir: 'up',
  },
  {
    id: 'smi_switzerland',
    name: 'SMI (Swiss Market)',
    country: 'Switzerland',
    flag: '🇨🇭',
    region: 'Europe',
    currency: 'CHF',
    ltp: 12180.40,
    change: 45.10,
    pChange: 0.37,
    open: 12140.00,
    high: 12210.00,
    low: 12120.00,
    prevClose: 12135.30,
    week52High: 12450.00,
    week52Low: 10250.00,
    status: 'OPEN',
    tradingHours: '12:30 - 21:00 IST',
    impactOnIndia: 'NEUTRAL',
    impactReason: 'Defensive healthcare & pharma holdings (Roche, Novartis) holding steady',
    lastTickDir: 'up',
  },
  {
    id: 'ibex_35',
    name: 'IBEX 35',
    country: 'Spain',
    flag: '🇪🇸',
    region: 'Europe',
    currency: 'EUR',
    ltp: 11870.20,
    change: 72.30,
    pChange: 0.61,
    open: 11810.00,
    high: 11910.00,
    low: 11790.00,
    prevClose: 11797.90,
    week52High: 11950.00,
    week52Low: 8870.00,
    status: 'OPEN',
    tradingHours: '12:30 - 21:00 IST',
    impactOnIndia: 'NEUTRAL',
    impactReason: 'Spanish retail banks showing resilience amidst ECB interest rate cycle',
    lastTickDir: 'up',
  },
  {
    id: 'ftse_mib',
    name: 'FTSE MIB',
    country: 'Italy',
    flag: '🇮🇹',
    region: 'Europe',
    currency: 'EUR',
    ltp: 34420.80,
    change: 210.50,
    pChange: 0.61,
    open: 34250.00,
    high: 34550.00,
    low: 34200.00,
    prevClose: 34210.30,
    week52High: 35430.00,
    week52Low: 26800.00,
    status: 'OPEN',
    tradingHours: '12:30 - 21:00 IST',
    impactOnIndia: 'NEUTRAL',
    impactReason: 'Milan exchange firming with financial services expansion',
    lastTickDir: 'up',
  },

  // --- 4. Macro Cues & Commodities (Crucial for Indian F&O Traders) ---
  {
    id: 'dollar_index',
    name: 'US DOLLAR INDEX (DXY)',
    country: 'United States',
    flag: '💵',
    region: 'Macro & Commodities',
    currency: 'Points',
    ltp: 100.42,
    change: -0.15,
    pChange: -0.15,
    open: 100.58,
    high: 100.70,
    low: 100.35,
    prevClose: 100.57,
    week52High: 107.35,
    week52Low: 100.15,
    status: 'OPEN',
    tradingHours: '24 Hours / Live',
    impactOnIndia: 'BULLISH',
    impactReason: 'Softening Dollar Index prompts foreign institutional investors (FII) to allocate into Emerging Markets like India',
    lastTickDir: 'down',
  },
  {
    id: 'brent_crude',
    name: 'BRENT CRUDE OIL ($/bbl)',
    country: 'Global Commodity',
    flag: '🛢️',
    region: 'Macro & Commodities',
    currency: 'USD',
    ltp: 74.49,
    change: -0.68,
    pChange: -0.91,
    open: 75.10,
    high: 75.60,
    low: 74.20,
    prevClose: 75.17,
    week52High: 96.50,
    week52Low: 69.28,
    status: 'OPEN',
    tradingHours: '24 Hours / Live',
    impactOnIndia: 'BULLISH',
    impactReason: 'Lower Brent crude reduces India import bill, curbing inflation and boosting Paints, OMCs & Airlines',
    lastTickDir: 'down',
  },
  {
    id: 'wti_crude',
    name: 'WTI CRUDE OIL ($/bbl)',
    country: 'United States',
    flag: '🛢️',
    region: 'Macro & Commodities',
    currency: 'USD',
    ltp: 70.82,
    change: -0.74,
    pChange: -1.03,
    open: 71.55,
    high: 72.10,
    low: 70.50,
    prevClose: 71.56,
    week52High: 93.98,
    week52Low: 65.27,
    status: 'OPEN',
    tradingHours: '24 Hours / Live',
    impactOnIndia: 'BULLISH',
    impactReason: 'US inventory build easing domestic fuel refining margins pressure',
    lastTickDir: 'down',
  },
  {
    id: 'us_10y_yield',
    name: 'US 10-YEAR BOND YIELD (%)',
    country: 'United States',
    flag: '📈',
    region: 'Macro & Commodities',
    currency: '%',
    ltp: 3.75,
    change: -0.04,
    pChange: -1.05,
    open: 3.79,
    high: 3.81,
    low: 3.74,
    prevClose: 3.79,
    week52High: 5.02,
    week52Low: 3.60,
    status: 'OPEN',
    tradingHours: '24 Hours / Live',
    impactOnIndia: 'BULLISH',
    impactReason: 'Yield compression lowers borrowing costs for corporate debt and fuels equity valuations globally',
    lastTickDir: 'down',
  },
  {
    id: 'gold_spot',
    name: 'GOLD SPOT (XAU/USD)',
    country: 'Global Commodity',
    flag: '🪙',
    region: 'Macro & Commodities',
    currency: 'USD',
    ltp: 2658.20,
    change: 14.50,
    pChange: 0.55,
    open: 2642.00,
    high: 2670.00,
    low: 2638.00,
    prevClose: 2643.70,
    week52High: 2685.50,
    week52Low: 1810.20,
    status: 'OPEN',
    tradingHours: '24 Hours / Live',
    impactOnIndia: 'NEUTRAL',
    impactReason: 'Safe haven gold trading near record highs, steady physical demand during Indian festival season',
    lastTickDir: 'up',
  },
  {
    id: 'silver_spot',
    name: 'SILVER SPOT (XAG/USD)',
    country: 'Global Commodity',
    flag: '🥈',
    region: 'Macro & Commodities',
    currency: 'USD',
    ltp: 32.08,
    change: 0.42,
    pChange: 1.33,
    open: 31.65,
    high: 32.30,
    low: 31.50,
    prevClose: 31.66,
    week52High: 32.70,
    week52Low: 20.69,
    status: 'OPEN',
    tradingHours: '24 Hours / Live',
    impactOnIndia: 'BULLISH',
    impactReason: 'Industrial silver demand for solar PV and electric vehicles expanding rapidly',
    lastTickDir: 'up',
  },
];

export interface GlobalSentimentSummary {
  sentimentScore: number; // 0 - 100
  sentimentLabel: 'STRONG BULLISH' | 'BULLISH' | 'NEUTRAL' | 'BEARISH';
  projectedNiftyGap: string;
  advances: number;
  declines: number;
  unchanged: number;
  giftNiftyDiff: number;
  giftNiftyPChange: number;
  usMarketsAvgPChange: number;
  asianMarketsAvgPChange: number;
  europeanMarketsAvgPChange: number;
}

class GlobalIndicesService {
  private indices: GlobalIndexRecord[] = [...DHAN_GLOBAL_INDICES];
  private subscribers: Array<(indices: GlobalIndexRecord[]) => void> = [];
  private tickTimer: any = null;

  constructor() {
    this.startStreaming();
  }

  public getIndices(): GlobalIndexRecord[] {
    return [...this.indices];
  }

  public getIndexById(id: string): GlobalIndexRecord | undefined {
    return this.indices.find((i) => i.id === id);
  }

  public subscribe(callback: (indices: GlobalIndexRecord[]) => void): () => void {
    this.subscribers.push(callback);
    callback(this.indices);
    return () => {
      this.subscribers = this.subscribers.filter((cb) => cb !== callback);
    };
  }

  private notify() {
    this.subscribers.forEach((cb) => cb(this.indices));
  }

  private startStreaming() {
    this.tickTimer = setInterval(() => {
      // Pick random index to tick
      const idx = Math.floor(Math.random() * this.indices.length);
      const item = this.indices[idx];
      if (!item) return;

      // Realistic tick delta based on price scale
      let deltaPercent = (Math.random() * 0.08 - 0.04);
      if (item.id === 'gift_nifty') {
        deltaPercent = (Math.random() * 0.06 - 0.03);
      }

      const delta = +(item.ltp * (deltaPercent / 100)).toFixed(2);
      if (Math.abs(delta) > 0.001) {
        item.ltp = +(item.ltp + delta).toFixed(2);
        item.change = +(item.ltp - item.prevClose).toFixed(2);
        item.pChange = +(((item.change) / item.prevClose) * 100).toFixed(2);
        item.lastTickDir = delta > 0 ? 'up' : 'down';

        if (item.ltp > item.high) item.high = item.ltp;
        if (item.ltp < item.low) item.low = item.ltp;
        if (item.ltp > item.week52High) item.week52High = item.ltp;
        if (item.ltp < item.week52Low) item.week52Low = item.ltp;

        this.notify();
      }
    }, 1200);
  }

  public computeSentimentSummary(): GlobalSentimentSummary {
    const list = this.indices;
    const advances = list.filter((i) => i.change > 0).length;
    const declines = list.filter((i) => i.change < 0).length;
    const unchanged = list.filter((i) => i.change === 0).length;

    const gift = list.find((i) => i.id === 'gift_nifty');
    const giftDiff = gift ? gift.change : 68.5;
    const giftPChange = gift ? gift.pChange : 0.27;

    const usIndices = list.filter((i) => i.region === 'Americas' && i.id !== 'cboe_vix');
    const usAvg = usIndices.length
      ? usIndices.reduce((acc, curr) => acc + curr.pChange, 0) / usIndices.length
      : 0.5;

    const asianIndices = list.filter((i) => i.region === 'Asia');
    const asianAvg = asianIndices.length
      ? asianIndices.reduce((acc, curr) => acc + curr.pChange, 0) / asianIndices.length
      : 1.2;

    const euroIndices = list.filter((i) => i.region === 'Europe');
    const euroAvg = euroIndices.length
      ? euroIndices.reduce((acc, curr) => acc + curr.pChange, 0) / euroIndices.length
      : 0.6;

    // Weight score: US 40%, Asia 35%, Euro 15%, Advances ratio 10%
    const advRatio = advances / (list.length || 1);
    let rawScore = 50 + (giftPChange * 40) + (usAvg * 20) + (asianAvg * 15) + (advRatio * 20);
    rawScore = Math.max(10, Math.min(95, rawScore));

    let label: 'STRONG BULLISH' | 'BULLISH' | 'NEUTRAL' | 'BEARISH' = 'BULLISH';
    if (rawScore > 75) label = 'STRONG BULLISH';
    else if (rawScore >= 55) label = 'BULLISH';
    else if (rawScore >= 45) label = 'NEUTRAL';
    else label = 'BEARISH';

    const projectedPoints = Math.round(giftDiff * 0.95);
    const sign = projectedPoints > 0 ? '+' : '';
    const projectedNiftyGap = `${sign}${projectedPoints} pts (${sign}${giftPChange.toFixed(2)}%)`;

    return {
      sentimentScore: Math.round(rawScore),
      sentimentLabel: label,
      projectedNiftyGap,
      advances,
      declines,
      unchanged,
      giftNiftyDiff: giftDiff,
      giftNiftyPChange: giftPChange,
      usMarketsAvgPChange: +usAvg.toFixed(2),
      asianMarketsAvgPChange: +asianAvg.toFixed(2),
      europeanMarketsAvgPChange: +euroAvg.toFixed(2),
    };
  }

  public exportCSV(): string {
    const headers = [
      'Index Name',
      'Country',
      'Region',
      'Currency',
      'LTP',
      'Change',
      'Change(%)',
      'Open',
      'High',
      'Low',
      'Prev. Close',
      '52W High',
      '52W Low',
      'Status',
      'Trading Hours (IST)',
      'Impact on Indian Market',
      'Analysis & Reason',
    ];

    const rows = this.indices.map((idx) => [
      `"${idx.name}"`,
      `"${idx.country}"`,
      `"${idx.region}"`,
      `"${idx.currency}"`,
      idx.ltp.toFixed(2),
      idx.change.toFixed(2),
      `"${idx.pChange >= 0 ? '+' : ''}${idx.pChange.toFixed(2)}%"`,
      idx.open.toFixed(2),
      idx.high.toFixed(2),
      idx.low.toFixed(2),
      idx.prevClose.toFixed(2),
      idx.week52High.toFixed(2),
      idx.week52Low.toFixed(2),
      `"${idx.status}"`,
      `"${idx.tradingHours}"`,
      `"${idx.impactOnIndia}"`,
      `"${idx.impactReason.replace(/"/g, '""')}"`,
    ]);

    return [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
  }

  public destroy() {
    if (this.tickTimer) clearInterval(this.tickTimer);
  }
}

export const globalIndicesService = new GlobalIndicesService();
