/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useCallback } from 'react';
import {
  AlertItem,
  IndexMarketData,
  IndexSymbol,
  OptionContractData,
  OptionType,
  StrategyLeg,
  StrikeRow,
  SystemBroadcast,
  UserRole,
  WatchlistItem,
} from './types';
import { marketFeed } from './services/marketFeed';
import { soundEngine } from './utils/audioAlert';
import { calculateMaxPain } from './utils/optionsAnalytics';

// Layout & UI components
import { TopTicker, IndexTickerBar } from './components/layout/TopTicker';
import { Navigation, ActiveTab } from './components/layout/Navigation';
import { OptionChainTable } from './components/chain/OptionChainTable';
import { AnalyticsDashboard } from './components/analytics/AnalyticsDashboard';
import { TradingViewChart } from './components/charts/TradingViewChart';
import { StrategyBuilder } from './components/strategy/StrategyBuilder';
import { AllParticipantsDashboard } from './components/participants/AllParticipantsDashboard';
import { EodDerivativesDashboard } from './components/eod/EodDerivativesDashboard';
import { AllStocksDashboard } from './components/stocks/AllStocksDashboard';
import { AllIndicesView } from './components/stocks/AllIndicesView';
import { StrategyScanner } from './components/scanner/StrategyScanner';
import { AlertSystem } from './components/alerts/AlertSystem';
import { NewsDashboard } from './components/news/NewsDashboard';
import { CalendarDashboard } from './components/calendar/CalendarDashboard';
import { AdminPanel } from './components/admin/AdminPanel';
import { RoleGateModal } from './components/ui/RoleGateModal';

import {
  AlertTriangle,
  CheckCircle,
  Download,
  FileText,
  Info,
  LogIn,
  Settings,
  Shield,
  User,
  X,
} from 'lucide-react';

export default function App() {
  // User & Session state
  const [userRole, setUserRole] = useState<UserRole>('PREMIUM');
  const [activeTab, setActiveTab] = useState<ActiveTab>('chain');
  const [isSidebarHidden, setIsSidebarHidden] = useState<boolean>(false);

  // Market Feed State
  const [indices, setIndices] = useState<Record<IndexSymbol, IndexMarketData>>(
    marketFeed.getIndices()
  );
  const [activeSymbol, setActiveSymbol] = useState<IndexSymbol>('NIFTY');
  const [activeExpiry, setActiveExpiry] = useState<string>('01 OCT 2026');
  const [strikes, setStrikes] = useState<StrikeRow[]>(marketFeed.getCurrentChain());
  const [latencyMs, setLatencyMs] = useState<number>(14);
  const [packetsReceived, setPacketsReceived] = useState<number>(0);
  const [isAutoUpdating, setIsAutoUpdating] = useState<boolean>(true);

  const [strikeRange, setStrikeRange] = useState<number>(10); // default ±10 strikes
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [soundEnabled, setSoundEnabled] = useState<boolean>(true);

  // Institutional Light Theme by default
  const [theme, setTheme] = useState<'dark' | 'light'>(() => {
    return (localStorage.getItem('ds_institutional_theme') as 'dark' | 'light') || 'light';
  });

  useEffect(() => {
    const root = document.documentElement;
    const body = document.body;
    if (theme === 'light') {
      root.classList.remove('dark');
      root.classList.add('light');
      body.classList.remove('dark');
      body.classList.add('light');
      root.setAttribute('data-theme', 'light');
      body.setAttribute('data-theme', 'light');
    } else {
      root.classList.remove('light');
      root.classList.add('dark');
      body.classList.remove('light');
      body.classList.add('dark');
      root.setAttribute('data-theme', 'dark');
      body.setAttribute('data-theme', 'dark');
    }
    localStorage.setItem('ds_institutional_theme', theme);
  }, [theme]);

  // Strategy Builder State
  const [strategyLegs, setStrategyLegs] = useState<StrategyLeg[]>([]);

  // Watchlist State
  const [watchlist, setWatchlist] = useState<WatchlistItem[]>([
    {
      id: 'wl_1',
      symbol: 'NIFTY',
      expiry: '01 OCT 2026',
      strike: 25000,
      type: 'CE',
      addedAt: 'Today',
      targetPrice: 180,
      stopLoss: 65,
    },
    {
      id: 'wl_2',
      symbol: 'NIFTY',
      expiry: '01 OCT 2026',
      strike: 24700,
      type: 'PE',
      addedAt: 'Today',
      targetPrice: 220,
      stopLoss: 75,
    },
  ]);

  // Alerts State
  const [alerts, setAlerts] = useState<AlertItem[]>([
    {
      id: 'alt_1',
      type: 'PRICE',
      symbol: 'NIFTY',
      condition: 'ABOVE',
      threshold: 24900,
      createdAt: '09:30 AM',
      active: true,
      triggered: false,
      telegramEnabled: true,
      note: 'NIFTY 24900 breakout watch',
    },
    {
      id: 'alt_2',
      type: 'PCR',
      symbol: 'NIFTY',
      condition: 'ABOVE',
      threshold: 1.30,
      createdAt: '09:45 AM',
      active: true,
      triggered: false,
      telegramEnabled: true,
      note: 'Overbought PCR reversal watch',
    },
  ]);

  // System Broadcast
  const [broadcast, setBroadcast] = useState<SystemBroadcast | null>(null);

  // Role Gate Modal State
  const [roleModalOpen, setRoleModalOpen] = useState<boolean>(false);
  const [roleModalFeature, setRoleModalFeature] = useState<string>('');

  // Institutional Modals (Profile, Reports, Settings, Login)
  const [activeModal, setActiveModal] = useState<'profile' | 'settings' | 'reports' | 'login' | null>(null);
  const [brokerId, setBrokerId] = useState<string>('DS-INST-9042');
  const [brokerConnected, setBrokerConnected] = useState<boolean>(true);

  // Start & subscribe to real-time market data feed
  useEffect(() => {
    marketFeed.start();

    const unsubscribe = marketFeed.subscribe((state) => {
      setIndices({ ...state.indices });
      setStrikes([...state.currentChain]);
      setLatencyMs(state.latencyMs);
      setPacketsReceived(state.packetsReceived);

      const currentSpot = state.indices[activeSymbol]?.spotPrice;
      if (currentSpot) {
        setAlerts((prevAlerts) =>
          prevAlerts.map((alt) => {
            if (!alt.active || alt.triggered) return alt;
            if (alt.type === 'PRICE' && alt.symbol === activeSymbol) {
              const conditionMet =
                (alt.condition === 'ABOVE' && currentSpot >= alt.threshold) ||
                (alt.condition === 'BELOW' && currentSpot <= alt.threshold);

              if (conditionMet) {
                soundEngine.playAlertSound();
                return {
                  ...alt,
                  triggered: true,
                  triggeredAt: new Date().toLocaleTimeString(),
                };
              }
            }
            return alt;
          })
        );
      }
    });

    return () => {
      unsubscribe();
      marketFeed.stop();
    };
  }, [activeSymbol]);

  const handleToggleAutoUpdate = useCallback(() => {
    if (isAutoUpdating) {
      marketFeed.stop();
      setIsAutoUpdating(false);
    } else {
      marketFeed.start();
      setIsAutoUpdating(true);
    }
  }, [isAutoUpdating]);

  const handleSelectSymbol = useCallback((symbol: IndexSymbol) => {
    setActiveSymbol(symbol);
    marketFeed.setActiveSymbol(symbol);
    setActiveExpiry(marketFeed.getActiveExpiry());
    soundEngine.playClickSound();
  }, []);

  const handleSelectExpiry = useCallback((expiry: string) => {
    setActiveExpiry(expiry);
    marketFeed.setActiveExpiry(expiry);
    soundEngine.playClickSound();
  }, []);

  const handleTabChange = (tab: ActiveTab) => {
    if (userRole === 'RETAIL' && tab === 'strategy') {
      setRoleModalFeature('Strategy Builder, Max Pain & Live Scanner');
      setRoleModalOpen(true);
      return;
    }
    setActiveTab(tab);
    soundEngine.playClickSound();
  };

  const handleToggleSound = () => {
    const next = !soundEnabled;
    setSoundEnabled(next);
    soundEngine.enabled = next;
  };

  const handleAddLegToStrategy = (
    type: OptionType,
    action: 'BUY' | 'SELL',
    strike: number,
    price: number,
    iv: number,
    greeks: OptionContractData['greeks']
  ) => {
    if (userRole === 'RETAIL') {
      setRoleModalFeature('Multi-Leg Strategy Simulator');
      setRoleModalOpen(true);
      return;
    }
    const currentIndex = indices[activeSymbol];
    const newLeg: StrategyLeg = {
      id: `leg_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      type,
      action,
      strike,
      lots: 1,
      lotSize: currentIndex.lotSize,
      price,
      iv,
      greeks,
    };
    setStrategyLegs((prev) => [...prev, newLeg]);
    setActiveTab('strategy');
    soundEngine.playClickSound();
  };

  const handleAddToWatchlist = (strike: number, type: OptionType) => {
    const exists = watchlist.some(
      (w) => w.symbol === activeSymbol && w.strike === strike && w.type === type
    );
    if (exists) return;

    const newItem: WatchlistItem = {
      id: `wl_${Date.now()}`,
      symbol: activeSymbol,
      expiry: activeExpiry,
      strike,
      type,
      addedAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };
    setWatchlist((prev) => [newItem, ...prev]);
    soundEngine.playClickSound();
  };

  const handleCreateQuickAlert = (strike: number, type: OptionType, price: number) => {
    const target = Number((price * 1.1).toFixed(1));
    const newAlert: AlertItem = {
      id: `alt_${Date.now()}`,
      type: 'PRICE',
      symbol: activeSymbol,
      strike,
      optionType: type,
      condition: 'ABOVE',
      threshold: target,
      createdAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      active: true,
      triggered: false,
      telegramEnabled: true,
      note: `${activeSymbol} ${strike} ${type} +10% spike alert`,
    };
    setAlerts((prev) => [newAlert, ...prev]);
    setActiveTab('alerts');
    soundEngine.playAlertSound();
  };

  const currentIndex = indices[activeSymbol] || indices.NIFTY;
  const maxPainData = calculateMaxPain(strikes, currentIndex.lotSize);
  const pendingAlertsCount = alerts.filter((a) => a.active && !a.triggered).length;

  return (
    <div
      className={`flex flex-col h-screen w-screen overflow-hidden ${
        theme === 'light'
          ? 'light-theme bg-[#F8FAFC] text-[#0F172A]'
          : 'dark-theme bg-[#080b11] text-slate-100'
      }`}
    >
      {/* System Broadcast Banner */}
      {broadcast && broadcast.active && (
        <div
          className={`px-4 py-2 flex items-center justify-between text-xs font-medium border-b ${
            broadcast.level === 'CRITICAL'
              ? 'bg-[#FEE2E2] border-[#FECACA] text-[#991B1B]'
              : broadcast.level === 'WARNING'
              ? 'bg-[#FEF3C7] border-[#FDE68A] text-[#92400E]'
              : 'bg-[#EFF6FF] border-[#BFDBFE] text-[#1E40AF]'
          }`}
        >
          <div className="flex items-center gap-2">
            {broadcast.level === 'CRITICAL' ? (
              <AlertTriangle className="w-4 h-4 text-[#DC2626]" />
            ) : broadcast.level === 'WARNING' ? (
              <Info className="w-4 h-4 text-[#F59E0B]" />
            ) : (
              <CheckCircle className="w-4 h-4 text-[#2563EB]" />
            )}
            <span className="uppercase font-semibold tracking-wider text-[10px] px-1.5 py-0.5 rounded bg-white/80">
              {broadcast.title || 'SYSTEM DESK NOTICE'}
            </span>
            <span>{broadcast.message}</span>
            <span className="text-[10px] opacity-70">({broadcast.timestamp})</span>
          </div>
          <button
            onClick={() => setBroadcast(null)}
            className="text-current opacity-70 hover:opacity-100"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* 1. Institutional Header Bar */}
      <TopTicker
        indices={indices}
        activeSymbol={activeSymbol}
        onSelectSymbol={handleSelectSymbol}
        onOpenIndices={() => setActiveTab('indices')}
        onOpenAlerts={() => setActiveTab('alerts')}
        onOpenModal={(m) => setActiveModal(m)}
        pendingAlertsCount={pendingAlertsCount}
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
        latencyMs={latencyMs}
        packetsReceived={packetsReceived}
        userRole={userRole}
        onRoleChange={(r) => {
          setUserRole(r);
          if (r !== 'ADMIN' && activeTab === 'admin') {
            setActiveTab('chain');
          }
        }}
        theme={theme}
        onThemeChange={setTheme}
        isSidebarHidden={isSidebarHidden}
        onToggleSidebar={() => setIsSidebarHidden((prev) => !prev)}
      />

      {/* 2. Main Institutional Workspace (Sidebar + Right Column with Top Ticker & Content) */}
      <div className="flex-1 min-h-0 flex flex-col lg:flex-row overflow-hidden bg-[#F8FAFC]">
        {/* Modern Institutional Sidebar (Desktop Left / Mobile Top) */}
        <Navigation
          activeTab={activeTab}
          onTabChange={handleTabChange}
          userRole={userRole}
          pendingAlertsCount={pendingAlertsCount}
          onOpenModal={(m) => setActiveModal(m)}
          isSidebarHidden={isSidebarHidden}
          onToggleSidebar={() => setIsSidebarHidden((prev) => !prev)}
        />

        {/* Dynamic Module Viewport (Starts from End of Sidebar) */}
        <main className="flex-1 min-h-0 overflow-hidden flex flex-col bg-[#F8FAFC]">
          {/* Top Index Ticker Bar starting from the end of the Sidebar */}
          <IndexTickerBar
            indices={indices}
            isSidebarHidden={isSidebarHidden}
            onToggleSidebar={() => setIsSidebarHidden((prev) => !prev)}
          />
          {activeTab === 'chain' && (
            <OptionChainTable
              strikes={strikes}
              currentIndex={currentIndex}
              activeSymbol={activeSymbol}
              onSelectSymbol={handleSelectSymbol}
              activeExpiry={activeExpiry}
              onSelectExpiry={handleSelectExpiry}
              strikeRange={strikeRange}
              onSelectStrikeRange={setStrikeRange}
              searchQuery={searchQuery}
              onSearchQueryChange={setSearchQuery}
              userRole={userRole}
              maxPainStrike={maxPainData.maxPainStrike}
              theme={theme}
              isAutoUpdating={isAutoUpdating}
              onToggleAutoUpdate={handleToggleAutoUpdate}
              soundEnabled={soundEnabled}
              onToggleSound={handleToggleSound}
              onAddLegToStrategy={handleAddLegToStrategy}
              onAddToWatchlist={handleAddToWatchlist}
              onCreateAlert={handleCreateQuickAlert}
            />
          )}

          {activeTab === 'analytics' && (
            <div className="flex-1 overflow-y-auto">
              <AnalyticsDashboard currentIndex={currentIndex} strikes={strikes} />
            </div>
          )}

          {activeTab === 'stocks' && <AllStocksDashboard />}

          {activeTab === 'indices' && (
            <div className="flex-1 overflow-y-auto bg-[#F8FAFC] p-3 sm:p-5">
              <AllIndicesView initialScope="GLOBAL" />
            </div>
          )}

          {activeTab === 'charts' && (
            <TradingViewChart
              currentIndex={currentIndex}
              maxPainStrike={maxPainData.maxPainStrike}
            />
          )}

          {activeTab === 'strategy' && (
            <StrategyBuilder
              currentIndex={currentIndex}
              strikes={strikes}
              legs={strategyLegs}
              onSetLegs={setStrategyLegs}
              userRole={userRole}
            />
          )}

          {activeTab === 'participants' && <AllParticipantsDashboard />}

          {(activeTab === 'eod' || activeTab === 'nse_participant_oi') && (
            <EodDerivativesDashboard
              activeSubTab={activeTab === 'nse_participant_oi' ? 'NSE_OI_DATA' : 'DASHBOARD'}
              onSubTabChange={(sub) =>
                setActiveTab(sub === 'NSE_OI_DATA' ? 'nse_participant_oi' : 'eod')
              }
            />
          )}

          {activeTab === 'scanner' && (
            <div className="flex-1 overflow-y-auto">
              <StrategyScanner
                userRole={userRole}
                onUpgradeRole={setUserRole}
                onSelectStrikeForStrategy={(_sym, strike, type) => {
                  const row = strikes.find((r) => r.strike === strike);
                  if (row) {
                    const contract = type === 'CE' ? row.call : row.put;
                    handleAddLegToStrategy(
                      type,
                      'BUY',
                      strike,
                      contract.ltp,
                      contract.iv,
                      contract.greeks
                    );
                  }
                }}
              />
            </div>
          )}

          {activeTab === 'alerts' && (
            <div className="flex-1 overflow-y-auto">
              <AlertSystem
                currentIndex={currentIndex}
                alerts={alerts}
                watchlist={watchlist}
                onAddAlert={(newAlert) => {
                  const item: AlertItem = {
                    ...newAlert,
                    id: `alt_${Date.now()}`,
                    createdAt: new Date().toLocaleTimeString([], {
                      hour: '2-digit',
                      minute: '2-digit',
                    }),
                    triggered: false,
                  };
                  setAlerts((prev) => [item, ...prev]);
                  soundEngine.playClickSound();
                }}
                onAddWatchlist={(newItem) => {
                  const wlItem: WatchlistItem = {
                    ...newItem,
                    id: `wl_${Date.now()}`,
                    addedAt: new Date().toLocaleTimeString([], {
                      hour: '2-digit',
                      minute: '2-digit',
                    }),
                  };
                  setWatchlist((prev) => [wlItem, ...prev]);
                  soundEngine.playClickSound();
                }}
                onDeleteAlert={(id: string) => {
                  setAlerts((prev) => prev.filter((a) => a.id !== id));
                }}
                onDeleteWatchlist={(id: string) => {
                  setWatchlist((prev) => prev.filter((w) => w.id !== id));
                }}
              />
            </div>
          )}

          {activeTab === 'news' && <NewsDashboard />}

          {activeTab === 'calendar' && <CalendarDashboard />}

          {activeTab === 'admin' && userRole === 'ADMIN' && (
            <div className="flex-1 overflow-y-auto">
              <AdminPanel
                userRole={userRole}
                broadcast={broadcast}
                onSetBroadcast={(b) => {
                  setBroadcast(b);
                  if (b) soundEngine.playAlertSound();
                }}
              />
            </div>
          )}
        </main>
      </div>

      {/* Role Upgrade Gate Modal */}
      <RoleGateModal
        isOpen={roleModalOpen}
        featureName={roleModalFeature}
        onClose={() => setRoleModalOpen(false)}
        onSelectRole={(role: UserRole) => {
          setUserRole(role);
          soundEngine.playClickSound();
        }}
      />

      {/* Institutional Modal: Profile, Reports, Settings, Login */}
      {activeModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-[2px] flex items-center justify-center p-4">
          <div className="bg-[#FFFFFF] border border-[#E2E8F0] rounded-[12px] w-full max-w-lg shadow-xl overflow-hidden text-xs">
            <div className="px-5 py-4 border-b border-[#E2E8F0] flex items-center justify-between bg-[#F8FAFC]">
              <div className="flex items-center gap-2.5">
                {activeModal === 'profile' && <User className="w-4 h-4 text-[#2563EB]" />}
                {activeModal === 'reports' && <FileText className="w-4 h-4 text-[#2563EB]" />}
                {activeModal === 'settings' && <Settings className="w-4 h-4 text-[#2563EB]" />}
                {activeModal === 'login' && <LogIn className="w-4 h-4 text-[#2563EB]" />}
                <h3 className="text-sm font-semibold text-[#0F172A]">
                  {activeModal === 'profile' && 'Institutional Trader Profile'}
                  {activeModal === 'reports' && 'Analytical & Risk Reports'}
                  {activeModal === 'settings' && 'Terminal Preferences & Feed Settings'}
                  {activeModal === 'login' && 'Broker API & Terminal Session'}
                </h3>
              </div>
              <button
                onClick={() => setActiveModal(null)}
                className="p-1 rounded-[8px] text-[#64748B] hover:text-[#0F172A] hover:bg-[#E2E8F0]/50"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-5 space-y-4">
              {activeModal === 'profile' && (
                <>
                  <div className="flex items-center gap-3.5 p-3.5 rounded-[12px] bg-[#F8FAFC] border border-[#E2E8F0]">
                    <div className="w-11 h-11 rounded-full bg-[#EFF6FF] border border-[#BFDBFE] text-[#2563EB] flex items-center justify-center font-semibold text-base">
                      TR
                    </div>
                    <div>
                      <div className="text-sm font-semibold text-[#0F172A]">
                        Institutional Derivatives Desk
                      </div>
                      <div className="text-xs text-[#475569]">
                        Desk ID: {brokerId} • Access Level: {userRole}
                      </div>
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <div className="p-3 rounded-[10px] border border-[#E2E8F0]">
                      <div className="text-[#64748B]">Exchange Segments</div>
                      <div className="font-semibold text-[#0F172A] mt-0.5">NSE F&amp;O, BSE F&amp;O, Cash</div>
                    </div>
                    <div className="p-3 rounded-[10px] border border-[#E2E8F0]">
                      <div className="text-[#64748B]">Feed Protocol</div>
                      <div className="font-semibold text-[#16A34A] mt-0.5">WebSocket Tick Stream (1s)</div>
                    </div>
                  </div>
                </>
              )}

              {activeModal === 'reports' && (
                <div className="space-y-2.5">
                  {[
                    {
                      title: 'Daily Option Chain OI & PCR Summary',
                      desc: `${activeSymbol} (${activeExpiry}) • Max Pain ${maxPainData.maxPainStrike}`,
                    },
                    {
                      title: 'FII / DII / Pro Participant Positioning Report',
                      desc: 'End-of-day & intraday institutional index derivatives matrix',
                    },
                    {
                      title: 'Multi-Leg Strategy Risk & Greeks Audit',
                      desc: `${strategyLegs.length} active legs in simulator`,
                    },
                  ].map((rep, i) => (
                    <div
                      key={i}
                      className="p-3.5 rounded-[12px] border border-[#E2E8F0] hover:bg-[#F8FAFC] flex items-center justify-between"
                    >
                      <div>
                        <div className="font-semibold text-[#0F172A]">{rep.title}</div>
                        <div className="text-[11px] text-[#64748B] mt-0.5">{rep.desc}</div>
                      </div>
                      <button
                        onClick={() => {
                          soundEngine.playClickSound();
                          setActiveModal(null);
                        }}
                        className="h-[38px] px-3 rounded-[10px] bg-[#2563EB] hover:bg-[#1D4ED8] text-white font-semibold flex items-center gap-1.5"
                      >
                        <Download className="w-3.5 h-3.5" />
                        <span>Export</span>
                      </button>
                    </div>
                  ))}
                </div>
              )}

              {activeModal === 'settings' && (
                <div className="space-y-3">
                  <div className="flex items-center justify-between p-3 rounded-[10px] border border-[#E2E8F0]">
                    <div>
                      <div className="font-semibold text-[#0F172A]">Real-Time 1s Stream</div>
                      <div className="text-[11px] text-[#64748B]">Automatic option chain &amp; equity tick updates</div>
                    </div>
                    <button
                      onClick={handleToggleAutoUpdate}
                      className={`h-[38px] px-3.5 rounded-[10px] font-semibold ${
                        isAutoUpdating
                          ? 'bg-[#16A34A] text-white'
                          : 'bg-[#F8FAFC] border border-[#E2E8F0] text-[#475569]'
                      }`}
                    >
                      {isAutoUpdating ? 'Enabled' : 'Paused'}
                    </button>
                  </div>
                  <div className="flex items-center justify-between p-3 rounded-[10px] border border-[#E2E8F0]">
                    <div>
                      <div className="font-semibold text-[#0F172A]">Audio Execution Alerts</div>
                      <div className="text-[11px] text-[#64748B]">Play sound on price &amp; PCR threshold triggers</div>
                    </div>
                    <button
                      onClick={handleToggleSound}
                      className={`h-[38px] px-3.5 rounded-[10px] font-semibold ${
                        soundEnabled
                          ? 'bg-[#2563EB] text-white'
                          : 'bg-[#F8FAFC] border border-[#E2E8F0] text-[#475569]'
                      }`}
                    >
                      {soundEnabled ? 'Active' : 'Muted'}
                    </button>
                  </div>
                </div>
              )}

              {activeModal === 'login' && (
                <div className="space-y-3">
                  <div>
                    <label className="block text-[#475569] font-medium mb-1">
                      Institutional Desk / Broker Client ID
                    </label>
                    <input
                      type="text"
                      value={brokerId}
                      onChange={(e) => setBrokerId(e.target.value)}
                      className="w-full h-[40px] px-3 rounded-[10px] border border-[#CBD5E1] text-[#0F172A]"
                    />
                  </div>
                  <div className="flex items-center justify-between p-3 rounded-[10px] bg-[#ECFDF5] border border-[#BBF7D0]">
                    <span className="text-[#166534] font-medium">
                      Status: {brokerConnected ? 'Connected to NSE/BSE Gateway' : 'Disconnected'}
                    </span>
                    <button
                      onClick={() => setBrokerConnected(!brokerConnected)}
                      className="px-3 py-1 rounded-[8px] bg-[#16A34A] text-white font-semibold"
                    >
                      {brokerConnected ? 'Reconnect' : 'Connect'}
                    </button>
                  </div>
                </div>
              )}
            </div>

            <div className="px-5 py-3 bg-[#F8FAFC] border-t border-[#E2E8F0] flex justify-end">
              <button
                onClick={() => setActiveModal(null)}
                className="h-[38px] px-4 rounded-[10px] bg-[#2563EB] hover:bg-[#1D4ED8] text-white font-semibold"
              >
                Done
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
